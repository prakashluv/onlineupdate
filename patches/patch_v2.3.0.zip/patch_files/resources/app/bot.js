const path = require('path');
const fs = require('fs');
const isPkg = typeof process.pkg !== 'undefined';
const isElectron = !!process.env.ELECTRON_RUNNING;

function resolveRootDir() {
    if (process.env.APP_DATA_DIR) return process.env.APP_DATA_DIR;
    if (isPkg || isElectron) {
        const appData = process.env.APPDATA || (process.platform === 'darwin' ? process.env.HOME + '/Library/Preferences' : process.env.HOME + '/.local/share');
        const drdData = path.join(appData, 'DRD-Property-Genius');
        if (!fs.existsSync(drdData)) fs.mkdirSync(drdData, { recursive: true });
        return drdData;
    }
    return __dirname;
}

const ROOT_DIR = resolveRootDir();

// ─── Startup Cleanup (Handle 'browser already running' error) ───
const SESSION_PATH = path.join(ROOT_DIR, '.wwebjs_auth', 'session-drd_bot_1');
if (fs.existsSync(SESSION_PATH)) {
    ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'lockfile'].forEach(file => {
        const lockPath = path.join(SESSION_PATH, file);
        if (fs.existsSync(lockPath)) {
            try { fs.unlinkSync(lockPath); console.log(`[CLEANUP] Removed stale lock: ${file}`); } catch(e) {}
        }
    });
}

require('dotenv').config({ path: path.join(__dirname, '.env') });

const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const xlsx = require('xlsx');
const { db } = require('./database');

console.log("-----------------------------------------");
console.log("   Initializing DRD Property Genius...   ");
console.log("   ROOT: " + ROOT_DIR);
console.log("-----------------------------------------");

// Global Error Handler for Standalone Stability
const BOT_START_TIME = new Date().toLocaleString('en-IN');

const logError = (type, err) => {
    const errorMsg = `\n[${type}] ${new Date().toISOString()}\nStack: ${err.stack || err}\n`;
    const crashFile = path.join(ROOT_DIR, 'CRASH_REPORT_BOT.txt');
    try {
        fs.appendFileSync(crashFile, errorMsg);
    } catch (e) {
        console.error("Failed to write to crash log:", e);
    }
    console.error(errorMsg);
    if (type === 'CRASH') process.exit(1);
};

process.on('uncaughtException', (err) => logError('CRASH', err));
process.on('unhandledRejection', (reason) => logError('REJECTION', reason));

// Load dynamic paths from config
const BOT_PRESETS_PATH = path.join(ROOT_DIR, 'bot_config.json');

function getBasePath() {
    try {
        if (fs.existsSync(BOT_PRESETS_PATH)) {
            const cfg = JSON.parse(fs.readFileSync(BOT_PRESETS_PATH, 'utf8'));
            if (cfg.dataDir && fs.existsSync(cfg.dataDir)) return cfg.dataDir;
        }
    } catch (e) { }
    return ROOT_DIR;
}

const DATA_ROOT = getBasePath();
const MASTER_DB_PATH = path.join(DATA_ROOT, 'Master_Enterprise_DB.xlsx');
const EXCEL_PATH = path.join(DATA_ROOT, 'Plots_Data.xlsx');
const INQUIRIES_PATH = path.join(DATA_ROOT, 'Customer_Inquiries.xlsx');
const TRAINING_DATA_DIR = path.join(DATA_ROOT, 'training_data');
const CUSTOMER_DOCS_DIR = path.join(DATA_ROOT, 'customer_docs');
const IMAGES_DIR = path.join(ROOT_DIR, 'Layout_Images');
// ─── Bot Settings & Configuration ───
const BOT_CONFIG_PATH = path.join(ROOT_DIR, 'bot_settings.json');
let botSettings = {
    greeting_cooldown_ms: 1000 * 60 * 60 * 48,
    // Note: real admin numbers live in bot_settings.json (configured via Developer Hub → Bot Config).
    // These in-memory defaults are intentionally empty so we never accidentally message a stale number.
    admin_numbers: [],
    primary_admin: "",
    business_keywords: ["plot", "house", "cent", "price", "rate", "layout", "location", "details", "available", "sqft", "map", "brochure", "loan", "bank", "finance", "emi", "call", "time", "morning", "evening", "afternoon", "after", "before", " am", " pm", "visit", "site", "hi", "hello", "hai", "interested"],
    ai_mode: "online",
    system_prompt_file: "Greeting_Message.txt",
    visualizer_url: "https://drdrealtors.github.io/drd-layouts/",
    location_auto_share: true,
    // Conversation context (rolling memory) — configurable from dashboard
    read_previous_messages: true,    // always include recent chat in AI prompt
    memory_turns: 5,                 // exchanges to keep per phone (1 turn = 1 user + 1 bot msg)
    memory_ttl_minutes: 60,          // drop a session after this many minutes idle
    // Admin dispatch safety
    max_media_per_dispatch: 5        // hard cap on images sent per "share details to" command
};

// Helper: re-read bot_settings.json on demand (UI saves the file directly).
// Cheap to call — settings are small JSON. Always returns current on-disk values.
function getBotSettings() {
    try {
        if (fs.existsSync(BOT_CONFIG_PATH)) {
            const onDisk = JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
            return Object.assign({}, botSettings, onDisk);
        }
    } catch (e) { /* fall through to defaults */ }
    return botSettings;
}

const COMPANY_SETTINGS_FILE = path.join(ROOT_DIR, 'drd_company_settings.json');
let companySettings = {};

function loadCompanySettings() {
    try {
        if (fs.existsSync(COMPANY_SETTINGS_FILE)) {
            companySettings = JSON.parse(fs.readFileSync(COMPANY_SETTINGS_FILE, 'utf8'));
        }
    } catch (e) { }
}

function formatJid(phone) {
    if (!phone) return null;
    let clean = phone.toString().replace(/\D/g, '');
    if (clean.length === 10) clean = '91' + clean;
    return clean.includes('@') ? clean : clean + '@c.us';
}


function loadBotSettings() {
    try {
        if (fs.existsSync(BOT_CONFIG_PATH)) {
            const newSettings = JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
            botSettings = { ...botSettings, ...newSettings };
            console.log("OK: Bot settings loaded from JSON.");
        }
    } catch (e) {
        console.error("Error loading bot settings:", e.message);
    }
}
async function syncToGitHub(fileName) {
    console.log(`[SYNC] Placeholder sync for ${fileName}`);
    return { success: true };
}

loadBotSettings();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const AI_MODELS = (botSettings.ai_models || []);
// If for some reason all models were filtered or missing, provide 2026 defaults
if (AI_MODELS.length === 0) {
    AI_MODELS.push('gemini-2.5-flash', 'gemini-2.0-flash');
}
let currentModelIndex = 0;
const GREETING_COOLDOWN_MS = botSettings.greeting_cooldown_ms;
const ADMIN_NUMBERS = botSettings.admin_numbers;

// ─── Analytics Tracker ───
function logLayoutInterest(layoutName) {
    if (!layoutName) return;
    try {
        const analyticsPath = path.join(ROOT_DIR, 'analytics_data.json');
        let data = {};
        if (fs.existsSync(analyticsPath)) {
            data = JSON.parse(fs.readFileSync(analyticsPath, 'utf8'));
        }
        data[layoutName] = (data[layoutName] || 0) + 1;
        fs.writeFileSync(analyticsPath, JSON.stringify(data, null, 2));
    } catch (e) { console.error("Analytics Error:", e); }
}

function logSourceInterest(sourceName) {
    if (!sourceName) return;
    try {
        const analyticsPath = path.join(ROOT_DIR, 'analytics_sources.json');
        let data = {};
        if (fs.existsSync(analyticsPath)) {
            data = JSON.parse(fs.readFileSync(analyticsPath, 'utf8'));
        }
        data[sourceName] = (data[sourceName] || 0) + 1;
        fs.writeFileSync(analyticsPath, JSON.stringify(data, null, 2));
    } catch (e) { console.error("Source Analytics Error:", e); }
}

function notifyModel() {
    if (process.send) {
        process.send({ type: 'model_update', model: AI_MODELS[currentModelIndex] });
    }
}

function getAiModel() {
    const modelName = AI_MODELS[currentModelIndex] || "gemini-2.5-flash";
    if (process.send) process.send({ type: 'aiModel', data: modelName });
    return genAI.getGenerativeModel({ model: modelName });
}
let aiModel = getAiModel();

// Notify immediately on startup
if (process.send) {
    process.send({ type: 'aiModel', data: AI_MODELS[currentModelIndex] || "gemini-2.5-flash" });
}
const { exec } = require('child_process');
const AdmZip = require('adm-zip');

// ─── Master DB Helpers ────────────────────────────────────
function getMasterData(sheetName) {
    if (!fs.existsSync(MASTER_DB_PATH)) return [];
    try {
        const wb = xlsx.readFile(MASTER_DB_PATH);
        if (!wb.SheetNames.includes(sheetName)) return [];
        return xlsx.utils.sheet_to_json(wb.Sheets[sheetName]);
    } catch (e) { return []; }
}

// Resolve the human name of the admin/staff member who sent a WhatsApp message.
// Lookup chain (in order): SQLite `staff` table → Master_Enterprise_DB Employees sheet
// → WhatsApp contact pushname/name → never the literal string "Admin".
async function resolveStaffName(rawPhone, message) {
    const phone10 = String(rawPhone || '').replace(/\D/g, '').slice(-10);
    if (!phone10) return await _waContactName(message);

    // 1. SQLite staff (authoritative — kept in sync with dashboard)
    try {
        const row = await new Promise((resolve) => {
            db.get(
                `SELECT name FROM staff
                   WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
                   AND is_active != 0
                 ORDER BY length(phone) DESC LIMIT 1`,
                [`%${phone10}`],
                (err, r) => resolve(err ? null : r)
            );
        });
        if (row && row.name && !/^admin$/i.test(row.name.trim())) return row.name.trim();
    } catch (e) { /* fall through */ }

    // 2. Master_Enterprise_DB Employees sheet (legacy / Excel-managed)
    try {
        const employees = getMasterData('Employees');
        const hit = employees.find(s => (s.Phone || '').toString().replace(/\D/g, '').endsWith(phone10));
        if (hit && hit.Name && !/^admin$/i.test(String(hit.Name).trim())) return String(hit.Name).trim();
    } catch (e) { /* fall through */ }

    // 3. WhatsApp contact (pushname / saved contact name on bot's phone)
    const wa = await _waContactName(message);
    if (wa) return wa;

    // 4. Last resort — generic but not the literal "Admin"
    return 'our team';
}

async function _waContactName(message) {
    try {
        if (!message || typeof message.getContact !== 'function') return null;
        const contact = await message.getContact();
        const cand = (contact && (contact.name || contact.pushname || contact.shortName) || '').trim();
        if (cand && !/^admin$/i.test(cand)) return cand;
    } catch (e) {}
    return null;
}

// ─── Interaction & Greet Logic ────────────────────────────
const lastGreeted = {}; // In-memory cooldown

// ─── AI Lead Scoring & MD Reporting ───
async function analyzeAndScoreLead(phone) {
    const logPath = path.join(TRAINING_DATA_DIR, `${phone.replace(/\D/g, '')}.txt`);
    if (!fs.existsSync(logPath)) return;

    try {
        const history = fs.readFileSync(logPath, 'utf8');
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const prompt = `Analyze this real estate chat history. 
        1. Score the lead intent from 1-10 (10 is ready to buy/visit). 
        2. Summarize their main requirement (budget, location).
        Return ONLY JSON: {"score": 8, "notes": "Highly interested in Anisam Garden, asks about loan."}
        HISTORY: ${history.slice(-4000)}`;

        const result = await model.generateContent(prompt);
        const jsonMatch = result.response.text().match(/\{.*\}/s);
        if (!jsonMatch) return;
        const analysis = JSON.parse(jsonMatch[0]);
        
        db.run(`UPDATE customers SET lead_score = ?, lead_notes = ? WHERE phone = ?`, 
            [analysis.score, analysis.notes, phone.replace(/\D/g, '')]);
        console.log(`[AI SCORE] Phone ${phone} scored ${analysis.score}`);
    } catch (e) { console.error("Lead scoring error:", e.message); }
}

async function sendDailyMDReport() {
    const primaryAdmin = botSettings.primary_admin || "919655766666";
    const today = new Date().toISOString().split('T')[0];

    db.all(`SELECT * FROM customers WHERE lead_score >= 7 AND date(last_interaction) = date('now', 'localtime') ORDER BY lead_score DESC`, [], async (err, rows) => {
        if (err || !rows.length) return;

        let report = `🚀 *DRD Daily Hot Leads Report* (${today})\n\n`;
        rows.forEach((c, i) => {
            report += `${i+1}. *${c.name || 'Unknown'}* (${c.phone})\n`;
            report += `   🔥 Score: ${c.lead_score}/10\n`;
            report += `   📝 Info: ${c.lead_notes || 'No notes'}\n\n`;
        });
        report += `Total high-intent leads today: ${rows.length}`;

        await client.sendMessage(formatJid(primaryAdmin), report);
        console.log("[REPORT] Daily MD report sent.");
    });
}

// ─── Site Visit Booking Logic ───
async function handleSiteVisitBooking(message, phone, userMsg) {
    const keywords = ['visit', 'see', 'view', 'காண', 'பார்க்க', 'visit layout'];
    const isVisitRequest = keywords.some(k => userMsg.includes(k));

    if (isVisitRequest && !userStates[phone]?.step) {
        try {
            const layouts = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'layouts_data.json'), 'utf8'));
            const matched = layouts.find(l => userMsg.includes(l.Layout_Name.toLowerCase()));

            if (matched) {
                await message.reply(`📅 We would love to show you *${matched.Layout_Name}*!\n\nPlease reply with your preferred *Date (DD-MM)* and *Time*. \n\nOur site manager will confirm and meet you there.`);
                userStates[phone] = { ...userStates[phone], step: 'BOOKING_VISIT', layout: matched.Layout_Name };
                return true;
            }
        } catch(e) {}
    }

    if (userStates[phone] && userStates[phone].step === 'BOOKING_VISIT') {
        const dateTime = message.body;
        const layout = userStates[phone].layout;
        
        db.run(`INSERT INTO site_visits (customer_phone, layout_name, notes, status) VALUES (?, ?, ?, ?)`,
            [phone, layout, `Requested Slot: ${dateTime}`, 'Pending']);
        
        await message.reply(`✅ *Visit Requested!* \n\nLayout: ${layout}\nSlot: ${dateTime}\n\nOur manager will call you shortly to confirm.`);
        
        // Notify Admin
        const adminMsg = `🚨 *NEW SITE VISIT REQUEST*\n\nCustomer: ${phone}\nLayout: ${layout}\nSlot: ${dateTime}`;
        await client.sendMessage(formatJid(botSettings.primary_admin), adminMsg);
        
        delete userStates[phone].step;
        delete userStates[phone].layout;
        return true;
    }
    return false;
}


async function logConversation(phone, role, text, message) {
    try {
        let idToLog = phone;
        // Try to unmask @lid if possible for cleaner logs
        if (idToLog.includes('@lid') && message) {
            try {
                const contact = await message.getContact();
                if (contact && contact.number) idToLog = contact.number;
            } catch (e) { }
        }

        const cleanPhone = idToLog.replace(/\D/g, '');
        const logFile = path.join(TRAINING_DATA_DIR, `${cleanPhone}.txt`);
        const entry = `[${new Date().toISOString()}] ${role}: ${text}\n`;
        fs.appendFileSync(logFile, entry);
    } catch (e) { console.error("Logging Error:", e); }
}

async function transcribeAudio(media, phone) {
    try {
        console.log(`[VOICE] Transcribing audio from ${phone}...`);
        const model = genAI.getGenerativeModel({ model: AI_MODELS[0] || 'gemini-2.5-flash' });
        const result = await model.generateContent([
            { inlineData: { mimeType: media.mimetype, data: media.data } },
            'Transcribe this audio message exactly as spoken. Return only the transcription text, nothing else.'
        ]);
        const text = result.response.text().trim();
        console.log(`[VOICE] ✅ Transcribed: "${text.substring(0, 80)}"`);
        return text;
    } catch (e) {
        logError('TRANSCRIPTION', e);
        return null;
    }
}

function checkCustomer(phone) {
    const cleanPhone = phone.replace(/\D/g, '');
    const customers = getMasterData('Customers');
    return customers.find(c => String(c.Phone).replace(/\D/g, '') === cleanPhone);
}

function logInquiryToExcel(phone, details) {
    const filePath = INQUIRIES_PATH;
    let workbook;

    const cleanPhone = (typeof phone === 'string' && phone.includes('@'))
        ? phone.split('@')[0]
        : phone;

    const newEntry = {
        'Date': new Date().toLocaleString(),
        'Phone': cleanPhone,
        'Name': details.name || 'Unknown',
        'Project': details.layout || 'General Inquiry',
        'Budget': details.budget || 'Pending',
        'Loan Required': details.loan || 'Pending',
        'Last Message': details.lastMsg || '',
        'Highlighted': details.highlighted ? 'YES' : 'NO'
    };

    try {
        if (fs.existsSync(filePath)) {
            workbook = xlsx.readFile(filePath);
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            let data = xlsx.utils.sheet_to_json(sheet);

            const existingIdx = data.findIndex(r => String(r.Phone) === String(cleanPhone));
            if (existingIdx > -1) {
                data[existingIdx] = {
                    ...data[existingIdx],
                    'Date': new Date().toLocaleString(),
                    'Project': details.layout || data[existingIdx].Project || 'General Inquiry',
                    'Last Message': details.lastMsg || data[existingIdx]['Last Message'],
                    'Highlighted': details.highlighted ? 'YES' : (data[existingIdx].Highlighted || 'NO')
                };
            } else {
                data.push(newEntry);
                // ─── START DRIP CAMPAIGN + FOLLOW-UPS ───
                scheduleDripCampaigns(cleanPhone);
                scheduleFollowUps(cleanPhone, details.name);
            }

            const newWs = xlsx.utils.json_to_sheet(data);
            workbook.Sheets[workbook.SheetNames[0]] = newWs;
        } else {
            workbook = xlsx.utils.book_new();
            const worksheet = xlsx.utils.json_to_sheet([newEntry]);
            xlsx.utils.book_append_sheet(workbook, worksheet, 'Inquiries');
        }
        xlsx.writeFile(workbook, filePath);

        // Mirror to SQLite
        try {
            db.run(`INSERT OR REPLACE INTO customers (phone, name, plot, status, highlighted, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
                [cleanPhone, details.name || 'Unknown', details.layout || 'General Inquiry', 'Inquiry', details.highlighted || 0, new Date().toISOString()]);
        } catch (e) { console.error("SQLite Mirroring Error:", e); }

    } catch (err) {
        console.error("Error logging to Excel:", err.message);
    }
}

function scheduleFollowUps(phone, name) {
    const followUps = [
        { days: 1, text: `Hi ${name || 'there'}! 👋 Do you need any more details about the property? We're happy to help. 🏡` },
        { days: 3, text: `Hi ${name || 'there'}! 📅 Would you like to schedule a site visit? Our team is available this week. Let us know your preferred time!` },
        { days: 7, text: `Hi ${name || 'there'}! 🌟 We have some exciting new layout options at DRD Realtors. Shall I send you the latest brochure?` },
    ];
    followUps.forEach(({ days, text }) => {
        const scheduledDate = new Date();
        scheduledDate.setDate(scheduledDate.getDate() + days);
        const dateStr = scheduledDate.toISOString().split('T')[0];
        // INSERT OR IGNORE prevents duplicate follow-ups if the customer messages again
        db.run(`INSERT OR IGNORE INTO scheduled_messages (customer_phone, message_text, scheduled_date, status) VALUES (?, ?, ?, 'Pending')`,
            [phone, text, dateStr],
            (err) => { if (!err) console.log(`[FOLLOW-UP] Scheduled T+${days}d for ${phone} on ${dateStr}`); });
    });
}

async function handlePaymentConfirmation(phone, message) {
    const cleanPhone = phone.replace(/\D/g, '');
    db.get(`SELECT * FROM payment_requests WHERE phone = ? AND status = 'Sent' ORDER BY created_at DESC LIMIT 1`,
        [cleanPhone],
        async (err, req) => {
            if (err || !req) return;
            const name = req.name || cleanPhone;
            const adminJid = (ADMIN_NUMBERS[0] || '').includes('@') ? ADMIN_NUMBERS[0] : (ADMIN_NUMBERS[0] + '@c.us');
            try {
                await client.sendMessage(adminJid,
                    `💰 *Payment Confirmation Received*\n\nFrom: *${name}* (${cleanPhone})\nAmount: ₹${req.amount}\nPurpose: ${req.purpose || 'N/A'}\n\n_Please verify and confirm._`);
                if (message.type === 'image') {
                    try {
                        const media = await message.downloadMedia();
                        if (media) await client.sendMessage(adminJid, media, { caption: `📎 Screenshot from ${name} (${cleanPhone})` });
                    } catch (e) { }
                }
                db.run(`UPDATE payment_requests SET status = 'Verification Pending', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [req.id]);
                console.log(`[PAYMENT] ✅ Admin notified for payment from ${cleanPhone}`);
            } catch (e) {
                console.error(`[PAYMENT] Failed to notify admin: ${e.message}`);
            }
        });
}

function logAIUsageToExcel(modelName) {
    const filePath = INQUIRIES_PATH;
    let workbook;

    // Format clearly, e.g., "17/04/2026"
    const today = new Date().toLocaleDateString('en-GB');

    try {
        if (fs.existsSync(filePath)) {
            workbook = xlsx.readFile(filePath);
        } else {
            workbook = xlsx.utils.book_new();
            xlsx.utils.book_append_sheet(workbook, xlsx.utils.json_to_sheet([]), 'Inquiries');
        }

        let sheetName = 'AI_Usage';
        let data = [];
        if (workbook.SheetNames.includes(sheetName)) {
            const sheet = workbook.Sheets[sheetName];
            data = xlsx.utils.sheet_to_json(sheet);
        } else {
            xlsx.utils.book_append_sheet(workbook, xlsx.utils.json_to_sheet([]), sheetName);
        }

        // Find today's entry
        let todayEntry = data.find(r => r.Date === today && r.Model === modelName);
        if (todayEntry) {
            todayEntry.Requests = (todayEntry.Requests || 0) + 1;
        } else {
            data.push({ Date: today, Model: modelName, Requests: 1 });
        }

        const newWs = xlsx.utils.json_to_sheet(data);
        workbook.Sheets[sheetName] = newWs;
        xlsx.writeFile(workbook, filePath);

        // Mirror to SQLite
        try {
            db.run(`INSERT INTO ai_usage (model, date, requests) VALUES (?, ?, 1) 
                    ON CONFLICT(model, date) DO UPDATE SET requests = requests + 1`,
                [modelName, today]);
        } catch (e) { }
    } catch (err) {
        console.error("Error logging AI to Excel:", err.message);
    }
}

function getPlotsData() {
    return new Promise((resolve, reject) => {
        db.all("SELECT * FROM plots", [], (err, rows) => {
            if (err) {
                console.error("SQLite plots error:", err);
                return resolve([]);
            }
            const mapped = rows.map(r => ({
                Layout_Name: r.layout_name,
                Plot_No: r.plot_no,
                Area_SqFt: r.size,
                Facing: r.facing,
                Status: r.status,
                Total_Price: r.price,
                Location: r.location
            }));
            resolve(mapped);
        });
    });
}

function findVisualForLayout(layoutName, searchDir) {
    if (!fs.existsSync(searchDir)) return null;
    const items = fs.readdirSync(searchDir, { withFileTypes: true });
    let target = items.find(i => {
        const lWords = layoutName.toLowerCase().match(/\b\w+\b/g) || [];
        const fWords = i.name.toLowerCase().match(/\b\w+\b/g) || [];
        const ignore = ['drd', 'layouts', 'layout', 'all', 'the', 'phase', 'plan', 'pdf'];
        const lSig = lWords.filter(w => !ignore.includes(w) && w.length > 2);
        const fSig = fWords.filter(w => !ignore.includes(w) && w.length > 2);
        if (lSig.length === 0 || fSig.length === 0) return false;
        return fSig.some(fw => lSig.includes(fw));
    });

    if (!target) return null;

    const ALLOWED_EXTS = ['.jpg', '.jpeg', '.png', '.webp', '.mp4', '.pdf'];
    const MAX_SIZE_MB = 16;

    let fullPath = path.join(searchDir, target.name);
    if (target.isDirectory()) {
        const files = fs.readdirSync(fullPath);
        let sendableFiles = files.filter(f => {
            const ext = path.extname(f).toLowerCase();
            if (!ALLOWED_EXTS.includes(ext)) return false;
            if (f.startsWith('~$')) return false; // Skip temporary files
            try {
                const stats = fs.statSync(path.join(fullPath, f));
                return stats.size < MAX_SIZE_MB * 1024 * 1024;
            } catch (e) { return false; }
        });
        if (sendableFiles.length > 0) return { type: 'directory', path: fullPath, files: sendableFiles };
        return null;
    } else {
        const ext = path.extname(target.name).toLowerCase();
        if (ALLOWED_EXTS.includes(ext) && !target.name.startsWith('~$')) {
            try {
                const stats = fs.statSync(fullPath);
                if (stats.size < MAX_SIZE_MB * 1024 * 1024) return { type: 'file', path: fullPath };
            } catch (e) { }
        }
        return null;
    }
}

async function sendTaglineImage(phone, client) {
    try {
        const p = path.join(IMAGES_DIR, '02 DRD Taglines');
        if (fs.existsSync(p)) {
            const files = fs.readdirSync(p);
            if (files.length > 0) {
                const rnd = files[Math.floor(Math.random() * files.length)];
                const media = MessageMedia.fromFilePath(path.join(p, rnd));
                await new Promise(r => setTimeout(r, 5000));
                await client.sendMessage(phone, media);
            }
        }
    } catch (err) {
        console.error("Error sending tagline:", err.message);
    }
}

function getSystemPrompt() {
    loadCompanySettings();
    const addr = companySettings.address || "99/1, Selvam Square, Siruvani Main Road, Coimbatore";
    const maps = companySettings.mapsUrl || "https://maps.app.goo.gl/Hqi59j65sgkRmYqz8";
    const tagline = companySettings.tagline || "";

    const base = `You are a senior property consultant named Property Genius from DRD Realtors.

    CRITICAL RULES:
    1. NEVER admit to being an AI. Respond professionally in the language the customer uses (English or Tamil/தமிழ்).
    2. Your tone should be professional yet approachable, like a real estate expert.
    3. If they ask about site visits, tell them you can schedule it and ask for their preferred date and time.
    4. If the customer expresses interest in a site visit or wants to discuss specifics over the phone, include the tag [HIGHLIGHT] in your response.
    5. If they ask for a callback, include both [HIGHLIGHT] and [REQUEST_CALL].
    6. Use the provided PLOT_DATA and PROJECT_KNOWLEDGE to provide precise details.
    IDENTITY: 
    - Name: Property Genius
    - Company: DRD Realtors
    - Tagline: ${tagline}
    
    PLOT DATA: {PLOT_DATA}
    BROCHURE KNOWLEDGE: {PROJECT_KNOWLEDGE}`;
    
    try {
        let fileContent = fs.readFileSync(path.join(ROOT_DIR, 'Greeting_Message.txt'), 'utf8');
        // Inject company info into the custom instructions if placeholders exist
        fileContent = fileContent.replace('{COMPANY_ADDRESS}', addr).replace('{COMPANY_MAPS_URL}', maps);
        return base + "\n\nCUSTOM INSTRUCTIONS:\n" + fileContent;
    } catch (e) {
        return base;
    }
}


// Browser detection for Windows / Linux
function findExecutable(dir, name) {
    if (!fs.existsSync(dir)) return null;
    const files = fs.readdirSync(dir, { withFileTypes: true });
    for (const f of files) {
        const full = path.join(dir, f.name);
        if (f.isDirectory()) {
            const found = findExecutable(full, name);
            if (found) return found;
        } else if (f.name.toLowerCase() === name.toLowerCase()) {
            return full;
        }
    }
    return null;
}

let executablePath = undefined;
if (process.platform === 'win32') {
    // 1. Check Portable Folders First (Recursive search)
    const portableFolders = [
        path.join(ROOT_DIR, 'chrome-win'),
        path.join(ROOT_DIR, 'portable_chrome'),
        path.join(ROOT_DIR, 'node_modules', 'puppeteer', '.local-chromium')
    ];

    for (const folder of portableFolders) {
        const found = findExecutable(folder, 'chrome.exe');
        if (found) {
            executablePath = found;
            console.log("BROWSER: Portable Chrome found at: " + found);
            break;
        }
    }

    // 2. Check System Paths if not found (Chrome first, then Edge which is always on Win10/11)
    if (!executablePath) {
        const winPaths = [
            // Google Chrome
            'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
            'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
            path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
            // Microsoft Edge (pre-installed on ALL Windows 10/11 machines)
            'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
            'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
            path.join(process.env.LOCALAPPDATA || '', 'Microsoft\\Edge\\Application\\msedge.exe'),
        ];
        for (const p of winPaths) {
            if (fs.existsSync(p)) {
                executablePath = p;
                console.log("BROWSER: Browser found at: " + p);
                break;
            }
        }
    }
} else {
    // Linux logic
    const portableFolders = [
        path.join(ROOT_DIR, 'chrome-linux'),
        path.join(ROOT_DIR, 'node_modules', 'puppeteer', '.local-chromium')
    ];
    for (const folder of portableFolders) {
        const found = findExecutable(folder, 'chrome');
        if (found) {
            executablePath = found;
            console.log("BROWSER: Portable Chromium found at: " + found);
            break;
        }
    }

    if (!executablePath) {
        const linuxPaths = [
            '/usr/bin/google-chrome-stable',
            '/usr/bin/chromium-browser',
            '/usr/bin/chrome'
        ];
        for (const p of linuxPaths) {
            if (fs.existsSync(p)) {
                executablePath = p;
                console.log("BROWSER: System Chrome found at: " + p);
                break;
            }
        }
    }
}

if (!executablePath) {
    console.log("BROWSER: No system browser found in common paths. Using Puppeteer's default.");
}


const client = new Client({
    authStrategy: new LocalAuth({
        clientId: "drd_bot_1",
        dataPath: path.join(ROOT_DIR, '.wwebjs_auth')
    }),
    puppeteer: {
        headless: false,
        // Allow for custom portable executable path
        executablePath: executablePath,
        args: [
            '--app=https://web.whatsapp.com',
            '--window-size=1280,720',
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--disable-gpu',
            '--disable-gpu-sandbox',
            '--disable-software-rasterizer',
            '--disable-extensions'
        ]
    }
});

// ── Connection watchdog ───────────────────────────────────────────────────────
// If no QR, authenticated, or ready signal arrives within 90s after initialize(),
// the saved session is stale (WhatsApp invalidated it silently server-side).
// Clear the session and exit so server.js respawns bot with a fresh QR.
let _initWatchdog = null;
function _clearWatchdog() { if (_initWatchdog) { clearTimeout(_initWatchdog); _initWatchdog = null; } }
function _startWatchdog() {
    _clearWatchdog();
    _initWatchdog = setTimeout(() => {
        console.log('⚠️ WATCHDOG: No response from WhatsApp in 90s — session stale. Clearing and restarting…');
        try {
            const sp = path.join(ROOT_DIR, '.wwebjs_auth', 'session-drd_bot_1');
            if (fs.existsSync(sp)) fs.rmSync(sp, { recursive: true, force: true });
        } catch (e) { console.error('Watchdog cleanup error:', e.message); }
        if (process.send) process.send({ type: 'disconnected' });
        setTimeout(() => process.exit(1), 1000);
    }, 90000);
}

client.on('qr', qr => {
    _clearWatchdog(); // Got QR — not stuck
    console.log("LOGIN: Scan QR Code:");
    qrcode.generate(qr, { small: true });
    if (process.send) process.send({ type: 'qr', data: qr });
});

client.on('authenticated', () => {
    _clearWatchdog(); // Session restored — not stuck
    console.log('🔐 WhatsApp session authenticated.');
});

client.on('auth_failure', (msg) => {
    _clearWatchdog();
    console.log(`❌ Auth failure: ${msg} — clearing stale session and restarting…`);
    try {
        const sp = path.join(ROOT_DIR, '.wwebjs_auth', 'session-drd_bot_1');
        if (fs.existsSync(sp)) fs.rmSync(sp, { recursive: true, force: true });
    } catch (e) {}
    if (process.send) process.send({ type: 'disconnected' });
    setTimeout(() => process.exit(1), 1500);
});

let globalAdminNumber = null;

client.on('ready', async () => {
    console.log('OK: DRD Bot is READY!');
    try {
        const page = client.pupPage;
        await page.evaluate(() => { document.title = "DRD Property Genius - Control Panel"; });

        let number = null;
        const info = client.info;
        number = info ? info.wid.user : null;
        globalAdminNumber = number + "@c.us";
        if (process.send) process.send({ type: 'connected', number });
        notifyModel(); // Send model info on connection
        scheduleMdReports();
    } catch (e) { }
});

function scheduleMdReports() {
    setInterval(async () => {
        const now = new Date();
        const time = now.getHours() + ":" + now.getMinutes();
        
        // Morning Pulse: 9:00 AM
        // Night Wrap-up: 9:00 PM
        if (time === "9:0" || time === "21:0") {
            const staff = getMasterData('Staff');
            const md = staff.find(s => s.Dept === 'Managing Director');
            if (md) {
                console.log(`[SCHEDULE] Sending ${time === "9:0" ? "Morning" : "Night"} report to MD...`);
                const report = await generateSystemReport();
                const jid = String(md.Phone).replace(/\D/g, '') + '@c.us';
                await client.sendMessage(jid, `⏰ *SCHEDULED ${time === "9:0" ? "MORNING" : "NIGHT"} REPORT*\n\n` + report);
            }
        }
    }, 60000); // Check every minute
}

client.on('disconnected', (reason) => {
    _clearWatchdog();
    console.log(`❌ Disconnected: ${reason}`);
    if (process.send) process.send({ type: 'disconnected' });
    if (reason === 'LOGOUT' || reason === 'UNPAIRED') {
        console.log('🧹 Session invalidated — clearing .wwebjs_auth for clean reconnect…');
        try {
            const sp = path.join(ROOT_DIR, '.wwebjs_auth', 'session-drd_bot_1');
            if (fs.existsSync(sp)) fs.rmSync(sp, { recursive: true, force: true });
        } catch (e) { console.error('Session cleanup error:', e.message); }
    }
});


const chatHistories = {};
const userStates = {};
const sessionMemory = new Map(); // { phone: { messages: [{role,text}], lastActivity: timestamp } }

function updateSessionMemory(phone, role, text) {
    if (!sessionMemory.has(phone)) {
        sessionMemory.set(phone, { messages: [], lastActivity: Date.now() });
    }
    const session = sessionMemory.get(phone);
    session.messages.push({ role, text });
    // memory_turns from settings: 1 turn = 1 user msg + 1 bot reply → cap entries at turns*2
    const turns = Math.max(1, parseInt(getBotSettings().memory_turns) || 5);
    const cap   = turns * 2;
    while (session.messages.length > cap) session.messages.shift();
    session.lastActivity = Date.now();
}

// Prune idle sessions every 5 minutes; idle threshold comes from settings.
setInterval(() => {
    const ttlMin = Math.max(1, parseInt(getBotSettings().memory_ttl_minutes) || 60);
    const cutoff = Date.now() - (ttlMin * 60 * 1000);
    for (const [phone, session] of sessionMemory) {
        if (session.lastActivity < cutoff) {
            sessionMemory.delete(phone);
            if (chatHistories[phone]) delete chatHistories[phone];
            console.log(`[SESSION] Expired context cleared for ${phone} (TTL=${ttlMin}m)`);
        }
    }
}, 5 * 60 * 1000);

async function checkIfAdmin(message) {
    if (message.fromMe) return true;
    
    let idToCheck = message.from || '';
    let contactNum = '';
    
    try {
        const contact = await message.getContact();
        contactNum = contact.number;
        if (idToCheck.includes('@lid') && contact.id) {
            idToCheck = contact.id._serialized || (contact.id.user + '@c.us');
        }
    } catch(e) { }
    
    const clean = (str) => (str || '').replace(/\D/g, '');
    const idClean = clean(idToCheck);
    const numClean = clean(contactNum);
    
    const loadSettings = () => {
        try {
            return JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
        } catch(e) { return botSettings; }
    };
    const currentSettings = loadSettings();
    const admins = currentSettings.admin_numbers || [];

    const isMatch = admins.some(admin => {
        const adminClean = clean(admin);
        return (idClean && idClean === adminClean) || (numClean && numClean === adminClean);
    });

    if (isMatch) {
        console.log(`[AUTH] Admin confirmed: ${idToCheck} (${contactNum})`);
    }
    return isMatch;
}

// ─── STAFF BOT COMMANDS: expense/GST quick-entry ──────────
// Any registered staff member can type:
//   !exp 5000 office supplies petrol          → logs expense
//   !gst 2000 Vendor Name some invoice        → logs GST inward entry
//   !myexp                                    → shows their last 5 submissions
// Entries are saved with source='bot' so the dashboard can flag them for admin review.

async function handleStaffBotCommand(message, phone) {
    if (message.fromMe) return false;
    const body = (message.body || '').trim();
    if (!/^!(exp|expense|gst|myexp)/i.test(body)) return false;

    // Look up sender in staff table (by phone last 10 digits)
    const phone10 = (phone || '').replace(/\D/g, '').slice(-10);
    let staffMember = null;
    try {
        staffMember = await new Promise((resolve) => {
            db.get(
                `SELECT id, name, role FROM staff
                   WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
                   AND is_active != 0 LIMIT 1`,
                [`%${phone10}`],
                (err, row) => resolve(err ? null : row)
            );
        });
    } catch (e) { }

    if (!staffMember) return false; // only registered staff can use these commands

    const cmd = body.toLowerCase();
    const target = message.from;

    // ── !myexp — show last 5 submissions ──
    if (/^!myexp$/i.test(body.trim())) {
        try {
            const rows = await new Promise((res2) => {
                db.all(
                    `SELECT 'Expense' AS type, description AS title, amount, date AS entry_date FROM expenses
                       WHERE bot_submitted_by = ? ORDER BY created_at DESC LIMIT 3
                     UNION ALL
                     SELECT 'GST' AS type, COALESCE(description, party_name) AS title, total_amount AS amount, invoice_date AS entry_date
                       FROM gst_ledger WHERE bot_submitted_by = ? ORDER BY created_at DESC LIMIT 3`,
                    [staffMember.name, staffMember.name],
                    (err, r) => res2(err ? [] : r)
                );
            });
            if (!rows.length) {
                await message.reply('📭 No submissions found from your number yet.');
            } else {
                const lines = rows.map(r => `• ${r.type}: *${r.title}* — ₹${r.amount} (${r.entry_date || 'today'})`).join('\n');
                await message.reply(`📋 *Your recent submissions:*\n\n${lines}\n\n_View full details in the dashboard Finance section._`);
            }
        } catch (e) {
            await message.reply('⚠️ Could not fetch submissions: ' + e.message);
        }
        return true;
    }

    // ── !exp <amount> <description…> ──
    if (/^!exp(ense)?\s/i.test(body)) {
        const parts = body.replace(/^!exp(ense)?\s+/i, '').trim();
        const amtMatch = parts.match(/^(\d[\d,.]*)(.*)$/);
        if (!amtMatch) {
            await message.reply('⚠️ Format: *!exp 5000 office supplies petrol*\nAmount must come first.');
            return true;
        }
        const amount = parseFloat(amtMatch[1].replace(/,/g, '')) || 0;
        const desc = amtMatch[2].trim() || 'Office Expense';

        // Guess category from description
        const descLower = desc.toLowerCase();
        let category = 'Other';
        if (/petrol|fuel|diesel/i.test(descLower)) category = 'Travel';
        else if (/office|stationery|print/i.test(descLower)) category = 'Office Expenses';
        else if (/electricity|eb|power/i.test(descLower)) category = 'Utilities';
        else if (/salary|wage/i.test(descLower)) category = 'Salary';
        else if (/material|cement|steel|sand/i.test(descLower)) category = 'Materials';
        else if (/food|lunch|tea|snack/i.test(descLower)) category = 'Food';
        else if (/phone|mobile|internet|data/i.test(descLower)) category = 'Communication';
        else if (/repair|maintenance|service/i.test(descLower)) category = 'Maintenance';
        else if (/rent/i.test(descLower)) category = 'Rent';

        const today = new Date().toISOString().split('T')[0];
        try {
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO expenses (category, description, amount, date, source, bot_submitted_by, notes)
                       VALUES (?, ?, ?, ?, 'bot', ?, ?)`,
                    [category, desc, amount, today, staffMember.name, `Bot entry by ${staffMember.name}`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });

            await message.reply(
                `✅ *Expense Recorded*\n\n` +
                `👤 Submitted by: ${staffMember.name}\n` +
                `💰 Amount: ₹${amount.toLocaleString('en-IN')}\n` +
                `📝 Description: ${desc}\n` +
                `🗂️ Category: ${category}\n` +
                `📅 Date: ${today}\n\n` +
                `_Entry saved. Admin will review from dashboard._`
            );

            // Notify admins
            const settings = getBotSettings();
            for (const adminNum of (settings.admin_numbers || [])) {
                const adminJid = adminNum.includes('@') ? adminNum : `${adminNum}@c.us`;
                try {
                    await client.sendMessage(adminJid,
                        `🔔 *New Bot Expense Entry*\n\nFrom: *${staffMember.name}*\nAmount: ₹${amount.toLocaleString('en-IN')}\nDesc: ${desc}\nCategory: ${category}\n\n_Review in Dashboard → Finance → Expenses_`
                    );
                } catch (e2) { }
            }
        } catch (e) {
            await message.reply('⚠️ Could not save expense: ' + e.message);
        }
        return true;
    }

    // ── !gst <amount> <party name> [description] ──
    if (/^!gst\s/i.test(body)) {
        const parts = body.replace(/^!gst\s+/i, '').trim();
        const amtMatch = parts.match(/^(\d[\d,.]*)(.*)$/);
        if (!amtMatch) {
            await message.reply('⚠️ Format: *!gst 5000 VendorName some invoice description*\nAmount must come first.');
            return true;
        }
        const total = parseFloat(amtMatch[1].replace(/,/g, '')) || 0;
        const rest = amtMatch[2].trim();
        // First word of rest = party name, rest = description
        const [party, ...descParts] = rest.split(' ');
        const partyName = party || 'Unknown Vendor';
        const desc = descParts.join(' ') || 'Bot GST Entry';
        const today = new Date().toISOString().split('T')[0];
        const d = new Date(today);
        const fy = (d.getMonth() + 1) >= 4 ? `${d.getFullYear()}-${String(d.getFullYear() + 1).slice(-2)}` : `${d.getFullYear() - 1}-${String(d.getFullYear()).slice(-2)}`;

        try {
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO gst_ledger
                       (direction, invoice_date, party_name, description, taxable_value, gst_rate,
                        cgst, sgst, igst, total_amount, is_interstate, is_exempt,
                        financial_year, month, year, status, source, bot_submitted_by, notes)
                       VALUES ('inward', ?, ?, ?, ?, 18, 0, 0, 0, ?, 0, 0, ?, ?, ?, 'Draft', 'bot', ?, ?)`,
                    [today, partyName, desc, total, total, fy, d.getMonth() + 1, d.getFullYear(),
                     staffMember.name, `Bot entry by ${staffMember.name} — verify GST details`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });

            await message.reply(
                `✅ *GST Entry Recorded (Inward)*\n\n` +
                `👤 Submitted by: ${staffMember.name}\n` +
                `🏢 Party: ${partyName}\n` +
                `💰 Amount: ₹${total.toLocaleString('en-IN')}\n` +
                `📝 Description: ${desc}\n` +
                `📅 Date: ${today}\n\n` +
                `⚠️ _GST rate defaulted to 18%. Please update in dashboard if different._\n` +
                `_Review in Dashboard → Finance → GST Ledger_`
            );

            // Notify admins
            const settings = getBotSettings();
            for (const adminNum of (settings.admin_numbers || [])) {
                const adminJid = adminNum.includes('@') ? adminNum : `${adminNum}@c.us`;
                try {
                    await client.sendMessage(adminJid,
                        `🔔 *New Bot GST Entry*\n\nFrom: *${staffMember.name}*\nParty: ${partyName}\nAmount: ₹${total.toLocaleString('en-IN')}\nDesc: ${desc}\n\n_Review in Dashboard → Finance → GST Ledger_`
                    );
                } catch (e2) { }
            }
        } catch (e) {
            await message.reply('⚠️ Could not save GST entry: ' + e.message);
        }
        return true;
    }

    return false;
}

async function handleAdminCommand(message) {
    const bodyRaw = (message.body || '').toLowerCase().trim();
    const bodyNoSpace = bodyRaw.replace(/\s+/g, '');
    const isAdmin = await checkIfAdmin(message);

    if (!isAdmin) return false;

    const target = message.fromMe ? message.to : message.from;
    const botId = client.info.wid._serialized;
    const isDirectToBot = (message.to === botId) || (message.from === botId);

    // ── Staff Attendance via WhatsApp ──
    if (bodyNoSpace === '!attendance' || (message.type === 'location' && message.hasMedia)) {
        try {
            // Find staff member by phone
            const phone = message.from.replace(/\D/g, '');
            const staffList = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'staff_members.json'), 'utf8') || '[]');
            const staffMember = staffList.find(s => s.Phone.replace(/\D/g, '').includes(phone.slice(-10)));

            if (!staffMember) {
                await message.reply("❌ Error: Phone number not recognized in Staff Database.");
                return true;
            }

            let gps = "Not Provided";
            if (message.type === 'location') {
                gps = `${message.location.latitude}, ${message.location.longitude}`;
            }

            let photoPath = "No Photo";
            if (message.hasMedia) {
                const media = await message.downloadMedia();
                if (media) {
                    const fileName = `attendance_${phone}_${Date.now()}.jpg`;
                    const dir = path.join(ROOT_DIR, 'customer_docs'); // Reuse existing media dir
                    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
                    fs.writeFileSync(path.join(dir, fileName), media.data, 'base64');
                    photoPath = `/customer_docs/${fileName}`;
                }
            }

            // Send to Server API to record attendance
            if (process.send) {
                process.send({
                    type: 'record_attendance',
                    data: {
                        staffId: staffMember.Staff_ID,
                        name: staffMember.Name,
                        gps: gps,
                        photo: photoPath,
                        timestamp: new Date().toISOString()
                    }
                });
            }

            await message.reply(`✅ *Attendance Recorded*\n👤 Name: ${staffMember.Name}\n📍 GPS: ${gps}\n📸 Photo: Verified\n⏰ Time: ${new Date().toLocaleTimeString()}`);
            return true;
        } catch (e) {
            console.error('[BOT] Attendance Error:', e);
            await message.reply("⚠️ Failed to record attendance. Please try again.");
            return true;
        }
    }

    if (bodyNoSpace.includes('!lead') || bodyNoSpace.includes('!sync') || bodyNoSpace.includes('!excel')) {
        console.log(`[ADMIN COMMAND] target=${target}, body=${bodyRaw}, isDirect=${isDirectToBot}`);
    }

    // ── Payment / Bank-details dispatch (intercepts BEFORE the layout dispatcher) ──
    // Triggers on: send|share|forward + payment-related keyword + recipient phone.
    // Examples:
    //   • share payment link to <phone>
    //   • send bank details to <phone>
    //   • forward UPI to <phone>
    //   • please share account details to <phone>
    //   • send payment request of 50000 to <phone>
    // Verb + money amount + phone is a strong signal for a payment-related request,
    // even when the body doesn't contain the literal "payment link" keyword.
    // Verbs widened to also include collect / request / raise.
    const _paymentVerb = bodyRaw.match(/^(?:please\s+|kindly\s+)?(send|share|forward|dispatch|collect|request|raise)\s+/i);

    // Strong word signals (anything money-related counts)
    const _hasPaymentKw = /(payment|advance|booking|token|deposit|registration\s*fee|emi|installment|instalment|bank\s*details|account\s*details|upi(\s*id)?|gpay|google\s*pay|qr\s*code\s*for\s*pay|payment\s*qr|account\s*number|bank|amount)/i.test(bodyRaw);

    // Money amount signals: digits with currency, lakh/crore, or just a 4+ digit number that looks like rupees
    const _hasMoneyAmount = /(?:rs\.?|₹|inr)\s*[\d,]{2,}/i.test(bodyRaw)
                         || /\b\d+(?:\.\d+)?\s*(?:lakh|lac|lakhs|cr|crore)s?\b/i.test(bodyRaw)
                         || /\b(?:of|for|amount|advance|booking|token|deposit)\s*(?:rs\.?|₹|inr)?\s*\d{4,}/i.test(bodyRaw);

    const _hasPhoneRun  = /\d[\d\s]{6,}\d/.test(bodyRaw);

    // Trigger if: verb + phone + (any payment keyword OR a money amount).
    // The money-amount check catches "send payment advance of 50000 to X" without needing exact keywords.
    if (_paymentVerb && _hasPhoneRun && (_hasPaymentKw || _hasMoneyAmount)) {
        try {
            const senderPhone = (message.fromMe ? message.to : message.from).replace(/\D/g, '');
            const senderName  = await resolveStaffName(senderPhone, message);

            // Extract target phone (last 10+ digit run)
            const digitRuns = [...bodyRaw.matchAll(/\d[\d\s]*\d/g)]
                .filter(m => m[0].replace(/\D/g, '').length >= 10);
            if (!digitRuns.length) { await client.sendMessage(target, '⚠️ No valid 10-digit phone in your message.'); return true; }
            const targetRaw = digitRuns[digitRuns.length - 1][0].replace(/\D/g, '');
            const targetNorm = targetRaw.length === 10 ? '91' + targetRaw : targetRaw;
            const targetJid  = targetNorm + '@c.us';

            // Dedup + per-target rate-limit reuse the same global guard as the layout dispatcher
            global.__recentAdminDispatches = global.__recentAdminDispatches || new Map();
            const bodyKey = `PAY|${message.from}|${bodyRaw.substring(0, 200)}`;
            const last = global.__recentAdminDispatches.get(bodyKey);
            if (last && Date.now() - last < 300_000) { console.log('[PAYMENT DISPATCH] dup suppressed'); return true; }
            global.__recentAdminDispatches.set(bodyKey, Date.now());

            // Amount extraction — handles several phrasings:
            //   "payment advance of 50000", "advance 50000", "booking amount 100000",
            //   "₹50,000", "Rs 1,00,000", "5 lakh", "1.5 lac", "2 crore", "send 50000".
            let amount = null;
            // Tier 1: word like "of/for/amount/advance/booking/token/deposit" then digits
            const m1 = bodyRaw.match(/\b(?:of|for|amount|advance|booking|token|deposit|payable|due|emi|installment|instalment)\s*(?:of\s*)?(?:rs\.?|₹|inr)?\s*([\d][\d,]{2,})/i);
            // Tier 2: explicit currency token then digits
            const m2 = bodyRaw.match(/(?:rs\.?|₹|inr)\s*([\d][\d,]{2,})/i);
            // Tier 3: "N lakh/lac/crore" — convert to rupees
            const m3 = bodyRaw.match(/\b(\d+(?:\.\d+)?)\s*(lakh|lac|lakhs|cr|crore)s?\b/i);
            // Tier 4 (last resort): a verb directly followed by a standalone money-sized number (4+ digits)
            const m4 = bodyRaw.match(/^(?:please\s+|kindly\s+)?(?:send|share|forward|dispatch|collect|request|raise)\s+([\d][\d,]{3,})\b/i);

            if (m3) {
                const mag = /lakh|lac|lakhs/i.test(m3[2]) ? 100000 : 10000000;
                amount = Math.round(parseFloat(m3[1]) * mag);
            } else if (m1) {
                amount = parseInt(m1[1].replace(/,/g, ''), 10);
            } else if (m2) {
                amount = parseInt(m2[1].replace(/,/g, ''), 10);
            } else if (m4) {
                amount = parseInt(m4[1].replace(/,/g, ''), 10);
            }
            // Sanity: very small numbers are probably not amounts (could be plot numbers)
            if (amount !== null && amount < 100) amount = null;

            // Pull bank/UPI from project_banks first, then drd_company_settings as fallback
            const bank = await new Promise((resolve) => {
                db.get(`SELECT * FROM project_banks ORDER BY id LIMIT 1`, [], (err, row) => resolve(err ? null : row));
            });
            const cs = (() => {
                try { return JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'drd_company_settings.json'), 'utf8')); } catch (e) { return {}; }
            })();

            const acc_name = (bank && bank.acc_name) || (cs.bank && cs.bank.acc_name) || cs.companyName || 'DRD Realtors';
            const bank_name = (bank && bank.bank_name) || (cs.bank && cs.bank.bank_name) || '';
            const acc_no   = (bank && bank.acc_no)   || (cs.bank && cs.bank.acc_no)   || '';
            const ifsc     = (bank && bank.ifsc)     || (cs.bank && cs.bank.ifsc)     || '';
            const branch   = (bank && bank.branch)   || (cs.bank && cs.bank.branch)   || '';
            const upi_id   = (bank && bank.upi_id)   || (cs.bank && cs.bank.upi_id)   || '';

            if (!acc_no && !upi_id) {
                await client.sendMessage(target,
                    `⚠️ No bank/UPI details configured.\n\nAdd them in *Payment Hub → Bank Details* or *Global Company Settings → bank_info*, then retry.`);
                return true;
            }

            // Resolve customer name for personalization
            const targetPhone10 = targetNorm.slice(-10);
            let customerName = await new Promise((resolve) => {
                db.get(
                    `SELECT name FROM customers
                       WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
                       ORDER BY last_interaction DESC LIMIT 1`,
                    [`%${targetPhone10}`], (e, r) => resolve(e || !r ? null : r.name || null)
                );
            });
            if (!customerName) {
                try {
                    const c = await client.getContactById(targetJid);
                    customerName = c && (c.name || c.pushname || c.shortName) || null;
                } catch (e) {}
            }
            if (customerName && /^(new\s+lead|unknown|whatsapp\s+user|undefined|null|admin)$/i.test(customerName.trim())) {
                customerName = null;
            }

            const greet = customerName ? `Hello *${customerName}*! 👋` : `Hello! 👋`;
            let msg = `${greet}\n\nAs requested by *${senderName}*, please find our payment details below.\n\n`;
            msg += `🏢 *${acc_name}*\n`;
            if (amount) msg += `💰 Amount: *₹${amount.toLocaleString('en-IN')}*\n\n`;
            else        msg += '\n';
            if (acc_no)   msg += `🏦 Bank: ${bank_name}\n`;
            if (acc_no)   msg += `📋 A/C No: \`${acc_no}\`\n`;
            if (ifsc)     msg += `🔢 IFSC: \`${ifsc}\`\n`;
            if (branch)   msg += `🏦 Branch: ${branch}\n`;
            if (upi_id) {
                const upiLink = `upi://pay?pa=${encodeURIComponent(upi_id)}&pn=${encodeURIComponent(acc_name)}${amount ? `&am=${amount}&cu=INR` : ''}`;
                msg += `\n📱 *UPI ID*: \`${upi_id}\`\n`;
                msg += `🔗 Tap to pay via UPI: ${upiLink}\n`;
            }
            msg += `\nPlease share the payment screenshot once done. Thank you! 🙏\n— Team DRD Realtors`;

            await client.sendMessage(targetJid, msg);

            // Log + record a payment_request row so the dashboard reflects it
            db.run(
                `INSERT INTO payment_requests (phone, name, amount, purpose, status) VALUES (?, ?, ?, ?, 'Sent')`,
                [targetPhone10, customerName || '', amount || 0, 'Admin Dispatch'],
                (err) => { if (err) console.warn('[PAYMENT DISPATCH] log row failed:', err.message); }
            );

            await client.sendMessage(target,
                `✅ Payment details sent to ${targetPhone10}${amount ? ` (₹${amount.toLocaleString('en-IN')})` : ''}.`);
            console.log(`[PAYMENT DISPATCH] By "${senderName}" to ${targetPhone10}${amount ? ` for ₹${amount}` : ''}`);
        } catch (err) {
            await client.sendMessage(target, `❌ Payment dispatch failed: ${err.message}`);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP A — SALES WORKFLOW ADMIN COMMANDS
    // ══════════════════════════════════════════════════════════════════════════

    // ── Shared helpers for Group A handlers ──────────────────────────────────
    const _extractPhone = (txt) => {
        const runs = [...(txt || '').matchAll(/\d[\d\s]*\d/g)].filter(m => m[0].replace(/\D/g, '').length >= 10);
        if (!runs.length) return null;
        const raw = runs[runs.length - 1][0].replace(/\D/g, '');
        return raw.length === 10 ? '91' + raw : raw;
    };
    const _extractAmount = (txt) => {
        if (!txt) return null;
        const m3 = txt.match(/\b(\d+(?:\.\d+)?)\s*(lakh|lac|lakhs|cr|crore)s?\b/i);
        if (m3) { const mag = /lakh|lac|lakhs/i.test(m3[2]) ? 100000 : 10000000; return Math.round(parseFloat(m3[1]) * mag); }
        const m1 = txt.match(/\b(?:of|for|amount|advance|booking|token|deposit|received|paid|payable)\s*(?:of\s*)?(?:rs\.?|₹|inr)?\s*([\d][\d,]{2,})/i);
        if (m1) return parseInt(m1[1].replace(/,/g, ''), 10);
        const m2 = txt.match(/(?:rs\.?|₹|inr)\s*([\d][\d,]{2,})/i);
        if (m2) return parseInt(m2[1].replace(/,/g, ''), 10);
        return null;
    };
    // Simple natural-date parser: tomorrow / today / monday / 25 may / 25/05/2026 / 5pm
    const _parseDateTime = (txt) => {
        if (!txt) return { date: null, time: null };
        const lower = txt.toLowerCase();
        let date = null, time = null;
        const now = new Date();

        // Time: "5pm", "5:30pm", "17:30"
        const t = lower.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/) || lower.match(/\b(\d{1,2}):(\d{2})\b/);
        if (t) {
            let h = parseInt(t[1], 10), m = parseInt(t[2] || '0', 10);
            const ampm = t[3];
            if (ampm === 'pm' && h < 12) h += 12;
            if (ampm === 'am' && h === 12) h = 0;
            time = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
        }

        // Date
        if (/\btoday\b/.test(lower))           date = now;
        else if (/\btomorrow\b/.test(lower))   date = new Date(now.getTime() + 86400000);
        else if (/\bday\s+after\s+tomorrow\b/.test(lower)) date = new Date(now.getTime() + 2 * 86400000);
        else {
            const days = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
            const dHit = days.findIndex(d => lower.includes(d));
            if (dHit !== -1) {
                date = new Date(now);
                const diff = (dHit - now.getDay() + 7) % 7 || 7; // next occurrence
                date.setDate(date.getDate() + diff);
            } else {
                // "25 may" / "25th may 2026" / "25/05/2026" / "2026-05-25"
                const monMap = { jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11 };
                let m = lower.match(/(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*(?:\s+(\d{4}))?/);
                if (m) date = new Date(parseInt(m[3] || now.getFullYear()), monMap[m[2]], parseInt(m[1]));
                else if ((m = lower.match(/(\d{4})-(\d{1,2})-(\d{1,2})/)))    date = new Date(parseInt(m[1]), parseInt(m[2])-1, parseInt(m[3]));
                else if ((m = lower.match(/(\d{1,2})[/-](\d{1,2})[/-](\d{4})/))) date = new Date(parseInt(m[3]), parseInt(m[2])-1, parseInt(m[1]));
            }
        }
        // Default time = 11:00 if a date was found but no time
        if (date && !time) time = '11:00';
        return { date: date ? date.toISOString().slice(0,10) : null, time };
    };
    // Relative day parser: "after 3 days", "in 5 days", "+7d"
    const _parseRelativeDays = (txt) => {
        const m = (txt || '').toLowerCase().match(/(?:after|in|next)\s+(\d+)\s*(?:day|days|d)\b|\+\s*(\d+)\s*d\b/);
        if (!m) return null;
        const n = parseInt(m[1] || m[2], 10);
        if (!n) return null;
        const d = new Date(Date.now() + n * 86400000);
        return d.toISOString().slice(0,10);
    };
    const _findCustomer = (phone10) => new Promise(resolve => {
        db.get(
            `SELECT * FROM customers
               WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
               ORDER BY last_interaction DESC LIMIT 1`,
            [`%${phone10}`], (e, r) => resolve(r || null)
        );
    });
    // Dedup-once guard (used by every Group A handler so retries don't fire twice)
    const _adminDedupOk = (label) => {
        global.__recentAdminDispatches = global.__recentAdminDispatches || new Map();
        const key = `${label}|${message.from}|${bodyRaw.substring(0, 200)}`;
        const last = global.__recentAdminDispatches.get(key);
        if (last && Date.now() - last < 300_000) { console.log(`[${label}] dedup`); return false; }
        global.__recentAdminDispatches.set(key, Date.now());
        return true;
    };
    const _greetingFor = (customer) => {
        const n = customer && customer.name && !/^(admin|unknown|new\s+lead)$/i.test(customer.name.trim())
            ? customer.name.trim() : null;
        return n ? `Hello *${n}*! 👋` : `Hello! 👋`;
    };

    // ── A2: BOOK PLOT ─────────────────────────────────────────────────────────
    //   • book plot 14 in anisam for <phone>
    //   • book anisam 14 for <phone>
    //   • book Velavan plot 3A for <phone> advance 50000
    // Negative lookahead skips "book (a) (site) visit ..." — that belongs to the A3 handler.
    if (/^(?:please\s+|kindly\s+)?book\s+(?!(?:a\s+)?(?:site\s+)?visit\b)/i.test(bodyRaw) && /\b(?:for|to)\s+\d/i.test(bodyRaw)) {
        if (!_adminDedupOk('BOOK')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            const amount = _extractAmount(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a 10-digit customer phone. Try: `book Anisam 14 for <phone>`'); return true; }
            const phone10 = phone.slice(-10);

            // Extract plot ref: try "plot <X>" or "<layout> <plot_no>"
            let plotNoText = '', layoutHint = '';
            const m1 = bodyRaw.match(/plot\s*(?:no\.?|number\.?)?\s*([a-z0-9\-]+)/i);
            if (m1) plotNoText = m1[1];
            // Layout hint: tokens that aren't filler/verb/phone
            const filler = new Set(['book','plot','for','to','of','the','in','please','kindly','advance','booking','token','amount','rs','rs.','₹','inr','no','number']);
            layoutHint = bodyRaw.replace(/\d/g,'').split(/\s+/).filter(w => w.length > 2 && !filler.has(w.toLowerCase())).join(' ').trim();

            // Find a matching plot in DB
            const plotRow = await new Promise(resolve => {
                db.get(
                    `SELECT * FROM plots
                       WHERE (LOWER(layout_name) LIKE ? OR ? = '')
                         AND (LOWER(TRIM(plot_no)) = ? OR ? = '')
                       ORDER BY (status = 'Available') DESC, id DESC LIMIT 1`,
                    [`%${(layoutHint||'').toLowerCase()}%`, layoutHint, plotNoText.toLowerCase(), plotNoText],
                    (e, r) => resolve(r || null)
                );
            });
            if (!plotRow) { await client.sendMessage(target, `⚠️ Couldn't find a plot matching "${layoutHint} ${plotNoText}".`); return true; }

            // Update plot → Booked
            db.run(`UPDATE plots SET status = 'Booked', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [plotRow.id]);
            // Upsert CRM customer
            const customer = await _findCustomer(phone10);
            db.run(
                `INSERT INTO customers (phone, name, plot, location, price, status, last_interaction)
                 VALUES (?, ?, ?, ?, ?, 'Booked', CURRENT_TIMESTAMP)
                 ON CONFLICT(phone) DO UPDATE SET
                   plot = excluded.plot, location = excluded.location,
                   price = COALESCE(NULLIF(excluded.price,''), price),
                   status = 'Booked', last_interaction = CURRENT_TIMESTAMP`,
                [phone10, (customer && customer.name) || '', `${plotRow.layout_name} - Plot ${plotRow.plot_no}`, plotRow.location || '', plotRow.price || 0]
            );
            // Log a payment_request for the advance if specified
            if (amount) {
                db.run(
                    `INSERT INTO payment_requests (phone, name, amount, purpose, status, layout_name, plot_no) VALUES (?, ?, ?, ?, 'Sent', ?, ?)`,
                    [phone10, (customer && customer.name) || '', amount, 'Booking Advance', plotRow.layout_name, plotRow.plot_no]
                );
            }

            // Notify customer
            const greet = _greetingFor(customer);
            const targetJid = phone + '@c.us';
            const priceTxt = plotRow.price ? `₹${parseInt(plotRow.price).toLocaleString('en-IN')}` : 'Quoted price';
            let msg = `${greet}\n\nThank you for booking with *DRD Realtors*! 🎉\n\n` +
                      `🏡 *${plotRow.layout_name}* — Plot *${plotRow.plot_no}*\n` +
                      `📐 Size: ${plotRow.size || '—'} sqft\n` +
                      `💰 Plot Value: ${priceTxt}\n`;
            if (amount) msg += `📋 Booking Advance: *₹${amount.toLocaleString('en-IN')}*\n`;
            msg += `\nYour booking has been confirmed by *${senderName}*. We'll share the next steps (sale agreement, registration date) shortly.`;
            await client.sendMessage(targetJid, msg);

            await client.sendMessage(target,
                `✅ Booked *${plotRow.plot_no}* in *${plotRow.layout_name}* for ${phone10}${amount ? ` (advance ₹${amount.toLocaleString('en-IN')})` : ''}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Booking failed: ${err.message}`);
        }
        return true;
    }

    // ── A3: SCHEDULE SITE VISIT ───────────────────────────────────────────────
    //   • schedule visit for <phone> tomorrow 4pm
    //   • schedule site visit on 25 may 5pm for <phone>
    //   • book visit for <phone> on monday 11am
    if (/^(?:please\s+|kindly\s+)?(?:schedule|book|fix|set)\s+(?:a\s+)?(?:site\s+)?visit\s+/i.test(bodyRaw)) {
        if (!_adminDedupOk('VISIT')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone. Try: `schedule visit for <phone> tomorrow 4pm`'); return true; }
            const phone10 = phone.slice(-10);

            const { date, time } = _parseDateTime(bodyRaw);
            if (!date) { await client.sendMessage(target, '⚠️ Couldn\'t parse the date. Try: `tomorrow 4pm`, `monday 11am`, `25 may 5pm`, `2026-05-25 17:00`'); return true; }

            const customer = await _findCustomer(phone10);
            // Layout hint (if present)
            let layoutHint = '';
            const lm = bodyRaw.match(/(?:at|in|for)\s+([a-z][a-z\s]+?)(?=\s+(?:on|for|tomorrow|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d|$))/i);
            if (lm) layoutHint = lm[1].trim();

            db.run(
                `INSERT INTO site_visits (customer_phone, layout_name, visit_date, visit_time, status, notes) VALUES (?, ?, ?, ?, 'Scheduled', ?)`,
                [phone10, layoutHint || (customer && customer.plot) || '', date, time, `Scheduled by ${senderName} via WhatsApp`]
            );

            const targetJid = phone + '@c.us';
            const greet = _greetingFor(customer);
            const dt = new Date(date + 'T' + (time || '11:00'));
            const dtPretty = dt.toLocaleDateString('en-IN', { weekday:'long', day:'2-digit', month:'short', year:'numeric' }) + ' at ' + dt.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', hour12:true });
            let msg = `${greet}\n\n📅 Your *Site Visit* has been scheduled!\n\n🗓️ *${dtPretty}*\n`;
            if (layoutHint || (customer && customer.plot)) msg += `📍 Location: ${layoutHint || customer.plot}\n`;
            msg += `\nScheduled by *${senderName}*. Please reply to reschedule or cancel.`;
            await client.sendMessage(targetJid, msg);

            await client.sendMessage(target, `✅ Visit scheduled for ${phone10} on ${dtPretty}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Schedule visit failed: ${err.message}`);
        }
        return true;
    }

    // ── A4: RESCHEDULE VISIT ──────────────────────────────────────────────────
    //   • reschedule visit for <phone> to tomorrow 5pm
    //   • move visit of <phone> to monday 11am
    if (/^(?:please\s+|kindly\s+)?(?:reschedule|move|postpone|shift)\s+(?:the\s+)?visit\s+/i.test(bodyRaw)) {
        if (!_adminDedupOk('RESCHEDULE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);
            const { date, time } = _parseDateTime(bodyRaw);
            if (!date) { await client.sendMessage(target, '⚠️ Couldn\'t parse the new date/time.'); return true; }

            const existing = await new Promise(resolve =>
                db.get(`SELECT * FROM site_visits WHERE customer_phone = ? AND status != 'Cancelled' ORDER BY id DESC LIMIT 1`, [phone10], (e, r) => resolve(r || null))
            );
            if (!existing) { await client.sendMessage(target, `⚠️ No active site visit found for ${phone10}. Use \`schedule visit\` instead.`); return true; }

            db.run(`UPDATE site_visits SET visit_date = ?, visit_time = ?, status = 'Rescheduled', notes = ? WHERE id = ?`,
                [date, time, `Rescheduled by ${senderName}`, existing.id]);

            const customer = await _findCustomer(phone10);
            const targetJid = phone + '@c.us';
            const greet = _greetingFor(customer);
            const dt = new Date(date + 'T' + (time || '11:00'));
            const dtPretty = dt.toLocaleDateString('en-IN', { weekday:'long', day:'2-digit', month:'short', year:'numeric' }) + ' at ' + dt.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', hour12:true });
            await client.sendMessage(targetJid,
                `${greet}\n\n🔄 Your site visit has been *rescheduled*.\n\n🗓️ New time: *${dtPretty}*\n\nUpdated by *${senderName}*. We look forward to meeting you!`);
            await client.sendMessage(target, `✅ Visit rescheduled for ${phone10} → ${dtPretty}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Reschedule failed: ${err.message}`);
        }
        return true;
    }

    // ── A5: FOLLOW-UP SCHEDULER ───────────────────────────────────────────────
    //   • follow up with <phone> after 3 days
    //   • remind to call <phone> in 5 days
    //   • set followup for <phone> on monday: discuss bank loan
    if (/^(?:please\s+|kindly\s+)?(?:follow\s*up|followup|remind|set\s+followup)\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('FOLLOWUP')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);

            // Date: prefer relative "after N days", else parsed date
            let next = _parseRelativeDays(bodyRaw);
            if (!next) {
                const { date } = _parseDateTime(bodyRaw);
                next = date;
            }
            if (!next) next = new Date(Date.now() + 3 * 86400000).toISOString().slice(0,10); // default T+3d

            // Note text after colon, if any
            const noteMatch = bodyRaw.match(/:\s*(.+)$/);
            const note = noteMatch ? noteMatch[1].trim() : '';

            db.run(
                `INSERT INTO followups (customer_phone, staff_name, notes, next_followup, status) VALUES (?, ?, ?, ?, 'Pending')`,
                [phone10, senderName, note, next]
            );
            const dtPretty = new Date(next).toLocaleDateString('en-IN', { weekday:'short', day:'2-digit', month:'short', year:'numeric' });
            await client.sendMessage(target, `✅ Follow-up scheduled for ${phone10} on ${dtPretty}${note ? ` — "${note}"` : ''}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Follow-up failed: ${err.message}`);
        }
        return true;
    }

    // ── A6: ASSIGN LEAD TO STAFF ──────────────────────────────────────────────
    //   • assign <phone> to ramesh
    //   • assign lead <phone> to staff prakash
    if (/^(?:please\s+|kindly\s+)?assign\s+/i.test(bodyRaw)) {
        if (!_adminDedupOk('ASSIGN')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone. Try: `assign <phone> to Ramesh`'); return true; }
            const phone10 = phone.slice(-10);

            // Staff token after "to"
            const m = bodyRaw.match(/\bto\s+([a-z][a-z\s]+?)(?:\s*$|\.|,)/i);
            const staffHint = m ? m[1].trim() : '';
            if (!staffHint) { await client.sendMessage(target, '⚠️ Tell me who to assign to. Try: `assign <phone> to Ramesh`'); return true; }

            const staff = await new Promise(resolve => {
                db.get(`SELECT * FROM staff WHERE LOWER(name) LIKE ? AND is_active != 0 ORDER BY length(name) ASC LIMIT 1`,
                    [`%${staffHint.toLowerCase()}%`], (e, r) => resolve(r || null));
            });
            if (!staff) { await client.sendMessage(target, `⚠️ No active staff member matching "${staffHint}". Check Team Management.`); return true; }

            // Mark customer with lead owner via a follow-up note + status update
            db.run(
                `INSERT INTO customers (phone, name, status, last_interaction, lead_notes)
                 VALUES (?, '', 'Assigned', CURRENT_TIMESTAMP, ?)
                 ON CONFLICT(phone) DO UPDATE SET
                   status = 'Assigned',
                   lead_notes = COALESCE(lead_notes,'') || ?, last_interaction = CURRENT_TIMESTAMP`,
                [phone10, `Assigned to ${staff.name} by ${senderName}`, `\n[${new Date().toISOString().slice(0,10)}] Assigned to ${staff.name} by ${senderName}`]
            );
            db.run(`INSERT INTO followups (customer_phone, staff_name, notes, next_followup, status)
                    VALUES (?, ?, ?, date('now','+1 day'), 'Pending')`,
                [phone10, staff.name, `Lead assignment from ${senderName}`]);

            // Notify the staff member if they have a phone
            const staffPhone = String(staff.phone || '').replace(/\D/g, '');
            if (staffPhone.length >= 10) {
                const staffJid = (staffPhone.length === 10 ? '91' + staffPhone : staffPhone) + '@c.us';
                try {
                    await client.sendMessage(staffJid,
                        `📌 New lead assigned to you by *${senderName}*.\n\n📞 Customer: ${phone10}\n\nPlease reach out within 24 hours.`);
                } catch (e) { console.warn('[ASSIGN] could not notify staff:', e.message); }
            }
            await client.sendMessage(target, `✅ Lead ${phone10} assigned to *${staff.name}*.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Assign failed: ${err.message}`);
        }
        return true;
    }

    // ── A1: SEND QUOTATION ────────────────────────────────────────────────────
    //   • send quotation for plot 14 anisam to <phone>
    //   • quote anisam 14 to <phone>
    //   • send quote of velavan 3A to <phone>
    if (/^(?:please\s+|kindly\s+)?(?:send\s+|share\s+)?(?:quotation|quote)\b/i.test(bodyRaw) && /\b(?:to|for)\s+\d/i.test(bodyRaw)) {
        if (!_adminDedupOk('QUOTE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);

            let plotNoText = '', layoutHint = '';
            const m1 = bodyRaw.match(/plot\s*(?:no\.?|number\.?)?\s*([a-z0-9\-]+)/i);
            if (m1) plotNoText = m1[1];
            const filler = new Set(['send','share','please','kindly','quotation','quote','for','to','of','the','in','plot','no','number']);
            layoutHint = bodyRaw.replace(/\d/g,'').split(/\s+/).filter(w => w.length > 2 && !filler.has(w.toLowerCase())).join(' ').trim();

            const plotRow = await new Promise(resolve => {
                db.get(
                    `SELECT * FROM plots
                       WHERE (LOWER(layout_name) LIKE ? OR ? = '')
                         AND (LOWER(TRIM(plot_no)) = ? OR ? = '')
                       ORDER BY (status = 'Available') DESC, id DESC LIMIT 1`,
                    [`%${(layoutHint||'').toLowerCase()}%`, layoutHint, plotNoText.toLowerCase(), plotNoText],
                    (e, r) => resolve(r || null)
                );
            });
            if (!plotRow) { await client.sendMessage(target, `⚠️ Couldn't find a plot for the quotation.`); return true; }

            const customer = await _findCustomer(phone10);
            const total = parseFloat(plotRow.price) || 0;
            const sqft  = parseFloat(plotRow.size) || 0;
            const ratePerSqft = sqft ? Math.round(total / sqft) : 0;
            const cent = sqft ? (sqft / 435.6) : 0;
            const ratePerCent = cent ? Math.round(total / cent) : 0;
            const regAprox = Math.round(total * 0.075); // Tamil Nadu approx 7% reg+stamp

            const targetJid = phone + '@c.us';
            const greet = _greetingFor(customer);
            const fmt = n => '₹' + (n || 0).toLocaleString('en-IN');
            const text =
                `${greet}\n\n📜 *Price Quotation* — *${plotRow.layout_name}*\n` +
                `Plot No: *${plotRow.plot_no}* · Size: *${plotRow.size || '—'} sqft* (${cent.toFixed(2)} cent)\n` +
                `Facing: ${plotRow.facing || '—'} · Location: ${plotRow.location || '—'}\n\n` +
                `*Pricing Breakup*\n` +
                `▪ Plot Value: ${fmt(total)}\n` +
                (ratePerSqft ? `▪ Rate / SqFt: ${fmt(ratePerSqft)}\n` : '') +
                (ratePerCent ? `▪ Rate / Cent: ${fmt(ratePerCent)}\n` : '') +
                `▪ Registration & Stamp Duty (est. 7%): ${fmt(regAprox)}\n` +
                `▪ *Estimated Total*: *${fmt(total + regAprox)}*\n\n` +
                `Bank loan facility available with leading banks.\n` +
                `Prepared by *${senderName}* · DRD Realtors`;
            await client.sendMessage(targetJid, text);

            // Update CRM status
            db.run(
                `INSERT INTO customers (phone, name, plot, location, price, status, last_interaction)
                 VALUES (?, ?, ?, ?, ?, 'Quotation Generated', CURRENT_TIMESTAMP)
                 ON CONFLICT(phone) DO UPDATE SET
                   plot = excluded.plot, location = excluded.location, price = excluded.price,
                   status = 'Quotation Generated', last_interaction = CURRENT_TIMESTAMP`,
                [phone10, (customer && customer.name) || '', `${plotRow.layout_name} - ${plotRow.plot_no}`, plotRow.location || '', total]
            );

            await client.sendMessage(target, `✅ Quotation sent to ${phone10} for *${plotRow.plot_no}* @ ${fmt(total)}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Quotation failed: ${err.message}`);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP B — OPERATIONS COMMANDS
    // ══════════════════════════════════════════════════════════════════════════

    // ── B1: MARK PLOT AS <STATUS> ─────────────────────────────────────────────
    //   • mark plot 14 anisam as sold
    //   • mark anisam 14 as booked
    //   • set status of velavan 3A to available
    if (/^(?:please\s+|kindly\s+)?(?:mark|set)\s+/i.test(bodyRaw)
        && /\b(?:as|to)\s+(available|booked|sold|blocked|hold|reserved)\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('MARK')) return true;
        try {
            const newStatusMatch = bodyRaw.match(/\b(?:as|to)\s+(available|booked|sold|blocked|hold|reserved)\b/i);
            const newStatus = newStatusMatch[1].charAt(0).toUpperCase() + newStatusMatch[1].slice(1).toLowerCase();

            // Strip the "as <status>" tail so plot parsing doesn't see it
            const head = bodyRaw.replace(/\s+(?:as|to)\s+(available|booked|sold|blocked|hold|reserved)\b.*$/i, '');
            let plotNoText = '', layoutHint = '';
            const m1 = head.match(/plot\s*(?:no\.?|number\.?)?\s*([a-z0-9\-]+)/i);
            if (m1) plotNoText = m1[1];
            const filler = new Set(['mark','set','plot','status','of','the','in','please','kindly','no','number']);
            layoutHint = head.replace(/\d/g,'').split(/\s+/).filter(w => w.length > 2 && !filler.has(w.toLowerCase())).join(' ').trim();

            const plotRow = await new Promise(resolve => {
                db.get(
                    `SELECT * FROM plots
                       WHERE (LOWER(layout_name) LIKE ? OR ? = '')
                         AND (LOWER(TRIM(plot_no)) = ? OR ? = '')
                       ORDER BY id DESC LIMIT 1`,
                    [`%${(layoutHint||'').toLowerCase()}%`, layoutHint, plotNoText.toLowerCase(), plotNoText],
                    (e, r) => resolve(r || null)
                );
            });
            if (!plotRow) { await client.sendMessage(target, `⚠️ No plot found matching "${layoutHint} ${plotNoText}".`); return true; }

            db.run(`UPDATE plots SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [newStatus, plotRow.id]);
            await client.sendMessage(target, `✅ *${plotRow.layout_name}* Plot *${plotRow.plot_no}* → *${newStatus}*.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Mark status failed: ${err.message}`);
        }
        return true;
    }

    // ── B2: SEND BROCHURE OF <LAYOUT> TO <PHONE> ──────────────────────────────
    // Differs from layout dispatch: sends ONLY PDF brochures, no full image set.
    if (/^(?:please\s+|kindly\s+)?(?:send|share|forward)\s+(?:the\s+)?brochure\s+/i.test(bodyRaw)
        && /\b(?:to|for)\s+\d/i.test(bodyRaw)) {
        if (!_adminDedupOk('BROCHURE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a phone number.'); return true; }
            const targetJid = phone + '@c.us';
            const phone10 = phone.slice(-10);

            // Extract layout name (everything between "brochure of" and "to <phone>")
            let layoutHint = bodyRaw.replace(/^.*?brochure\s+(?:of\s+)?/i, '').replace(/\s+(?:to|for)\s+.*$/i, '').trim();

            // Find a directory matching layout; filter to .pdf only
            let visuals = findVisualForLayout(layoutHint, IMAGES_DIR)
                       || findVisualForLayout(layoutHint, path.join(IMAGES_DIR, '01 All Layouts'));
            if (!visuals) { await client.sendMessage(target, `⚠️ No layout media found for "${layoutHint}".`); return true; }

            const customer = await _findCustomer(phone10);
            const greet = _greetingFor(customer);
            await client.sendMessage(targetJid,
                `${greet}\n\nAs requested by *${senderName}*, please find the *${layoutHint}* brochure attached.\n\nFor any questions, feel free to reply.\n— Team DRD Realtors`);

            let sentCount = 0;
            if (visuals.type === 'directory') {
                const pdfs = visuals.files.filter(f => f.toLowerCase().endsWith('.pdf') && !f.startsWith('~$')).slice(0, 3);
                if (!pdfs.length) {
                    // Fall back: send the most "brochure-like" image (master/cover/main) if no PDFs
                    const fallback = visuals.files
                        .filter(f => !f.startsWith('~$') && /\.(jpe?g|png)$/i.test(f))
                        .sort((a, b) => (/master|brochure|main|cover/i.test(a) ? 0 : 1) - (/master|brochure|main|cover/i.test(b) ? 0 : 1))
                        .slice(0, 1);
                    for (const f of fallback) {
                        try { await client.sendMessage(targetJid, MessageMedia.fromFilePath(path.join(visuals.path, f))); sentCount++; } catch (e) {}
                    }
                } else {
                    for (const f of pdfs) {
                        try { await client.sendMessage(targetJid, MessageMedia.fromFilePath(path.join(visuals.path, f))); sentCount++; await new Promise(r => setTimeout(r, 1500)); } catch (e) {}
                    }
                }
            } else if (visuals.path.toLowerCase().endsWith('.pdf')) {
                try { await client.sendMessage(targetJid, MessageMedia.fromFilePath(visuals.path)); sentCount++; } catch (e) {}
            }

            await client.sendMessage(target, sentCount ? `✅ Brochure sent to ${phone10} (${sentCount} file).` : `⚠️ No brochure PDF found for "${layoutHint}". Add one in Asset Manager.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Brochure send failed: ${err.message}`);
        }
        return true;
    }

    // ── B3: SEND GPS / LOCATION OF <LAYOUT> TO <PHONE> ────────────────────────
    if (/^(?:please\s+|kindly\s+)?(?:send|share|forward)\s+(?:the\s+)?(?:gps|location|maps?|map\s+link)\s+/i.test(bodyRaw)
        && /\b(?:to|for)\s+\d/i.test(bodyRaw)) {
        if (!_adminDedupOk('GPS')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a phone number.'); return true; }
            const phone10 = phone.slice(-10);
            const targetJid = phone + '@c.us';

            // Extract layout from "location of <layout> to ..."
            let layoutHint = bodyRaw.replace(/^.*?(?:gps|location|maps?|map\s+link)\s+(?:of\s+)?/i, '').replace(/\s+(?:to|for)\s+.*$/i, '').trim();

            // Look up GPS from plots table
            const plotRow = await new Promise(resolve =>
                db.get(`SELECT layout_name, gps_location, location FROM plots WHERE LOWER(layout_name) LIKE ? AND gps_location != '' AND gps_location IS NOT NULL ORDER BY id LIMIT 1`,
                    [`%${layoutHint.toLowerCase()}%`], (e, r) => resolve(r || null)));

            // Fall back to company settings GPS
            let gpsLink = plotRow && plotRow.gps_location ? plotRow.gps_location : '';
            let layoutName = plotRow ? plotRow.layout_name : layoutHint;
            if (!gpsLink) {
                try {
                    const cs = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'drd_company_settings.json'), 'utf8'));
                    gpsLink = cs.mapsUrl || (cs.gps ? `https://maps.google.com/?q=${cs.gps}` : '');
                } catch (e) {}
            }
            if (!gpsLink) { await client.sendMessage(target, `⚠️ No GPS link configured for "${layoutHint}". Add it in Property Inventory → Edit Plot, or in Global Company Settings.`); return true; }

            const vizUrl = (getBotSettings().visualizer_url || '').trim();
            const customer = await _findCustomer(phone10);
            const greet = _greetingFor(customer);
            const msg = `${greet}\n\n📍 *${layoutName}* — site location\n\n🗺️ ${gpsLink}\n` +
                        (vizUrl ? `\n🎨 Interactive Visualizer: ${vizUrl}\n` : '') +
                        `\nShared by *${senderName}*. See you at the site!`;
            await client.sendMessage(targetJid, msg);
            await client.sendMessage(target, `✅ GPS sent to ${phone10}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ GPS send failed: ${err.message}`);
        }
        return true;
    }

    // ── B4: SEND FLOOR PLAN / MASTER PLAN ─────────────────────────────────────
    if (/^(?:please\s+|kindly\s+)?(?:send|share|forward)\s+(?:the\s+)?(?:floor\s+plan|master\s+plan|site\s+plan|layout\s+plan|plan)\s+/i.test(bodyRaw)
        && /\b(?:to|for)\s+\d/i.test(bodyRaw)) {
        if (!_adminDedupOk('PLAN')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a phone number.'); return true; }
            const targetJid = phone + '@c.us';
            const phone10 = phone.slice(-10);

            let layoutHint = bodyRaw.replace(/^.*?plan\s+(?:of\s+)?/i, '').replace(/\s+(?:to|for)\s+.*$/i, '').trim();
            const visuals = findVisualForLayout(layoutHint, IMAGES_DIR)
                         || findVisualForLayout(layoutHint, path.join(IMAGES_DIR, '01 All Layouts'));
            if (!visuals) { await client.sendMessage(target, `⚠️ No layout media for "${layoutHint}".`); return true; }

            // Pick the file most likely to be a master/floor plan
            let planFile = null;
            if (visuals.type === 'directory') {
                const ranked = visuals.files
                    .filter(f => !f.startsWith('~$') && /\.(pdf|jpe?g|png)$/i.test(f))
                    .sort((a, b) => {
                        const score = f => /master|floor|site|plan|layout/i.test(f) ? 0 : 1;
                        return score(a) - score(b);
                    });
                planFile = ranked[0] ? path.join(visuals.path, ranked[0]) : null;
            } else {
                planFile = visuals.path;
            }
            if (!planFile) { await client.sendMessage(target, `⚠️ No suitable plan file found.`); return true; }

            const customer = await _findCustomer(phone10);
            const greet = _greetingFor(customer);
            await client.sendMessage(targetJid, `${greet}\n\n🗺️ *${layoutHint}* — master plan\n\nShared by *${senderName}*. Have a look at the plot positions, road sizes, and amenities.`);
            await client.sendMessage(targetJid, MessageMedia.fromFilePath(planFile));
            await client.sendMessage(target, `✅ Plan sent to ${phone10}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Plan send failed: ${err.message}`);
        }
        return true;
    }

    // ── B5: PATTA STATUS OF <PLOT> ────────────────────────────────────────────
    //   • patta status of velavan 3A
    //   • patta status anisam 14
    if (/^(?:please\s+|kindly\s+)?patta\s+status\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('PATTA')) return true;
        try {
            let plotNoText = '', layoutHint = '';
            const m1 = bodyRaw.match(/plot\s*(?:no\.?)?\s*([a-z0-9\-]+)/i);
            if (m1) plotNoText = m1[1];
            const filler = new Set(['patta','status','of','plot','the','in','please','kindly','no']);
            layoutHint = bodyRaw.replace(/\d/g,'').split(/\s+/).filter(w => w.length > 2 && !filler.has(w.toLowerCase())).join(' ').trim();

            const reg = await new Promise(resolve =>
                db.get(`SELECT * FROM customer_registrations
                          WHERE LOWER(layout_name) LIKE ? AND (LOWER(TRIM(plot_no)) = ? OR ? = '')
                          ORDER BY id DESC LIMIT 1`,
                    [`%${layoutHint.toLowerCase()}%`, plotNoText.toLowerCase(), plotNoText],
                    (e, r) => resolve(r || null)));
            if (!reg) { await client.sendMessage(target, `⚠️ No registration found for "${layoutHint} ${plotNoText}".`); return true; }

            const txt = `📋 *Patta & Registration Status*\n\n` +
                        `🏡 ${reg.layout_name} · Plot ${reg.plot_no}\n` +
                        `👤 Customer: ${reg.customer_name || '—'} (${reg.customer_phone || '—'})\n` +
                        `📅 Reg Date: ${reg.reg_date || '—'}\n` +
                        `📋 Doc No: ${reg.doc_no || '—'}\n` +
                        `🏛️ SRO: ${reg.sro_office || '—'}\n\n` +
                        `🟦 *Patta Status*: ${reg.patta_status || 'Not applied'}\n` +
                        (reg.patta_applied_date ? `📅 Applied: ${reg.patta_applied_date}\n` : '') +
                        (reg.patta_notes ? `📝 Notes: ${reg.patta_notes}\n` : '');
            await client.sendMessage(target, txt);
        } catch (err) {
            await client.sendMessage(target, `❌ Patta lookup failed: ${err.message}`);
        }
        return true;
    }

    // ── B6: OUTSTANDING BALANCE FOR <PHONE> ───────────────────────────────────
    //   • outstanding for <phone>
    //   • balance for <phone>
    // Negative lookahead skips "outstanding loans" — that belongs to C5.
    if (/^(?:please\s+|kindly\s+)?(?:outstanding|balance|dues?)\b/i.test(bodyRaw) && !/\bloans?\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('BALANCE')) return true;
        try {
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);
            const customer = await _findCustomer(phone10);
            if (!customer) { await client.sendMessage(target, `⚠️ ${phone10} not in CRM.`); return true; }

            const payRows = await new Promise(resolve =>
                db.all(`SELECT amount, status FROM payment_requests WHERE phone = ?`, [phone10], (e, r) => resolve(r || [])));
            const received = payRows.filter(p => /received|verified|completed/i.test(p.status || '')).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
            const pending  = payRows.filter(p => /sent|pending|verification/i.test(p.status || '')).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
            const total    = parseFloat(customer.price) || 0;
            const balance  = Math.max(0, total - received);

            const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');
            await client.sendMessage(target,
                `📑 *Payment Status* — ${customer.name || phone10}\n\n` +
                `🏡 Plot: ${customer.plot || '—'}\n` +
                `💰 Total Price: ${fmt(total)}\n` +
                `✅ Received: ${fmt(received)}\n` +
                `🟡 Pending (sent, not yet received): ${fmt(pending)}\n` +
                `🔴 *Outstanding Balance*: *${fmt(balance)}*\n\n` +
                `${payRows.length} payment record(s) on file.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Balance lookup failed: ${err.message}`);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP C — MONEY & REPORTS COMMANDS
    // ══════════════════════════════════════════════════════════════════════════

    // ── C1: SEND RECEIPT / ACKNOWLEDGE PAYMENT ────────────────────────────────
    //   • send receipt for <phone>
    //   • acknowledge 50000 from <phone>
    //   • payment received 50000 from <phone>
    if (/^(?:please\s+|kindly\s+)?(?:send\s+)?(?:receipt|acknowledge|acknowledg|payment\s+received|received\s+payment)\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('RECEIPT')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);
            const targetJid = phone + '@c.us';

            let amount = _extractAmount(bodyRaw);
            // If no explicit amount, fetch the latest pending payment_request
            let originalRequest = null;
            if (!amount) {
                originalRequest = await new Promise(resolve =>
                    db.get(`SELECT * FROM payment_requests WHERE phone = ? AND status IN ('Sent','Verification Pending') ORDER BY created_at DESC LIMIT 1`,
                        [phone10], (e, r) => resolve(r || null)));
                if (originalRequest) amount = parseFloat(originalRequest.amount) || 0;
            }
            if (!amount) { await client.sendMessage(target, `⚠️ Need an amount. Try: \`acknowledge 50000 from ${phone10}\``); return true; }

            const customer = await _findCustomer(phone10);

            // Mark the request as received (or insert a new "received" row if none exists)
            if (originalRequest) {
                db.run(`UPDATE payment_requests SET status = 'Received', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [originalRequest.id]);
            } else {
                db.run(
                    `INSERT INTO payment_requests (phone, name, amount, purpose, status) VALUES (?, ?, ?, 'Direct Receipt', 'Received')`,
                    [phone10, (customer && customer.name) || '', amount]
                );
            }

            const greet = _greetingFor(customer);
            const fmt = n => '₹' + parseInt(n).toLocaleString('en-IN');
            const receiptNo = 'RCP-' + new Date().toISOString().slice(0,10).replace(/-/g,'') + '-' + (Math.floor(Math.random() * 9000) + 1000);

            // Receipt to customer
            await client.sendMessage(targetJid,
                `${greet}\n\n📜 *PAYMENT RECEIVED — RECEIPT*\n\n` +
                `Receipt No: \`${receiptNo}\`\n` +
                `📅 Date: ${new Date().toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })}\n` +
                `💰 Amount: *${fmt(amount)}*\n` +
                `🏡 Plot: ${(customer && customer.plot) || (originalRequest && originalRequest.layout_name) || '—'}\n\n` +
                `Thank you for your payment! We have received the amount and updated your account.\n\n` +
                `Acknowledged by *${senderName}*\n— DRD Realtors`);

            // Confirmation to admin
            await client.sendMessage(target, `✅ Receipt sent to ${phone10} for ${fmt(amount)} · No. ${receiptNo}`);
        } catch (err) {
            await client.sendMessage(target, `❌ Receipt failed: ${err.message}`);
        }
        return true;
    }

    // ── C2: PAYMENT STATUS OF <PHONE> ─────────────────────────────────────────
    //   • payment status of <phone>
    //   • payments for <phone>
    if (/^(?:please\s+|kindly\s+)?payment(?:s)?\s+(?:status|history|of|for|list)\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('PAYSTATUS')) return true;
        try {
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);
            const customer = await _findCustomer(phone10);
            const rows = await new Promise(resolve =>
                db.all(`SELECT * FROM payment_requests WHERE phone = ? ORDER BY created_at DESC LIMIT 15`, [phone10], (e, r) => resolve(r || [])));
            if (!rows.length) { await client.sendMessage(target, `📭 No payment records for ${phone10}.`); return true; }

            const fmt = n => '₹' + parseInt(n || 0).toLocaleString('en-IN');
            let msg = `💳 *Payment History — ${customer ? customer.name : phone10}*\n\n`;
            for (const r of rows) {
                const ic = /received|verified|completed/i.test(r.status || '') ? '✅'
                        : /verification/i.test(r.status || '') ? '🟡'
                        : /sent|pending/i.test(r.status || '') ? '🟠' : '⚪';
                msg += `${ic} ${(r.created_at || '').slice(0, 10)} — ${fmt(r.amount)} — ${r.purpose || '—'} — *${r.status}*\n`;
            }
            await client.sendMessage(target, msg);
        } catch (err) {
            await client.sendMessage(target, `❌ Payment status failed: ${err.message}`);
        }
        return true;
    }

    // ── C3: DAILY / WEEKLY REPORT ─────────────────────────────────────────────
    //   • daily report  /  weekly report  /  today's report  /  report today
    if (/^(?:please\s+|kindly\s+)?(?:daily|weekly|today(?:'s)?|yesterday(?:'s)?)\s+report\b/i.test(bodyRaw)
        || /^(?:please\s+|kindly\s+)?report\s+(?:for\s+)?(?:today|yesterday|this\s+week|week)\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('REPORT')) return true;
        try {
            const isWeekly = /weekly|week/i.test(bodyRaw);
            const isYday = /yesterday/i.test(bodyRaw);
            const days = isWeekly ? 7 : 1;
            const sinceDate = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
            const today = new Date().toISOString().slice(0, 10);
            const range = isWeekly ? `last 7 days` : (isYday ? `yesterday` : `today`);

            const q = (sql, args) => new Promise(r => db.all(sql, args, (e, rows) => r(rows || [])));
            const cnt = sql => new Promise(r => db.get(sql, (e, row) => r(row ? Object.values(row)[0] || 0 : 0)));

            const cutoff = `datetime('now', '-${days} days')`;
            const [newLeads, booked, sold, payments, visits, attendance] = await Promise.all([
                cnt(`SELECT COUNT(*) FROM customers WHERE created_at >= ${cutoff}`),
                cnt(`SELECT COUNT(*) FROM customers WHERE status = 'Booked' AND last_interaction >= ${cutoff}`),
                cnt(`SELECT COUNT(*) FROM customers WHERE status = 'Purchased' AND last_interaction >= ${cutoff}`),
                q(`SELECT amount, status FROM payment_requests WHERE created_at >= ${cutoff}`, []),
                cnt(`SELECT COUNT(*) FROM site_visits WHERE visit_date >= date('now','-${days} days')`),
                cnt(`SELECT COUNT(DISTINCT staff_id) FROM attendance WHERE date = '${today}'`),
            ]);
            const received = payments.filter(p => /received|verified|completed/i.test(p.status || '')).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
            const pending  = payments.filter(p => /sent|pending|verification/i.test(p.status || '')).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
            const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');

            const msg =
                `📊 *${isWeekly ? 'Weekly' : (isYday ? "Yesterday's" : "Today's")} Report*\n` +
                `_Period: ${range}_\n\n` +
                `📞 New Leads: *${newLeads}*\n` +
                `📝 Bookings: *${booked}*\n` +
                `🏆 Purchases: *${sold}*\n` +
                `📅 Site Visits scheduled: *${visits}*\n` +
                `👥 Staff present today: *${attendance}*\n\n` +
                `💰 *Payments*\n` +
                `   ✅ Received: ${fmt(received)}\n` +
                `   🟡 Pending: ${fmt(pending)}\n\n` +
                `_Generated at ${new Date().toLocaleString('en-IN')}_`;
            await client.sendMessage(target, msg);
        } catch (err) {
            await client.sendMessage(target, `❌ Report failed: ${err.message}`);
        }
        return true;
    }

    // ── C4: COMMISSION FOR <STAFF> ────────────────────────────────────────────
    //   • commission for Saravanan
    //   • commission for ramesh this month
    if (/^(?:please\s+|kindly\s+)?commission\s+(?:for|of)\s+/i.test(bodyRaw)) {
        if (!_adminDedupOk('COMMISSION')) return true;
        try {
            const m = bodyRaw.match(/commission\s+(?:for|of)\s+([a-z][a-z\s]+?)(?:\s+(?:this|last)\s+month|\s*$|\.|,)/i);
            const staffHint = m ? m[1].trim() : '';
            if (!staffHint) { await client.sendMessage(target, '⚠️ Specify staff. Try: `commission for Saravanan`'); return true; }
            const isLastMonth = /last\s+month/i.test(bodyRaw);

            const staff = await new Promise(resolve =>
                db.get(`SELECT * FROM staff WHERE LOWER(name) LIKE ? AND is_active != 0 LIMIT 1`,
                    [`%${staffHint.toLowerCase()}%`], (e, r) => resolve(r || null)));
            if (!staff) { await client.sendMessage(target, `⚠️ No staff matching "${staffHint}".`); return true; }

            // Best-effort: total commission/sales from customer_loans + bookings credited to this staff.
            // Schema doesn't have a direct staff link on sales — surface what we can.
            const monthSql = isLastMonth
                ? `strftime('%Y-%m', start_date) = strftime('%Y-%m', date('now','-1 month'))`
                : `strftime('%Y-%m', start_date) = strftime('%Y-%m','now')`;
            const loans = await new Promise(resolve =>
                db.all(`SELECT * FROM customer_loans WHERE ${monthSql} ORDER BY id DESC LIMIT 30`, [], (e, r) => resolve(r || [])));
            const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');

            const totalLoanValue = loans.reduce((s, l) => s + (parseFloat(l.loan_amount) || 0), 0);
            // No staff_id column on customer_loans — show as portfolio summary
            await client.sendMessage(target,
                `💼 *Commission / Portfolio*\n\n` +
                `👤 *${staff.name}* (${staff.phone || '—'})\n` +
                `📅 Period: ${isLastMonth ? 'Last month' : 'This month'}\n\n` +
                `🏦 Loans in DB this period: *${loans.length}*\n` +
                `💰 Total loan value: *${fmt(totalLoanValue)}*\n\n` +
                `_Note: Commission auto-calc requires staff↔sale linkage. Tag deals to staff via Assign Lead command for accurate tracking._`);
        } catch (err) {
            await client.sendMessage(target, `❌ Commission lookup failed: ${err.message}`);
        }
        return true;
    }

    // ── C5: OUTSTANDING LOANS ─────────────────────────────────────────────────
    //   • outstanding loans  /  pending loans  /  active loans
    if (/^(?:please\s+|kindly\s+)?(?:outstanding|pending|active|all)\s+loans?\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('LOANS')) return true;
        try {
            const rows = await new Promise(resolve =>
                db.all(`SELECT customer_name, customer_phone, bank_name, loan_amount, status, plot FROM customer_loans
                          WHERE status IS NULL OR LOWER(status) IN ('pending','active','disbursed','approved','in process')
                          ORDER BY id DESC LIMIT 20`, [], (e, r) => resolve(r || [])));
            if (!rows.length) { await client.sendMessage(target, `📭 No active loans on file.`); return true; }

            const fmt = n => '₹' + parseInt(n || 0).toLocaleString('en-IN');
            const total = rows.reduce((s, r) => s + (parseFloat(r.loan_amount) || 0), 0);
            let msg = `🏦 *Active / Pending Loans* (top ${rows.length})\n\n`;
            for (const r of rows) {
                msg += `• ${r.customer_name || r.customer_phone || '—'} — ${fmt(r.loan_amount)} — ${r.bank_name || '—'} — ${r.status || 'Pending'}\n`;
                if (r.plot) msg += `   _Plot: ${r.plot}_\n`;
            }
            msg += `\n💰 *Total portfolio*: ${fmt(total)}`;
            await client.sendMessage(target, msg);
        } catch (err) {
            await client.sendMessage(target, `❌ Loans lookup failed: ${err.message}`);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP D — TEAM & ADMIN COMMANDS
    // ══════════════════════════════════════════════════════════════════════════

    // ── D1: WHO IS ON LEAVE TODAY ─────────────────────────────────────────────
    if (/^(?:please\s+|kindly\s+)?(?:who(?:'s|\s+is)\s+(?:on\s+)?(?:leave|absent)|(?:leave|absent)\s+today|today(?:'s)?\s+(?:leave|absent))\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('LEAVE_TODAY')) return true;
        try {
            const today = new Date().toISOString().slice(0, 10);
            const staff = await new Promise(resolve =>
                db.all(`SELECT id, name FROM staff WHERE is_active != 0`, [], (e, r) => resolve(r || [])));
            const presentRows = await new Promise(resolve =>
                db.all(`SELECT DISTINCT staff_id, name FROM attendance WHERE date = ? AND LOWER(COALESCE(status,'present')) != 'absent'`, [today], (e, r) => resolve(r || [])));
            const presentSet = new Set(presentRows.map(r => String(r.staff_id || r.name || '').toLowerCase()));
            const absent = staff.filter(s => !presentSet.has(String(s.id).toLowerCase()) && !presentSet.has(String(s.name).toLowerCase()));

            if (!absent.length) { await client.sendMessage(target, `✅ All ${staff.length} active staff have checked in today.`); return true; }
            const list = absent.map(s => `• ${s.name}`).join('\n');
            await client.sendMessage(target, `📋 *Absent / Not Checked In Today* (${absent.length} of ${staff.length})\n\n${list}\n\n_Check Attendance Hub for late check-ins._`);
        } catch (err) {
            await client.sendMessage(target, `❌ Leave check failed: ${err.message}`);
        }
        return true;
    }

    // ── D2: BROADCAST <MESSAGE> TO <SEGMENT> ──────────────────────────────────
    //   • broadcast "We have new plots in DRD Velavan" to all leads
    //   • broadcast Festival offer 5% off to all booked
    //   • announce Office closed Saturday to all staff
    // Negative lookahead skips "announce price/rate/cost change" — that belongs to D3.
    if (/^(?:please\s+|kindly\s+)?(?:broadcast|announce)\s+/i.test(bodyRaw) && !/\b(?:price|rate|cost)\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('BROADCAST')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);

            // Extract message body and segment
            // Patterns: broadcast "<msg>" to <segment>  OR  broadcast <msg> to <segment>
            let msgBody = '', segment = '';
            const quoted = bodyRaw.match(/^(?:please\s+|kindly\s+)?(?:broadcast|announce)\s+"([^"]+)"\s+to\s+(.+)$/i);
            if (quoted) { msgBody = quoted[1]; segment = quoted[2]; }
            else {
                const m = bodyRaw.match(/^(?:please\s+|kindly\s+)?(?:broadcast|announce)\s+(.+?)\s+to\s+(.+)$/i);
                if (m) { msgBody = m[1]; segment = m[2]; }
            }
            if (!msgBody || !segment) { await client.sendMessage(target, '⚠️ Usage: `broadcast "Your message" to all leads`'); return true; }

            // Resolve segment to recipient list
            let recipients = [];
            const segLower = segment.toLowerCase();
            if (/all\s+staff/.test(segLower)) {
                recipients = await new Promise(r => db.all(`SELECT phone, name FROM staff WHERE is_active != 0 AND phone != ''`, [], (e, rows) => r(rows || [])));
            } else if (/all\s+(booked|customers|purchased)/.test(segLower)) {
                recipients = await new Promise(r => db.all(`SELECT phone, name FROM customers WHERE status IN ('Booked','Purchased') AND phone != ''`, [], (e, rows) => r(rows || [])));
            } else if (/all\s+(leads|inquir)/.test(segLower)) {
                recipients = await new Promise(r => db.all(`SELECT phone, name FROM customers WHERE phone != '' ORDER BY last_interaction DESC LIMIT 100`, [], (e, rows) => r(rows || [])));
            } else if (/in\s+([a-z][a-z\s]+)/i.test(segment)) {
                const layoutHint = segment.match(/in\s+([a-z][a-z\s]+)/i)[1].trim();
                recipients = await new Promise(r => db.all(`SELECT phone, name FROM customers WHERE LOWER(plot) LIKE ? AND phone != ''`, [`%${layoutHint.toLowerCase()}%`], (e, rows) => r(rows || [])));
            } else {
                await client.sendMessage(target, '⚠️ Unknown segment. Try: `all leads`, `all booked`, `all staff`, `in DRD Anisam`');
                return true;
            }

            if (!recipients.length) { await client.sendMessage(target, `⚠️ No recipients in segment "${segment}".`); return true; }
            // Safety cap
            const SAFE_MAX = 50;
            if (recipients.length > SAFE_MAX) {
                await client.sendMessage(target, `⚠️ Segment has ${recipients.length} recipients — capping at ${SAFE_MAX} for safety. Use Bulk Broadcast dashboard for larger blasts.`);
                recipients = recipients.slice(0, SAFE_MAX);
            }

            await client.sendMessage(target, `📣 Broadcasting to ${recipients.length} recipient(s)... I'll send a summary when done.`);

            let sent = 0, failed = 0;
            for (const r of recipients) {
                const phoneClean = String(r.phone).replace(/\D/g, '');
                if (phoneClean.length < 10) { failed++; continue; }
                const jid = (phoneClean.length === 10 ? '91' + phoneClean : phoneClean) + '@c.us';
                try {
                    await client.sendMessage(jid, `${r.name ? `Hello *${r.name}*! 👋\n\n` : ''}${msgBody}\n\n— DRD Realtors`);
                    sent++;
                    await new Promise(rs => setTimeout(rs, 1500)); // 1.5s between sends to avoid WA rate limits
                } catch (e) { failed++; }
            }
            await client.sendMessage(target, `📊 Broadcast complete by *${senderName}*\n✅ Sent: ${sent}\n❌ Failed: ${failed}`);
        } catch (err) {
            await client.sendMessage(target, `❌ Broadcast failed: ${err.message}`);
        }
        return true;
    }

    // ── D3: ANNOUNCE PRICE CHANGE ON <LAYOUT> ─────────────────────────────────
    //   • announce price change on velavan to 350 per sqft
    //   • update rate of anisam to 8 lakh per cent
    if (/^(?:please\s+|kindly\s+)?(?:announce|update)\s+(?:price|rate|cost)\b/i.test(bodyRaw)) {
        if (!_adminDedupOk('PRICE_CHANGE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);

            const layoutMatch = bodyRaw.match(/(?:on|of|for)\s+([a-z][a-z\s]+?)(?:\s+to\s+|\s*$)/i);
            const rateMatch = bodyRaw.match(/(?:to|at|@)\s*(?:rs\.?|₹|inr)?\s*([\d.,]+)\s*(?:lakh|lac|cr|crore|rupees?|rs|inr)?\s*(?:per|\/)\s*(sqft|sq\.?\s*ft|cent|cents)/i);
            if (!layoutMatch || !rateMatch) {
                await client.sendMessage(target, '⚠️ Usage: `announce price change on Velavan to 350 per sqft` or `update rate of Anisam to 8 lakh per cent`');
                return true;
            }
            const layoutHint = layoutMatch[1].trim();
            let rate = parseFloat(rateMatch[1].replace(/,/g, ''));
            if (/lakh|lac/i.test(rateMatch[0])) rate *= 100000;
            else if (/cr|crore/i.test(rateMatch[0])) rate *= 10000000;
            const unit = /cent/i.test(rateMatch[2]) ? 'cent' : 'sqft';

            const plots = await new Promise(resolve =>
                db.all(`SELECT id, size, plot_no FROM plots WHERE LOWER(layout_name) LIKE ? AND status IN ('Available','Booked')`, [`%${layoutHint.toLowerCase()}%`], (e, r) => resolve(r || [])));
            if (!plots.length) { await client.sendMessage(target, `⚠️ No active plots in "${layoutHint}".`); return true; }

            // Update prices
            for (const p of plots) {
                const sqft = parseFloat(p.size) || 0;
                let newPrice = 0;
                if (unit === 'sqft') newPrice = Math.round(sqft * rate);
                else /* cent */     newPrice = Math.round((sqft / 435.6) * rate);
                if (newPrice > 0) db.run(`UPDATE plots SET price = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [newPrice, p.id]);
            }
            await client.sendMessage(target,
                `✅ Price updated for *${plots.length}* plot(s) in *${layoutHint}* → ₹${rate.toLocaleString('en-IN')} per ${unit}.\n\n` +
                `Changed by *${senderName}*. New prices reflect in dashboard immediately.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Price change failed: ${err.message}`);
        }
        return true;
    }

    // ── D4: MARK STAFF LEAVE ──────────────────────────────────────────────────
    //   • leave for Saravanan today
    //   • leave for Preeti on 25 may
    if (/^(?:please\s+|kindly\s+)?leave\s+(?:for|of)\s+/i.test(bodyRaw)) {
        if (!_adminDedupOk('STAFF_LEAVE')) return true;
        try {
            const m = bodyRaw.match(/leave\s+(?:for|of)\s+([a-z][a-z\s]+?)(?:\s+(?:on|today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d).*)?$/i);
            const staffHint = m ? m[1].trim() : '';
            if (!staffHint) { await client.sendMessage(target, '⚠️ Usage: `leave for Saravanan today`'); return true; }

            const staff = await new Promise(resolve =>
                db.get(`SELECT * FROM staff WHERE LOWER(name) LIKE ? AND is_active != 0 LIMIT 1`, [`%${staffHint.toLowerCase()}%`], (e, r) => resolve(r || null)));
            if (!staff) { await client.sendMessage(target, `⚠️ No staff "${staffHint}".`); return true; }

            const { date } = _parseDateTime(bodyRaw);
            const leaveDate = date || new Date().toISOString().slice(0,10);

            db.run(
                `INSERT INTO attendance (staff_id, name, date, status, gps_location, photo_proof, notes) VALUES (?, ?, ?, 'Absent', 'Leave', 'No Photo', ?)`,
                [staff.id, staff.name, leaveDate, `Leave marked by admin`]);
            await client.sendMessage(target, `✅ Marked *${staff.name}* on leave for ${leaveDate}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Leave failed: ${err.message}`);
        }
        return true;
    }

    // ── D5: ADD CRM NOTE ──────────────────────────────────────────────────────
    //   • note for <phone>: customer asked for east-facing
    //   • add note <phone> budget upto 50 lakh
    if (/^(?:please\s+|kindly\s+)?(?:add\s+)?note(?:s)?\s+(?:for|on|about)?\s*\d/i.test(bodyRaw)) {
        if (!_adminDedupOk('NOTE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a phone.'); return true; }
            const phone10 = phone.slice(-10);

            const colonNote = bodyRaw.match(/:\s*(.+)$/);
            let note = colonNote ? colonNote[1].trim() : '';
            if (!note) {
                // Take anything after the phone number as the note
                const afterPhone = bodyRaw.split(phone10).slice(1).join(phone10).trim();
                if (afterPhone) note = afterPhone.replace(/^[\s.,;:]+/, '');
            }
            if (!note) { await client.sendMessage(target, '⚠️ No note text. Try: `note for <phone>: prefers east-facing plot`'); return true; }

            const stamp = `[${new Date().toISOString().slice(0,10)} · ${senderName}] ${note}`;
            db.run(
                `INSERT INTO customers (phone, lead_notes, last_interaction) VALUES (?, ?, CURRENT_TIMESTAMP)
                   ON CONFLICT(phone) DO UPDATE SET
                     lead_notes = COALESCE(lead_notes,'') || char(10) || ?,
                     last_interaction = CURRENT_TIMESTAMP`,
                [phone10, stamp, stamp]);
            await client.sendMessage(target, `📝 Note added to ${phone10}:\n_"${note}"_`);
        } catch (err) {
            await client.sendMessage(target, `❌ Note failed: ${err.message}`);
        }
        return true;
    }

    // Admin dispatch: accepts SEND / SHARE / FORWARD / DISPATCH as the verb.
    // Algorithm (robust to natural phrasings, filler words, and punctuation):
    //   1. Match verb at start of message
    //   2. Find the LAST 10+ digit run anywhere in the message → that's the phone
    //   3. Remove verb prefix + the phone + everything between " to ..." and the phone (filler)
    //   4. Iteratively strip leading filler tokens (layout, details, of, the, info, about, for, please, kindly)
    //   5. What remains is the layout name
    // Supported (and many more) — all of these now work:
    //   • send Anisam Garden to <phone>
    //   • share Anisam to <phone>
    //   • share details of Anisam to <phone>
    //   • share layout details of anisam to <phone>
    //   • share layout details of anisam to following number <phone>
    //   • share layout details of anisam to the following number..<phone>
    //   • forward Anisam Garden to <phone>
    //   • send 91<phone> details Anisam Garden  (legacy syntax A)
    // Allow optional "please/kindly" before the verb
    const dispatchVerb = bodyRaw.match(/^(?:please\s+|kindly\s+)?(send|share|forward|dispatch)\s+/i);
    const hasLongDigitRun = /\d[\d\s]{6,}\d/.test(bodyRaw);
    if (dispatchVerb && (bodyRaw.includes(' details ') || hasLongDigitRun)) {
        try {
            const senderPhone = (message.fromMe ? message.to : message.from).replace(/\D/g, '');
            const senderName = await resolveStaffName(senderPhone, message);

            // Verb prefix matches "send "/"send" (with or without trailing space) so it strips cleanly.
            const verbPattern   = /^(?:please\s+|kindly\s+)?(send|share|forward|dispatch)(?=\s+|$)\s*/i;
            // Leading filler tokens to strip iteratively. Order matters — longer phrases first.
            const fillerToken   = /^(layout\s+details\s+of|please\s+share|kindly\s+share|details\s+of|layout\s+of|the\s+layout|the|layout|details|info|about|for|please|kindly|of)(?=\s+|$)\s*/i;

            // 1. Find the LAST run of digits-with-optional-spaces (10+ digits when whitespace removed)
            //    anywhere in the body. Handles "91 9894 815803", "<phone>", "..<phone>", etc.
            let phoneMatch = null;
            const digitRuns = [...bodyRaw.matchAll(/\d[\d\s]*\d/g)]
                .filter(m => m[0].replace(/\D/g, '').length >= 10);
            if (digitRuns.length) phoneMatch = digitRuns[digitRuns.length - 1];
            else {
                // Fallback: 7+ digit run if no proper 10-digit phone found
                const fb = [...bodyRaw.matchAll(/\d[\d\s]*\d/g)]
                    .filter(m => m[0].replace(/\D/g, '').length >= 7);
                if (fb.length) phoneMatch = fb[fb.length - 1];
            }

            let targetPhone, layoutName;
            if (phoneMatch) {
                const rawPhone = phoneMatch[0].replace(/\D/g, '');
                const normalizedPhone = rawPhone.length === 10 ? '91' + rawPhone : rawPhone;
                targetPhone = normalizedPhone + '@c.us';

                // Build layoutName from the body with the phone (and surrounding clutter) excised.
                let residue = bodyRaw.slice(0, phoneMatch.index);

                // If this is legacy "<verb> <phone> details <layout>" (phone BEFORE " details "),
                // layoutName actually comes from AFTER " details ", not before.
                const tail = bodyRaw.slice(phoneMatch.index + phoneMatch[0].length);
                if (/^\s*details\s+/i.test(tail) || residue.replace(verbPattern, '').replace(/\s+/g,'').length < 3) {
                    // Tail contains the layout after "details"
                    const tailParts = tail.split(/\s+details\s+/i);
                    if (tailParts.length > 1) {
                        residue = tailParts.slice(1).join(' details ');
                    } else if (/^\s*details\s+/i.test(tail)) {
                        residue = tail.replace(/^\s*details\s+/i, '');
                    } else {
                        residue = tail; // bare layout after phone
                    }
                } else {
                    // Standard "<verb> <layout> to <phone>" — cut at the LAST " to " before the phone.
                    const toIdx = residue.lastIndexOf(' to ');
                    if (toIdx !== -1) residue = residue.slice(0, toIdx);
                }

                // Strip verb prefix
                residue = residue.replace(verbPattern, '');
                // Iteratively strip leading filler tokens
                let prev;
                do { prev = residue; residue = residue.replace(fillerToken, ''); } while (residue !== prev);
                // Strip trailing punctuation/whitespace
                layoutName = residue.replace(/[\s.,;:!?"'`]+$/g, '').trim();
            } else if (bodyRaw.includes(' details ')) {
                // Pure legacy Syntax A: digits already null means no phone at all → error
                const parts = bodyRaw.split(' details ');
                const rawPhone = parts[0].replace(verbPattern, '').trim().replace(/\D/g, '');
                const normalizedPhone = rawPhone.length === 10 ? '91' + rawPhone : rawPhone;
                targetPhone = rawPhone ? normalizedPhone + '@c.us' : '';
                let residue = (parts[1] || '');
                let prev;
                do { prev = residue; residue = residue.replace(fillerToken, ''); } while (residue !== prev);
                layoutName = residue.replace(/[\s.,;:!?"'`]+$/g, '').trim();
            }

            if (!targetPhone || targetPhone === '@c.us' || !/^\d{10,}@c\.us$/.test(targetPhone)) {
                await client.sendMessage(target, `⚠️ Couldn't find a valid 10-digit phone number in your message.`);
                return true;
            }
            if (!layoutName) {
                await client.sendMessage(target,
                    `⚠️ Couldn't identify which layout to send. Try:\n` +
                    `• send [layout] to [phone]\n` +
                    `• share [layout] to [phone]\n` +
                    `• share details of [layout] to [phone]\n` +
                    `Examples: "share Anisam to <phone>", "send Velavan Garden to <phone>"`);
                return true;
            }

            // ── Idempotency guard (HARDENED) ──
            // Build a STABLE key from sender + body — message.id is an object that re-instantiates
            // on every message_create re-fire, so object identity comparisons fail and dedup misses.
            // Also keep id-based key as a secondary check.
            global.__recentAdminDispatches = global.__recentAdminDispatches || new Map();
            const idStr = (message.id && (message.id._serialized || (message.id.id ? `${message.fromMe}_${message.id.id}` : ''))) || '';
            const bodyKey = `${message.fromMe ? 'me' : 'them'}|${message.from}|${bodyRaw.substring(0, 200)}`;
            const lastByBody = global.__recentAdminDispatches.get(bodyKey);
            const lastById   = idStr ? global.__recentAdminDispatches.get(idStr) : null;
            const now = Date.now();
            // Within 5 minutes, same body OR same id = ignore. (Was 60s — too short for WA re-syncs.)
            if ((lastByBody && (now - lastByBody) < 300_000) || (lastById && (now - lastById) < 300_000)) {
                console.log(`[ADMIN DISPATCH] Duplicate command suppressed (body-dedup): "${bodyRaw.substring(0,80)}"`);
                return true;
            }
            global.__recentAdminDispatches.set(bodyKey, now);
            if (idStr) global.__recentAdminDispatches.set(idStr, now);
            // Prune entries older than 10 min
            for (const [k, t] of global.__recentAdminDispatches) {
                if (now - t > 600_000) global.__recentAdminDispatches.delete(k);
            }

            // ── GLOBAL RATE LIMIT (safety net) ──
            // No matter what bugs slip through, never send more than 10 messages to the SAME target
            // within 5 minutes from the dispatch flow. This is a hard ceiling.
            global.__dispatchSendCounter = global.__dispatchSendCounter || new Map();
            const rateKey = `RATE|${targetPhone}`;
            const counter = global.__dispatchSendCounter.get(rateKey) || { count: 0, since: now };
            if (now - counter.since > 300_000) { counter.count = 0; counter.since = now; }
            if (counter.count >= 10) {
                console.log(`[ADMIN DISPATCH] RATE-LIMITED — refused to send (already ${counter.count} msgs to ${targetPhone} in last 5min)`);
                try { await client.sendMessage(target, `⚠️ Safety stop: already sent ${counter.count} messages to ${targetPhone} in the last 5 minutes. Wait a few minutes before retrying.`); } catch(_) {}
                return true;
            }
            global.__dispatchSendCounter.set(rateKey, counter);
            const _origSend = client.sendMessage.bind(client);
            const _trackedSendForThisDispatch = async (jid, ...args) => {
                if (jid === targetJid) {
                    const c = global.__dispatchSendCounter.get(rateKey);
                    if (c) c.count++;
                    if (c && c.count > 10) {
                        console.log(`[ADMIN DISPATCH] Hit per-target ceiling mid-dispatch; aborting further sends.`);
                        throw new Error('per-target send ceiling reached');
                    }
                }
                return _origSend(jid, ...args);
            };
            // We do NOT replace client.sendMessage globally — instead, use this tracker only inside the
            // dispatch flow below by referencing it explicitly. (See sendToTarget() helper below.)
            const sendToTarget = (jid, payload) => _trackedSendForThisDispatch(jid, payload);

            const targetJid = targetPhone.includes('@c.us') ? targetPhone : `${targetPhone.replace(/\D/g, '')}@c.us`;
            const isSelfTarget = (targetJid === target);
            if (isSelfTarget) {
                await client.sendMessage(target, `⚠️ You're sending to your own number. Proceeding once — confirmations suppressed to avoid spam.`);
            } else {
                await client.sendMessage(target, `🔄 Sending *${layoutName}* details to ${targetPhone}...`);
            }

            // 1. Get Text Details
            const plots = await getPlotsData();
            const needle = layoutName.toLowerCase();
            const STOPWORDS = new Set(['drd', 'the', 'garden', 'gardens', 'enclave', 'layout', 'project']);
            const needleTokens = needle.split(/\W+/).filter(t => t.length > 1 && !STOPWORDS.has(t));

            // Score each DISTINCT layout name across all plot rows, then pick the SINGLE best layout
            // and filter to plots belonging only to it. This guarantees one dispatch = one layout.
            const layoutScores = new Map(); // layout_name → score
            for (const p of plots) {
                const layout = (p.Layout_Name || '');
                if (!layout || layoutScores.has(layout)) continue;
                const hay = layout.toLowerCase();
                const hayTokens = hay.split(/\W+/).filter(Boolean);
                let score = 0;
                // Tier A: exact substring of full needle (strongest signal)
                if (needle && hay.includes(needle)) score += 100;
                // Tier B: each needle token that appears in haystack
                for (const nt of needleTokens) {
                    if (hay.includes(nt))           score += 25;
                    // 5-char prefix overlap for transliteration variance
                    else if (nt.length >= 5) {
                        const pref = nt.slice(0, 5);
                        if (hayTokens.some(ht => ht.startsWith(pref) || nt.startsWith(ht.slice(0, 5)))) score += 10;
                    }
                }
                if (score > 0) layoutScores.set(layout, score);
            }

            let matching = [];
            if (layoutScores.size) {
                // Pick the highest-scoring layout; ties broken alphabetically for stability
                const ranked = [...layoutScores.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
                const [bestLayout, bestScore] = ranked[0];
                console.log(`[ADMIN DISPATCH] layout scoring: ${JSON.stringify(Object.fromEntries(ranked))} → picked "${bestLayout}" (score ${bestScore})`);
                matching = plots.filter(p => p.Layout_Name === bestLayout);
            }

            console.log(`[ADMIN DISPATCH] layoutName="${layoutName}", target=${targetPhone}, matched=${matching.length}`);

            if (matching.length === 0) {
                // Surface the actual layout names so the admin can re-type accurately.
                const known = [...new Set(plots.map(p => p.Layout_Name).filter(Boolean))];
                const list = known.length
                    ? `\n\nAvailable layouts:\n• ${known.slice(0, 15).join('\n• ')}`
                    : '\n\n(Plots table appears empty — check Database Sync.)';
                await client.sendMessage(target, `❌ Layout *${layoutName}* not found in database.${list}`);
                return true;
            }
            if (!client.info) {
                await client.sendMessage(target, `❌ Bot is starting up. Please try again in a few seconds.`);
                return true;
            }

            const layoutDisplay = matching[0].Layout_Name;

            // ── Resolve customer name: CRM first, then WhatsApp contact, then null ──
            const targetPhone10 = targetJid.replace(/\D/g, '').slice(-10);
            let customerName = null;
            let customerFromCRM = false;
            try {
                customerName = await new Promise((resolve) => {
                    db.get(
                        `SELECT name FROM customers WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ? ORDER BY last_interaction DESC LIMIT 1`,
                        [`%${targetPhone10}`],
                        (err, row) => resolve(err || !row ? null : (row.name || null))
                    );
                });
                if (customerName) customerFromCRM = true;
            } catch (e) { console.warn('[ADMIN DISPATCH] CRM lookup failed:', e.message); }

            if (!customerName) {
                try {
                    const contact = await client.getContactById(targetJid);
                    customerName = (contact && (contact.name || contact.pushname || contact.shortName)) || null;
                    if (customerName) console.log(`[ADMIN DISPATCH] WhatsApp contact name resolved: "${customerName}"`);
                } catch (e) { console.warn('[ADMIN DISPATCH] WA contact lookup failed:', e.message); }
            }

            // Strip generic placeholders that aren't real names
            if (customerName && /^(new\s+lead|unknown|whatsapp\s+user|undefined|null)$/i.test(customerName.trim())) {
                customerName = null;
            }

            // Auto-add to CRM if this is a brand-new contact, so future flows can use them.
            if (!customerFromCRM && customerName) {
                db.run(
                    `INSERT INTO customers (phone, name, plot, location, status, last_interaction)
                     VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(phone) DO UPDATE SET
                       name=COALESCE(NULLIF(name,''), excluded.name),
                       last_interaction=CURRENT_TIMESTAMP`,
                    [targetPhone10, customerName, layoutDisplay, matching[0].Location || '', 'Admin Dispatch'],
                    (err) => { if (err) console.warn('[ADMIN DISPATCH] CRM auto-insert failed:', err.message); }
                );
                console.log(`[ADMIN DISPATCH] Auto-added new customer to CRM: ${customerName} (${targetPhone10})`);
            }

            const greetingLine = customerName
                ? `Hello *${customerName}*! 👋`
                : `Hello! 👋`;

            const text =
                `${greetingLine}\n\nAs *${senderName}* asked to share details about *${layoutDisplay}*, please find the property information below.\n\n` +
                `🏡 *${layoutDisplay}*\n` +
                `📍 Location: ${matching[0].Location}\n` +
                `🏗️ Status: ${matching[0].Status}\n\n` +
                `Do you need any further details? We are here to help! 🙏\n` +
                `📞 Professional services by DRD Realtors.`;

            try { await sendToTarget(targetJid, text); }
            catch (e) { console.warn('[ADMIN DISPATCH] greeting send aborted:', e.message); return true; }

            // 2. Send Media — HARD CAP from settings + per-target ceiling enforced via sendToTarget
            const MAX_MEDIA_PER_DISPATCH = Math.max(1, parseInt(getBotSettings().max_media_per_dispatch) || 5);
            let sentCount = 0;
            const visuals = findVisualForLayout(layoutName, IMAGES_DIR)
                          || findVisualForLayout(layoutName, path.join(IMAGES_DIR, '01 All Layouts'));
            if (visuals) {
                if (visuals.type === 'directory') {
                    const ranked = [...visuals.files].sort((a, b) => {
                        const score = f => /master|brochure|main|cover|plan|layout/i.test(f) ? 0 : 1;
                        return score(a) - score(b);
                    }).slice(0, MAX_MEDIA_PER_DISPATCH);
                    for (const f of ranked) {
                        try {
                            const fullPath = path.join(visuals.path, f);
                            if (fs.existsSync(fullPath) && !f.startsWith('~$')) {
                                await sendToTarget(targetJid, MessageMedia.fromFilePath(fullPath));
                                sentCount++;
                                await new Promise(r => setTimeout(r, 2000));
                            }
                        } catch (e) {
                            console.error("Admin dispatch media error:", e.message);
                            if (/ceiling/.test(e.message)) break; // hard stop on safety abort
                        }
                    }
                    if (visuals.files.length > MAX_MEDIA_PER_DISPATCH) {
                        console.log(`[ADMIN DISPATCH] Capped media at ${MAX_MEDIA_PER_DISPATCH} (had ${visuals.files.length} files in ${visuals.path})`);
                    }
                } else {
                    try {
                        if (fs.existsSync(visuals.path)) {
                            await sendToTarget(targetJid, MessageMedia.fromFilePath(visuals.path));
                            sentCount++;
                        }
                    } catch (e) { console.error("Admin single media error:", e.message); }
                }
            }

            if (!isSelfTarget) {
                await client.sendMessage(target, `✅ Sent to ${targetJid.split('@')[0]} — 1 text + ${sentCount} media file(s).`);
            }
        } catch (err) {
            await client.sendMessage(target, `❌ Admin Dispatch Failed: ${err.message}`);
        }
        return true;
    }

    if (bodyRaw.startsWith('approve ') || bodyRaw.startsWith('reject ')) {
        const parts = bodyRaw.split(' ');
        const action = parts[0].toLowerCase();
        const docId = parts[1];
        
        if (docId) {
            const status = action === 'approve' ? 'Approved' : 'Rejected';
            console.log(`[LEGAL] Admin ${message.from} ${status} DocID=${docId}`);
            
            if (process.send) {
                process.send({
                    type: 'legal_approval_res',
                    data: { docId, status, adminPhone: message.from }
                });
            }
            
            await message.reply(`${action === 'approve' ? '✅' : '❌'} Document ${docId} has been marked as *${status}*.`);
            return true;
        }
    }

    if (bodyNoSpace === '!leads' || bodyNoSpace === '!lead' || bodyNoSpace === '!excel') {
        try {
            const leadsPath = path.join(ROOT_DIR, 'Customer_Inquiries.xlsx');
            if (fs.existsSync(leadsPath)) {
                const media = MessageMedia.fromFilePath(leadsPath);
                await client.sendMessage(target, media);
                await client.sendMessage(target, "DATA: Here is the latest Leads Excel sheet.");
            } else {
                await client.sendMessage(target, "!: Leads file not found.");
            }
        } catch (err) {
            console.error("Error sending leads:", err);
            await client.sendMessage(target, "X: Failed to send Leads: " + err.message);
        }
        return true;
    }

    if (bodyNoSpace === 'status' || bodyNoSpace === '!status') {
        const report = await generateSystemReport();
        await message.reply(report);
        return true;
    }

    if (bodyNoSpace === 'status+' || bodyNoSpace === '!status+') {
        const report = await generateDetailedReport();
        await message.reply(report);
        return true;
    }

    if (bodyNoSpace === 'help' || bodyNoSpace === '!help') {
        const helpText = `🛠️ *BOT COMMANDS*
---------------------------------------
*ADMIN COMMANDS*
📈 *status* - Quick system report
📊 *status+* - Detailed audit report
📑 *!leads* - Download latest inquiries
🔄 *!sync* - Trigger cloud sync

*STAFF COMMANDS* (registered staff only)
💸 *!exp 5000 petrol fuel* - Log an expense
🧾 *!gst 2000 VendorName desc* - Log GST entry
📋 *!myexp* - View your recent submissions
---------------------------------------
_Property Genius_`;
        await message.reply(helpText);
        return true;
    }


    if (bodyNoSpace === '!sync' || bodyNoSpace === '!syc') {
        const isPrimaryAdmin = target.includes(botSettings.primary_admin || '<phone>');
        if (!isPrimaryAdmin) {
            await client.sendMessage(target, "X: Only the primary Admin is authorized for Cloud Sync.");
            return true;
        }
        try {
            await client.sendMessage(target, "SYNC: Manual Sync Started...");
            const result = await syncToGitHub("Manual_Sync");
            if (result.success) await client.sendMessage(target, "OK: Cloud Synchronized Successfully.");
            else await client.sendMessage(target, "!: Git sync failed: " + result.error);
        } catch (err) {
            await client.sendMessage(target, "X: Sync Failed: " + err.message);
        }
        return true;
    }

    // [NEW] Flexible Relay / Share Command for Admins & Staff
    const relayPattern = /share\s+(?:photos?|details?|price|details)\s+(?:to\s+)?(\d+)\s+([\s\S]+)/im;
    const relayMatch = bodyRaw.match(relayPattern);
    if (relayMatch) {
        const targetPhone = relayMatch[1].trim();
        const rawContext = relayMatch[2].trim();
        
        // Extract Plot No (e.g. "10A" or "plot 5")
        const plotMatch = rawContext.match(/(?:plot\s+)?(\d+[a-z]?)\b/i);
        const plotNo = plotMatch ? plotMatch[1].toUpperCase() : "";
        
        // Match against known layouts from DB
        const plotData = await getPlotsData();
        const layoutNames = [...new Set(plotData.map(d => d.Layout || d.Layout_Name).filter(Boolean))];
        let matchedLayout = "";
        
        const cleanContext = rawContext.toLowerCase();
        for (const l of layoutNames) {
            const cleanL = l.toLowerCase().replace('drd ', '').replace('gardens', 'garden').trim();
            if (cleanContext.includes(cleanL)) {
                matchedLayout = l;
                break;
            }
        }
        
        if (!matchedLayout) {
             matchedLayout = rawContext.replace(plotNo, '')
                               .replace(/plot|details|price|following|no|garden/gi, '')
                               .replace(/\s+/g, ' ')
                               .trim();
        }

        if (targetPhone) {
            const finalTarget = targetPhone.length === 10 ? '91' + targetPhone : targetPhone;
            console.log(`[RELAY COMMAND] target=${finalTarget}, plot=${plotNo}, layout=${matchedLayout}`);
            
            if (process.send) {
                process.send({ 
                    type: 'manager_share', 
                    data: { 
                        target: finalTarget, 
                        plotNo: plotNo || 'any', 
                        layout: matchedLayout || 'General', 
                        sender: 'Admin Team' 
                    } 
                });
            }

            const targetJid = finalTarget.includes('@') ? finalTarget : `${finalTarget}@c.us`;
            const intro = `Hello! 👋 I'm Property Genius from *DRD Realtors*.\n\nOur team requested me to share the details of *Plot ${plotNo || 'available plots'}* in *${matchedLayout || 'our projects'}* with you.\n\nSending over the technical details and media now!`;
            
            try {
                await client.sendMessage(targetJid, intro);
                await message.reply(`✅ Relaying details of ${plotNo} (${matchedLayout}) to ${finalTarget}. I'll handle the interaction with them!`);
            } catch (e) {
                await message.reply(`❌ Failed to send intro to ${finalTarget}: ${e.message}`);
            }
            return true;
        }
    }


    if (message.hasMedia || message.type === 'document') {
        const isPrimaryAdmin = !!botSettings.primary_admin && target.includes(botSettings.primary_admin);
        if (!isPrimaryAdmin || !isDirectToBot) return false;

        try {
            console.log(`MEDIA: Admin Media Received: ${message.type}`);


            await new Promise(r => setTimeout(r, 5000));
            const refreshedMsg = await client.getMessageById(message.id._serialized);
            const media = await refreshedMsg.downloadMedia();
            if (!media) {
                await client.sendMessage(target, "X: Failed to download media.");
                return true;
            }

            let fileName = "";
            const isExcel = media.mimetype?.includes('spreadsheet') || media.filename?.toLowerCase().endsWith('.xlsx');
            const isZip = media.filename?.toLowerCase().endsWith('.zip');
            const isImage = media.mimetype?.includes('image');

            if (isExcel) {
                fileName = 'Plots_Data.xlsx';
                fs.writeFileSync(path.join(ROOT_DIR, fileName), Buffer.from(media.data, 'base64'));
                await client.sendMessage(target, "OK: Excel Updated Locally.");
            } else if (isImage) {
                const folder = path.join(IMAGES_DIR, '01 All Layouts');
                if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });

                let cleanCaption = body.replace(/[^a-z0-9]/gi, '_').substring(0, 40);
                if (!cleanCaption && media.filename) {
                    cleanCaption = path.parse(media.filename).name.replace(/[^a-z0-9]/gi, '_');
                }
                const baseName = cleanCaption || "layout_img";
                fileName = `${baseName}_${Date.now()}.jpg`;

                fs.writeFileSync(path.join(folder, fileName), Buffer.from(media.data, 'base64'));
                await client.sendMessage(target, `IMAGE: Added Locally: ${fileName}`);
            } else if (isZip) {
                const zipPath = path.join(ROOT_DIR, 'temp_upload.zip');
                fs.writeFileSync(zipPath, Buffer.from(media.data, 'base64'));
                const zip = new AdmZip(zipPath);
                zip.getEntries().forEach(entry => {
                    // Use only the basename — never allow path components from ZIP entries
                    const safeName = path.basename(entry.entryName);
                    const entryName = safeName.toLowerCase();
                    if (!safeName) return; // skip entries with no filename
                    if (entryName.endsWith('.xlsx')) {
                        fs.writeFileSync(path.join(ROOT_DIR, 'Plots_Data.xlsx'), entry.getData());
                    } else if (/\.(jpg|jpeg|png)$/.test(entryName)) {
                        const imgFolder = path.join(IMAGES_DIR, '01 All Layouts');
                        if (!fs.existsSync(imgFolder)) fs.mkdirSync(imgFolder, { recursive: true });
                        fs.writeFileSync(path.join(imgFolder, safeName), entry.getData());
                    }
                });
                fs.unlinkSync(zipPath);
                fileName = "Bulk_ZIP_Update";
                await client.sendMessage(target, "ZIP: Content Processed.");
            }

            if (fileName) {
                const result = await syncToGitHub(fileName);
                if (result.success) {
                    await client.sendMessage(target, "CLOUD: Synchronized Successfully.");
                } else {
                    await client.sendMessage(target, `!: Saved Locally, but Cloud Sync failed.\nError: ${result.error}`);
                }
            }
            return true;
        } catch (err) {
            console.error("Admin upload failed:", err);
            await client.sendMessage(target, "X: Upload Failed: " + err.message);
            return true;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP E — GEMINI INTENT ROUTER (catch-all for unmatched admin commands)
    // ══════════════════════════════════════════════════════════════════════════
    // Triggers ONLY when:
    //   (1) the sender is an admin (we know — handleAdminCommand only runs for admins via the outer check)
    //   (2) the message starts with a command-ish verb, OR mentions a phone, OR mentions an amount
    //   (3) nothing above matched
    // It asks Gemini to classify the intent against the known command catalog,
    // then replies to the admin with the correct exact phrasing — does NOT auto-execute
    // (safer for v1; Gemini hallucinations / prompt injection won't cost money or fire messages).
    const looksLikeAdminCommand =
        /^(?:please\s+|kindly\s+)?(?:send|share|forward|dispatch|collect|request|raise|book|schedule|reschedule|move|postpone|shift|follow|remind|assign|mark|set|patta|outstanding|balance|dues?|receipt|acknowledge|payment|payments|daily|weekly|today|yesterday|report|commission|leave|broadcast|announce|update|note|notes)\b/i.test(bodyRaw)
        || /\d{10,}/.test(bodyRaw)
        || /(?:rs\.?|₹|inr)/i.test(bodyRaw);

    if (looksLikeAdminCommand && !_adminDedupOk('E_INTENT')) return true;
    if (looksLikeAdminCommand) {
        try {
            // Hard cap so we don't burn quota on every random admin chat
            global.__intentRouterCount = global.__intentRouterCount || { count: 0, since: Date.now() };
            if (Date.now() - global.__intentRouterCount.since > 3600_000) global.__intentRouterCount = { count: 0, since: Date.now() };
            if (global.__intentRouterCount.count > 30) {
                console.log('[INTENT ROUTER] hourly cap reached');
                return false;
            }
            global.__intentRouterCount.count++;

            const catalog = `
You are the command-suggestion assistant for the DRD Property Genius WhatsApp bot.
The admin tried to issue a command and it was NOT matched by any specific handler.

Available admin commands (suggest the closest one):
SALES
- send quotation for <plot> <layout> to <phone>
- book <layout> <plot> for <phone> [advance <amount>]
- schedule visit for <phone> <date> <time>
- reschedule visit for <phone> to <new date> <time>
- follow up with <phone> after <N> days [: note]
- assign <phone> to <staff name>

OPERATIONS
- mark <plot> <layout> as <Available|Booked|Sold|Blocked>
- send brochure of <layout> to <phone>
- send GPS of <layout> to <phone>
- send floor plan of <layout> to <phone>
- patta status of <layout> <plot>
- outstanding for <phone>

MONEY
- send receipt for <phone>   /  acknowledge <amount> from <phone>
- payment status of <phone>
- daily report  /  weekly report
- commission for <staff>
- outstanding loans

TEAM
- who is on leave today
- broadcast "<message>" to <all leads|all booked|all staff|in <layout>>
- announce price change on <layout> to <rate> per <sqft|cent>
- leave for <staff> [on <date>]
- note for <phone>: <text>

PAYMENT
- share payment link to <phone>
- send payment advance of <amount> to <phone>

Return JSON only: {"suggestion": "<best-guess command phrasing>", "reason": "<one-line why>"}.
If you genuinely cannot map it to anything, return {"suggestion": null, "reason": "..."}.`.trim();

            const aiModel = genAI.getGenerativeModel({ model: AI_MODELS[currentModelIndex] || 'gemini-2.5-flash-lite' });
            const result = await aiModel.generateContent(catalog + '\n\nAdmin wrote: ' + JSON.stringify(bodyRaw));
            const txt = result.response.text();
            const jsonMatch = txt.match(/\{[\s\S]*\}/);
            let suggestion = null, reason = '';
            if (jsonMatch) {
                try { const j = JSON.parse(jsonMatch[0]); suggestion = j.suggestion || null; reason = j.reason || ''; } catch (e) {}
            }

            if (suggestion) {
                await client.sendMessage(target,
                    `🤖 Not sure what you meant. Did you want:\n\n*${suggestion}*\n\n_${reason}_\n\nReply with the exact command above to execute. Type *!help* for the full command list.`);
            } else {
                await client.sendMessage(target,
                    `🤖 I couldn't map your request to a known command.${reason ? `\n\n_${reason}_` : ''}\n\nType *!help* to see all admin commands.`);
            }
            return true;
        } catch (e) {
            console.warn('[INTENT ROUTER] failed:', e.message);
            // Fall through — let the message reach the customer-AI flow (which is harmless from admin)
        }
    }

    return false;
}

async function runLocalFallback(message, phone, userMsg) {
    try {
        if (!userStates[phone]) userStates[phone] = { step: 'MENU' };
        const state = userStates[phone];
        const data = await getPlotsData();
        const availablePlots = data.filter(d => d.Status && d.Status.toLowerCase().includes('available'));
        const layouts = [...new Set(availablePlots.map(d => d.Layout || d.Layout_Name).filter(Boolean))];

        let matchedLayout = null;
        const userMsgNoSpace = userMsg.replace(/\s+/g, '').toLowerCase();
        for (const layout of layouts) {
            const layoutNoSpace = layout.replace(/\s+/g, '').toLowerCase();
            if (userMsgNoSpace.includes(layoutNoSpace)) { matchedLayout = layout; break; }
        }
        if (!matchedLayout) {
            const index = parseInt(userMsg.trim());
            if (!isNaN(index) && index >= 1 && index <= layouts.length) matchedLayout = layouts[index - 1];
        }

        if (!matchedLayout) {
            console.log(`[FALLBACK] No specific layout matched. Sending Menu.`);
            let menu = "🏡 *Welcome to DRD Realtors!* \n\nOur AI agent is currently busy, but here are our available projects to get you started. Which property would you like details for?\n\n";
            layouts.forEach((l, i) => {
                menu += `${i + 1}. ${l}\n`;
            });
            menu += "\nReply with the *Project Name* or *Number*!";
            await message.reply(menu);
            return;
        }

        const layoutPlots = availablePlots.filter(d => (d.Layout || d.Layout_Name) === matchedLayout);
        logLayoutInterest(matchedLayout); // Log popularity hit

        const perCentRates = layoutPlots.map(p => {
            const price = parseFloat(p.Price || p.Total_Price);
            const size = parseFloat(p.Size || p.Area_SqFt);
            if (!price || !size) return null;
            return (price / size) * 435.6;
        }).filter(Boolean);

        if (perCentRates.length > 0) {
            const minRate = Math.min(...perCentRates);
            const maxRate = Math.max(...perCentRates);

            // Format as Approx Range per Cent
            const lower = Math.floor(minRate / 100000);
            const upper = Math.ceil(maxRate / 100000);
            const rangeStr = lower === upper ? `${lower}L` : `${lower}L - ${upper}L`;

            let response = `🏡 *${matchedLayout}* Details:\n\n`;
            response += `📍 Prices range from **Approx. Rs.${rangeStr} per Cent**.\n`;
            response += `📞 *Note:* Final fixed price will be confirmed via Call.\n`;
            await message.reply(response);
        } else {
            await message.reply(`🏡 *${matchedLayout}*: Available soon. Please call for pricing.`);
        }

        let targetResult = findVisualForLayout(matchedLayout, IMAGES_DIR) || findVisualForLayout(matchedLayout, path.join(IMAGES_DIR, '01 All Layouts'));
        if (targetResult) {
            if (targetResult.type === 'directory') {
                for (const file of targetResult.files) {
                    try {
                        const filePath = path.join(targetResult.path, file);
                        if (fs.existsSync(filePath)) {
                            const media = MessageMedia.fromFilePath(filePath);
                            await client.sendMessage(phone, media);
                            await new Promise(r => setTimeout(r, 2000));
                        }
                    } catch(e) { console.log('Fallback media error:', e.message); }
                }
            } else {
                try {
                    if (fs.existsSync(targetResult.path)) {
                        await client.sendMessage(phone, MessageMedia.fromFilePath(targetResult.path));
                    }
                } catch(e) { console.log('Fallback single media error:', e.message); }
            }
            await client.sendMessage(phone, `(MAP) Site Plan: ${(botSettings.visualizer_url || 'https://drdrealtors.github.io/drd-layouts/')}`);
        }
        await client.sendMessage(phone, `-> Please reply with your Budget & Loan interest.`);
        userStates[phone] = userStates[phone] || {};
        userStates[phone].step = 'EXPECTING_ANSWER';
        userStates[phone].lastLayout = matchedLayout;

    } catch (err) {
        console.error("Fallback error:", err);
    }
}

client.on('message_create', async message => {
    // ── QR TRACKING LOGIC (Priority) ──
    // Detects pre-filled QR messages like: "I am interested in... [Ref: ANISAM_GARDENS]" or "[Ref: STAFF01]"
    // This allows tracking even if your office has no public IP.
    const qrMatch = message.body.match(/\[Ref:\s*([^\]]+)\]/i);
    if (qrMatch) {
        const refCode = qrMatch[1].trim();
        const cleanPhone = message.from.replace(/\D/g, '');

        console.log(`[QR/REF SCAN] Customer ${cleanPhone} used Reference: ${refCode}`);

        try {
            // Check if it's a layout or a staff member
            const layouts = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'layouts_data.json'), 'utf8'));
            const matchedLayout = layouts.find(l => l.Layout_Name.replace(/[^a-z0-9]/gi, '_').toUpperCase() === refCode.toUpperCase());
            
            const staff = getMasterData('Staff');
            const matchedStaff = staff.find(s => (s.Staff_ID || s.id || '').toUpperCase() === refCode.toUpperCase());

            const logName = matchedLayout ? matchedLayout.Layout_Name : 'Affiliate Visit';
            const logAffiliate = matchedStaff ? matchedStaff.Staff_ID : 'WhatsApp_QR';

            // 1. Log to QR Scans table (for analytics)
            db.run(`INSERT INTO qr_scans (layout_name, affiliate_code, ip_address, user_agent) VALUES (?, ?, ?, ?)`,
                [logName, logAffiliate, `Phone:${cleanPhone}`, 'WhatsApp_Bot_Ref']);
            
            // 2. CONNECT TO MASTER CRM: Auto-create or Update Lead
            // This merges the QR scan directly into your existing CRM system
            db.run(`INSERT INTO customers (phone, name, plot, location, status, last_interaction) 
                    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(phone) DO UPDATE SET 
                    status='QR Inquiry', 
                    plot=excluded.plot,
                    last_interaction=CURRENT_TIMESTAMP`,
                [cleanPhone, 'New Lead (QR)', matchedLayout ? matchedLayout.Layout_Name : 'Property Inquiry', matchedLayout ? matchedLayout.Location : '', 'QR Inquiry']);

            console.log(`[CRM SYNC] QR Scan for ${cleanPhone} synced to Master CRM.`);

            // 3. Auto-reply logic
            if (matchedLayout && matchedLayout['GPS Location']) {
                await message.reply(`📍 *GPS Location for ${matchedLayout.Layout_Name}*:\n\n${matchedLayout['GPS Location']}\n\nOur team will contact you shortly to assist with your site visit.`);
                return; 
            } else if (matchedStaff) {
                await message.reply(`👋 Welcome! You are now connected with our senior consultant *${matchedStaff.Name}*. \n\nHow can we help you today?`);
                return;
            }
        } catch(e) { console.error('[QR] Tracking error:', e.message); }
    }

    // Permanent physical logging for debug
    const logStr = `\n[${new Date().toISOString()}] fromMe:${message.fromMe} | from:${message.from} | body:${message.body.substring(0, 250)}`;
    const scratchDir = path.join(ROOT_DIR, 'scratch');
    if (!fs.existsSync(scratchDir)) fs.mkdirSync(scratchDir, { recursive: true });
    fs.appendFileSync(path.join(scratchDir, 'message_dump.log'), logStr);

    // Only log incoming to terminal, but process admin commands from both
    if (!message.fromMe) console.log(`[INCOMING] From: ${message.from}, Body: ${message.body.substring(0, 50)}...`);

    if (message.from === 'status@broadcast' || message.from.includes('@g.us')) {
        console.log(`[FILTER] Ignored (Status/Group)`);
        return;
    }

    let phone = message.from.replace(/\D/g, '');
    if (message.from.includes('@lid')) {
        try {
            const contact = await message.getContact();
            if (contact && contact.number) {
                phone = contact.number;
                console.log(`[LID UNMASK] ${message.from} -> ${phone}`);
            }
        } catch(e) {}
    }

    // ─── Voice Note Transcription ──────────────────────────────
    if (message.type === 'audio' || message.type === 'ptt') {
        try {
            const media = await message.downloadMedia();
            if (media) {
                const transcribed = await transcribeAudio(media, phone);
                if (transcribed) {
                    message.body = transcribed;
                    console.log(`[VOICE] Transcribed for ${phone}: "${transcribed.substring(0, 80)}"`);
                } else {
                    await message.reply("🎤 Sorry, I couldn't process that voice message. Please type your question.");
                    return;
                }
            } else { return; }
        } catch (e) {
            console.error(`[VOICE] Error processing audio from ${phone}: ${e.message}`);
            return;
        }
    }

    const userMsg = message.body.trim().toLowerCase();

    // ── SITE VISIT BOOKING ──
    if (await handleSiteVisitBooking(message, phone, userMsg)) {
        analyzeAndScoreLead(phone); // Background scoring
        return;
    }

    // ── STAFF / MANAGER COMMANDS ──
    const staff = getMasterData('Staff');
    const senderStaff = staff.find(s => String(s.Phone).replace(/\D/g, '') === phone);
    
    if (senderStaff) {
        // MD Status Check
        if (senderStaff.Dept === 'Managing Director' && (userMsg === 'status' || userMsg === 'report' || userMsg === 'summary')) {
            const report = await generateSystemReport();
            await message.reply(report);
            return;
        }
    }

    if (userStates[phone]?.managerLead && userStates[phone].step === 'MANAGER_INTRO') {
        // Bypass standard welcome/menu for manager leads
        userStates[phone].step = 'DONE'; 
    }

    // Auto-update bot log for clarity
    const bodyLower = message.body.trim().toLowerCase();
    if (bodyLower === 'status' || bodyLower === '!status' || bodyLower === 'status +' || bodyLower === '!status +') {
        const isAdmin = await checkIfAdmin(message);
        if (isAdmin) {
            if (bodyLower.includes('+')) {
                console.log(`[ADMIN COMMAND] Advanced Status requested by ${message.from}`);
                const report = await generateSystemReport();
                await message.reply(report);
            } else {
                console.log(`[ADMIN COMMAND] Status requested by ${message.from}`);
                await message.reply(`🟢 *DRD Property Genius Status*\n\nStatus: ONLINE & READY\nStarted At: ${BOT_START_TIME}`);
            }
            return;
        }
    }

    const handled = await handleAdminCommand(message);
    if (handled) return;

    // ── STAFF EXPENSE / GST QUICK-ENTRY ──
    const staffHandled = await handleStaffBotCommand(message, phone);
    if (staffHandled) return;

    // STOP THE INFINITE ALICE-IN-WONDERLAND LOOP
    // Ignore all other outgoing messages if they aren't admin commands so the bot never replies to itself.
    if (message.fromMe) return;

    // Phase 1: Logging & Tracking ───────────────────────
    // phone and userMsg are already defined above
    await logConversation(phone, 'USER', message.body, message);
    updateSessionMemory(phone, 'USER', message.body);
    // ─── Phase 1.5: Auto-Save Media Assets ───
    if (message.hasMedia) {
        try {
            const media = await message.downloadMedia();
            if (media) {
                const custDir = path.join(CUSTOMER_DOCS_DIR, phone);
                if (!fs.existsSync(custDir)) fs.mkdirSync(custDir, { recursive: true });
                
                const ext = media.mimetype.split('/')[1] || 'bin';
                const filename = `WA_ASSET_${Date.now()}.${ext}`;
                const fullPath = path.join(custDir, filename);
                
                fs.writeFileSync(fullPath, media.data, { encoding: 'base64' });
                console.log(`[ASSET AUTO-SAVE] Saved media from ${phone} to ${filename}`);

                // Update CRM: append filename to adhar field, mark last_interaction
                db.run(
                    `INSERT INTO customers (phone, adhar, last_interaction, status)
                     VALUES (?, ?, CURRENT_TIMESTAMP, 'Inquiry')
                     ON CONFLICT(phone) DO UPDATE SET
                       adhar = CASE WHEN adhar IS NULL OR adhar = '' THEN ? ELSE adhar || ', ' || ? END,
                       last_interaction = CURRENT_TIMESTAMP`,
                    [phone, filename, filename, filename],
                    (err) => { if (!err) console.log(`[CRM] Doc received from ${phone} saved to CRM`); }
                );
            }
        } catch (e) {
            console.error(`[ASSET ERROR] Failed to auto-save media from ${phone}: ${e.message}`);
        }
    }

    // ─── Payment Confirmation Detection ───────────────────────
    const paymentKeywords = ['paid', 'done', 'utr', 'screenshot', 'payment', 'transferred', 'gpay', 'phonepe', 'neft', 'paytm'];
    if (message.type === 'image' || paymentKeywords.some(kw => userMsg.includes(kw))) {
        handlePaymentConfirmation(phone, message); // non-blocking
    }

    // ─── Phase 2: Cooldown Tracking ───
    const customer = checkCustomer(phone);
    const now = Date.now();
    lastGreeted[phone] = now;


    // ─── Phase 0: Source Tracking ───
    if (userMsg.includes('[source:')) {
        const sourceMatch = message.body.match(/\[source:(\w+)\]/i);
        if (sourceMatch && sourceMatch[1]) {
            console.log(`[ANALYTICS] New Lead Origin detected: ${sourceMatch[1]}`);
            logSourceInterest(sourceMatch[1].toUpperCase());
        }
    }

    // ─── Phase 1: Custom Keyword Rules ───────────────────────
    try {
        const rulesPath = path.join(ROOT_DIR, 'keyword_rules.json');
        if (fs.existsSync(rulesPath)) {
            const rules = JSON.parse(fs.readFileSync(rulesPath, 'utf8'));
            const userMsgNoSpace = userMsg.replace(/\s+/g, '').toLowerCase();
            const matchedRule = rules.find(r => {
                const triggerLow = r.trigger.toLowerCase();
                const userMsgLow = userMsg.toLowerCase().trim();
                // Only trigger if message is EXACTLY the keyword, or if it's a very short message containing it
                const isExact = userMsgLow === triggerLow;
                const isShortMatch = userMsgLow.includes(triggerLow) && userMsg.length < 15;
                return isExact || isShortMatch;
            });
            if (matchedRule) {
                console.log(`[KEYWORD] Rule matched: ${matchedRule.trigger}`);
                // Dynamic help menus for both English "Help" and Tamil "உதவி"
                const isTamilHelp = matchedRule.trigger === 'உதவி';
                const isEnglishHelp = matchedRule.trigger.toLowerCase() === 'help';
                if (isEnglishHelp || isTamilHelp) {
                    // Tanglish triggers (Latin script but Tamil-language responses)
                    const TANGLISH = new Set(['vilai', 'map venuma', 'loan venuma', 'ullam']);
                    const isEnglishRule = t => /^[a-zA-Z\s]+$/.test(t) && !TANGLISH.has(t.toLowerCase());
                    const menuRules = rules.filter(r => {
                        if (r.trigger.toLowerCase() === 'help' || r.trigger === 'உதவி') return false;
                        // English help: English triggers only; Tamil help: Tamil/Tanglish triggers only
                        return isTamilHelp ? !isEnglishRule(r.trigger) : isEnglishRule(r.trigger);
                    });
                    const lines = menuRules.map(r => {
                        const firstLine = r.response.split('\n')[0].replace(/[*_]/g, '').trim();
                        const desc = firstLine.length > 45 ? firstLine.slice(0, 45) + '…' : firstLine;
                        return `• *${r.trigger}* — ${desc}`;
                    }).join('\n');
                    const helpReply = isTamilHelp
                        ? `🤖 *உதவி மெனு*\n\nகீழ்வரும் வார்த்தைகளை அனுப்பலாம்:\n\n${lines}\n\nநேரடியாக கேள்விகள் கேட்கலாம்! 😊`
                        : `🤖 *Quick Help Menu*\n\nType any keyword below for instant info:\n\n${lines}\n\nOr just chat — I'm always here to help! 😊`;
                    await message.reply(helpReply);
                    return;
                }
                await message.reply(matchedRule.response);
                return;
            }
        }
    } catch (e) { console.error("Keyword rule error:", e); }

    try {
        const dataObjects = await getPlotsData();
        const availablePlotsForKeywords = dataObjects.filter(d => d.Status && d.Status.toLowerCase().includes('available'));
        const layoutNames = [...new Set(availablePlotsForKeywords.map(d => d.Layout || d.Layout_Name).filter(Boolean))];
        let dynamicWords = [];
        layoutNames.forEach(l => l.split(' ').forEach(w => { if (w.length > 3) dynamicWords.push(w.toLowerCase()) }));


        const realEstateKeywords = botSettings.business_keywords || ['plot', 'house', 'cent', 'price', 'rate', 'layout', 'location', 'details', 'available', 'sqft', 'map', 'brochure', 'loan', 'bank', 'finance', 'emi', 'call', 'time', 'morning', 'evening', 'afternoon', 'after', 'before', ' am', ' pm', 'visit', 'site', 'hi', 'hello', 'hai', 'interested', ...dynamicWords];
        const userMsgNoSpace = userMsg.replace(/\s+/g, '').toLowerCase();
        const isRealEstateInquiry = realEstateKeywords.some(keyword => {
            const kwNoSpace = keyword.replace(/\s+/g, '').toLowerCase();
            return userMsgNoSpace.includes(kwNoSpace);
        });
        // Recognized states where the bot is waiting for a specific response (avoids filtering out numbers/selections)
        const activeSteps = ['AI_EXPECTING_ANSWER', 'MENU', 'EXPECTING_ANSWER', 'AWAITING_CALL_TIME', 'DONE'];
        const isWaitingForResponse = activeSteps.includes(userStates[phone]?.step);

        const botId = client.info.wid._serialized;
        const isDirectToBot = (message.to === botId) || (message.from === botId);
        const isAdmin = await checkIfAdmin(message);

        // Refined Admin/Keyword Filter: 
        // 1. If it's an admin and talking to the bot, ALWAYS proceed.
        // 2. If it's a customer, ignore if it doesn't contain keywords AND we aren't waiting for a lead response
        const isBusinessMsg = isRealEstateInquiry || isWaitingForResponse || (isAdmin && isDirectToBot);

        console.log(`[DEBUG] isBusinessMsg: ${isBusinessMsg}, isAdmin: ${isAdmin}, isDirect: ${isDirectToBot}`);

        if (isAdmin && isDirectToBot) {
            console.log(`[ADMIN CHECK] User is ADMIN. Proceeding with interaction.`);
        } else if (!isBusinessMsg) {
            console.log(`[FILTER] Message ignored (Non-business)`);
            return;
        }

        console.log(`[PROCESS] Starting AI logic for ${phone}...`);

        const configPath = path.join(ROOT_DIR, 'bot_config.json');
        let aiMode = 'online';
        if (fs.existsSync(configPath)) {
            try {
                const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
                aiMode = cfg.aiMode || 'online';
            } catch (e) { }
        }

        if (aiMode === 'fallback') {
            console.log(`[FLOW] Admin forced Local Fallback Template.`);
            await runLocalFallback(message, phone, userMsg);
            return;
        }

        // ─── Smart Retry + Model Failover ─────────────────────────
        let aiResponse = null;
        let lastError = null;

        // [NEW] Offline/Local Mode Override
        if (botSettings && botSettings.ai_mode === 'offline') {
            console.log(`[OFFLINE] 🏠 Using local menu for ${phone}`);
            await runLocalFallback(message, phone, userMsg);
            return;
        }

        for (let attempt = 0; attempt < AI_MODELS.length; attempt++) {
            try {
                aiModel = getAiModel();
                if (process.send) process.send({ type: 'aiModel', data: AI_MODELS[currentModelIndex] });
                console.log(`[AI] Attempt ${attempt + 1}/${AI_MODELS.length} using model: ${AI_MODELS[currentModelIndex]}`);


                // Re-initialize chat history with current model if needed
                if (!chatHistories[phone] || attempt > 0) {
                    // Format DB data as a clean, readable list for the AI
                    const rawData = await getPlotsData();
                    const liveData = rawData.map(r => {
                        const totalPrice = parseFloat(r.Total_Price) || 0;
                        const areaSqFt = parseFloat(r.Area_SqFt) || 0;
                        let priceStr = 'Contact for Price';
                        if (totalPrice > 0) {
                            const priceL = (totalPrice / 100000).toFixed(2);
                            if (areaSqFt > 0) {
                                const perCentL = ((totalPrice / areaSqFt) * 435.6 / 100000).toFixed(2);
                                priceStr = `Total ₹${priceL}L (₹${perCentL}L/Cent)`;
                            } else {
                                priceStr = `Total ₹${priceL}L`;
                            }
                        }
                        return `- Project: ${r.Layout_Name}, Plot: ${r.Plot_No || 'N/A'}, Area: ${areaSqFt} SqFt, Location: ${r.Location}, Price: ${priceStr}, Status: ${r.Status}, Facing: ${r.Facing || 'N/A'}`;
                    }).join('\n');

                    let initPrompt = getSystemPrompt().replaceAll('{PLOT_DATA}', liveData);

                    // [NEW] Load Project Knowledge from PDFs
                    const knowledgePath = path.join(ROOT_DIR, 'Project_Knowledge.txt');
                    let projectKnowledge = "";
                    if (fs.existsSync(knowledgePath)) {
                        projectKnowledge = fs.readFileSync(knowledgePath, 'utf8');
                    }
                    initPrompt = initPrompt.replaceAll('{PROJECT_KNOWLEDGE}', projectKnowledge);

                    // ── Lead Qualification Protocol ────────────────────────
                    initPrompt += `\n\n--- LEAD QUALIFICATION PROTOCOL ---
Before sharing detailed pricing, plot availability, brochures, or site visit arrangements, naturally gather these three things (ask one at a time):
1. Budget range (e.g., "5L-10L, 10L-20L, or above 20L?")
2. Preferred location or layout name
3. Purpose: Investment or Own Use
Once all three are collected, tag your response with: [PRE_QUALIFIED:budget=X,area=Y,purpose=Z]`;

                    // ── Language Policy (English-only responses) ──────────
                    initPrompt += `\n\n--- LANGUAGE POLICY ---
You may RECEIVE messages in Tamil script (தமிழ்) or Tanglish (Tamil words in English letters, e.g. "plot venumaa?", "enna rate", "site visit pannalam"). Understand them and respond to what they mean.
But your REPLY must always be in clear, simple English. NEVER reply in Tamil or Tanglish — CRM records and follow-up sales calls are conducted in English, so consistent English replies keep the conversation thread useful for the sales team.`;

                    let historyBuilder = [
                        { role: "user", parts: [{ text: initPrompt }] },
                        { role: "model", parts: [{ text: "Understood. I will act as DRD Property Genius and analyze the chat context using the provided plot data and detailed brochure knowledge." }] }
                    ];

                    // Use in-memory session (last N turns from settings) — faster and more controlled than WhatsApp fetch.
                    // Skipped only if read_previous_messages is explicitly set to false in bot_settings.json.
                    const _readPrev = getBotSettings().read_previous_messages !== false;
                    const session = _readPrev ? sessionMemory.get(phone) : null;
                    if (session && session.messages.length > 0) {
                        for (const m of session.messages) {
                            const geminiRole = m.role === 'USER' ? 'user' : 'model';
                            const last = historyBuilder[historyBuilder.length - 1];
                            // Gemini requires strictly alternating roles — merge consecutive same-role messages
                            if (last && last.role === geminiRole) {
                                last.parts[0].text += '\n\n' + m.text;
                            } else {
                                historyBuilder.push({ role: geminiRole, parts: [{ text: m.text }] });
                            }
                        }
                        console.log(`[AI] Using ${session.messages.length} in-memory context messages for ${phone}`);
                    } else if (_readPrev) {
                        // Fallback: fetch from WhatsApp if no session memory yet (only when reading context is enabled)
                        try {
                            const chatObj = await message.getChat();
                            const pastMsgs = await chatObj.fetchMessages({ limit: 10 });
                            for (let pMsg of pastMsgs) {
                                if (pMsg.id.id !== message.id.id && pMsg.body) {
                                    historyBuilder.push({
                                        role: pMsg.fromMe ? "model" : "user",
                                        parts: [{ text: pMsg.body }]
                                    });
                                }
                            }
                        } catch (histErr) {
                            console.log("[AI] Could not fetch previous messages for context");
                        }
                    }

                    chatHistories[phone] = aiModel.startChat({ history: historyBuilder });
                }

                const chat = chatHistories[phone];
                const result = await chat.sendMessage(message.body);
                aiResponse = result.response.text();
                console.log(`[AI] ✅ Response received from ${AI_MODELS[currentModelIndex]}`);

                // Track usage in Excel CRM
                logAIUsageToExcel(AI_MODELS[currentModelIndex]);

                break; // Success — exit retry loop

            } catch (retryErr) {
                lastError = retryErr;
                const errMsg = retryErr.message || '';
                const errorLog = `[${new Date().toISOString()}] AI Error (Model: ${AI_MODELS[currentModelIndex]}): ${errMsg}\n\n`;
                try { fs.appendFileSync(path.join(ROOT_DIR, 'scratch', 'ai_debug.log'), errorLog); } catch (err) { }

                console.log(`[AI] ❌ Model ${AI_MODELS[currentModelIndex]} failed: ${errMsg.substring(0, 80)}`);

                // Move to next backup model
                currentModelIndex = (currentModelIndex + 1) % AI_MODELS.length;

                if (attempt < AI_MODELS.length - 1) {
                    console.log(`[AI] ⏳ Waiting 3s before trying backup model: ${AI_MODELS[currentModelIndex]}...`);
                    await new Promise(r => setTimeout(r, 3000));
                }
            }
        }

        // If all models failed: wait 30s and retry once before local fallback
        if (!aiResponse) {
            console.log(`[AI] ⏳ All ${AI_MODELS.length} models failed. Waiting 30s before final retry...`);
            await new Promise(r => setTimeout(r, 30000));
            currentModelIndex = 0;
            try {
                aiModel = getAiModel();
                chatHistories[phone] = null; // force fresh context on retry
                const retryRaw = await getPlotsData();
                const retryData = retryRaw.map(r => {
                    const tp = parseFloat(r.Total_Price) || 0;
                    const sq = parseFloat(r.Area_SqFt) || 0;
                    const priceStr = tp > 0 ? `Total ₹${(tp/100000).toFixed(2)}L` : 'Contact for Price';
                    return `- Project: ${r.Layout_Name}, Plot: ${r.Plot_No || 'N/A'}, Area: ${sq} SqFt, Status: ${r.Status}, Price: ${priceStr}`;
                }).join('\n');
                let retryPrompt = getSystemPrompt().replaceAll('{PLOT_DATA}', retryData).replaceAll('{PROJECT_KNOWLEDGE}', '');
                chatHistories[phone] = aiModel.startChat({ history: [
                    { role: "user", parts: [{ text: retryPrompt }] },
                    { role: "model", parts: [{ text: "Understood." }] }
                ]});
                const retryResult = await chatHistories[phone].sendMessage(message.body);
                aiResponse = retryResult.response.text();
                logAIUsageToExcel(AI_MODELS[0]);
                console.log('[AI] ✅ 30s retry succeeded.');
            } catch (retryFinalErr) {
                console.log(`[FALLBACK] ❌ Final retry failed: ${retryFinalErr.message?.substring(0, 80)}`);
            }
        }

        if (!aiResponse) {
            console.log(`[FALLBACK] ❌ All retries exhausted. Using Local Fallback Template...`);
            await runLocalFallback(message, phone, userMsg);
            return;
        }

        // Context Awareness Check: Did the AI detect this as an office/personal chat?
        if (aiResponse.includes('[IGNORE_MSG]')) {
            console.log(`[AI] 🛑 Ignoring message from ${phone} (Office/Personal Conversation Context Detected)`);
            return;
        }

        console.log(`[AI] Raw response: ${aiResponse.substring(0, 50)}...`);

        const imageMatch = aiResponse.match(/\[SEND_IMAGE:\s*(.*?)\]/i);
        let layoutName = null;
        if (imageMatch) {
            layoutName = imageMatch[1].trim();
            aiResponse = aiResponse.replace(imageMatch[0], '').trim();
        }

        // Parse [PRE_QUALIFIED:budget=X,area=Y,purpose=Z] tag
        const qualMatch = aiResponse.match(/\[PRE_QUALIFIED:([^\]]+)\]/i);
        if (qualMatch) {
            const params = {};
            qualMatch[1].split(',').forEach(p => {
                const [k, v] = p.split('=');
                if (k && v) params[k.trim()] = v.trim();
            });
            db.run(`UPDATE customers SET status = 'Pre-Qualified', loan_details = ? WHERE phone = ?`,
                [JSON.stringify(params), phone.replace(/\D/g, '')]);
            console.log(`[QUALIFY] Lead ${phone} pre-qualified: ${qualMatch[1]}`);
            aiResponse = aiResponse.replace(qualMatch[0], '').trim();
        }

        if (aiResponse) {
            // Check for tags from AI
            let isHighlighted = false;
            if (aiResponse.includes('[HIGHLIGHT]')) {
                aiResponse = aiResponse.replace('[HIGHLIGHT]', '').trim();
                isHighlighted = true;
                console.log(`[CRM] Lead ${phone} HIGHLIGHTED (High Intent)`);
            }
            if (aiResponse.includes('[REQUEST_CALL]')) {
                aiResponse = aiResponse.replace('[REQUEST_CALL]', '').trim();
                isHighlighted = true; // Call request always highlights
                console.log(`[ALERT] Call requested by ${phone}`);
                const staff = getMasterData('Staff');
                const md = staff.find(s => s.Dept === 'Managing Director');
                if (md && process.send) {
                    process.send({ type: 'send_otp', data: { otp: `📞 CALL REQUEST from ${phone}`, adminPhone: String(md.Phone) } });
                }
            }

            await message.reply(aiResponse);
            await logConversation(phone, 'BOT', aiResponse, message);
            updateSessionMemory(phone, 'MODEL', aiResponse);

            // Trigger AI Lead Scoring asynchronously
            analyzeAndScoreLead(phone);


            // Auto-share location + visualizer when customer asks about location/map
            const locationTriggers = ['location', 'where is', 'where are', 'map', 'address', 'how to reach', 'how to come', 'directions', 'direction', 'navigate', 'route', 'gps', 'எங்கே', 'எங்க'];
            const isLocationQuery = botSettings.location_auto_share !== false &&
                locationTriggers.some(kw => userMsg.includes(kw));
            if (isLocationQuery) {
                try {
                    loadCompanySettings();
                    const mapsUrl = companySettings.mapsUrl || 'https://maps.app.goo.gl/7oKNZgKzV6oop1vlh';
                    const vizUrl = botSettings.visualizer_url || 'https://drdrealtors.github.io/drd-layouts/';
                    await new Promise(r => setTimeout(r, 800));
                    await client.sendMessage(phone, `📍 *Our Location:*\n${mapsUrl}`);
                    await new Promise(r => setTimeout(r, 600));
                    await client.sendMessage(phone, `🗺️ *View All Our Layouts Online:*\n${vizUrl}`);
                    updateSessionMemory(phone, 'BOT', `📍 Location: ${mapsUrl}\n🗺️ Visualizer: ${vizUrl}`);
                    if (chatHistories[phone]) delete chatHistories[phone];
                    console.log(`[LOCATION] Auto-shared maps + visualizer to ${phone}`);
                } catch (locErr) {
                    console.error('[LOCATION] Failed to send location/visualizer:', locErr.message);
                }
            }

            // [PROACTIVE LEAD CAPTURE]
            const contact = await message.getContact();
            logInquiryToExcel(contact.number || phone, {
                name: contact.pushname || contact.name || "Customer",
                layout: userStates[phone]?.lastLayout || "Inquiry",
                budget: "Talking...",
                lastMsg: message.body,
                highlighted: isHighlighted ? 1 : 0
            });
        }

        if (userStates[phone]?.step === 'AI_EXPECTING_ANSWER') {
            await sendTaglineImage(phone, client);
            userStates[phone].step = 'DONE';
        }

        if (layoutName) {
            try {
                userStates[phone] = userStates[phone] || {};
                userStates[phone].lastLayout = layoutName;
                let targetResult = findVisualForLayout(layoutName, IMAGES_DIR) || findVisualForLayout(layoutName, path.join(IMAGES_DIR, '01 All Layouts'));
                if (targetResult) {
                    if (targetResult.type === 'directory') {
                        for (const file of targetResult.files) {
                            try {
                                if (client && client.pupPage && !client.pupPage.isClosed()) {
                                    const fullPath = path.join(targetResult.path, file);
                                    if (fs.existsSync(fullPath) && fs.lstatSync(fullPath).isFile()) {
                                        const media = MessageMedia.fromFilePath(fullPath);
                                        await client.sendMessage(phone, media);
                                        await new Promise(r => setTimeout(r, 1500));
                                    }
                                }
                            } catch (err) { console.error(`[MEDIA ERROR] Failed to send ${file}:`, err.message); }
                        }
                    } else {
                        try {
                            if (client && client.pupPage && !client.pupPage.isClosed()) {
                                if (fs.existsSync(targetResult.path) && fs.lstatSync(targetResult.path).isFile()) {
                                    const media = MessageMedia.fromFilePath(targetResult.path);
                                    await client.sendMessage(phone, media);
                                }
                            }
                        } catch (err) { console.error('[MEDIA ERROR] Failed to send single media:', err.message); }
                    }
                    userStates[phone].step = 'AI_EXPECTING_ANSWER';
                    try {
                        await client.sendMessage(phone, `(MAP) Site Plan: ${(botSettings.visualizer_url || 'https://drdrealtors.github.io/drd-layouts/')}`);
                    } catch (err) { console.error('[MEDIA ERROR] Failed to send MAP URL:', err.message); }
                }
            } catch (mediaErr) {
                console.error('[MEDIA BLOCK ERROR] Image send block failed:', mediaErr.message);
                // Isolated — does not cascade to runLocalFallback
            }
        }
    } catch (e) {
        // Unexpected critical error
        const errorLog = `[${new Date().toISOString()}] CRITICAL Error: ${e.message}\nStack: ${e.stack}\n\n`;
        try { fs.appendFileSync(path.join(ROOT_DIR, 'scratch', 'ai_debug.log'), errorLog); } catch (err) { }
        console.error(`[CRITICAL] Unexpected error: ${e.message}`);
        await runLocalFallback(message, phone, userMsg);
    }
});

async function generateSystemReport() {
    let leadsCount = 0, aiTotal = 0, crashCount = 0;
    try {
        const leadsPath = path.join(ROOT_DIR, 'Customer_Inquiries.xlsx');
        if (fs.existsSync(leadsPath)) {
            const wb = xlsx.readFile(leadsPath);
            leadsCount = xlsx.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]).length;
            if (wb.SheetNames.includes('AI_Usage')) {
                aiTotal = xlsx.utils.sheet_to_json(wb.Sheets['AI_Usage']).reduce((s, r) => s + (r.Requests || 0), 0);
            }
        }
        const crashPath = path.join(ROOT_DIR, 'CRASH_REPORT_BOT.txt');
        if (fs.existsSync(crashPath)) crashCount = (fs.readFileSync(crashPath, 'utf8').match(/\[CRASH\]/g) || []).length;
    } catch (e) { }

    return `📊 *DRD SYSTEM QUICK STATUS*
---------------------------------------
🟢 Status: ONLINE
📑 Total Leads: ${leadsCount}
🤖 AI Requests: ${aiTotal}
❌ System Crashes: ${crashCount}
---------------------------------------
_Property Genius Active_`;
}

async function generateDetailedReport() {
    const uptime = Math.floor((Date.now() - BOT_START_TIME_MS) / 3600000);
    const today = new Date().toLocaleDateString('en-GB');
    
    let totalLeadsToday = 0;
    let highIntentLeads = 0;
    let topLayout = "General Interest";
    const layoutCounts = {};

    try {
        const leads = await new Promise((resolve) => {
            db.all(`SELECT * FROM customers WHERE created_at >= date('now', 'start of day')`, [], (err, rows) => resolve(rows || []));
        });
        totalLeadsToday = leads.length;
        highIntentLeads = leads.filter(l => l.highlighted === 1).length;

        leads.forEach(l => {
            if (l.plot) layoutCounts[l.plot] = (layoutCounts[l.plot] || 0) + 1;
        });
        
        const top = Object.entries(layoutCounts).sort((a,b) => b[1] - a[1])[0];
        if (top) topLayout = top[0];

    } catch (e) { console.error("Report Generation Error:", e); }

    const status = client.info ? "🟢 ONLINE" : "🔴 OFFLINE";

    return `📊 *DRD SYSTEM AUDIT REPORT* (${today})
---------------------------------------
🤖 Bot Status: ${status}
⏱️ Uptime: ${uptime} Hours
👥 New Leads Today: ${totalLeadsToday}
🔥 High Intent Leads: ${highIntentLeads}
📍 Hot Layout: ${topLayout}
🤖 AI Failover: ${currentModelIndex > 0 ? "⚠️ ACTIVE" : "✅ STABLE"}
🧠 Memory: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB
---------------------------------------
_Audit ID: ${Date.now().toString(36).toUpperCase()}_`;
}


const BOT_START_TIME_MS = Date.now();

process.on('message', async (msg) => {
    if (msg.type === 'selftest_ping') {
        if (process.send) {
            process.send({
                type: 'selftest_pong',
                requestId: msg.requestId,
                data: { ok: true, uptime: Math.floor(process.uptime()), pid: process.pid }
            });
        }
        return;
    }

    if (msg.type === 'fetch_eb_bill') {
        const { serviceNo, region, requestId } = msg;
        console.log(`[BOT] EB Fetch Request: ServiceNo=${serviceNo}, Region=${region}`);
        
        let browser;
        try {
            const puppeteer = require('puppeteer');
            browser = await puppeteer.launch({
                headless: "new",
                executablePath: executablePath,
                args: ['--no-sandbox', '--disable-setuid-sandbox']
            });
            const page = await browser.newPage();
            
            // TANGEDCO Bill Status Page
            await page.goto('https://www.tangedco.org/en/tangedco/consumer-services/bill-status/', { waitUntil: 'networkidle2', timeout: 30000 });
            
            // Fill form
            await page.select('#region', region);
            await page.type('#consumerNo', serviceNo);
            
            // Note: TANGEDCO often has a captcha. If so, we might need a workaround or user intervention.
            // For now, let's try to submit if no captcha is present or if it's bypassable.
            // Many gov sites are hard to scrape due to captcha.
            
            await Promise.all([
                page.click('#submit'),
                page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 })
            ]);

            // Extract data
            const data = await page.evaluate(() => {
                const rows = Array.from(document.querySelectorAll('table tr'));
                const result = { ok: true };
                rows.forEach(row => {
                    const text = row.innerText;
                    if (text.includes('Total Amount')) result.amount = text.split(':').pop().trim();
                    if (text.includes('Due Date')) result.dueDate = text.split(':').pop().trim();
                    if (text.includes('Status')) result.status = text.split(':').pop().trim();
                });
                return result;
            });

            if (process.send) {
                process.send({ type: 'eb_bill_res', requestId, data });
            }
        } catch (e) {
            console.error('[BOT] EB Fetch Failed:', e.message);
            if (process.send) {
                process.send({ type: 'eb_bill_res', requestId, data: { ok: false, msg: "Failed to fetch from TANGEDCO. Captcha or site change might be blocking." } });
            }
        } finally {
            if (browser) await browser.close();
        }
        return;
    }

    if (msg.type === 'focus_whatsapp') {
        console.log(`[BOT] Focus request received. Bringing WhatsApp window to front...`);
        try {
            const page = await client.pupPage;
            if (page) {
                await page.bringToFront();
                console.log(`[BOT] Page brought to front successfully.`);
            } else {
                console.log(`[BOT] Puppeteer page not found, cannot focus.`);
            }
        } catch (err) {
            console.error(`[BOT] Failed to focus window: ${err.message}`);
        }
        return;
    }
    if (msg.type === 'request_legal_approval') {
        const { docId, adminPhone, fileName, plotInfo } = msg.data;
        const target = adminPhone.includes('@') ? adminPhone : `${adminPhone}@c.us`;
        const docPath = path.join(ROOT_DIR, 'legal_docs', fileName);
        
        console.log(`[LEGAL] Requesting approval for DocID=${docId} from ${target}`);
        
        try {
            if (fs.existsSync(docPath)) {
                const media = MessageMedia.fromFilePath(docPath);
                await client.sendMessage(target, media);
            }
            
            const text = `⚖️ *LEGAL DOCUMENT APPROVAL REQUEST*\n\n` +
                         `Plot: ${plotInfo}\n` +
                         `Document: ${fileName}\n\n` +
                         `Please reply with:\n` +
                         `✅ *Approve ${docId}*\n` +
                         `❌ *Reject ${docId}*`;
            
            await client.sendMessage(target, text);
            console.log(`[LEGAL] Approval request sent to ${target}`);
        } catch (err) {
            console.error(`[LEGAL] FAILED to send approval request: ${err.message}`);
        }
        return;
    }

    
        if (msg.type === 'send_pdf_quotation') {
            const { target, htmlPath, filename, caption, jobId } = msg.data;
            console.log(`[QUOTATION] Generating PDF from ${htmlPath} for ${target}`);

            let pdfBrowser = null;
            let page = null;
            try {
                // Use puppeteer-core with the same Chrome that WhatsApp already downloaded.
                // We MUST use a separate browser instance — sharing client.pupBrowser causes
                // file:/// security blocks and corrupts the WhatsApp session page context.
                const puppeteerCore = require('puppeteer-core');

                // Get the Chrome executable path from the running WhatsApp browser process
                const execPath = client.pupBrowser?.process()?.spawnfile
                    || client.pupBrowser?.executablePath?.()
                    || null;

                if (!execPath) throw new Error('Could not find Chrome executable from WhatsApp bot');

                pdfBrowser = await puppeteerCore.launch({
                    executablePath: execPath,
                    headless: true,
                    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage',
                           '--disable-web-security', '--allow-file-access-from-files']
                });

                page = await pdfBrowser.newPage();
                page.setDefaultTimeout(30000);

                const fileUrl = 'file:///' + htmlPath.replace(/\\/g, '/');
                await page.goto(fileUrl, { waitUntil: 'networkidle0', timeout: 30000 });

                // page.pdf() returns Uint8Array in newer Chromium — Buffer.from() handles both
                const pdfResult = await page.pdf({
                    format: 'A4',
                    printBackground: true,
                    margin: { top: '10mm', bottom: '10mm', left: '10mm', right: '10mm' }
                });
                const base64Pdf = Buffer.from(pdfResult).toString('base64');

                const media = new MessageMedia('application/pdf', base64Pdf, filename || 'Quotation.pdf');
                const msgCaption = caption || `📄 *Price Quotation*\n\nPlease find your property quotation from *DRD Realtors* attached.\n\nFor queries, contact us anytime. Thank you! 🙏`;
                await client.sendMessage(target, media, { caption: msgCaption });
                console.log(`[QUOTATION] PDF successfully sent to ${target}`);

                if (fs.existsSync(htmlPath)) fs.unlinkSync(htmlPath);
                if (jobId && process.send) process.send({ type: 'pdf_done', jobId, ok: true, target });
            } catch (err) {
                console.error(`[QUOTATION ERROR] ${err.message}`);
                if (jobId && process.send) process.send({ type: 'pdf_done', jobId, ok: false, error: err.message, target });
                if (htmlPath && fs.existsSync(htmlPath)) { try { fs.unlinkSync(htmlPath); } catch(e){} }
            } finally {
                // Close only the PDF browser — NEVER touch client.pupBrowser (WhatsApp session)
                if (page)       await page.close().catch(() => {});
                if (pdfBrowser) await pdfBrowser.close().catch(() => {});
            }
            return;
        }

        if (msg.type === 'send_otp') {
        const { otp, adminPhone } = msg.data;
        const target = adminPhone.includes('@') ? adminPhone : `${adminPhone}@c.us`;
        console.log(`[AUTH] Attempting to send OTP to ${target}...`);
        try {
            await client.sendMessage(target, `🔐 *DRD DEVELOPER AUTH*\n\nYour One-Time Password is: *${otp}*\n\nValid for 5 minutes. Do not share this code.`);
            console.log(`[AUTH] OTP successfully sent to ${target}`);
        } catch (err) {
            console.error(`[AUTH] FAILED to send OTP: ${err.message}`);
        }
        return;
    }
    if (msg.type === 'send_password_otp') {
        const { otp, phone, name } = msg.data;
        const target = phone.includes('@') ? phone : `${phone}@c.us`;
        console.log(`[AUTH] Sending password reset OTP to ${target}...`);
        try {
            await client.sendMessage(target,
                `🔑 *DRD Property Genius*\n\nHi ${name || 'there'},\n\nYour password reset OTP is: *${otp}*\n\nValid for 5 minutes. Do not share this code.\n\n_DRD Realtors_`);
            console.log(`[AUTH] Password reset OTP sent to ${target}`);
        } catch (err) {
            console.error(`[AUTH] Failed to send password reset OTP: ${err.message}`);
        }
        return;
    }
    if (msg.type === 'send_admin_report') {
        const { adminPhone } = msg.data;
        const target = adminPhone.includes('@') ? adminPhone : `${adminPhone}@c.us`;
        console.log(`[AUTH] Attempting to dispatch Admin Report to ${target}...`);
        try {
            const report = await generateSystemReport();
            await client.sendMessage(target, report);
            console.log(`[AUTH] Admin Report successfully sent to ${target}`);
        } catch (err) {
            console.error(`[AUTH] FAILED to dispatch Report: ${err.message}`);
        }
        return;
    }
    if (msg.type === 'send_plot_share' || msg.type === 'send_whatsapp') {
        const { target, text, mediaPaths } = msg.data;
        const jid = formatJid(target);
        
        if (!client.info) {
            console.error(`[SEND] FAILED: Bot not logged in. Cannot send to ${jid}`);
            if (process.send) process.send({ type: 'share_error', target: jid, msg: 'WhatsApp Bot not logged in / connected.' });
            return;
        }

        console.log(`[SEND] Dispatching to ${jid}. Media items: ${mediaPaths?.length || 0}`);
        try {
            // 1. Send Text
            if (text) {
                await client.sendMessage(jid, text);
                // Track admin-sent messages so the AI retains context when customer replies
                const rPhone = jid.replace('@c.us', '').replace(/\D/g, '');
                if (rPhone) {
                    updateSessionMemory(rPhone, 'BOT', text);
                    if (chatHistories[rPhone]) delete chatHistories[rPhone]; // force rebuild with updated context
                }
            }

            // 2. Send Media
            if (mediaPaths && Array.isArray(mediaPaths)) {
                for (const p of mediaPaths) {
                    if (fs.existsSync(p)) {
                        if (client.pupPage && !client.pupPage.isClosed()) {
                            const media = MessageMedia.fromFilePath(p);
                            // Ensure filename is preserved for documents
                            if (p.toLowerCase().endsWith('.pdf')) {
                                media.filename = path.basename(p);
                                media.mimetype = 'application/pdf';
                            }
                            await client.sendMessage(jid, media);
                            console.log(`[SEND] Media file sent: ${path.basename(p)}`);
                        }
                    } else {
                        console.error(`[SEND] Media file missing at path: ${p}`);
                    }
                }
            }
            console.log(`[SEND] Batch successfully sent to ${jid}`);
            if (process.send) process.send({ type: 'share_success', target: jid });
        } catch (err) {
            console.error(`[SEND] FAILED to send to ${jid}: ${err.message}`);
            if (process.send) process.send({ type: 'share_error', target: jid, msg: err.message });
        }
        return;
    }


    if (msg.type === 'get_chat_history') {
        const { phone, requestId } = msg.data;
        const jid = formatJid(phone);
        try {
            const chat = await client.getChatById(jid);
            const msgs = await chat.fetchMessages({ limit: 25 });
            const messages = msgs.map(m => ({
                body: m.body || '',
                fromMe: m.fromMe,
                timestamp: m.timestamp,
                type: m.type,
                hasMedia: m.hasMedia,
                author: m.fromMe ? 'DRD Bot' : (m.notifyName || phone)
            }));
            if (process.send) process.send({ type: 'chat_history_response', requestId, messages });
        } catch (err) {
            console.error(`[CHAT HISTORY] Failed for ${jid}: ${err.message}`);
            if (process.send) process.send({ type: 'chat_history_response', requestId, messages: [], error: err.message });
        }
        return;
    }

    if (msg.type === 'reload_settings') {
        console.log("[BOT] Reloading Company Settings...");
        loadCompanySettings();
        return;
    }


    if (msg.type === 'send_notification') {
        const { phone: notifPhone, message: notifMsg } = msg;
        const jid = notifPhone.includes('@') ? notifPhone : `${notifPhone}@c.us`;
        try {
            await client.sendMessage(jid, notifMsg);
            // Track in session so AI has context when customer replies
            const rPhone = notifPhone.replace(/\D/g, '');
            if (rPhone) {
                updateSessionMemory(rPhone, 'BOT', notifMsg);
                if (chatHistories[rPhone]) delete chatHistories[rPhone];
            }
            console.log(`[NOTIF] ✅ Sent notification to ${notifPhone}`);
            if (process.send) process.send({ type: 'notif_sent', phone: notifPhone, ok: true });
        } catch (e) {
            console.error(`[NOTIF] ❌ Failed for ${notifPhone}: ${e.message}`);
            if (process.send) process.send({ type: 'notif_sent', phone: notifPhone, ok: false, err: e.message });
        }
        return;
    }

    if (msg.type === 'broadcast') {
        const content = msg.data;
        console.log(`[BROADCAST] Starting campaign: "${content.substring(0, 30)}..."`);

        try {
            const filePath = path.join(DATA_ROOT, 'Customer_Inquiries.xlsx');
            if (!fs.existsSync(filePath)) return;

            const workbook = xlsx.readFile(filePath);
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const data = xlsx.utils.sheet_to_json(sheet);

            // Get unique phone numbers
            const uniqueNumbers = [...new Set(data.map(lead => String(lead.Phone).replace(/\D/g, '')))];
            console.log(`[BROADCAST] Found ${uniqueNumbers.length} unique targets.`);

            for (let num of uniqueNumbers) {
                try {
                    if (num.length < 10) continue;
                    const jid = num.includes('@c.us') ? num : `${num}@c.us`;
                    await client.sendMessage(jid, content);
                    console.log(`[BROADCAST] Sent to ${num}`);
                    // Safety delay: 1.5 seconds per message to avoid ban
                    await new Promise(r => setTimeout(r, 1500));
                } catch (e) {
                    console.error(`[BROADCAST] Failed for ${num}:`, e.message);
                }
            }
            console.log(`[BROADCAST] Campaign completed.`);
        } catch (e) {
            console.error("[BROADCAST] Error in campaign thread:", e);
        }
    }
});

// ─── SCHEDULED MESSAGES PROCESSOR ────────────────────
async function scheduleDripCampaigns(phone) {
    console.log(`[DRIP] Scheduling campaigns for new lead: ${phone}`);
    db.all(`SELECT * FROM drip_campaigns WHERE is_active = 1`, [], (err, campaigns) => {
        if (err || !campaigns) return;
        
        campaigns.forEach(c => {
            const scheduledDate = new Date();
            scheduledDate.setDate(scheduledDate.getDate() + (c.days_offset || 0));
            const dateStr = scheduledDate.toISOString().split('T')[0];
            
            db.run(`INSERT INTO scheduled_messages (customer_phone, campaign_id, message_text, media_path, scheduled_date, status)
                    VALUES (?, ?, ?, ?, ?, 'Pending')`,
                    [phone, c.id, c.message_text, c.media_path, dateStr]);
            console.log(`[DRIP] Scheduled "${c.name}" for ${phone} on ${dateStr}`);
        });
    });
}

async function processScheduledMessages() {
    if (!client.info) return; // Wait for login

    const today = new Date().toISOString().split('T')[0];
    console.log(`[SCHEDULER] Checking for pending messages for ${today}...`);

    db.all(`SELECT * FROM scheduled_messages WHERE status = 'Pending' AND scheduled_date <= ?`, [today], async (err, rows) => {
        if (err) {
            console.error(`[SCHEDULER] DB Error: ${err.message}`);
            return;
        }

        if (rows.length === 0) {
            console.log(`[SCHEDULER] No pending messages.`);
            return;
        }

        console.log(`[SCHEDULER] Found ${rows.length} messages to process.`);

        for (const msg of rows) {
            try {
                const jid = msg.customer_phone.includes('@c.us') ? msg.customer_phone : `${msg.customer_phone}@c.us`;
                
                // Send Media if exists
                if (msg.media_path && fs.existsSync(msg.media_path)) {
                    const media = MessageMedia.fromFilePath(msg.media_path);
                    await client.sendMessage(jid, media);
                }

                // Send Text
                if (msg.message_text) {
                    await client.sendMessage(jid, msg.message_text);
                }

                db.run(`UPDATE scheduled_messages SET status = 'Sent', sent_at = CURRENT_TIMESTAMP WHERE id = ?`, [msg.id]);
                console.log(`[SCHEDULER] Successfully sent to ${msg.customer_phone}`);
                
                // Rate limiting delay
                await new Promise(r => setTimeout(r, 5000));
            } catch (err) {
                console.error(`[SCHEDULER] Failed for ${msg.customer_phone}: ${err.message}`);
                db.run(`UPDATE scheduled_messages SET status = 'Failed', error = ? WHERE id = ?`, [err.message, msg.id]);
            }
        }
    });
}

// Check every 30 minutes
setInterval(processScheduledMessages, 30 * 60 * 1000);

_startWatchdog();
client.initialize();
