const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const axios = require('axios');

// Reject non-admin callers on sensitive endpoints. Logs leak customer
// phones, IPC traffic, and SMTP details, so they must not be visible to
// regular roles.
function adminOnly(req, res, next) {
    const role = req.session?.userRole;
    if (role === 'admin' || role === 'super_admin') return next();
    return res.status(403).json({ ok: false, error: 'Admin access required' });
}

// System Routes: Logs, Diagnostics, and Config
router.get('/ping', (req, res) => {
    res.json({ ok: true, msg: "Pong! Server is active.", time: new Date().toLocaleTimeString() });
});

router.get('/diagnostics/logs', adminOnly, (req, res) => {
    try {
        // Prefer in-memory logs (always fresh for current session)
        const memoryLogs = req.app.get('logs');
        if (memoryLogs && memoryLogs.length > 0) {
            return res.json({ ok: true, logs: memoryLogs.map(e => `[${e.time}] ${e.msg}`) });
        }

        const rootDir = req.app.get('ROOT_DIR');
        const logPath = path.join(rootDir, 'server_log.txt');
        
        if (!fs.existsSync(logPath)) {
            return res.json({ ok: true, logs: [] });
        }
        
        // Read last 500 lines
        const content = fs.readFileSync(logPath, 'utf8');
        const lines = content.split('\n').filter(Boolean);
        const lastLines = lines.slice(-500);
        
        res.json({ ok: true, logs: lastLines });
    } catch (e) { 
        res.status(500).json({ ok: false, msg: "Error reading logs: " + e.message }); 
    }
});

router.post('/diagnostics/clear', adminOnly, (req, res) => {
    try {
        const rootDir = req.app.get('ROOT_DIR');
        const logPath = path.join(rootDir, 'server_log.txt');
        fs.writeFileSync(logPath, `[RESET] Log cleared at ${new Date().toISOString()}\n`);
        const pushLog = req.app.get('pushLog');
        if (pushLog) pushLog("🧹 System: Persistent log file cleared.");
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

router.get('/version', (req, res) => {
    try {
        const rootDir = req.app.get('ROOT_DIR');
        const vPath = path.join(__dirname, '../version.json');
        if (fs.existsSync(vPath)) {
            res.json(JSON.parse(fs.readFileSync(vPath, 'utf8')));
        } else {
            res.json({ version: "1.4.0" });
        }
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

router.get('/check-update', async (req, res) => {
    try {
        const rootDir = req.app.get('ROOT_DIR');
        const vPath = path.join(__dirname, '../version.json');

        if (!fs.existsSync(vPath)) return res.json({ ok: false, msg: 'version.json not found' });
        const localVersion = JSON.parse(fs.readFileSync(vPath, 'utf8')).version;

        // Read GitHub URL from Developer_Details.txt (configurable)
        let githubUrl = null;
        const devPath = path.join(rootDir, 'Developer_Details.txt');
        if (fs.existsSync(devPath)) {
            const lines = fs.readFileSync(devPath, 'utf8').split('\n');
            const urlLine = lines.find(l => l.trim().toLowerCase().startsWith('update_url:'));
            if (urlLine) githubUrl = urlLine.split(':').slice(1).join(':').trim();
        }

        if (!githubUrl) {
            return res.json({ ok: false, msg: 'Update URL not configured. Please set it in Developer Options.' });
        }

        const response = await axios.get(githubUrl, { timeout: 8000 }).catch(() => null);

        if (response && response.data && response.data.version) {
            const remoteVersion = response.data.version;
            const hasUpdate = remoteVersion !== localVersion;
            const download_url = response.data.download_url || null;
            res.json({ ok: true, local: localVersion, remote: remoteVersion, hasUpdate, url: githubUrl, download_url });
        } else {
            res.json({ ok: false, msg: 'Could not reach update server. Check the URL in Developer Options.' });
        }
    } catch (e) { res.json({ ok: false, msg: e.message }); }
});

// Save the GitHub Update URL to Developer_Details.txt
router.post('/system/update-url', adminOnly, (req, res) => {
    try {
        const rootDir = req.app.get('ROOT_DIR');
        const { url } = req.body;
        if (!url) return res.status(400).json({ ok: false, msg: 'URL is required' });

        const devPath = path.join(rootDir, 'Developer_Details.txt');
        let lines = fs.existsSync(devPath) ? fs.readFileSync(devPath, 'utf8').split('\n') : [];

        // Replace or append the Update_URL line
        const idx = lines.findIndex(l => l.trim().toLowerCase().startsWith('update_url:'));
        if (idx > -1) {
            lines[idx] = `Update_URL: ${url}`;
        } else {
            lines.push(`Update_URL: ${url}`);
        }

        fs.writeFileSync(devPath, lines.join('\n'));

        const pushLog = req.app.get('pushLog');
        if (pushLog) pushLog(`🔄 Developer: Update URL set to ${url}`);
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

// ── Online update: progress + download-apply ─────────────────────────────────
const os = require('os');
let _updateProgress = { pct: 0, phase: 'idle' };

router.get('/system/update-progress', (req, res) => {
    res.json(_updateProgress);
});

router.post('/system/download-apply-update', adminOnly, async (req, res) => {
    const rootDir    = req.app.get('ROOT_DIR');
    const pushLog    = req.app.get('pushLog');

    // Read saved update URL (points to latest.json)
    let latestUrl = null;
    try {
        const devPath = path.join(rootDir, 'Developer_Details.txt');
        if (fs.existsSync(devPath)) {
            const urlLine = fs.readFileSync(devPath, 'utf8').split('\n')
                .find(l => l.trim().toLowerCase().startsWith('update_url:'));
            if (urlLine) latestUrl = urlLine.split(':').slice(1).join(':').trim();
        }
    } catch (_) {}

    if (!latestUrl) {
        return res.status(400).json({ ok: false, error: 'Update URL not configured. Set it in Developer Options → Update Server Config.' });
    }

    try {
        _updateProgress = { pct: 5, phase: 'fetching' };

        // 1. Fetch latest.json
        const latestRes = await axios.get(latestUrl, { timeout: 10000 });
        const latest    = latestRes.data;
        if (!latest.patch_url) {
            return res.status(400).json({ ok: false, error: 'latest.json has no patch_url field.' });
        }

        _updateProgress = { pct: 10, phase: 'downloading' };

        // 2. Download zip
        const zipRes = await axios.get(latest.patch_url, {
            responseType: 'arraybuffer',
            timeout: 120000,
            onDownloadProgress: (e) => {
                if (e.total) _updateProgress = { pct: Math.round(10 + (e.loaded / e.total) * 75), phase: 'downloading' };
            }
        });

        _updateProgress = { pct: 87, phase: 'extracting' };

        // 3. Extract zip to temp dir
        const extractDir = path.join(os.tmpdir(), 'PG_OnlinePatch_' + Date.now());
        fs.mkdirSync(extractDir, { recursive: true });
        const AdmZip = require('adm-zip');
        new AdmZip(Buffer.from(zipRes.data)).extractAllTo(extractDir, true);

        _updateProgress = { pct: 90, phase: 'applying' };

        // 4. Read manifest
        const manifestPath = path.join(extractDir, 'patch_manifest.json');
        if (!fs.existsSync(manifestPath)) {
            return res.status(400).json({ ok: false, error: 'patch_manifest.json not in zip.' });
        }
        const { files } = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

        // 5. Resolve install root:
        //    Packaged:  ROOT_DIR = .../Property Genius/resources/  → install root = ROOT_DIR/..
        //    Dev:       ROOT_DIR = project root                    → files applied relative to project root
        const installRoot = path.join(rootDir, '..');

        // 6. Backup + apply
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupDir = path.join(rootDir, 'backups', `online-patch-${timestamp}`);
        fs.mkdirSync(backupDir, { recursive: true });

        const results = [];
        for (const f of files) {
            const srcPath  = path.join(extractDir, f.src);
            const destPath = path.join(installRoot, f.dest);
            try {
                if (fs.existsSync(destPath)) {
                    const bk = path.join(backupDir, f.dest);
                    fs.mkdirSync(path.dirname(bk), { recursive: true });
                    fs.copyFileSync(destPath, bk);
                }
                fs.mkdirSync(path.dirname(destPath), { recursive: true });
                fs.copyFileSync(srcPath, destPath);
                results.push({ label: f.label, dest: f.dest, ok: true });
            } catch (e) {
                results.push({ label: f.label, dest: f.dest, ok: false, error: e.message });
            }
        }

        try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (_) {}
        _updateProgress = { pct: 100, phase: 'done' };

        const allOk = results.every(r => r.ok);
        if (pushLog) pushLog(`🔄 Online update v${latest.version} ${allOk ? 'applied ✅' : 'completed with errors ⚠️'}`);
        res.json({ ok: allOk, results, backupDir, version: latest.version });

    } catch (e) {
        _updateProgress = { pct: 0, phase: 'error' };
        res.status(500).json({ ok: false, error: e.message, results: [] });
    }
});

// Version Manager — read + write version.json from the dashboard
router.get('/system/version', (req, res) => {
    try {
        const vPath = path.join(__dirname, '../version.json');
        if (fs.existsSync(vPath)) {
            res.json(JSON.parse(fs.readFileSync(vPath, 'utf8')));
        } else {
            res.json({ version: '1.0.0', date: '', notes: '', download_url: '' });
        }
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

router.post('/system/version', adminOnly, (req, res) => {
    try {
        const { version, date, notes, download_url } = req.body;
        if (!version) return res.status(400).json({ ok: false, msg: 'Version is required' });
        const vPath = path.join(__dirname, '../version.json');
        const current = fs.existsSync(vPath) ? JSON.parse(fs.readFileSync(vPath, 'utf8')) : {};
        const updated = {
            ...current,
            version,
            date: date || new Date().toISOString().split('T')[0],
            notes: notes || current.notes || '',
        };
        if (download_url !== undefined) updated.download_url = download_url;
        fs.writeFileSync(vPath, JSON.stringify(updated, null, 2));
        const pushLog = req.app.get('pushLog');
        if (pushLog) pushLog(`📦 Version bumped to v${version} — ready for deployment`);
        res.json({ ok: true, data: updated });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

module.exports = router;
