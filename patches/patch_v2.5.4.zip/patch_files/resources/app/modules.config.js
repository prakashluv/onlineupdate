// ─── Module Registry (Single Source of Truth) ──────────────
// Adding a new module: append one entry to MODULES below. The backend
// gateway middleware and the dashboard's permission UI both read from
// this file, so new modules auto-appear in the grant-access checkbox
// grid and are immediately enforceable on the backend.
//
// Each module entry:
//   key       — short id stored in the staff.permissions JSON
//   label     — what admins see in the UI
//   icon      — emoji shown in the checkbox grid
//   urlRegex  — URL prefix(es) this module owns (server-side gating)
//   viewIds   — dashboard view ids this module owns (UI tab hiding)
//
// Role defaults: roles in ROLE_DEFAULTS map to which modules they get
// out-of-the-box; per-user overrides in staff.permissions take priority.

const MODULES = [
    {
        key: 'crm',
        label: 'CRM / Leads',
        icon: '📑',
        urlRegex: /^\/api\/(leads|customers|inquiries|followups|site-visits|registrations|affiliates|customer\b|score-lead|chat-history)/,
        viewIds: ['crm', 'staff', 'linkgen', 'qr-scans', 'site-visits', 'visitors'],
        tables: ['customers', 'followups', 'site_visits', 'customer_registrations', 'affiliates', 'qr_scans'],
        subModules: [
            { viewId: 'crm',        label: 'Leads & Customers',  icon: '👥' },
            { viewId: 'staff',      label: 'Staff Management',   icon: '👷' },
            { viewId: 'site-visits',label: 'Site Visits',        icon: '📍' },
            { viewId: 'linkgen',    label: 'Affiliate QR',       icon: '🔗' },
            { viewId: 'qr-scans',   label: 'QR Analytics',       icon: '📊' },
            { viewId: 'visitors',   label: 'Visitor Log',        icon: '🚶' },
        ]
    },
    {
        key: 'inventory',
        label: 'Inventory / Plots',
        icon: '🏡',
        urlRegex: /^\/api\/(plots|inventory|layout|brochure|available-sites|visual-maps)/,
        viewIds: ['inventory', 'available-sites', 'visual-maps', 'auto-viz', 'inventory-health'],
        tables: ['plots', 'plot_documents', 'dtcp_approvals'],
        subModules: [
            { viewId: 'inventory',       label: 'Plots & Inventory',    icon: '🏡' },
            { viewId: 'available-sites', label: 'Available Sites',       icon: '🌐' },
            { viewId: 'visual-maps',     label: 'Visual Maps',           icon: '🗺️' },
            { viewId: 'auto-viz',        label: 'Auto Visualizer',       icon: '⚡' },
            { viewId: 'inventory-health',label: 'Inventory Health',      icon: '📈' },
        ]
    },
    {
        key: 'finance',
        label: 'Finance',
        icon: '💰',
        // salaries/commissions/attendance moved to the hr module
        urlRegex: /^\/api\/(expenses|loans|finance|eb-bill|project-banks|loan-banks|cheques|suppliers)/,
        viewIds: ['bank-details', 'loan-hub', 'quote-history', 'quotation', 'suppliers', 'cheques', 'expenses', 'eb-billing'],
        tables: ['expenses', 'customer_loans', 'loan_banks', 'project_banks', 'eb_connections', 'suppliers', 'cheques'],
        subModules: [
            { viewId: 'bank-details',  label: 'Project Bank Hub',     icon: '🏦' },
            { viewId: 'loan-hub',      label: 'Loan Hub',              icon: '📋' },
            { viewId: 'quotation',     label: 'Quotation Engine',      icon: '📜' },
            { viewId: 'quote-history', label: 'Quotation History',     icon: '🗂️' },
            { viewId: 'suppliers',     label: 'Suppliers',             icon: '🤝' },
            { viewId: 'cheques',       label: 'Cheques',               icon: '📝' },
            { viewId: 'expenses',      label: 'Expenses',              icon: '📉' },
            { viewId: 'eb-billing',    label: 'EB Billing',            icon: '💡' },
        ]
    },
    {
        key: 'hr',
        label: 'HR / Payroll',
        icon: '👷',
        urlRegex: /^\/api\/(attendance|salaries|commissions|hr)/,
        viewIds: ['attendance', 'salaries', 'commissions'],
        tables: ['attendance', 'salaries', 'commissions'],
        subModules: [
            { viewId: 'attendance',  label: 'Attendance',       icon: '📅' },
            { viewId: 'salaries',    label: 'Salaries',          icon: '💵' },
            { viewId: 'commissions', label: 'Commissions',       icon: '🏅' },
        ]
    },
    {
        key: 'marketing',
        label: 'Marketing',
        icon: '🎨',
        urlRegex: /^\/api\/(marketing|drip|campaigns|broadcast|generate-copy|digital-marketing)/,
        viewIds: ['marketing-designer', 'broadcast', 'social', 'rules', 'digital-marketing'],
        tables: ['marketing_campaigns', 'drip_campaigns', 'layout_brochures'],
        subModules: [
            { viewId: 'marketing-designer', label: 'Campaigns & Designer', icon: '🎨' },
            { viewId: 'broadcast',          label: 'Bulk Broadcast',        icon: '📢' },
            { viewId: 'social',             label: 'Social Manager',        icon: '📱' },
            { viewId: 'rules',              label: 'Bot Rules',             icon: '⚙️' },
            { viewId: 'digital-marketing',  label: 'Digital Marketing',     icon: '📣' },
        ]
    },
    {
        key: 'email',
        label: 'Email Hub',
        icon: '📧',
        urlRegex: /^\/api\/email/,
        viewIds: ['email-hub'],
        tables: [],
        subModules: [
            { viewId: 'email-hub', label: 'Email Composer', icon: '📧' },
        ]
    },
    {
        key: 'whatsapp',
        label: 'WhatsApp Bot',
        icon: '🤖',
        urlRegex: /^\/api\/(whatsapp|bot|messages|chat|send-message|qr)/,
        viewIds: ['chats', 'bot-config', 'claimed-chats'],
        tables: ['scheduled_messages'],
        subModules: [
            { viewId: 'chats',         label: 'Chat Logs',          icon: '💬' },
            { viewId: 'bot-config',    label: 'Bot Configuration',  icon: '⚙️' },
            { viewId: 'claimed-chats', label: 'Claimed Chats',       icon: '🏷️' },
        ]
    },
    {
        key: 'notifications',
        label: 'Notifications',
        icon: '🔔',
        urlRegex: /^\/api\/notifications|^\/api\/scheduled/,
        viewIds: ['notifications'],
        tables: ['scheduled_messages'],
        subModules: [
            { viewId: 'notifications', label: 'Notification Center', icon: '🔔' },
        ]
    },
    {
        key: 'payments',
        label: 'Payments',
        icon: '💳',
        urlRegex: /^\/api\/payments|^\/api\/payment/,
        viewIds: ['payments'],
        tables: ['payment_requests'],
        subModules: [
            { viewId: 'payments', label: 'Payment Hub', icon: '💳' },
        ]
    },
    {
        key: 'reports',
        label: 'Reports & Analytics',
        icon: '📊',
        urlRegex: /^\/api\/(analytics|stats|reports|dashboard-stats|ai-usage)/,
        viewIds: ['analytics', 'home'],
        tables: ['ai_usage', 'activity_logs'],
        subModules: [
            { viewId: 'analytics', label: 'Analytics Dashboard', icon: '📊' },
            { viewId: 'home',      label: 'Home Overview',        icon: '🏠' },
        ]
    },
    {
        key: 'gst',
        label: 'GST',
        icon: '🧾',
        urlRegex: /^\/api\/gst/,
        viewIds: ['gst'],
        tables: ['gst_rates', 'gst_ledger'],
        subModules: [
            { viewId: 'gst', label: 'GST Module', icon: '🧾' },
        ]
    },
    {
        key: 'legal',
        label: 'Legal',
        icon: '⚖️',
        urlRegex: /^\/api\/(legal|dtcp|doc-registration)/,
        viewIds: ['legal-hub', 'doc-registration', 'dtcp'],
        tables: ['legal_approvals'],
        subModules: [
            { viewId: 'legal-hub',        label: 'Legal Hub',          icon: '⚖️' },
            { viewId: 'doc-registration', label: 'Doc Registration',    icon: '📄' },
            { viewId: 'dtcp',             label: 'DTCP Approvals',      icon: '✅' },
        ]
    },
    {
        key: 'estimates',
        label: 'Estimates',
        icon: '📐',
        urlRegex: /^\/api\/(estimate|guideline)/,
        viewIds: ['estimate-engine', 'guideline-values'],
        tables: [],
        subModules: [
            { viewId: 'estimate-engine',   label: 'Estimate Engine',    icon: '📐' },
            { viewId: 'guideline-values',  label: 'Guideline Values',   icon: '📏' },
        ]
    },
    {
        key: 'remisier',
        label: 'Remisier CRM',
        icon: '🤝',
        urlRegex: /^\/api\/(remisier|affiliate-qr)\//,
        viewIds: ['remisier-crm'],
        tables: [],
        subModules: [
            { viewId: 'remisier-crm', label: 'Remisier Portal', icon: '🤝' },
        ]
    },
    {
        key: 'admin',
        label: 'Admin / Settings',
        icon: '⚙️',
        urlRegex: /^\/api\/(admin|company-settings|developer-info|developer|users)/,
        viewIds: ['developer', 'db', 'visualizer', 'download-hub', 'website', 'diagnostics', 'testbench'],
        tables: ['staff'],
        subModules: [
            { viewId: 'developer',    label: 'Developer Hub',      icon: '🔧' },
            { viewId: 'db',           label: 'Database & Sync',     icon: '🗄️' },
            { viewId: 'visualizer',   label: 'Visualizer Config',   icon: '🗺️' },
            { viewId: 'download-hub', label: 'Download Hub',        icon: '📥' },
            { viewId: 'website',      label: 'Website Builder',     icon: '🌐' },
            { viewId: 'diagnostics',  label: 'Diagnostics',         icon: '🔍' },
            { viewId: 'testbench',    label: 'Test Bench',          icon: '🧪' },
        ]
    },
    {
        key: 'id_cards',
        label: 'ID Cards',
        icon: '🪪',
        urlRegex: /^\/api\/(id-card|id-photo|staff-qr)\//,
        viewIds: ['id-cards'],
        tables: [],
        subModules: [
            { viewId: 'id-cards', label: 'ID Card Generator', icon: '🪪' },
        ]
    }
];

// URL prefixes that bypass module checks (still require login).
// New non-module utilities can be added here.
const PUBLIC_API_PATTERNS = [
    /^\/api\/auth\//,
    /^\/api\/me\b/,
    /^\/api\/ping\b/,
    /^\/api\/status\b/,
    /^\/api\/version\b/,
    /^\/api\/logs\b/,
    /^\/api\/check-update\b/,
    /^\/api\/ai-limit\b/,
    /^\/api\/diagnostics\//,
    /^\/api\/test\//,
    /^\/api\/system\//,
    /^\/api\/lan-url\b/,            // LAN IP utility — no module gate needed
    /^\/api\/company-settings\b/,   // read-only branding info used across all roles
    /^\/api\/developer-details\b/   // static dev contact info — no module gate needed
];

const ALL = Object.fromEntries(MODULES.map(m => [m.key, true]));
const none = (only) => Object.fromEntries(MODULES.map(m => [m.key, only.includes(m.key)]));

// Built-in roles. Adding a new role here makes it selectable in the UI.
// `super_admin` always bypasses checks regardless of this map.
const ROLE_DEFAULTS = {
    super_admin: ALL,
    admin:       ALL,
    manager:     none(['crm', 'inventory', 'marketing', 'reports', 'notifications', 'id_cards', 'remisier', 'estimates', 'hr']),
    sales_agent: none(['crm', 'inventory', 'remisier']),
    accounts:    none(['finance', 'hr', 'payments', 'reports', 'gst', 'estimates']),
    viewer:      none(['crm', 'inventory', 'reports'])
};

// ─── Global Module Config (modules_config.json) ─────────────
// Super admin can disable entire modules for the whole installation.
// This is the "which modules are deployed" setting — separate from per-user perms.

let _globalConfig = null;
let _globalConfigMtime = 0;

function getGlobalModuleConfig() {
    try {
        const configPath = require('path').join(__dirname, 'modules_config.json');
        const stat = require('fs').statSync(configPath);
        // Re-read only when file has changed (cheap mtime check)
        if (stat.mtimeMs !== _globalConfigMtime) {
            _globalConfig = JSON.parse(require('fs').readFileSync(configPath, 'utf8'));
            _globalConfigMtime = stat.mtimeMs;
        }
        return _globalConfig;
    } catch (_) {
        return { configured: true, enabled: Object.fromEntries(MODULES.map(m => [m.key, true])) };
    }
}

function isModuleGloballyEnabled(key) {
    const cfg = getGlobalModuleConfig();
    if (!cfg || !cfg.enabled) return true; // default open
    return cfg.enabled[key] !== false;
}

function saveGlobalModuleConfig(newCfg) {
    try {
        const configPath = require('path').join(__dirname, 'modules_config.json');
        require('fs').writeFileSync(configPath, JSON.stringify(newCfg, null, 2));
        _globalConfig = newCfg;
        _globalConfigMtime = require('fs').statSync(configPath).mtimeMs;
        return true;
    } catch (e) { return false; }
}

function effectivePerms(role, overridesJson) {
    const base = ROLE_DEFAULTS[role] || ROLE_DEFAULTS.viewer;
    if (!overridesJson) return { ...base };
    try {
        const ov = typeof overridesJson === 'string' ? JSON.parse(overridesJson) : overridesJson;
        return { ...base, ...ov };
    } catch (_) { return { ...base }; }
}

function findModuleForUrl(url) {
    for (const m of MODULES) {
        if (m.urlRegex.test(url)) return m.key;
    }
    return null;
}

function isPublicApi(url) {
    return PUBLIC_API_PATTERNS.some(rx => rx.test(url));
}

module.exports = {
    MODULES,
    ROLE_DEFAULTS,
    PUBLIC_API_PATTERNS,
    effectivePerms,
    findModuleForUrl,
    isPublicApi,
    getGlobalModuleConfig,
    isModuleGloballyEnabled,
    saveGlobalModuleConfig
};
