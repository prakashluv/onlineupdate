const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const axios = require('axios');

// Reject non-admin callers on sensitive endpoints. Logs leak customer
// phones, IPC traffic, and SMTP details, so they must not be visible to
// regular roles.
function adminOnly(req, res, next) {
    const role = req.session?.userRole;
    if (role === 'admin' || role === 'super_admin') return next();
    return res.status(403).json({ ok: false, error: 'Admin access required' });
}

// System Routes: Logs, Diagnostics, and Config
router.get('/ping', (req, res) => {
    res.json({ ok: true, msg: "Pong! Server is active.", time: new Date().toLocaleTimeString() });
});

router.get('/diagnostics/logs', adminOnly, (req, res) => {
    try {
        // Prefer in-memory logs (always fresh for current session)
        const memoryLogs = req.app.get('logs');
        if (memoryLogs && memoryLogs.length > 0) {
            return res.json({ ok: true, logs: memoryLogs.map(e => `[${e.time}] ${e.msg}`) });
        }

        const rootDir = req.app.get('ROOT_DIR');
        const logPath = path.join(rootDir, 'server_log.txt');
        
        if (!fs.existsSync(logPath)) {
            return res.json({ ok: true, logs: [] });
        }
        
        // Read last 500 lines
        const content = fs.readFileSync(logPath, 'utf8');
        const lines = content.split('\n').filter(Boolean);
        const lastLines = lines.slice(-500);
        
        res.json({ ok: true, logs: lastLines });
    } catch (e) { 
        res.status(500).json({ ok: false, msg: "Error reading logs: " + e.message }); 
    }
});

router.post('/diagnostics/clear', adminOnly, (req, res) => {
    try {
        const rootDir = req.app.get('ROOT_DIR');
        const logPath = path.join(rootDir, 'server_log.txt');
        fs.writeFileSync(logPath, `[RESET] Log cleared at ${new Date().toISOString()}\n`);
        const pushLog = req.app.get('pushLog');
        if (pushLog) pushLog("🧹 System: Persistent log file cleared.");
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

router.get('/version', (req, res) => {
    try {
        const rootDir = req.app.get('ROOT_DIR');
        const vPath = path.join(__dirname, '../version.json');
        if (fs.existsSync(vPath)) {
            res.json(JSON.parse(fs.readFileSync(vPath, 'utf8')));
        } else {
            res.json({ version: "1.4.0" });
        }
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

router.get('/system/check-update', async (req, res) => {
    try {
        const rootDir = req.app.get('ROOT_DIR');
        const vPath = path.join(__dirname, '../version.json');

        if (!fs.existsSync(vPath)) return res.json({ ok: false, msg: 'version.json not found' });
        const localVersion = JSON.parse(fs.readFileSync(vPath, 'utf8')).version;

        // Read GitHub URL from Developer_Details.txt (configurable)
        let githubUrl = null;
        const devPath = path.join(rootDir, 'Developer_Details.txt');
        if (fs.existsSync(devPath)) {
            const lines = fs.readFileSync(devPath, 'utf8').split('\n');
            const urlLine = lines.find(l => l.trim().toLowerCase().startsWith('update_url:'));
            if (urlLine) githubUrl = urlLine.split(':').slice(1).join(':').trim();
        }

        if (!githubUrl) {
            return res.json({ ok: false, msg: 'Update URL not configured. Please set it in Developer Options.' });
        }

        const response = await axios.get(githubUrl, { timeout: 8000 }).catch(() => null);

        if (response && response.data && response.data.version) {
            const remoteVersion = response.data.version;
            const hasUpdate = remoteVersion !== localVersion;
            const download_url = response.data.download_url || null;
            res.json({ ok: true, local: localVersion, remote: remoteVersion, hasUpdate, url: githubUrl, download_url });
        } else {
            res.json({ ok: false, msg: 'Could not reach update server. Check the URL in Developer Options.' });
        }
    } catch (e) { res.json({ ok: false, msg: e.message }); }
});

// Save the GitHub Update URL to Developer_Details.txt
router.post('/system/update-url', adminOnly, (req, res) => {
    try {
        const rootDir = req.app.get('ROOT_DIR');
        const { url } = req.body;
        if (!url) return res.status(400).json({ ok: false, msg: 'URL is required' });

        const devPath = path.join(rootDir, 'Developer_Details.txt');
        let lines = fs.existsSync(devPath) ? fs.readFileSync(devPath, 'utf8').split('\n') : [];

        // Replace or append the Update_URL line
        const idx = lines.findIndex(l => l.trim().toLowerCase().startsWith('update_url:'));
        if (idx > -1) {
            lines[idx] = `Update_URL: ${url}`;
        } else {
            lines.push(`Update_URL: ${url}`);
        }

        fs.writeFileSync(devPath, lines.join('\n'));

        const pushLog = req.app.get('pushLog');
        if (pushLog) pushLog(`🔄 Developer: Update URL set to ${url}`);
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

// ── Online update: progress + download-apply ─────────────────────────────────
const os = require('os');
let _updateProgress = { pct: 0, phase: 'idle' };

router.get('/system/update-progress', (req, res) => {
    res.json(_updateProgress);
});

router.post('/system/download-apply-update', adminOnly, async (req, res) => {
    const rootDir    = req.app.get('ROOT_DIR');
    const pushLog    = req.app.get('pushLog');

    // Read saved update URL (points to latest.json)
    let latestUrl = null;
    try {
        const devPath = path.join(rootDir, 'Developer_Details.txt');
        if (fs.existsSync(devPath)) {
            const urlLine = fs.readFileSync(devPath, 'utf8').split('\n')
                .find(l => l.trim().toLowerCase().startsWith('update_url:'));
            if (urlLine) latestUrl = urlLine.split(':').slice(1).join(':').trim();
        }
    } catch (_) {}

    if (!latestUrl) {
        return res.status(400).json({ ok: false, error: 'Update URL not configured. Set it in Developer Options → Update Server Config.' });
    }

    try {
        _updateProgress = { pct: 5, phase: 'fetching' };

        // 1. Fetch latest.json
        const latestRes = await axios.get(latestUrl, { timeout: 10000 });
        const latest    = latestRes.data;
        if (!latest.patch_url) {
            return res.status(400).json({ ok: false, error: 'latest.json has no patch_url field.' });
        }

        _updateProgress = { pct: 10, phase: 'downloading' };

        // 2. Download zip
        const zipRes = await axios.get(latest.patch_url, {
            responseType: 'arraybuffer',
            timeout: 120000,
            onDownloadProgress: (e) => {
                if (e.total) _updateProgress = { pct: Math.round(10 + (e.loaded / e.total) * 75), phase: 'downloading' };
            }
        });

        _updateProgress = { pct: 87, phase: 'extracting' };

        // 3. Extract zip to temp dir
        const extractDir = path.join(os.tmpdir(), 'PG_OnlinePatch_' + Date.now());
        fs.mkdirSync(extractDir, { recursive: true });
        const AdmZip = require('adm-zip');
        new AdmZip(Buffer.from(zipRes.data)).extractAllTo(extractDir, true);

        _updateProgress = { pct: 90, phase: 'applying' };

        // 4. Read manifest
        const manifestPath = path.join(extractDir, 'patch_manifest.json');
        if (!fs.existsSync(manifestPath)) {
            return res.status(400).json({ ok: false, error: 'patch_manifest.json not in zip.' });
        }
        const { files } = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

        // 5. Resolve install root:
        //    INTERNAL_DIR = resources/app/ (where server.js lives, always correct even in packaged mode)
        //    installRoot  = resources/app/../../  = the app install folder (e.g. C:\Program Files\Property Genius)
        //    Dev mode:    INTERNAL_DIR = project root, so installRoot = project root/../..  → fallback to rootDir
        const internalDir = req.app.get('INTERNAL_DIR') || rootDir;
        const installRoot = path.join(internalDir, '..', '..');

        // 6. Backup + apply
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupDir = path.join(rootDir, 'backups', `online-patch-${timestamp}`);
        fs.mkdirSync(backupDir, { recursive: true });

        const results = [];
        for (const f of files) {
            const srcPath  = path.join(extractDir, f.src);
            const destPath = path.join(installRoot, f.dest);
            try {
                if (fs.existsSync(destPath)) {
                    const bk = path.join(backupDir, f.dest);
                    fs.mkdirSync(path.dirname(bk), { recursive: true });
                    fs.copyFileSync(destPath, bk);
                }
                fs.mkdirSync(path.dirname(destPath), { recursive: true });
                fs.copyFileSync(srcPath, destPath);
                results.push({ label: f.label, dest: f.dest, ok: true });
            } catch (e) {
                results.push({ label: f.label, dest: f.dest, ok: false, error: e.message });
            }
        }

        try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (_) {}
        _updateProgress = { pct: 100, phase: 'done' };

        const allOk = results.every(r => r.ok);
        if (pushLog) pushLog(`🔄 Online update v${latest.version} ${allOk ? 'applied ✅' : 'completed with errors ⚠️'}`);
        res.json({ ok: allOk, results, backupDir, version: latest.version });

    } catch (e) {
        _updateProgress = { pct: 0, phase: 'error' };
        res.status(500).json({ ok: false, error: e.message, results: [] });
    }
});

// Version Manager — read + write version.json from the dashboard
router.get('/system/version', (req, res) => {
    try {
        const vPath = path.join(__dirname, '../version.json');
        if (fs.existsSync(vPath)) {
            res.json(JSON.parse(fs.readFileSync(vPath, 'utf8')));
        } else {
            res.json({ version: '1.0.0', date: '', notes: '', download_url: '' });
        }
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

router.post('/system/version', adminOnly, (req, res) => {
    try {
        const { version, date, notes, download_url } = req.body;
        if (!version) return res.status(400).json({ ok: false, msg: 'Version is required' });
        const vPath = path.join(__dirname, '../version.json');
        const current = fs.existsSync(vPath) ? JSON.parse(fs.readFileSync(vPath, 'utf8')) : {};
        const updated = {
            ...current,
            version,
            date: date || new Date().toISOString().split('T')[0],
            notes: notes || current.notes || '',
        };
        if (download_url !== undefined) updated.download_url = download_url;
        fs.writeFileSync(vPath, JSON.stringify(updated, null, 2));
        const pushLog = req.app.get('pushLog');
        if (pushLog) pushLog(`📦 Version bumped to v${version} — ready for deployment`);
        res.json({ ok: true, data: updated });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

// ── Error Reporting → GitHub Issues ─────────────────────────────────────────
router.post('/system/report-error', async (req, res) => {
    const rootDir = req.app.get('ROOT_DIR');
    const pushLog = req.app.get('pushLog');

    try {
        const { description = '' } = req.body;

        // Collect version
        let version = '?';
        try {
            const vp = path.join(__dirname, '../version.json');
            version = JSON.parse(fs.readFileSync(vp, 'utf8')).version || '?';
        } catch (_) {}

        // Collect server log (last 150 lines)
        let serverLog = '(no log file)';
        try {
            const logPath = path.join(rootDir, 'server_log.txt');
            if (fs.existsSync(logPath)) {
                const lines = fs.readFileSync(logPath, 'utf8').split('\n').filter(Boolean);
                serverLog = lines.slice(-150).join('\n');
            }
        } catch (_) {}

        // Also pull in-memory logs
        const memLogs = req.app.get('logs') || [];
        if (memLogs.length > 0) {
            serverLog = memLogs.slice(-100).map(e => `[${e.time}] ${e.msg}`).join('\n')
                + '\n--- (above: in-memory) ---\n' + serverLog;
        }

        // Collect crash report
        let crashReport = '(none)';
        try {
            const cp = path.join(rootDir, 'CRASH_REPORT_BOT.txt');
            if (fs.existsSync(cp)) crashReport = fs.readFileSync(cp, 'utf8').slice(-3000);
        } catch (_) {}

        // Collect electron log
        let electronLog = '(none)';
        try {
            const ep = path.join(rootDir, '..', 'electron.log');
            if (fs.existsSync(ep)) {
                const lines = fs.readFileSync(ep, 'utf8').split('\n').filter(Boolean);
                electronLog = lines.slice(-80).join('\n');
            }
        } catch (_) {}

        // Collect WhatsApp message dump log (last 100 messages)
        let waLog = '(none)';
        try {
            const wp = path.join(rootDir, 'scratch', 'message_dump.log');
            if (fs.existsSync(wp)) {
                const lines = fs.readFileSync(wp, 'utf8').split('\n').filter(Boolean);
                waLog = lines.slice(-100).join('\n');
            }
        } catch (_) {}

        const os  = require('os');
        const now = new Date().toISOString();

        const issueTitle = `[Bug Report] Property Genius v${version} — ${now.split('T')[0]}`;
        const issueBody  =
`## 📋 Bug Report — Property Genius v${version}
**Reported:** ${now}
**OS:** ${os.platform()} ${os.release()} (${os.arch()})
**Node:** ${process.version}

### 📝 Description
${description.trim() || '*(no description provided)*'}

---
### 🖥️ Server Log (last 150 lines)
\`\`\`
${serverLog.slice(-4000)}
\`\`\`

---
### 💥 Bot Crash Report
\`\`\`
${crashReport.slice(-2000)}
\`\`\`

---
### ⚡ Electron Log (last 80 lines)
\`\`\`
${electronLog.slice(-2000)}
\`\`\`

---
### 📱 WhatsApp Message Log (last 100 messages)
\`\`\`
${waLog.slice(-3000)}
\`\`\`
`;

        const pat = process.env.GITHUB_PAT || '';

        // Save a local copy regardless (acts as backup and sole storage when no PAT)
        try {
            const reportsDir = path.join(rootDir, 'error_reports');
            if (!fs.existsSync(reportsDir)) fs.mkdirSync(reportsDir, { recursive: true });
            const fname = `report_${now.replace(/[:.]/g, '-')}.txt`;
            fs.writeFileSync(path.join(reportsDir, fname), `${issueTitle}\n\n${issueBody}`, 'utf8');
        } catch (_) {}

        if (!pat) {
            if (pushLog) pushLog('🐛 Error report saved locally (no GITHUB_PAT configured)');
            return res.json({ ok: true, local: true, msg: 'Report saved locally in error_reports/ folder (GITHUB_PAT not configured).' });
        }

        const payload = JSON.stringify({
            title: issueTitle,
            body:  issueBody,
            labels: ['bug-report'],
        });

        // POST to GitHub Issues API
        // Honour the dashboard's configured "GitHub Repo — Bug Reports" field
        // (Developer Hub → Bot Configuration → bug_report_repo).
        // Falls back to prakashluv/onlineupdate if nothing is set.
        let bugRepo = 'prakashluv/onlineupdate';
        try {
            const cfg = JSON.parse(fs.readFileSync(path.join(rootDir, 'bot_settings.json'), 'utf8'));
            if (cfg.bug_report_repo && cfg.bug_report_repo.includes('/')) bugRepo = cfg.bug_report_repo.trim();
        } catch (_) {}

        const https = require('https');
        const result = await new Promise((resolve, reject) => {
            const options = {
                hostname: 'api.github.com',
                path:     `/repos/${bugRepo}/issues`,
                method:   'POST',
                headers: {
                    'Authorization': `Bearer ${pat}`,
                    'Content-Type':  'application/json',
                    'Content-Length': Buffer.byteLength(payload),
                    'User-Agent':    'PropertyGenius-ErrorReporter/1.0',
                    'Accept':        'application/vnd.github.v3+json',
                },
            };
            const r = https.request(options, (resp) => {
                let data = '';
                resp.on('data', d => { data += d; });
                resp.on('end', () => {
                    try { resolve({ status: resp.statusCode, body: JSON.parse(data) }); }
                    catch (_) { resolve({ status: resp.statusCode, body: data }); }
                });
            });
            r.on('error', reject);
            r.write(payload);
            r.end();
        });

        if (result.status === 201) {
            const issueUrl = result.body.html_url;
            if (pushLog) pushLog(`🐛 Error report filed: ${issueUrl}`);
            res.json({ ok: true, url: issueUrl });
        } else {
            let hint = '';
            if (result.status === 403 || result.status === 401) hint = ' — check PAT has Issues:Write permission on the repo';
            if (result.status === 404) hint = ` — check repo "${bugRepo}" exists and has Issues enabled`;
            if (pushLog) pushLog(`🐛 Error report saved locally (GitHub ${result.status}${hint})`);
            res.status(500).json({ ok: false, error: `GitHub API returned ${result.status}${hint}`, detail: result.body });
        }

    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

// ── Browser Engine Status ────────────────────────────────────────────────────
router.get('/system/browser-status', (req, res) => {
    const rootDir = req.app.get('ROOT_DIR');
    const { execSync } = require('child_process');

    const portablePaths = [
        path.join(rootDir, 'chrome-win', 'chrome.exe'),
        path.join(rootDir, 'portable_chrome', 'chrome.exe'),
    ];
    const systemPaths = [
        { p: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', type: 'chrome' },
        { p: 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', type: 'chrome' },
        { p: path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'), type: 'chrome' },
        { p: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', type: 'edge' },
        { p: 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe', type: 'edge' },
        { p: path.join(process.env.LOCALAPPDATA || '', 'Microsoft\\Edge\\Application\\msedge.exe'), type: 'edge' },
    ];

    let chromePath = null, type = 'none';

    for (const p of portablePaths) {
        if (fs.existsSync(p)) { chromePath = p; type = 'portable'; break; }
    }
    if (!chromePath) {
        for (const { p, type: t } of systemPaths) {
            if (fs.existsSync(p)) { chromePath = p; type = t; break; }
        }
    }

    if (!chromePath) return res.json({ ok: false, type: 'none', msg: 'No browser found on this machine.' });

    let version = 'Unknown';
    try {
        const safe = chromePath.replace(/'/g, "''");
        version = execSync(`powershell -NoProfile -Command "(Get-Item '${safe}').VersionInfo.ProductVersion"`,
            { timeout: 6000, stdio: ['pipe','pipe','pipe'] }).toString().trim();
    } catch (_) {}

    res.json({ ok: true, type, path: chromePath, version });
});

// Check for browser update (reports current engine; portable Chromium must be updated manually)
router.post('/update-browser', (req, res) => {
    const rootDir = req.app.get('ROOT_DIR');
    const { execSync } = require('child_process');

    const portablePaths = [
        path.join(rootDir, 'chrome-win', 'chrome.exe'),
        path.join(rootDir, 'portable_chrome', 'chrome.exe'),
    ];

    let isPortable = false;
    for (const p of portablePaths) {
        if (fs.existsSync(p)) { isPortable = true; break; }
    }

    let version = 'Unknown';
    try {
        const systemPaths = [
            'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
            'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
            path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
            'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
            'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        ];
        for (const p of systemPaths) {
            if (fs.existsSync(p)) {
                const safe = p.replace(/'/g, "''");
                version = execSync(`powershell -NoProfile -Command "(Get-Item '${safe}').VersionInfo.ProductVersion"`,
                    { timeout: 6000, stdio: ['pipe','pipe','pipe'] }).toString().trim();
                break;
            }
        }
    } catch (_) {}

    if (isPortable) {
        return res.json({ ok: false, msg: `Portable Chromium detected (v${version}). To update, replace the chrome-win folder with a newer build.` });
    }
    res.json({ ok: true, msg: `Using system browser v${version}. Chrome/Edge updates automatically via Google Update / Windows Update — no action needed here.` });
});

module.exports = router;
