// Polyfill diagnostics_channel.tracingChannel for Electron 28 (Node 18.18.x < 18.19)
;(function() {
    const dc = require('diagnostics_channel');
    if (typeof dc.tracingChannel !== 'function') {
        dc.tracingChannel = (namePrefix) => ({
            start:      dc.channel(namePrefix + '.start'),
            end:        dc.channel(namePrefix + '.end'),
            asyncStart: dc.channel(namePrefix + '.asyncStart'),
            asyncEnd:   dc.channel(namePrefix + '.asyncEnd'),
            error:      dc.channel(namePrefix + '.error'),
            traceSync(fn, context, thisArg) { return fn.call(thisArg); },
            tracePromise(fn, context, thisArg) { return fn.call(thisArg); },
            traceCallback(fn, position, context, thisArg, ...args) { return fn.call(thisArg, ...args); },
            subscribe() {}, unsubscribe() {}
        });
    }
})();

const os = require('os');
const express = require('express');
const path = require('path');
const fs = require('fs');
const { spawn, exec, execSync } = require('child_process');
const qrcode = require('qrcode');
const multer = require('multer');
const xlsx = require('xlsx');
const axios = require('axios');
const AdmZip = require('adm-zip');
// Lazy-loaded inside route to prevent DOMMatrix ReferenceError on startup in packaged environments
// const pdf = require('pdf-parse'); 
const compression = require('compression');
const { GoogleGenerativeAI } = require("@google/generative-ai");
// ─── Restore-Pending Check (must run before DB opens) ────────────────────────
// If a backup restore was staged via the Backup Manager, apply it now before
// the sqlite3 module opens a connection to database.sqlite.
;(function applyPendingRestore() {
    const isPkg2 = typeof process.pkg !== 'undefined';
    const isElectron2 = !!process.env.ELECTRON_RUNNING;
    let rootForRestore = process.env.APP_DATA_DIR || __dirname;
    if ((isPkg2 || isElectron2) && !process.env.APP_DATA_DIR) {
        const appData2 = process.env.APPDATA || (process.platform === 'darwin' ? process.env.HOME + '/Library/Preferences' : process.env.HOME + '/.local/share');
        rootForRestore = path.join(appData2, 'DRD-Property-Genius');
    }
    const pendingPath = path.join(rootForRestore, 'database.sqlite.restore-pending');
    if (fs.existsSync(pendingPath)) {
        try {
            const dbTarget = path.join(rootForRestore, 'database.sqlite');
            // Remove WAL sidecar files so SQLite starts clean
            for (const ext of ['-shm', '-wal']) {
                const side = dbTarget + ext;
                if (fs.existsSync(side)) { try { fs.unlinkSync(side); } catch (_) {} }
            }
            fs.copyFileSync(pendingPath, dbTarget);
            fs.unlinkSync(pendingPath);
            console.log('[RESTORE] database.sqlite restored from backup successfully.');
        } catch (e) {
            console.error('[RESTORE] Failed to apply pending restore:', e.message);
        }
    }
})();

const { db, initDB, migrateFromExcel } = require('./database');
const { MODULES, ROLE_DEFAULTS, effectivePerms, findModuleForUrl, isPublicApi, isModuleGloballyEnabled, getGlobalModuleConfig, saveGlobalModuleConfig } = require('./modules.config');
// Load .env from AppData first (secure location), fall back to project folder
;(function() {
    const appDataEnv = path.join(os.homedir(), 'AppData', 'Roaming', 'DRD-Property-Genius', '.env');
    const localEnv   = path.join(__dirname, '.env');
    const envPath    = fs.existsSync(appDataEnv) ? appDataEnv : localEnv;
    require('dotenv').config({ path: envPath, override: true });
})();

// ─── Version & Environment ──────────────────────────────
const VERSION_PATH = (() => {
    const local = path.join(__dirname, 'version.json');
    if (fs.existsSync(local)) return local;
    const parent = path.join(__dirname, '..', 'version.json');
    if (fs.existsSync(parent)) return parent;
    return local;
})();
let softwareVersion = "v1.2.0";
try {
    if (fs.existsSync(VERSION_PATH)) {
        const vData = JSON.parse(fs.readFileSync(VERSION_PATH, 'utf8'));
        softwareVersion = 'v' + vData.version;
    }
} catch(e) {}

const isPkg = typeof process.pkg !== 'undefined';
const isElectron = !!process.env.ELECTRON_RUNNING;

function resolveRootDir() {
    if (process.env.APP_DATA_DIR) return process.env.APP_DATA_DIR;
    if (isPkg || isElectron) {
        const appData = process.env.APPDATA || (process.platform === 'darwin' ? process.env.HOME + '/Library/Preferences' : process.env.HOME + '/.local/share');
        const drdData = path.join(appData, 'DRD-Property-Genius');
        if (!fs.existsSync(drdData)) fs.mkdirSync(drdData, { recursive: true });
        return drdData;
    }
    return __dirname;
}

const ROOT_DIR = resolveRootDir();
const INTERNAL_DIR = __dirname;

// ─── Zero-Dependency Binary Resolver ───────────────────
function resolveBin(name) {
    const portablePath = path.join(ROOT_DIR, 'bin', name + (process.platform === 'win32' ? '.exe' : ''));
    if (fs.existsSync(portablePath)) return portablePath;
    return name; // Fallback to system path
}
const NODE_BIN = resolveBin('node');
const PYTHON_BIN = resolveBin('python');

const ASSETS_DIR = path.join(ROOT_DIR, 'assets');
if (!fs.existsSync(ASSETS_DIR)) fs.mkdirSync(ASSETS_DIR, { recursive: true });

const assetStorage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, ASSETS_DIR),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const uploadAsset = multer({ storage: assetStorage });

const app = express();
const PORT = 3000;

// ─── Bot-scoped Chrome killer ──────────────────────────────────────────
// SAFETY: NEVER blanket-kill chrome.exe — that nukes the user's open tabs
// and any unsaved browser data. Only kill Chrome processes whose command
// line references our bot's puppeteer profile directory (.wwebjs_auth).
function killBotChromeOnly(label = 'bot') {
    const marker = '.wwebjs_auth';
    let cmd;
    if (process.platform === 'win32') {
        // PowerShell + Win32_Process filtered by CommandLine.
        // -ErrorAction SilentlyContinue suppresses "no such process" errors.
        cmd = `powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'chrome.exe' -and $_.CommandLine -like '*${marker}*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"`;
    } else {
        // pkill -f matches by full command line; `|| true` so empty matches don't throw
        cmd = `pkill -f "${marker}" || true`;
    }
    try {
        execSync(cmd, { timeout: 8000, stdio: 'ignore' });
        console.log(`[CHROME-KILL] (${label}) Terminated puppeteer Chrome only — user's regular browser untouched.`);
    } catch (e) {
        console.log(`[CHROME-KILL] (${label}) Nothing to kill or kill failed: ${e.message}`);
    }
}

// Startup: kill any orphaned bot Chrome from a previous session (safe — filtered
// by .wwebjs_auth in the command line, never touches the user's own browser),
// then remove stale lock files.
killBotChromeOnly('startup');
try {
    const sessionRoot = path.join(ROOT_DIR, '.wwebjs_auth');
    if (fs.existsSync(sessionRoot)) {
        for (const sub of fs.readdirSync(sessionRoot)) {
            const subPath = path.join(sessionRoot, sub);
            if (fs.statSync(subPath).isDirectory()) {
                for (const lock of ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'lockfile']) {
                    const p = path.join(subPath, lock);
                    if (fs.existsSync(p)) { try { fs.unlinkSync(p); } catch(_) {} }
                }
            }
        }
        console.log('LOG: Cleared stale puppeteer session locks (user Chrome untouched).');
    }
} catch (e) { console.warn('LOG: Lock cleanup skipped:', e.message); }

console.log('--------------------------------------------------');
console.log('🚀 DRD SERVER LOADING FROM:', __filename);
console.log('--------------------------------------------------');

app.use(compression({
    filter: (req, res) => {
        if (req.path === '/api/logs') return false;
        return compression.filter(req, res);
    }
}));

// ─── Security Headers ─────────────────────────────────────
const helmet = require('helmet');
app.use(helmet({
    contentSecurityPolicy: false, // dashboard uses inline scripts/styles
    crossOriginEmbedderPolicy: false
}));

app.use(express.json());
app.use(express.urlencoded({ extended: false })); // needed for portal-login form POST

// ─── Session ──────────────────────────────────────────────
const session = require('express-session');
if (!process.env.SESSION_SECRET) {
    console.warn('[SECURITY] SESSION_SECRET not set in .env — using default. Set a strong random value in production.');
}

// Minimal file-backed Store — required so "Remember me" survives server restart.
// Default MemoryStore loses all sessions on restart, which breaks the 30-day cookie.
class FileSessionStore extends session.Store {
    constructor(filePath) {
        super();
        this.filePath = filePath;
        this.sessions = {};
        this.dirty   = false;
        try {
            if (fs.existsSync(filePath)) {
                this.sessions = JSON.parse(fs.readFileSync(filePath, 'utf8') || '{}');
                // Drop expired entries on load
                const now = Date.now();
                for (const sid of Object.keys(this.sessions)) {
                    const exp = this.sessions[sid]?.cookie?.expires;
                    if (exp && new Date(exp).getTime() < now) delete this.sessions[sid];
                }
            }
        } catch (e) { console.warn('[SESSION-STORE] Load failed, starting fresh:', e.message); }
        // Flush every 5s if changed
        setInterval(() => this._flush(), 5000).unref();
    }
    _flush() {
        if (!this.dirty) return;
        try { fs.writeFileSync(this.filePath, JSON.stringify(this.sessions)); this.dirty = false; }
        catch (e) { console.warn('[SESSION-STORE] Flush failed:', e.message); }
    }
    get(sid, cb)        { process.nextTick(() => cb(null, this.sessions[sid] || null)); }
    set(sid, sess, cb)  { this.sessions[sid] = sess; this.dirty = true; process.nextTick(() => cb && cb(null)); }
    destroy(sid, cb)    { delete this.sessions[sid]; this.dirty = true; process.nextTick(() => cb && cb(null)); }
    touch(sid, sess, cb){ if (this.sessions[sid]) { this.sessions[sid].cookie = sess.cookie; this.dirty = true; } process.nextTick(() => cb && cb(null)); }
    length(cb)          { process.nextTick(() => cb(null, Object.keys(this.sessions).length)); }
    clear(cb)           { this.sessions = {}; this.dirty = true; process.nextTick(() => cb && cb(null)); }
}

// Wipe all sessions on every restart so every user must re-login after a server restart.
try {
    fs.writeFileSync(path.join(ROOT_DIR, 'sessions.json'), '{}');
    console.log('[SESSION] Sessions cleared on restart — all users must re-login.');
} catch (e) { console.warn('[SESSION] Could not clear sessions.json:', e.message); }

const _sessionStore = new FileSessionStore(path.join(ROOT_DIR, 'sessions.json'));
app.set('sessionStore', _sessionStore); // expose to auth routes for single-PC enforcement + concurrent-user cap
app.use(session({
    secret: process.env.SESSION_SECRET || 'drd-pg-secret-2026-x7k9m',
    resave: false,
    saveUninitialized: false,
    store: _sessionStore,
    cookie: { httpOnly: true, maxAge: 8 * 60 * 60 * 1000 } // 8h default; 30d if "Remember me" checked
}));

// ─── Auth Guard ───────────────────────────────────────────
const STATIC_EXTS = ['.css','.js','.png','.jpg','.jpeg','.svg','.ico','.webp','.woff','.woff2','.ttf','.gif','.pdf','.map'];
const PUBLIC_PATHS = ['/login.html', '/favicon.ico', '/visitor-checkin', '/api/visitor-checkin', '/api/visitor-checkin/lookup'];

app.use((req, res, next) => {
    const ext = require('path').extname(req.path).toLowerCase();
    if (PUBLIC_PATHS.includes(req.path)) return next();
    if (STATIC_EXTS.includes(ext)) return next();
    if (req.path.startsWith('/api/auth/')) return next();
    if (req.path.startsWith('/r/')) return next(); // affiliate/referral links are public
    if (req.session?.userId) return next();
    if (req.path.startsWith('/api/')) return res.status(401).json({ ok: false, error: 'Unauthorized', redirect: '/login.html' });
    res.redirect('/login.html');
});

// ─── Module Access Gateway ────────────────────────────────
// Runs AFTER auth guard (so we know who's calling) and BEFORE any module
// routes register. Looks up the requested URL in modules.config.js and
// rejects with 403 if the user's role/perms don't include that module.
// Unmapped URLs are allowed but logged so admins can spot gaps.
app.use((req, res, next) => {
    if (!req.path.startsWith('/api/')) return next();
    if (isPublicApi(req.path)) return next();
    const role = req.session?.userRole || null;
    if (!role) return next(); // auth guard above already handled missing session

    const mod = findModuleForUrl(req.path);

    // Global module gate: super_admin bypasses, but even super_admin can't use a globally disabled module
    if (mod && !isModuleGloballyEnabled(mod)) {
        return res.status(403).json({ ok: false, error: 'Module disabled', module: mod, reason: 'globally_disabled' });
    }

    if (role === 'super_admin') return next();

    if (!mod) return next(); // legacy / utility endpoint — let it through

    const perms = req.session.userPerms || effectivePerms(role, null);
    if (perms[mod] === true) return next();

    // Audit denial — helps spot probing / role misconfig.
    try {
        pushLog(`🚫 ACCESS DENIED: user=${req.session.userId} role=${role} module=${mod} ${req.method} ${req.path}`);
    } catch (_) {}
    return res.status(403).json({ ok: false, error: 'Access denied', module: mod });
});

// ─── Random layout image for dashboard backdrop ───────────────────────────
app.get('/api/system/backdrop-image', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const imageExts = /\.(jpg|jpeg|png|webp)$/i;
    const images = [];
    const scan = (dir, urlPrefix) => {
        try {
            for (const folder of fs.readdirSync(dir)) {
                const folderPath = path.join(dir, folder);
                if (!fs.statSync(folderPath).isDirectory()) continue;
                for (const file of fs.readdirSync(folderPath)) {
                    if (imageExts.test(file)) images.push(`${urlPrefix}/${encodeURIComponent(folder)}/${encodeURIComponent(file)}`);
                }
            }
        } catch (_) {}
    };
    scan(LAYOUT_IMAGES_DIR, '/layout_media');
    scan(path.join(ASSETS_DIR, 'layouts'), '/assets/layouts');
    if (!images.length) return res.json({ ok: false });
    res.json({ ok: true, url: images[Math.floor(Math.random() * images.length)] });
});

// ─── Manual Error Report: send logs to developer via WhatsApp ───────────────
app.post('/api/system/send-error-report', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    try {
        const lines = [];
        const crashFile = path.join(ROOT_DIR, 'CRASH_REPORT_BOT.txt');
        if (fs.existsSync(crashFile)) {
            const tail = fs.readFileSync(crashFile, 'utf8').split('\n').slice(-50).join('\n');
            lines.push(`--- BOT CRASH LOG (last 50 lines) ---\n${tail}`);
        }
        if (fs.existsSync(SYSTEM_LOG_PATH)) {
            const tail = fs.readFileSync(SYSTEM_LOG_PATH, 'utf8').split('\n').slice(-40).join('\n');
            lines.push(`--- SERVER LOG (last 40 lines) ---\n${tail}`);
        }
        if (!lines.length) return res.json({ ok: false, msg: 'No log files found.' });
        const snippet = lines.join('\n\n').slice(-3500);
        const sentBy = req.session.userName || req.session.userId;
        const os = require('os');
        const ts = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
        const text = `📋 *DRD Error Report*\n*Sent by:* ${sentBy}\n*Time:* ${ts}\n*Host:* ${os.hostname()}\n\n${snippet}`;

        if (botStatus === 'connected' && botProcess && botProcess.send) {
            botProcess.send({ type: 'send_whatsapp', data: { target: DEV_ALERT_PHONE, text } });
            res.json({ ok: true, msg: 'Error report sent to developer via WhatsApp ✅' });
        } else {
            if (_devAlertQueue.length < 5) _devAlertQueue.push({ category: 'Manual Report', text });
            res.json({ ok: true, msg: 'Queued — will be sent when WhatsApp reconnects ⏳' });
        }
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

// ─── Module Config (super admin) ────────────────────────────────────────────
app.get('/api/system/module-config', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const cfg = getGlobalModuleConfig();
    res.json({ ok: true, config: cfg, modules: MODULES.map(m => ({ key: m.key, label: m.label, icon: m.icon })) });
});

app.post('/api/system/module-config', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    if (req.session.userRole !== 'super_admin') return res.status(403).json({ ok: false, error: 'Super admin only' });
    const { enabled, business_type } = req.body;
    if (!enabled || typeof enabled !== 'object') return res.status(400).json({ ok: false });
    const newCfg = {
        configured: true,
        setup_date: new Date().toISOString().split('T')[0],
        business_type: business_type || 'general',
        enabled
    };
    const ok = saveGlobalModuleConfig(newCfg);
    if (ok) {
        pushLog(`⚙️ Module config updated by ${req.session.userName}`);
        res.json({ ok: true });
    } else {
        res.status(500).json({ ok: false, error: 'Failed to save config' });
    }
});

// Helper: enforce admin-or-better on a single sensitive endpoint.
function requireAdmin(req, res, next) {
    const role = req.session?.userRole;
    if (role === 'admin' || role === 'super_admin') return next();
    try { pushLog(`🚫 ADMIN-ONLY DENIED: user=${req.session?.userId} role=${role} ${req.method} ${req.path}`); } catch (_) {}
    return res.status(403).json({ ok: false, error: 'Admin access required' });
}
app.set('requireAdmin', requireAdmin);

// ─── Modular Routes ───────────────────────────────────────
const crmRoutes = require('./routes/crm');
const whatsappRoutes = require('./routes/whatsapp');
const systemRoutes = require('./routes/system');
const inventoryRoutes = require('./routes/inventory');
const financeRoutes = require('./routes/finance');
const suppliersRoutes = require('./routes/suppliers');
const gstRoutes = require('./routes/gst');
const adminRoutes = require('./routes/admin');
const aiRoutes = require('./routes/ai');
const marketingRoutes = require('./routes/marketing');
const paymentsRoutes = require('./routes/payments');
const notificationsRoutes = require('./routes/notifications');
const emailRoutes = require('./routes/email');
const authRoutes = require('./routes/auth');
const { router: backupRoutes, runBackup, loadSettings: loadBackupSettings } = require('./routes/backup');

app.use('/api', crmRoutes);
app.use('/api/whatsapp', whatsappRoutes);
app.use('/api', systemRoutes);
app.use('/api', inventoryRoutes);
app.use('/api', financeRoutes);
app.use('/api', suppliersRoutes);
app.use('/api', gstRoutes);
app.use('/api', adminRoutes);
app.use('/api', aiRoutes);
app.use('/api', marketingRoutes);
app.use('/api', paymentsRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/email', emailRoutes);
app.use('/api', backupRoutes);
// ─── Login Rate Limiter ───────────────────────────────────
// 10 attempts per 15 minutes per IP — blocks brute-force without locking out real users
const rateLimit = require('express-rate-limit');
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { ok: false, error: 'Too many login attempts. Please wait 15 minutes and try again.' }
});
app.use('/api/auth/login', loginLimiter);
app.use('/api/auth/portal-login', loginLimiter); // same rate limit for website portal
app.use('/api/auth/forgot-password', rateLimit({ windowMs: 60 * 60 * 1000, max: 5, message: { ok: false, error: 'Too many reset requests. Try again in 1 hour.' } }));

app.use('/api/auth', authRoutes);

// [DIAGNOSTIC] Global Request Logger (Filtered)
app.use((req, res, next) => {
    const skipPaths = ['/api/status', '/api/ai-limit', '/api/logs', '/api/ping', '/api/stats', '/api/leads', '/api/analytics'];
    const skipExts = ['.css', '.js', '.png', '.jpg', '.jpeg', '.svg', '.ico', '.webp'];
    
    const isPolling = skipPaths.some(p => req.path.startsWith(p));
    const isStatic = skipExts.some(ext => req.path.endsWith(ext));
    
    if (!isPolling && !isStatic) {
        const msg = `[DEBUG] ${req.method} ${req.url}`;
        console.log(msg);
    }
    next();
});

app.get('/', (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.sendFile(path.join(INTERNAL_DIR, 'dashboard.html'));
});

app.get('/dashboard.html', (req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.sendFile(path.join(INTERNAL_DIR, 'dashboard.html'));
});

app.use(express.static(INTERNAL_DIR));
app.use('/Visual_Maps', express.static(path.join(ROOT_DIR, 'Visual_Maps')));


const CUSTOMER_DOCS_DIR = path.join(ROOT_DIR, 'customer_docs');
if (!fs.existsSync(CUSTOMER_DOCS_DIR)) fs.mkdirSync(CUSTOMER_DOCS_DIR, { recursive: true });
app.use('/customer_docs', express.static(CUSTOMER_DOCS_DIR));
app.use('/assets', express.static(ASSETS_DIR));


app.get('/api/customer-assets/:phone', (req, res) => {
    const phone = req.params.phone.replace(/\D/g, '');
    const dir = path.join(CUSTOMER_DOCS_DIR, phone);
    if (!fs.existsSync(dir)) return res.json([]);
    try {
        const files = fs.readdirSync(dir).map(f => ({
            name: f,
            url: `/customer_docs/${phone}/${f}`,
            mtime: fs.statSync(path.join(dir, f)).mtime
        }));
        res.json(files.sort((a,b) => b.mtime - a.mtime));
    } catch (e) { res.status(500).json({ error: e.message }); }
});

const customerDocsStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const phone = (req.body.phone || 'general').replace(/\D/g, '');
        const dir = path.join(CUSTOMER_DOCS_DIR, phone);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        const category = req.body.category || 'DOC';
        cb(null, `${category}_${Date.now()}_${file.originalname.replace(/\s+/g, '_')}`);
    }
});
const uploadCustomerDoc = multer({ storage: customerDocsStorage });

app.post('/api/upload-customer-doc', uploadCustomerDoc.single('doc'), (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
    const phone = (req.body.phone || 'general').replace(/\D/g, '');
    res.json({ ok: true, filename: req.file.filename, url: `/customer_docs/${phone}/${req.file.filename}` });
});


// ─── OFFICE DOCUMENTS ─────────────────────────────────────────
const OFFICE_DOCS_DIR = path.join(ROOT_DIR, 'office_docs');
if (!fs.existsSync(OFFICE_DOCS_DIR)) fs.mkdirSync(OFFICE_DOCS_DIR, { recursive: true });

const officeDocsStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        if (!fs.existsSync(OFFICE_DOCS_DIR)) fs.mkdirSync(OFFICE_DOCS_DIR, { recursive: true });
        cb(null, OFFICE_DOCS_DIR);
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}_${file.originalname.replace(/\s+/g, '_')}`);
    }
});
const uploadOfficeDoc = multer({ storage: officeDocsStorage, limits: { fileSize: 50 * 1024 * 1024 } });

app.get('/api/office-docs', (req, res) => {
    db.all(`SELECT * FROM office_documents ORDER BY uploaded_at DESC`, [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true, docs: rows });
    });
});

app.post('/api/office-docs/upload', uploadOfficeDoc.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
    const { title, category, notes } = req.body;
    if (!title) return res.status(400).json({ ok: false, msg: 'Title is required' });
    const filePath = `/office_docs/${req.file.filename}`;
    const uploadedBy = req.session?.userName || req.session?.userId || '';
    db.run(
        `INSERT INTO office_documents (title, category, file_name, file_path, notes, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)`,
        [title, category || 'Other', req.file.originalname, filePath, notes || '', uploadedBy],
        function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true, id: this.lastID, path: filePath, name: req.file.originalname });
        }
    );
});

app.get('/api/office-docs/file/:filename', (req, res) => {
    const filePath = path.join(OFFICE_DOCS_DIR, req.params.filename);
    if (fs.existsSync(filePath)) res.sendFile(filePath);
    else res.status(404).send('File not found');
});

app.delete('/api/office-docs/:id', (req, res) => {
    db.get(`SELECT * FROM office_documents WHERE id=?`, [req.params.id], (err, row) => {
        if (err || !row) return res.status(404).json({ ok: false, msg: 'Not found' });
        const fullPath = path.join(OFFICE_DOCS_DIR, path.basename(row.file_path));
        try { if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath); } catch(_) {}
        db.run(`DELETE FROM office_documents WHERE id=?`, [req.params.id], (err2) => {
            if (err2) return res.status(500).json({ ok: false, msg: err2.message });
            res.json({ ok: true });
        });
    });
});


app.get('/api/version', (req, res) => {
    try {
        const vData = fs.existsSync(VERSION_PATH) ? JSON.parse(fs.readFileSync(VERSION_PATH, 'utf8')) : {};
        res.json({ version: vData.version || '2.3.0', build: vData.build, date: vData.date, notes: vData.notes });
    } catch(e) { res.json({ version: softwareVersion }); }
});

app.get('/api/lan-url', (req, res) => {
    const ifaces = os.networkInterfaces();
    const candidates = [];
    for (const [name, addrs] of Object.entries(ifaces)) {
        for (const iface of addrs) {
            if ((iface.family === 'IPv4' || iface.family === 4) && !iface.internal) {
                const ip = iface.address;
                if (ip.startsWith('169.254.')) continue; // APIPA/link-local
                candidates.push({ ip, name });
            }
        }
    }
    // Sort: 192.168.x.x first (home/office Wi-Fi), then others
    candidates.sort((a, b) => {
        const score = ip => ip.startsWith('192.168.') ? 0 : ip.startsWith('10.42.') ? 2 : 1;
        return score(a.ip) - score(b.ip);
    });
    const best = candidates[0]?.ip || null;
    const url = best ? `http://${best}:${PORT}` : `http://localhost:${PORT}`;
    res.json({
        url,
        ip: best || 'localhost',
        port: PORT,
        all: candidates.map(c => ({ ip: c.ip, name: c.name, url: `http://${c.ip}:${PORT}` }))
    });
});

// ─── State ────────────────────────────────────────────────
let botProcess = null;
let botStatus = 'offline';
let lastBotHeartbeat = 0; // epoch ms of most recent heartbeat from bot.js
const claimedInboundBuffer = []; // recent inbound messages on claimed conversations (rolling 200)

// ─── CLAIMS SSE ────────────────────────────────────────────────────────────
let sseClaimClients = [];
function pushClaimSSE(type, data) {
    const payload = `data: ${JSON.stringify({ type, ...data })}\n\n`;
    sseClaimClients = sseClaimClients.filter(res => {
        try { res.write(payload); return true; }
        catch { return false; }
    });
}

// ─── CLAIM NOTIFICATIONS ───────────────────────────────────────────────────
const _claimNotifLastSent = new Map(); // phone10 → last-sent epoch ms (rate-limit 1/min)
const _claimExpiryWarned  = new Set(); // claim IDs that have already received a 5-min warning

function _notifyClaimingAgent(phone10, staffId, customerText) {
    const now = Date.now();
    if (now - (_claimNotifLastSent.get(phone10) || 0) < 60000) return;
    _claimNotifLastSent.set(phone10, now);
    db.get(
        `SELECT s.phone AS sPhone, s.name AS sName, c.name AS cName
           FROM conversation_claims cc
           JOIN staff s ON CAST(s.id AS TEXT) = CAST(cc.staff_id AS TEXT)
           LEFT JOIN customers c ON c.phone = ?
          WHERE (cc.customer_phone = ? OR cc.customer_phone = ?)
            AND cc.status = 'Active' LIMIT 1`,
        [phone10, phone10, '91' + phone10],
        (err, row) => {
            if (err || !row || !row.sPhone) return;
            const rawPhone = String(row.sPhone).replace(/\D/g, '');
            if (!rawPhone) return;
            const target = rawPhone.length === 10 ? '91' + rawPhone : rawPhone;
            const custName = row.cName || phone10;
            const preview  = (customerText || '').slice(0, 80);
            const text = `📩 *${custName}* replied in your claimed chat:\n"${preview}"\n\n_Open dashboard → Claimed Chats to reply._`;
            if (botProcess) botProcess.send({ type: 'send_whatsapp', data: { target, text } });
        }
    );
}

function _sendClaimExpiryWarning(claim, minsLeft) {
    const phone10 = String(claim.customer_phone).replace(/\D/g, '').slice(-10);
    db.get(`SELECT phone FROM staff WHERE CAST(id AS TEXT) = CAST(? AS TEXT) LIMIT 1`, [claim.staff_id], (err, row) => {
        if (err || !row || !row.phone) return;
        const rawPhone = String(row.phone).replace(/\D/g, '');
        if (!rawPhone) return;
        const target = rawPhone.length === 10 ? '91' + rawPhone : rawPhone;
        db.get(`SELECT name FROM customers WHERE phone = ? LIMIT 1`, [phone10], (e2, cust) => {
            const custName = (cust && cust.name) || phone10;
            const text = `⚠️ *Claim Expiring*\nYour claimed conversation with *${custName}* auto-releases in ~${minsLeft} min.\n\nSend a reply from the dashboard to reset the timer.`;
            if (botProcess) botProcess.send({ type: 'send_whatsapp', data: { target, text } });
            pushLog(`⚠️ EXPIRY WARNING → ${claim.staff_name || claim.staff_id} for ${claim.customer_phone} (${minsLeft}m left)`);
        });
    });
}

// Keep app.get('botStatus') in sync so modular routes can read it
function setBotStatus(s) { botStatus = s; app.set('botStatus', s); }
let lastBotId = 'drd_bot_1';
let currentQR = null;
let connectedNumber = null;
let lastRestartRequestedBy = null;
let logs = [];
let logClients = [];
const startTime = Date.now();
const SYSTEM_LOG_PATH = path.join(ROOT_DIR, 'server_log.txt');

// ─── Log Rotation — trim to last 500 lines on startup + daily at midnight ────
function trimLog() {
    try {
        if (!fs.existsSync(SYSTEM_LOG_PATH)) return;
        const lines = fs.readFileSync(SYSTEM_LOG_PATH, 'utf8').split('\n');
        if (lines.length > 600) {
            fs.writeFileSync(SYSTEM_LOG_PATH, lines.slice(-500).join('\n'));
        }
    } catch (_) {}
}
trimLog(); // trim on every server start
(function scheduleDailyLogTrim() {
    const now = new Date();
    const msUntilMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 1, 0) - now;
    setTimeout(() => { trimLog(); setInterval(trimLog, 24 * 60 * 60 * 1000); }, msUntilMidnight);
})();

// ─── Developer Error Alert via WhatsApp ──────────────────────────────────────
const DEV_ALERT_PHONE = '919894815803@c.us';
const _devAlertQueue = [];         // holds messages when bot isn't connected yet
let _lastAlertSent = 0;            // debounce: no more than 1 alert per 60s per category
const _alertCooldown = {};

function sendDevAlert(category, snippet) {
    const now = Date.now();
    if (_alertCooldown[category] && now - _alertCooldown[category] < 60000) return; // 1-min cooldown per category
    _alertCooldown[category] = now;

    const os = require('os');
    const maxChars = 3800;
    const body = (snippet || '').toString().slice(-maxChars); // keep tail (most recent errors)
    const ts = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
    const host = os.hostname();
    const text = `🚨 *DRD System Alert*\n*Type:* ${category}\n*Time:* ${ts}\n*Host:* ${host}\n\n\`\`\`\n${body}\n\`\`\``;

    if (botStatus === 'connected' && botProcess && botProcess.send) {
        try { botProcess.send({ type: 'send_whatsapp', data: { target: DEV_ALERT_PHONE, text } }); } catch (_) {}
    } else {
        if (_devAlertQueue.length < 5) _devAlertQueue.push({ category, text }); // queue up to 5
    }
}

function _drainDevAlertQueue() {
    while (_devAlertQueue.length > 0 && botStatus === 'connected' && botProcess && botProcess.send) {
        const item = _devAlertQueue.shift();
        try { botProcess.send({ type: 'send_whatsapp', data: { target: DEV_ALERT_PHONE, text: item.text } }); } catch (_) {}
    }
}

// Server-level crash hooks — report to developer
process.on('uncaughtException', (err) => {
    const msg = `[uncaughtException]\n${err.stack || err}`;
    try { fs.appendFileSync(SYSTEM_LOG_PATH, `[${new Date().toISOString()}] FATAL: ${msg}\n`); } catch(_) {}
    sendDevAlert('Server Crash', msg);
    setTimeout(() => process.exit(1), 3000); // allow WhatsApp send to fire
});
process.on('unhandledRejection', (reason) => {
    const msg = `[unhandledRejection]\n${reason?.stack || reason}`;
    try { fs.appendFileSync(SYSTEM_LOG_PATH, `[${new Date().toISOString()}] WARN: ${msg}\n`); } catch(_) {}
    sendDevAlert('Unhandled Rejection', msg);
});

// Share with routes
app.set('ROOT_DIR', ROOT_DIR);
app.set('INTERNAL_DIR', INTERNAL_DIR);
app.set('SYSTEM_LOG_PATH', SYSTEM_LOG_PATH);
app.set('logs', logs);
app.set('pushLog', pushLog);
app.set('db', db);

let recentActivity = [];
let currentAiModel = "Gemini 1.5 Flash Latest";

function pushLog(msg) {
    const time = new Date().toLocaleTimeString('en-IN');
    const entry = { time, msg };
    logs.push(entry);
    recentActivity.unshift(entry);
    if(recentActivity.length > 10) recentActivity.pop();
    if(logs.length > 1000) logs.shift();
    
    // Write to persistent file
    const logLine = `[${new Date().toISOString()}] ${msg}\n`;
    try { fs.appendFileSync(SYSTEM_LOG_PATH, logLine); } catch(e) {}

    console.log(`[LOG] ${msg}`);
    logClients.forEach(c => { try { c.write(`data: ${JSON.stringify(entry)}\n\n`); } catch(_) {} });
}

const CONFIG_PATH = path.join(ROOT_DIR, 'Companies_Config.json');
const RULES_PATH = path.join(ROOT_DIR, 'keyword_rules.json');
const AUTH_DIR = path.join(ROOT_DIR, '.wwebjs_auth');
const BOT_PRESETS_PATH = path.join(ROOT_DIR, 'bot_config.json');
const MASTER_DB_PATH = path.join(ROOT_DIR, 'Master_Enterprise_DB.xlsx');
const QUOTATIONS_PATH = path.join(ROOT_DIR, 'quotations.json');
const TRAINING_DATA_DIR = path.join(ROOT_DIR, 'training_data');
const COMPANY_SETTINGS_PATH = path.join(ROOT_DIR, 'drd_company_settings.json');

// Admin and WhatsApp routes moved to modular files



function getMasterData(sheetName) {
    // Legacy shim — returns data from SQLite instead of Excel
    try {
        if (sheetName === 'Customers') {
            let rows = [];
            db.all(`SELECT phone AS Phone, name AS Name, plot AS Plot_Bought, price AS App_Price,
                           status AS Status, location AS Location FROM customers`, [], (err, r) => { if (!err) rows = r; });
            return rows;
        }
        if (sheetName === 'Employees') {
            let rows = [];
            db.all(`SELECT id, name AS Name, dept AS Dept, phone AS Phone, email AS Email FROM staff`, [], (err, r) => { if (!err) rows = r; });
            return rows;
        }
        return [];
    } catch (e) { return []; }
}

function saveMasterData(sheetName, data) {
    try {
        let wb = fs.existsSync(MASTER_DB_PATH) ? xlsx.readFile(MASTER_DB_PATH) : xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(data);
        if (wb.SheetNames.includes(sheetName)) wb.Sheets[sheetName] = ws;
        else xlsx.utils.book_append_sheet(wb, ws, sheetName);
        xlsx.writeFile(wb, MASTER_DB_PATH);
        return true;
    } catch (e) { return false; }
}

app.get('/api/staff', (req, res) => {
    db.run(`ALTER TABLE staff ADD COLUMN employee_code TEXT`, () => {});  // idempotent
    db.all(`SELECT id, name, dept, phone, email, role, is_active, photo, employee_code FROM staff ORDER BY name`, [], (err, rows) => {
        if (err) return res.json([]);
        res.json(rows || []);
    });
});

app.post('/api/staff', (req, res) => {
    if (req.query.delete) {
        db.run(`DELETE FROM staff WHERE id = ?`, [req.query.delete], (err) => {
            res.json({ ok: !err });
        });
    } else {
        // Accept both Excel-style keys (Staff_ID, Name) and SQLite-style (id, name)
        const id    = (req.body.Staff_ID || req.body.id    || '').trim().toUpperCase();
        const name  =  req.body.Name     || req.body.name  || '';
        const dept  =  req.body.Department || req.body.dept || '';
        const phone =  req.body.Phone    || req.body.phone  || '';
        const email =  req.body.Email    || req.body.email  || '';
        if (!id || !name) return res.json({ ok: false, msg: 'id and name required' });
        db.run(`INSERT OR REPLACE INTO staff (id, name, dept, phone, email) VALUES (?, ?, ?, ?, ?)`,
            [id, name, dept, phone, email],
            (err) => res.json({ ok: !err, msg: err?.message })
        );
    }
});

// PUT /api/staff/:id — update editable fields only (never touches password_hash, photo, role, is_active)
app.put('/api/staff/:id', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const staffId = req.params.id.toUpperCase();
    const { name, dept, phone, email } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ ok: false, msg: 'name required' });
    db.run(`UPDATE staff SET name=?, dept=?, phone=?, email=? WHERE id=?`,
        [name.trim(), (dept||'').trim(), (phone||'').trim(), (email||'').trim(), staffId],
        function(err) { res.json({ ok: !err, changes: this?.changes || 0, msg: err?.message }); }
    );
});

// ─── UI ERROR REPORTER → GitHub issue ──────────────────────────────
// Dashboard reportUiError() POSTs batched UI errors here. We write a local
// file (always), then if a GITHUB_PAT + bug_report_repo are configured we
// open one GitHub issue per batch so they surface in the same place as
// manual bug reports. Deduped per session by a short hash of the messages
// to avoid spamming the repo if the same error fires repeatedly.
const ERROR_REPORTS_DIR = path.join(ROOT_DIR, 'error_reports');
const _seenErrorHashes = new Map(); // hash → timestamp
const _ERROR_DEDUP_WINDOW_MS = 60 * 60 * 1000; // 1 hr

app.post('/api/error-report', async (req, res) => {
    try {
        if (!fs.existsSync(ERROR_REPORTS_DIR)) fs.mkdirSync(ERROR_REPORTS_DIR, { recursive: true });

        const errors = Array.isArray(req.body?.errors) ? req.body.errors.slice(0, 50) : [];
        if (!errors.length) return res.json({ ok: false, error: 'no errors in batch' });

        const stamp = new Date().toISOString().replace(/[:.]/g, '-');
        const fname = `ui_${stamp}.json`;
        try { fs.writeFileSync(path.join(ERROR_REPORTS_DIR, fname), JSON.stringify({ user: req.session?.userId, errors }, null, 2)); } catch (_) {}

        // Dedup — collapse identical messages within the rolling window
        const sig = errors.map(e => `${e.type}|${e.message}|${e.line || ''}`).join('\n');
        const hash = require('crypto').createHash('sha1').update(sig).digest('hex').slice(0, 12);
        const lastSeen = _seenErrorHashes.get(hash);
        const now = Date.now();
        // Garbage-collect old entries
        for (const [h, t] of _seenErrorHashes) if (now - t > _ERROR_DEDUP_WINDOW_MS) _seenErrorHashes.delete(h);
        if (lastSeen && (now - lastSeen) < _ERROR_DEDUP_WINDOW_MS) {
            return res.json({ ok: true, deduped: true, hash });
        }
        _seenErrorHashes.set(hash, now);

        // GitHub upload (opt-in via env + bot_settings.bug_report_repo)
        const pat = process.env.GITHUB_PAT || '';
        let bug_repo = '';
        try {
            const cfg = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'bot_settings.json'), 'utf8'));
            bug_repo = (cfg.bug_report_repo || '').trim() || 'prakashluv/onlineupdate';
        } catch (_) { bug_repo = 'prakashluv/onlineupdate'; }

        if (!pat || !bug_repo) {
            return res.json({ ok: true, local: true, file: fname, note: 'GITHUB_PAT or bug_report_repo not set — error saved locally only.' });
        }

        const lines = errors.map(e => `- **${e.type || 'error'}** at ${e.url || '/'} (line ${e.line || '?'}, ${e.ts}): ${String(e.message || '').slice(0, 400)}${e.stack ? '\n  <details><summary>stack</summary>\n\n  ```\n  ' + e.stack.slice(0, 1200) + '\n  ```\n  </details>' : ''}`).join('\n');
        const issueTitle = `🐛 UI errors: ${errors[0]?.message ? String(errors[0].message).slice(0, 80) : 'batch'}`;
        const issueBody  = `Auto-filed by the dashboard error reporter.\n\n**User:** ${req.session?.userId || 'anonymous'}\n**Batch size:** ${errors.length}\n**UA:** ${errors[0]?.ua || '?'}\n**Hash:** \`${hash}\`\n\n### Errors\n${lines}`;

        const payload = JSON.stringify({ title: issueTitle, body: issueBody, labels: ['bug-report', 'ui-auto'] });
        const https = require('https');
        const result = await new Promise((resolve) => {
            const r = https.request({
                hostname: 'api.github.com',
                path: `/repos/${bug_repo}/issues`,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${pat}`,
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(payload),
                    'User-Agent': 'PropertyGenius-ErrorReporter/1.0',
                    'Accept': 'application/vnd.github.v3+json'
                }
            }, resp => {
                let data = '';
                resp.on('data', d => data += d);
                resp.on('end', () => { try { resolve({ status: resp.statusCode, body: JSON.parse(data) }); } catch (_) { resolve({ status: resp.statusCode, body: data }); } });
            });
            r.on('error', err => resolve({ status: 0, body: { message: err.message } }));
            r.write(payload);
            r.end();
        });

        if (result.status === 201) {
            try { pushLog(`🐛 UI error filed: ${result.body.html_url}`); } catch (_) {}
            res.json({ ok: true, url: result.body.html_url, hash });
        } else {
            res.json({ ok: false, local: true, file: fname, github_status: result.status, hint: 'Saved locally. Check GITHUB_PAT permissions or bug_report_repo setting.' });
        }
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

// ─── AI Automation: bot command on/off + custom commands ──────────
// Source of truth: bot_commands.json in ROOT_DIR. bot.js watches the file
// and re-reads on change, so saves take effect within seconds without restart.
const BOT_COMMANDS_PATH = path.join(ROOT_DIR, 'bot_commands.json');

app.get('/api/bot-commands', (req, res) => {
    try {
        if (!fs.existsSync(BOT_COMMANDS_PATH)) return res.json({ builtin: {}, custom: [] });
        const cfg = JSON.parse(fs.readFileSync(BOT_COMMANDS_PATH, 'utf8'));
        res.json(cfg);
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.post('/api/bot-commands', (req, res) => {
    try {
        const incoming = req.body || {};
        if (!incoming.builtin || typeof incoming.builtin !== 'object') return res.status(400).json({ ok: false, error: 'builtin object required' });
        if (!Array.isArray(incoming.custom)) incoming.custom = [];
        // Persist with stable ordering of keys; merge in case partial update arrives
        let existing = {};
        try { existing = JSON.parse(fs.readFileSync(BOT_COMMANDS_PATH, 'utf8')); } catch (_) {}
        const merged = {
            _meta: existing._meta || { version: 1 },
            builtin: { ...(existing.builtin || {}), ...incoming.builtin },
            custom: incoming.custom
        };
        fs.writeFileSync(BOT_COMMANDS_PATH, JSON.stringify(merged, null, 2));
        res.json({ ok: true });
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

// ─── HR & ACCOUNTS MODULE API ──────────────────────────

// Attendance API
app.get('/api/attendance', (req, res) => {
    const { date } = req.query;
    const filterDate = date ? `${date}%` : `${new Date().toISOString().split('T')[0]}%`;
    db.all(`SELECT * FROM attendance WHERE date LIKE ?`, [filterDate], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.post('/api/attendance', (req, res) => {
    const { staff_id, name, status, gps_location, photo_proof, date, check_in, check_out, notes } = req.body;
    const recordDate = date || new Date().toISOString().split('T')[0];
    db.run(`INSERT INTO attendance (staff_id, name, date, check_in, check_out, status, gps_location, photo_proof, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [staff_id, name, recordDate, check_in || null, check_out || null,
             status || 'Present', gps_location || 'Manual Entry', photo_proof || 'No Photo', notes || null],
            function(err) {
                if (err) return res.status(500).json({ ok: false, msg: err.message });
                res.json({ ok: true, id: this.lastID });
            });
});

app.put('/api/attendance/:id', (req, res) => {
    const { check_in, check_out, status, notes } = req.body;
    db.run(`UPDATE attendance SET check_in=?, check_out=?, status=?, notes=? WHERE id=?`,
        [check_in||null, check_out||null, status||'Present', notes||null, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true });
        });
});

app.delete('/api/attendance/:id', (req, res) => {
    db.run(`DELETE FROM attendance WHERE id=?`, [req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

// Salaries API
app.get('/api/salaries', (req, res) => {
    const month = req.query.month;
    const year = req.query.year || new Date().getFullYear();
    db.all(`SELECT sa.*, s.name as staff_name FROM salaries sa 
            LEFT JOIN staff s ON sa.staff_id = s.id 
            WHERE sa.month = ? AND sa.year = ?`, [month, year], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.post('/api/salaries', (req, res) => {
    const { staff_id, month, year, base_pay, deductions, net_pay, status } = req.body;
    db.run(`INSERT INTO salaries (staff_id, month, year, base_pay, deductions, net_pay, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?)`, 
            [staff_id, month, year, base_pay, deductions, net_pay, status], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true, id: this.lastID });
    });
});

app.put('/api/salaries/:id', (req, res) => {
    const { base_pay, deductions, net_pay, status } = req.body;
    db.run(`UPDATE salaries SET base_pay=?, deductions=?, net_pay=?, status=? WHERE id=?`,
        [base_pay, deductions, net_pay, status, req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        if (this.changes === 0) return res.status(404).json({ ok: false, msg: 'Record not found' });
        res.json({ ok: true });
    });
});

app.delete('/api/salaries/:id', (req, res) => {
    db.run(`DELETE FROM salaries WHERE id=?`, [req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

// Expenses API
app.get('/api/expenses', (req, res) => {
    db.all(`SELECT * FROM expenses ORDER BY date DESC LIMIT 100`, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.post('/api/expenses', (req, res) => {
    const { date, category, layout_name, amount, description, recorded_by } = req.body;
    db.run(`INSERT INTO expenses (date, category, layout_name, amount, description, recorded_by)
            VALUES (?, ?, ?, ?, ?, ?)`,
            [date, category, layout_name, amount, description, recorded_by], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true, id: this.lastID });
    });
});
app.put('/api/expenses/:id', (req, res) => {
    const { date, category, layout_name, amount, description, supplier_id } = req.body;
    db.run(`UPDATE expenses SET date=?, category=?, layout_name=?, amount=?, description=?, supplier_id=? WHERE id=?`,
        [date, category, layout_name, amount, description, supplier_id || null, req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        if (this.changes === 0) return res.status(404).json({ ok: false, msg: 'Expense not found' });
        res.json({ ok: true });
    });
});
app.delete('/api/expenses/:id', (req, res) => {
    db.run(`DELETE FROM expenses WHERE id = ?`, [req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

// ─── MARKETING & DRIP CAMPAIGNS API ──────────────────
app.get('/api/campaigns', (req, res) => {
    db.all(`SELECT * FROM drip_campaigns ORDER BY days_offset ASC`, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.post('/api/campaigns', (req, res) => {
    const { name, days_offset, message_text, media_path, is_active } = req.body;
    db.run(`INSERT INTO drip_campaigns (name, days_offset, message_text, media_path, is_active)
            VALUES (?, ?, ?, ?, ?)`,
            [name, days_offset, message_text, media_path, is_active || 1], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true, id: this.lastID });
    });
});

app.get('/api/scheduled-messages', (req, res) => {
    db.all(`SELECT s.*, c.name as campaign_name FROM scheduled_messages s
            LEFT JOIN drip_campaigns c ON s.campaign_id = c.id
            ORDER BY scheduled_date DESC LIMIT 200`, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});


app.get('/api/crm/followups/:phone', (req, res) => {
    // Match by last 10 digits so 10-digit and 12-digit stored values both resolve
    const phone10 = String(req.params.phone).replace(/\D/g, '').slice(-10);
    db.all(
        `SELECT * FROM followups WHERE substr(customer_phone, -10) = ? ORDER BY created_at DESC`,
        [phone10], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.post('/api/crm/followup', (req, res) => {
    const { phone, staff, notes, next_date } = req.body;
    const phone10 = String(phone || '').replace(/\D/g, '').slice(-10);
    db.run('INSERT INTO followups (customer_phone, staff_name, notes, next_followup) VALUES (?, ?, ?, ?)',
        [phone10, staff, notes, next_date], (err) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

// Generic follow-up save (used by the 📝 modal from the CRM table row)
app.post('/api/followups', (req, res) => {
    const { lead_id, scheduled_at, note } = req.body;
    const phone10 = String(lead_id || '').replace(/\D/g, '').slice(-10);
    if (!phone10) return res.status(400).json({ ok: false, error: 'Phone required' });
    const next_date = scheduled_at ? scheduled_at.split('T')[0] : null;
    db.run(
        `INSERT INTO followups (customer_phone, staff_name, notes, next_followup, status) VALUES (?, ?, ?, ?, 'Pending')`,
        [phone10, req.session?.user?.username || 'Staff', note || '', next_date], (err) => {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        res.json({ ok: true });
    });
});


app.get('/api/campaign-status', (req, res) => {
    db.all(`SELECT status, COUNT(*) as count FROM scheduled_messages GROUP BY status`, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.get('/api/campaign-logs', (req, res) => {
    db.all(`SELECT * FROM scheduled_messages ORDER BY created_at DESC LIMIT 50`, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.get('/api/crm/reminders', (req, res) => {
    const today = new Date().toISOString().split('T')[0];
    db.all(
        `SELECT f.*, c.name FROM followups f
         LEFT JOIN customers c ON substr(c.phone, -10) = substr(f.customer_phone, -10)
         WHERE f.next_followup = ? AND f.status = 'Pending'
         ORDER BY f.created_at DESC`,
        [today], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});


// Pending PDF send callbacks: jobId → { resolve, reject, timer }
const pdfCallbacks = new Map();

// Pending OTP-delivery callbacks: ackId → callback({ok, error}). Used by auth.js
// to wait for the bot to actually deliver a WhatsApp OTP before responding.
const otpCallbacks = new Map();
app.set('otpCallbacks', otpCallbacks);

app.post('/api/broadcast/send-pdf', async (req, res) => {
    try {
        const { phone, html, name, caption } = req.body;
        const target = phone.includes('@c.us') ? phone : `${phone}@c.us`;

        if (!botProcess || !botProcess.send || botStatus !== 'connected') {
            return res.status(500).json({ ok: false, msg: 'WhatsApp Bot not connected. Please scan QR and try again.' });
        }

        const scratchDir = path.join(ROOT_DIR, 'scratch');
        if (!fs.existsSync(scratchDir)) fs.mkdirSync(scratchDir, { recursive: true });
        const tempHtmlPath = path.join(ROOT_DIR, 'scratch', `quote_${Date.now()}.html`);

        // ── Inline images so the file:// loaded page renders logos correctly ──
        // The PDF browser loads via file://, so relative paths like "/logo/foo.png" resolve to
        // the filesystem root (not the server root). Convert every <img src="..."> that points
        // to a local logo/asset into a data: URI, so the PDF matches the printout exactly.
        const inlineLocalImages = (htmlStr) => {
            const replaceMatch = (full, srcQuote, srcVal) => {
                if (/^(?:data|https?):/i.test(srcVal)) return full; // already inlined / remote
                // Resolve a few common shapes — leading "/", relative, "./", file://
                let rel = srcVal.replace(/^file:\/+/i, '/').replace(/^\.\//, '');
                if (rel.startsWith('/')) rel = rel.slice(1);
                const candidates = [
                    path.join(ROOT_DIR, rel),
                    path.join(__dirname, rel),
                    path.join(ROOT_DIR, 'logo', path.basename(rel)),
                ];
                for (const p of candidates) {
                    try {
                        if (fs.existsSync(p) && fs.statSync(p).isFile()) {
                            const ext = (path.extname(p).slice(1) || 'png').toLowerCase();
                            const mime = ({ jpg: 'jpeg', jpeg: 'jpeg', png: 'png', gif: 'gif', svg: 'svg+xml', webp: 'webp' })[ext] || ext;
                            const b64 = fs.readFileSync(p).toString('base64');
                            return `src=${srcQuote}data:image/${mime};base64,${b64}${srcQuote}`;
                        }
                    } catch (e) { /* try next */ }
                }
                return full; // give up — leave original src
            };
            return htmlStr.replace(/\bsrc=(["'])([^"']+)\1/g, (m, q, v) => replaceMatch(m, q, v));
        };

        const inlinedHtml = inlineLocalImages(html);
        fs.writeFileSync(tempHtmlPath, inlinedHtml);

        const jobId = Date.now().toString(36) + Math.random().toString(36).slice(2);

        // Wait for bot to confirm success or failure (45s timeout)
        await new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                pdfCallbacks.delete(jobId);
                reject(new Error('Timed out — bot took too long. Check if WhatsApp is connected.'));
            }, 45000);
            pdfCallbacks.set(jobId, (result) => {
                clearTimeout(timer);
                pdfCallbacks.delete(jobId);
                result.ok ? resolve() : reject(new Error(result.error || 'Bot failed to send PDF'));
            });
            botProcess.send({
                type: 'send_pdf_quotation',
                data: { target, htmlPath: tempHtmlPath, filename: `Quotation_${name || 'Customer'}.pdf`, caption: caption || '', jobId }
            });
        });

        res.json({ ok: true });
    } catch (e) {
        res.status(500).json({ ok: false, msg: e.message });
    }
});

app.post('/api/broadcast', (req, res) => {
    const { phones, message, media_path } = req.body;
    if (!phones || !Array.isArray(phones) || !message) {
        return res.status(400).json({ ok: false, msg: 'Invalid broadcast data' });
    }

    const today = new Date().toISOString().split('T')[0];
    const stmt = db.prepare(`INSERT INTO scheduled_messages (customer_phone, message_text, media_path, scheduled_date, status)
                             VALUES (?, ?, ?, ?, 'Pending')`);
    
    phones.forEach(p => {
        let finalMsg = message;
        if(typeof p === 'object') {
            finalMsg = message.replace(/{name}/gi, p.name || 'Customer');
            stmt.run(p.phone, finalMsg, media_path, today);
        } else {
            stmt.run(p, message, media_path, today);
        }
    });
    stmt.finalize();
    res.json({ ok: true, msg: `Broadcast of ${phones.length} messages scheduled.` });
});

// ─── Broadcast image upload ────────────────────────────
const broadcastImagesDir = path.join(ROOT_DIR, 'broadcast_images');
if (!fs.existsSync(broadcastImagesDir)) fs.mkdirSync(broadcastImagesDir, { recursive: true });
const broadcastImgStorage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, broadcastImagesDir),
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        cb(null, `broadcast_${Date.now()}${ext}`);
    }
});
const uploadBroadcastImg = multer({ storage: broadcastImgStorage, limits: { fileSize: 20 * 1024 * 1024 } });

app.post('/api/broadcast/upload-image', uploadBroadcastImg.single('image'), (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, error: 'No file uploaded' });
    res.json({ ok: true, filename: req.file.filename, path: path.join(broadcastImagesDir, req.file.filename) });
});

// ─── Broadcast: personalized send ─────────────────────
app.post('/api/broadcast/personalized', (req, res) => {
    const { message, media_path, recipient_type, list_name, specific_phone, phones, send_vcf } = req.body || {};
    if (!message) return res.status(400).json({ ok: false, error: 'message required' });

    const today = new Date().toISOString().split('T')[0];
    // __SEND_VCF__ sentinel: bot.js sends contact card before the text message
    const effectiveMedia = send_vcf ? '__SEND_VCF__' : (media_path || null);

    const insertRow = (phone, name) => {
        const p = String(phone || '').replace(/\D/g, '');
        if (!p) return false;
        const text = message.replace(/{name}/gi, name || 'Customer');
        db.run(`INSERT INTO scheduled_messages (customer_phone, message_text, media_path, scheduled_date, status) VALUES (?, ?, ?, ?, 'Pending')`, [p, text, effectiveMedia, today]);
        return true;
    };

    if (recipient_type === 'specific' && specific_phone) {
        insertRow(specific_phone.trim(), 'Customer');
        return res.json({ ok: true, count: 1 });
    }

    if (recipient_type === 'phones' && Array.isArray(phones)) {
        let count = 0;
        phones.forEach(p => { if (insertRow(p, 'Customer')) count++; });
        return res.json({ ok: true, count });
    }

    if (recipient_type === 'list' && list_name) {
        const settingsPath = path.join(ROOT_DIR, 'bot_settings.json');
        let lists = [];
        try { lists = (JSON.parse(fs.readFileSync(settingsPath, 'utf8')).broadcast_lists || []); } catch {}
        const lst = lists.find(l => l.name === list_name);
        if (!lst) return res.status(404).json({ ok: false, error: 'List not found' });
        let count = 0;
        (lst.phones || []).forEach(p => { if (insertRow(p, 'Customer')) count++; });
        return res.json({ ok: true, count });
    }

    // Default: all CRM leads
    db.all(`SELECT name, phone FROM customers WHERE phone IS NOT NULL AND phone != '' GROUP BY phone`, [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        let count = 0;
        (rows || []).forEach(row => { if (insertRow(row.phone, row.name)) count++; });
        res.json({ ok: true, count });
    });
});

// ─── Broadcast Lists CRUD ──────────────────────────────
function getBotSettings() {
    const p = path.join(ROOT_DIR, 'bot_settings.json');
    try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return {}; }
}
function saveBotSettings(data) {
    fs.writeFileSync(path.join(ROOT_DIR, 'bot_settings.json'), JSON.stringify(data, null, 2));
}

app.get('/api/broadcast/lists', (req, res) => {
    const s = getBotSettings();
    res.json({ ok: true, lists: s.broadcast_lists || [] });
});

app.post('/api/broadcast/lists', (req, res) => {
    const { name, phones } = req.body || {};
    if (!name) return res.status(400).json({ ok: false, error: 'name required' });
    const s = getBotSettings();
    if (!s.broadcast_lists) s.broadcast_lists = [];
    if (s.broadcast_lists.find(l => l.name === name)) return res.status(400).json({ ok: false, error: 'List name already exists' });
    s.broadcast_lists.push({ name, phones: phones || [] });
    saveBotSettings(s);
    res.json({ ok: true });
});

app.put('/api/broadcast/lists/:name', (req, res) => {
    const oldName = decodeURIComponent(req.params.name);
    const { name, phones } = req.body || {};
    const s = getBotSettings();
    if (!s.broadcast_lists) return res.status(404).json({ ok: false, error: 'Not found' });
    const idx = s.broadcast_lists.findIndex(l => l.name === oldName);
    if (idx === -1) return res.status(404).json({ ok: false, error: 'List not found' });
    s.broadcast_lists[idx] = { name: name || oldName, phones: phones !== undefined ? phones : s.broadcast_lists[idx].phones };
    saveBotSettings(s);
    res.json({ ok: true });
});

app.delete('/api/broadcast/lists/:name', (req, res) => {
    const name = decodeURIComponent(req.params.name);
    const s = getBotSettings();
    if (!s.broadcast_lists) return res.json({ ok: true });
    s.broadcast_lists = s.broadcast_lists.filter(l => l.name !== name);
    saveBotSettings(s);
    res.json({ ok: true });
});

// ─── Smart Lists (CRM auto-generated) ─────────────────
app.get('/api/broadcast/smart-lists', (req, res) => {
    const defs = [
        { key: 'all_leads',         label: 'All Leads',              icon: '👥',
          sql: `SELECT name, phone FROM customers WHERE phone IS NOT NULL AND phone != '' GROUP BY phone` },
        { key: 'hot_leads',         label: 'Hot Leads',              icon: '🔥',
          sql: `SELECT name, phone FROM customers WHERE phone IS NOT NULL AND phone != '' AND (lead_score >= 7 OR status = 'Hot' OR status = 'Interested') GROUP BY phone` },
        { key: 'recent_enquiries',  label: 'Enquiries (30 days)',    icon: '📅',
          sql: `SELECT name, phone FROM customers WHERE phone IS NOT NULL AND phone != '' AND created_at >= date('now','-30 days') GROUP BY phone` },
        { key: 'booked',            label: 'Booked Customers',       icon: '✅',
          sql: `SELECT name, phone FROM customers WHERE phone IS NOT NULL AND phone != '' AND (status = 'Booked' OR status = 'Registered' OR status = 'Sold') GROUP BY phone` },
        { key: 'followup_due',      label: 'Follow-up Due Today',    icon: '⏰',
          sql: `SELECT c.name, c.phone FROM followups f JOIN customers c ON c.id = f.customer_id WHERE f.follow_up_date <= date('now') AND (f.status IS NULL OR f.status != 'Done') AND c.phone IS NOT NULL AND c.phone != '' GROUP BY c.phone` },
        { key: 'no_followup',       label: 'Never Followed Up',      icon: '💤',
          sql: `SELECT name, phone FROM customers WHERE phone IS NOT NULL AND phone != '' AND id NOT IN (SELECT DISTINCT customer_id FROM followups WHERE customer_id IS NOT NULL) GROUP BY phone` },
    ];
    const results = [];
    let pending = defs.length;
    defs.forEach(d => {
        db.all(d.sql, [], (err, rows) => {
            results.push({
                key: d.key, label: d.label, icon: d.icon,
                count: err ? 0 : (rows || []).length,
                phones: err ? [] : (rows || []).map(r => String(r.phone || '').replace(/\D/g, '')).filter(Boolean)
            });
            if (--pending === 0) {
                results.sort((a, b) => defs.findIndex(x => x.key === a.key) - defs.findIndex(x => x.key === b.key));
                res.json({ ok: true, lists: results });
            }
        });
    });
});

// ─── CRM Contact Picker ────────────────────────────────
app.get('/api/customers/picker', (req, res) => {
    const q = (req.query.q || '').trim();
    let sql = `SELECT name, phone FROM customers WHERE phone IS NOT NULL AND phone != ''`;
    const params = [];
    if (q) { sql += ` AND (name LIKE ? OR phone LIKE ?)`; params.push(`%${q}%`, `%${q}%`); }
    sql += ` GROUP BY phone ORDER BY name LIMIT 300`;
    db.all(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        res.json({ ok: true, contacts: (rows || []).map(r => ({ name: r.name || '', phone: String(r.phone || '').replace(/\D/g, '') })) });
    });
});

// ─── VCF Card Settings ─────────────────────────────────
const VCF_FIELDS = ['vcf_name','vcf_phone','vcf_phone2','vcf_email','vcf_address','vcf_website','vcf_tagline','vcf_caption','vcf_logo','vcf_include'];

app.get('/api/vcf/settings', (req, res) => {
    try {
        const s = JSON.parse(fs.readFileSync(COMPANY_SETTINGS_PATH, 'utf8'));
        const out = {
            vcf_name:    s.vcf_name    || s.companyName || '',
            vcf_phone:   s.vcf_phone   || s.phone       || '',
            vcf_phone2:  s.vcf_phone2  || s.phone2      || '',
            vcf_email:   s.vcf_email   || s.email       || '',
            vcf_address: s.vcf_address || s.address     || '',
            vcf_website: s.vcf_website || s.website     || '',
            vcf_tagline: s.vcf_tagline || s.tagline     || '',
            vcf_caption: s.vcf_caption || '',
            vcf_logo:    s.vcf_logo    || s.logo        || '',
            vcf_include: s.vcf_include || { phone2: true, email: true, address: true, website: true, tagline: true, logo: true },
        };
        // Available logo files
        const logoDir = path.join(__dirname, 'logo');
        let logo_options = [];
        try {
            logo_options = fs.readdirSync(logoDir)
                .filter(f => /\.(png|jpg|jpeg|gif|webp)$/i.test(f))
                .map(f => {
                    const size = fs.statSync(path.join(logoDir, f)).size;
                    return { name: f, path: `/logo/${f}`, size, kb: Math.round(size / 1024), ok: size <= 200 * 1024 };
                })
                .sort((a, b) => a.size - b.size);
        } catch (_) {}
        res.json({ ok: true, settings: out, logo_options });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/vcf/settings', (req, res) => {
    if (!['super_admin','admin'].includes(req.session?.userRole)) return res.status(403).json({ ok: false });
    try {
        let s = {};
        try { s = JSON.parse(fs.readFileSync(COMPANY_SETTINGS_PATH, 'utf8')); } catch {}
        VCF_FIELDS.forEach(k => { if (req.body[k] !== undefined) s[k] = req.body[k]; });
        fs.writeFileSync(COMPANY_SETTINGS_PATH, JSON.stringify(s, null, 2));
        const bp = app.get('botProcess');
        if (bp?.send) bp.send({ type: 'reload_settings' });
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/vcf/send', (req, res) => {
    const { phone } = req.body || {};
    if (!phone) return res.status(400).json({ ok: false, error: 'phone required' });
    const bp = app.get('botProcess');
    if (!bp?.send) return res.status(503).json({ ok: false, error: 'Bot not running' });
    bp.send({ type: 'send_vcf', data: { phone: String(phone).replace(/\D/g, '') } });
    res.json({ ok: true });
});

// ─── Broadcast Auto-Image Config ───────────────────────
app.get('/api/broadcast/auto-image', (req, res) => {
    const s = getBotSettings();
    res.json({ ok: true, config: s.auto_image || { enabled: false, list_name: '', send_time: '09:00' } });
});

app.post('/api/broadcast/auto-image', (req, res) => {
    const { enabled, list_name, send_time } = req.body || {};
    const s = getBotSettings();
    s.auto_image = { enabled: !!enabled, list_name: list_name || '', send_time: send_time || '09:00' };
    saveBotSettings(s);
    res.json({ ok: true });
});

app.get('/api/broadcast/images', (req, res) => {
    try {
        const files = fs.readdirSync(broadcastImagesDir)
            .filter(f => /\.(jpg|jpeg|png|gif|webp)$/i.test(f))
            .map(f => ({ name: f, path: path.join(broadcastImagesDir, f), mtime: fs.statSync(path.join(broadcastImagesDir, f)).mtimeMs }))
            .sort((a, b) => b.mtime - a.mtime);
        res.json({ ok: true, images: files.map(f => f.name) });
    } catch { res.json({ ok: true, images: [] }); }
});

app.get('/api/broadcast/image/:filename', (req, res) => {
    const safe = path.basename(req.params.filename);
    const filePath = path.resolve(broadcastImagesDir, safe);
    if (!filePath.startsWith(broadcastImagesDir + path.sep) && filePath !== broadcastImagesDir) return res.status(400).send('Invalid');
    if (!fs.existsSync(filePath)) return res.status(404).send('Not found');
    res.sendFile(filePath);
});

// ─── Auto-image daily scheduler ───────────────────────
(function startAutoImageScheduler() {
    let lastSentDate = '';
    setInterval(() => {
        try {
            const s = getBotSettings();
            const ai = s.auto_image;
            if (!ai || !ai.enabled || !ai.list_name || !ai.send_time) return;
            const now = new Date();
            const todayStr = now.toISOString().split('T')[0];
            if (lastSentDate === todayStr) return;
            const [hh, mm] = (ai.send_time || '09:00').split(':').map(Number);
            if (now.getHours() !== hh || now.getMinutes() !== mm) return;
            lastSentDate = todayStr;
            // Find latest image
            const files = fs.readdirSync(broadcastImagesDir)
                .filter(f => /\.(jpg|jpeg|png|gif|webp)$/i.test(f))
                .sort((a, b) => fs.statSync(path.join(broadcastImagesDir, b)).mtimeMs - fs.statSync(path.join(broadcastImagesDir, a)).mtimeMs);
            if (!files.length) return pushLog('⏰ Auto-image: no images found in broadcast_images/');
            const imgPath = path.join(broadcastImagesDir, files[0]);
            const lists = s.broadcast_lists || [];
            const lst = lists.find(l => l.name === ai.list_name);
            if (!lst || !lst.phones || !lst.phones.length) return pushLog(`⏰ Auto-image: list "${ai.list_name}" empty or not found`);
            const today = new Date().toISOString().split('T')[0];
            const stmt = db.prepare(`INSERT INTO scheduled_messages (customer_phone, message_text, media_path, scheduled_date, status) VALUES (?, ?, ?, ?, 'Pending')`);
            lst.phones.forEach(p => stmt.run(String(p).replace(/\D/g,''), '📸 Daily Update from DRD Realtors', imgPath, today));
            stmt.finalize();
            pushLog(`⏰ Auto-image: queued ${lst.phones.length} message(s) to list "${ai.list_name}"`);
        } catch (e) { pushLog('⏰ Auto-image scheduler error: ' + e.message); }
    }, 60 * 1000);
})();

// ─── FINANCIAL ANALYTICS ──────────────────────────────
app.get('/api/reports/project-profitability', (req, res) => {
    const query = `
        SELECT 
            p.layout_name,
            SUM(CASE WHEN p.status = 'Sold' THEN p.price ELSE 0 END) as total_sales,
            (SELECT SUM(amount) FROM expenses WHERE layout_name = p.layout_name) as total_expenses
        FROM plots p
        GROUP BY p.layout_name
    `;
    db.all(query, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

const legalDocsStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dir = path.join(INTERNAL_DIR, 'legal_docs');
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        cb(null, `LEGAL_${Date.now()}${ext}`);
    }
});
const uploadLegalDoc = multer({ storage: legalDocsStorage });

app.post('/api/legal-docs/upload', uploadLegalDoc.single('doc'), (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
    res.json({ ok: true, filename: req.file.filename });
});

app.get('/api/legal-docs/file/:filename', (req, res) => {
    // Strip any directory components — serve only bare filenames
    const safeName = path.basename(req.params.filename);
    if (!safeName || safeName !== req.params.filename) return res.status(400).send('Invalid filename');
    const legalDir = path.resolve(INTERNAL_DIR, 'legal_docs');
    const filePath = path.resolve(legalDir, safeName);
    if (!filePath.startsWith(legalDir + path.sep)) return res.status(400).send('Invalid filename');
    if (fs.existsSync(filePath)) res.sendFile(filePath);
    else res.status(404).send('File not found');
});

// ─── LEGAL & DOCUMENTATION API ───────────────────────
app.get('/api/legal-docs', (req, res) => {
    db.all(`SELECT d.*, p.plot_no, p.layout_name FROM plot_documents d
            JOIN plots p ON d.plot_id = p.id
            ORDER BY d.updated_at DESC`, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.post('/api/legal-docs', (req, res) => {
    const { plot_id, agreement_date, sale_deed_date, registration_number, pending_documents, document_path, notes } = req.body;
    db.run(`INSERT INTO plot_documents (plot_id, agreement_date, sale_deed_date, registration_number, pending_documents, document_path, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [plot_id, agreement_date, sale_deed_date, registration_number, pending_documents, document_path, notes], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true, id: this.lastID });
    });
});

app.put('/api/legal-docs/:id', (req, res) => {
    const { agreement_date, sale_deed_date, registration_number, pending_documents, notes } = req.body;
    db.run(`UPDATE plot_documents SET agreement_date=?, sale_deed_date=?, registration_number=?, pending_documents=?, notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`,
        [agreement_date, sale_deed_date, registration_number, pending_documents, notes, req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        if (this.changes === 0) return res.status(404).json({ ok: false, msg: 'Record not found' });
        res.json({ ok: true });
    });
});

app.post('/api/legal-docs/request-approval', (req, res) => {
    const { docId, adminPhone } = req.body;
    
    db.get(`SELECT d.*, p.plot_no, p.layout_name FROM plot_documents d 
            JOIN plots p ON d.plot_id = p.id WHERE d.id = ?`, [docId], (err, row) => {
        if (err || !row) return res.status(500).json({ ok: false, msg: 'Document not found' });
        
        if (botProcess && botProcess.send) {
            botProcess.send({
                type: 'request_legal_approval',
                data: {
                    docId,
                    adminPhone,
                    fileName: row.document_path,
                    plotInfo: `${row.plot_no} in ${row.layout_name}`
                }
            });
            res.json({ ok: true, msg: 'Approval request sent to WhatsApp' });
        } else {
            res.status(500).json({ ok: false, msg: 'Bot is offline' });
        }
    });
});

app.delete('/api/legal-docs/:id', (req, res) => {
    // 1. Get filename to delete physical file
    db.get(`SELECT document_path FROM plot_documents WHERE id = ?`, [req.params.id], (err, row) => {
        if (row && row.document_path) {
            const filePath = path.join(INTERNAL_DIR, 'legal_docs', row.document_path);
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        }
        // 2. Delete from DB
        db.run(`DELETE FROM plot_documents WHERE id = ?`, [req.params.id], function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true });
        });
    });
});

// ─── DTCP / LAYOUT APPROVALS API ──────────────────────
app.get('/api/dtcp', (req, res) => {
    db.all(`SELECT * FROM dtcp_approvals ORDER BY layout_name`, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows || []);
    });
});

app.post('/api/dtcp', (req, res) => {
    const { layout_name, dtcp_no, approval_date, rera_no, rera_expiry, patta_status, fmb_status, govt_order } = req.body;
    if (!layout_name) return res.status(400).json({ ok: false, msg: 'Layout name required' });
    db.run(`INSERT INTO dtcp_approvals (layout_name, dtcp_no, approval_date, rera_no, rera_expiry, patta_status, fmb_status, govt_order)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [layout_name, dtcp_no || '', approval_date || '', rera_no || '', rera_expiry || '', patta_status || '', fmb_status || '', govt_order || ''],
        function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true, id: this.lastID });
        }
    );
});

app.put('/api/dtcp/:id', (req, res) => {
    const { layout_name, dtcp_no, approval_date, rera_no, rera_expiry, patta_status, fmb_status, govt_order } = req.body;
    db.run(`UPDATE dtcp_approvals SET layout_name=?, dtcp_no=?, approval_date=?, rera_no=?, rera_expiry=?, patta_status=?, fmb_status=?, govt_order=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`,
        [layout_name, dtcp_no || '', approval_date || '', rera_no || '', rera_expiry || '', patta_status || '', fmb_status || '', govt_order || '', req.params.id],
        function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true });
        }
    );
});

app.delete('/api/dtcp/:id', (req, res) => {
    db.run(`DELETE FROM dtcp_approvals WHERE id = ?`, [req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

// ─── COMMISSION TRACKING API ──────────────────────────
app.get('/api/commissions', (req, res) => {
    // staff_id may be a plain integer (old records, staff) or "remisier:N" (new records)
    db.all(`SELECT c.*,
                   COALESCE(s.name, a.name, c.staff_id) AS staff_name,
                   p.plot_no, p.layout_name
            FROM commissions c
            LEFT JOIN staff s ON (
                c.staff_id NOT LIKE 'remisier:%' AND CAST(s.id AS TEXT) = CAST(c.staff_id AS TEXT)
            )
            LEFT JOIN affiliates a ON (
                c.staff_id LIKE 'remisier:%' AND CAST(a.id AS TEXT) = SUBSTR(c.staff_id, 10)
            )
            LEFT JOIN plots p ON c.plot_id = p.id
            ORDER BY c.created_at DESC`, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows || []);
    });
});

app.post('/api/commissions', (req, res) => {
    const { staff_id, plot_id, amount, status, notes } = req.body;
    const plotIdVal = plot_id && String(plot_id).trim() ? Number(plot_id) : null;
    db.run(`INSERT INTO commissions (staff_id, plot_id, amount, status, notes)
            VALUES (?, ?, ?, ?, ?)`,
            [staff_id, plotIdVal, amount, status || 'Pending', notes], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true, id: this.lastID });
    });
});

app.patch('/api/commissions/:id/status', (req, res) => {
    const { status } = req.body;
    db.run(`UPDATE commissions SET status = ?, paid_at = ? WHERE id = ?`,
            [status, status === 'Paid' ? new Date().toISOString() : null, req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

app.put('/api/commissions/:id', (req, res) => {
    const { amount, status, notes } = req.body;
    db.run(`UPDATE commissions SET amount=?, status=?, notes=?, paid_at=? WHERE id=?`,
        [amount, status, notes, status === 'Paid' ? new Date().toISOString() : null, req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        if (this.changes === 0) return res.status(404).json({ ok: false, msg: 'Commission not found' });
        res.json({ ok: true });
    });
});
app.delete('/api/commissions/:id', (req, res) => {
    db.run(`DELETE FROM commissions WHERE id=?`, [req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

// ─── ADVANCED AI: LEAD SCORING ───────────────────────
app.post('/api/ai/score-lead', async (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ ok: false, msg: 'Phone number required' });

    const cleanPhone = phone.replace(/\D/g, '');
    const logPath = path.join(INTERNAL_DIR, 'training_data', `${cleanPhone}.txt`);
    
    let history = "No chat history found.";
    if (fs.existsSync(logPath)) {
        history = fs.readFileSync(logPath, 'utf8').slice(-5000); // Last 5k chars
    }

    try {
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        
        const prompt = `Analyze the following chat history between a Real Estate Bot and a customer.
        Rank the lead on a scale of 1-10 (1=Not Interested, 10=Highly Hot Lead).
        Identify their key interests (e.g. specific project, budget, loan requirement).
        Respond in JSON format: {"score": 8, "interests": "Interested in Skanda Enclave, needs home loan", "summary": "Highly motivated buyer"}.
        
        Chat History:
        ${history}`;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();
        
        // Clean JSON from potential markdown blocks
        const jsonMatch = text.match(/\{.*\}/s);
        const analysis = jsonMatch ? JSON.parse(jsonMatch[0]) : { score: 0, interests: 'Unknown', summary: 'AI analysis failed' };
        
        res.json({ ok: true, analysis });
    } catch (err) {
        console.error("AI Scoring Error:", err);
        res.status(500).json({ ok: false, msg: err.message });
    }
});

// ─── GLOBAL SEARCH ────────────────────────────────────
app.get('/api/search', (req, res) => {
    const queryStr = req.query.q || '';
    const q = `%${queryStr}%`;
    const results = { plots: [], customers: [], staff: [], quotes: [], settings: null };

    // Check company settings
    try {
        const settingsPath = path.join(ROOT_DIR, 'drd_company_settings.json');
        if (fs.existsSync(settingsPath)) {
            const settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
            if (JSON.stringify(settings).toLowerCase().includes(queryStr.toLowerCase())) {
                results.settings = settings;
            }
        }
    } catch(e) {}

    // Check quotes
    try {
        const qPath = path.join(ROOT_DIR, 'quotations.json');
        if (fs.existsSync(qPath)) {
            const quotes = JSON.parse(fs.readFileSync(qPath, 'utf8'));
            results.quotes = quotes.filter(qt => JSON.stringify(qt).toLowerCase().includes(queryStr.toLowerCase())).slice(0, 10);
        }
    } catch(e) {}

    db.all(`SELECT * FROM plots WHERE plot_no LIKE ? OR layout_name LIKE ? OR location LIKE ? LIMIT 10`, [q, q, q], (err, plots) => {
        results.plots = plots || [];
        db.all(`SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? OR location LIKE ? LIMIT 10`, [q, q, q], (err, customers) => {
            results.customers = customers || [];
            // Try to match staff table columns accurately (assume 'name', 'staff_id', 'phone' if they exist)
            db.all(`SELECT * FROM staff WHERE name LIKE ? OR id LIKE ? OR phone LIKE ? LIMIT 10`, [q, q, q], (err, staff) => {
                results.staff = staff || [];
                res.json(results);
            });
        });
    });
});




// ─── VISUALIZER CMS API ────────────────────────────────
const cmsPhotoStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const layoutName = req.body.name || 'Unknown_Layout';
        const dir = path.join(INTERNAL_DIR, 'Visual_Maps', 'Layout_Images', layoutName);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: (req, file, cb) => cb(null, file.originalname)
});
const uploadCmsPhotos = multer({ storage: cmsPhotoStorage });

app.post('/api/website/add-layout', uploadCmsPhotos.array('photos'), (req, res) => {
    const { name, plots, price, area, gps } = req.body;
    if (!name) return res.json({ ok: false, msg: 'Layout name required' });
    const totalPlots = parseInt(plots) || 0;
    let inserted = 0;
    let errors = [];
    const done = () => {
        if (errors.length) return res.json({ ok: false, msg: errors[0] });
        res.json({ ok: true, msg: `Layout added: ${inserted} plots saved.` });
    };
    if (totalPlots === 0) return done();
    for (let i = 1; i <= totalPlots; i++) {
        db.run(
            `INSERT INTO plots (layout_name, plot_no, status, price, area, gps_location) VALUES (?, ?, 'Available', ?, ?, ?)`,
            [name, i, price || 0, area || 0, gps || ''],
            (err) => {
                if (err) errors.push(err.message);
                else inserted++;
                if (inserted + errors.length === totalPlots) done();
            }
        );
    }
});

app.post('/api/website/generate', (req, res) => {
    const pyDir = path.join(INTERNAL_DIR, 'Visual_Maps');
    exec(`${PYTHON_BIN} update_data.py`, { cwd: pyDir }, (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return res.status(500).json({ ok: false, msg: stderr || error.message });
        }
        res.json({ ok: true, output: stdout });
    });
});

app.post('/api/website/deploy', (req, res) => {
    const { remote, branch } = req.body;

    if (!remote || !branch) return res.status(400).json({ ok: false, msg: 'remote and branch are required' });
    if (!/^https?:\/\/[^\s]+$/.test(remote) && !/^git@[^\s]+$/.test(remote)) {
        return res.status(400).json({ ok: false, msg: 'Invalid remote URL' });
    }
    if (!/^[a-zA-Z0-9_\-./]+$/.test(branch)) {
        return res.status(400).json({ ok: false, msg: 'Invalid branch name' });
    }

    const pyDir = path.join(INTERNAL_DIR, 'Visual_Maps');
    const devNull = process.platform === 'win32' ? '2>nul' : '2>/dev/null';

    // Command sequence for Git
    const cmds = [
        'git init',
        `git remote add origin ${remote} ${devNull} || git remote set-url origin ${remote}`,
        'git add .',
        'git commit -m "Live Update from Dashboard CMS"',
        `git push -u origin ${branch} --force`
    ];

    exec(cmds.join(' && '), { cwd: pyDir }, (error, stdout, stderr) => {
        if (error) {
            console.error('Deploy error:', stderr);
            return res.status(500).json({ ok: false, msg: stderr || error.message });
        }
        res.json({ ok: true, output: stdout });
    });
});

app.get('/api/website/layouts', (req, res) => {
    db.all(`SELECT layout_name, COUNT(*) as plot_count FROM plots GROUP BY layout_name`, [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        
        // Load static metadata from data_v3.js if it exists, otherwise provide defaults
        let metadata = [];
        try {
            const filePath = path.join(INTERNAL_DIR, 'Visual_Maps', 'data_v3.js');
            if (fs.existsSync(filePath)) {
                let content = fs.readFileSync(filePath, 'utf8');
                content = content.replace(/^const\s+LAYOUT_DATA\s*=\s*/m, '').trim();
                if(content.endsWith(';')) content = content.slice(0, -1).trim();
                metadata = JSON.parse(content);
            }
        } catch(e) {}

        const layouts = rows.map(r => {
            const meta = metadata.find(m => m.name === r.layout_name) || {};
            return {
                name: r.layout_name,
                plots_count: r.plot_count,
                available_count: 0, // Will be calculated on frontend or via extra query
                price_range: meta.price_range || "Contact for Price",
                coords: meta.coords || [11.0168, 76.9558],
                images: meta.images || []
            };
        });
        res.json({ ok: true, layouts });
    });
});



app.get('/api/customers', (req, res) => {
    db.all(`SELECT * FROM customers ORDER BY last_interaction DESC, created_at DESC`, [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        // Normalise to both-case keys for dashboard compatibility
        const mapped = (rows || []).map(c => ({
            ...c,
            Phone: c.phone, Name: c.name,
            Plot_Bought: c.plot, App_Price: c.price,
            Received_Amount: c.received_amount || 0,
            Balance_Amount: c.balance_amount || 0,
            Doc_No: c.doc_no, Adhar_Copy: c.adhar,
            Loan: c.loan, Loan_Details: c.loan_details,
            Location: c.location, Status: c.status
        }));
        res.json(mapped);
    });
});

app.post('/api/customers/update', (req, res) => {
    try {
        const { Phone, Name, Plot_Bought, App_Price, Received_Amount, Balance_Amount, Doc_No, Adhar_Copy, Loan, Loan_Details, Location, Status, Lead_Notes } = req.body;
        const phone = (Phone || '').toString().replace(/\D/g, '');
        if (!phone) return res.status(400).json({ ok: false, msg: "Phone number required" });

        // Update SQLite — lead_notes is the existing column for CRM follow-up log
        db.run(`INSERT INTO customers (phone, name, plot, price, received_amount, balance_amount, doc_no, adhar, loan, loan_details, location, status, lead_notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(phone) DO UPDATE SET
                name=excluded.name, plot=excluded.plot, price=excluded.price,
                received_amount=excluded.received_amount, balance_amount=excluded.balance_amount,
                doc_no=excluded.doc_no, adhar=excluded.adhar, loan=excluded.loan,
                loan_details=excluded.loan_details, location=excluded.location,
                status=excluded.status, lead_notes=excluded.lead_notes,
                last_interaction=CURRENT_TIMESTAMP`,
            [phone, Name, Plot_Bought, App_Price, Received_Amount || 0, Balance_Amount || 0, Doc_No, Adhar_Copy, Loan, Loan_Details, Location, Status, Lead_Notes || null],
            (err) => {
                if (err) return res.status(500).json({ ok: false, msg: err.message });

                // 3. Cancel any pending AI drip nudges if this lead is now
                //    booked / purchased / not interested / ignored / junk —
                //    we don't want the bot to keep messaging closed leads.
                const closedStatuses = ['Booked','Purchased','Site Visit Done','Not Interested','Ignored','Junk'];
                if (Status && closedStatuses.includes(Status)) {
                    db.run(`UPDATE followups SET status = 'Cancelled'
                              WHERE customer_phone = ? AND staff_name = 'AI_DRIP' AND status = 'Pending'`,
                        [phone.slice(-10)]);
                }
                res.json({ ok: true });
            }
        );
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});
app.post('/api/customers/add', (req, res) => {
    // Alias for update
    res.redirect(307, '/api/customers/update');
});

// Bulk import customers/leads from an uploaded sheet (UI parses Excel/CSV → JSON rows).
// Upserts on phone — existing rows get name/plot/location/status updated, new rows inserted.
app.post('/api/customers/import', (req, res) => {
    try {
        const rows = Array.isArray(req.body && req.body.rows) ? req.body.rows : [];
        if (!rows.length) return res.json({ ok: false, error: 'No rows provided' });

        let inserted = 0, updated = 0;
        const stmt = db.prepare(`
            INSERT INTO customers (phone, name, plot, location, price, status, lead_notes, last_interaction)
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(phone) DO UPDATE SET
                name       = COALESCE(NULLIF(excluded.name,''),      name),
                plot       = COALESCE(NULLIF(excluded.plot,''),      plot),
                location   = COALESCE(NULLIF(excluded.location,''),  location),
                price      = COALESCE(NULLIF(excluded.price,''),     price),
                status     = COALESCE(NULLIF(excluded.status,''),    status),
                lead_notes = COALESCE(NULLIF(excluded.lead_notes,''),lead_notes),
                last_interaction = CURRENT_TIMESTAMP
        `);

        db.serialize(() => {
            db.run('BEGIN');
            for (const r of rows) {
                const phone = String(r.phone || '').replace(/\D/g, '');
                if (!phone || phone.length < 10) continue;
                db.get(`SELECT 1 FROM customers WHERE phone = ?`, [phone], (err, exists) => {
                    if (exists) updated++; else inserted++;
                });
                stmt.run(
                    phone,
                    String(r.name || '').trim(),
                    String(r.plot || '').trim(),
                    String(r.location || '').trim(),
                    String(r.price || ''),
                    String(r.status || 'Imported').trim(),
                    String(r.notes || '').trim(),
                );
            }
            stmt.finalize();
            db.run('COMMIT', (commitErr) => {
                if (commitErr) return res.status(500).json({ ok: false, error: commitErr.message });
                // Counts may lag the async db.get calls — re-query for accurate totals
                db.get(`SELECT COUNT(*) AS c FROM customers`, [], (e, row) => {
                    res.json({ ok: true, inserted, updated, total: rows.length, current_db_total: row && row.c });
                });
            });
        });

        pushLog(`📥 CRM Import: queued ${rows.length} row(s).`);
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.post('/api/customers/delete', (req, res) => {
    try {
        console.log("[DEBUG] Strong Delete Request:", req.body);
        let phonesToDelete = [];
        if (req.body.phones && Array.isArray(req.body.phones)) {
            phonesToDelete = req.body.phones.map(p => p.toString().replace(/\D/g, ''));
        } else if (req.body.phone) {
            phonesToDelete = [req.body.phone.toString().replace(/\D/g, '')];
        }

        if (phonesToDelete.length === 0) return res.json({ ok: false, msg: "No phones provided" });

        // Delete from SQLite
        const placeholders = phonesToDelete.map(() => '?').join(',');
        db.run(`DELETE FROM customers WHERE phone IN (${placeholders})`, phonesToDelete, (err) => {
            if (err) console.error("[ERROR] SQLite Delete failed:", err.message);
            res.json({ ok: true, count: phonesToDelete.length });
        });

    } catch (e) {
        console.error("[CRITICAL] Strong Delete Error:", e);
        res.status(500).json({ ok: false, msg: e.message });
    }
});


app.post('/api/company-configs', (req, res) => {
    try {
        const companies = req.body;
        if (!Array.isArray(companies)) return res.status(400).json({ ok: false, msg: "Expected array of companies" });
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(companies, null, 2));
        // Keep global settings in sync with Company 1 (the default company).
        if (companies.length > 0) {
            const c1 = companies[0];
            const globalPath = path.join(ROOT_DIR, 'drd_company_settings.json');
            let global = {};
            try { global = JSON.parse(fs.readFileSync(globalPath, 'utf8')); } catch {}
            const synced = {
                ...global,
                companyName: c1.companyName || c1.name || global.companyName,
                phone:   c1.phone   !== undefined ? c1.phone   : global.phone,
                phone2:  c1.phone2  !== undefined ? c1.phone2  : global.phone2,
                email:   c1.email   !== undefined ? c1.email   : global.email,
                website: c1.website !== undefined ? c1.website : global.website,
                tagline: c1.tagline !== undefined ? c1.tagline : global.tagline,
                address: c1.address !== undefined ? c1.address : global.address,
                tax_id:  c1.tax_id  !== undefined ? c1.tax_id  : global.tax_id,
                bank_info: c1.bank_info !== undefined ? c1.bank_info : global.bank_info,
                logo:    c1.logo    !== undefined ? c1.logo    : global.logo,
            };
            fs.writeFileSync(globalPath, JSON.stringify(synced, null, 2));
        }
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

app.get('/api/company-configs', (req, res) => {
    try {
        if (!fs.existsSync(CONFIG_PATH)) return res.json({ ok: true, companies: [] });
        const companies = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
        // Return all original fields so the client can edit and save them back intact.
        // Assign a stable id (index) only when the record has none.
        const full = companies.map((c, idx) => ({
            ...c,
            id: c.id !== undefined && c.id !== null && c.id !== '' ? c.id : idx,
            name: c.companyName || c.name || '',
        }));
        res.json({ ok: true, companies: full });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

app.get('/api/quotations', (req, res) => {
    try {
        if (!fs.existsSync(QUOTATIONS_PATH)) return res.json([]);
        res.json(JSON.parse(fs.readFileSync(QUOTATIONS_PATH, 'utf8')));
    } catch (e) { res.status(500).json([]); }
});

app.post('/api/quotations', (req, res) => {
    let current = fs.existsSync(QUOTATIONS_PATH) ? JSON.parse(fs.readFileSync(QUOTATIONS_PATH, 'utf8')) : [];
    req.body.id = 'Q' + Date.now();
    req.body.createdAt = new Date().toISOString();
    current.push(req.body);
    fs.writeFileSync(QUOTATIONS_PATH, JSON.stringify(current, null, 2));
    res.json({ ok: true, id: req.body.id });
});

app.delete('/api/quotations/:id', (req, res) => {
    try {
        if (!fs.existsSync(QUOTATIONS_PATH)) return res.json({ ok: false, msg: "File not found" });
        let current = JSON.parse(fs.readFileSync(QUOTATIONS_PATH, 'utf8'));
        const filtered = current.filter(q => q.id !== req.params.id);
        fs.writeFileSync(QUOTATIONS_PATH, JSON.stringify(filtered, null, 2));
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

app.put('/api/quotations/:id', (req, res) => {
    try {
        if (!fs.existsSync(QUOTATIONS_PATH)) return res.json({ ok: false, msg: "File not found" });
        let current = JSON.parse(fs.readFileSync(QUOTATIONS_PATH, 'utf8'));
        const idx = current.findIndex(q => q.id === req.params.id);
        if (idx === -1) return res.json({ ok: false, msg: "Quote not found" });
        
        current[idx] = { ...current[idx], ...req.body, id: req.params.id };
        fs.writeFileSync(QUOTATIONS_PATH, JSON.stringify(current, null, 2));
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

app.get('/api/chat-history/:phone', (req, res) => {
    try {
        const phone = req.params.phone.replace(/\D/g, '');
        const logPath = path.join(ROOT_DIR, 'training_data', `${phone}.txt`);
        if (fs.existsSync(logPath)) {
            const history = fs.readFileSync(logPath, 'utf8');
            res.json({ ok: true, history });
        } else {
            res.json({ ok: false, msg: "No history found" });
        }
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

// ─── CONVERSATIONS: structured chat memory (for training + analytics) ────────
// Each row in the conversations table is a single message. Inserted by bot.js
// logConversation in parallel with the legacy .txt file.

// GET /api/conversations/:phone?limit=200&before=2026-05-28
// Returns the most recent N messages for a customer, newest first.
app.get('/api/conversations/:phone', (req, res) => {
    const phone = String(req.params.phone || '').replace(/\D/g, '');
    if (!phone) return res.status(400).json({ ok: false, error: 'phone required' });
    const limit = Math.min(parseInt(req.query.limit, 10) || 200, 1000);
    const before = req.query.before ? String(req.query.before) : null;
    const params = [phone];
    let sql = `SELECT id, role, text, message_type, ai_model, customer_name, created_at
                 FROM conversations WHERE phone = ?`;
    if (before) { sql += ` AND created_at < ?`; params.push(before); }
    sql += ` ORDER BY created_at DESC LIMIT ?`;
    params.push(limit);
    db.all(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        res.json({ ok: true, phone, count: rows.length, messages: rows });
    });
});

// GET /api/conversations/search?q=east+facing&limit=50
// Substring search across all customer messages — useful for sales mining.
app.get('/api/conversations/search', (req, res) => {
    const q = String(req.query.q || '').trim();
    if (!q) return res.status(400).json({ ok: false, error: 'q required' });
    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 500);
    const role = req.query.role ? String(req.query.role).toUpperCase() : null;
    const params = [`%${q}%`];
    let sql = `SELECT id, phone, role, text, ai_model, customer_name, created_at
                 FROM conversations WHERE text LIKE ?`;
    if (role) { sql += ` AND role = ?`; params.push(role); }
    sql += ` ORDER BY created_at DESC LIMIT ?`;
    params.push(limit);
    db.all(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        res.json({ ok: true, query: q, count: rows.length, hits: rows });
    });
});

// GET /api/conversations/stats — quick health/overview.
app.get('/api/conversations/stats', (req, res) => {
    db.get(`SELECT
              COUNT(*) AS total_messages,
              COUNT(DISTINCT phone) AS unique_customers,
              SUM(CASE WHEN role = 'USER' THEN 1 ELSE 0 END) AS customer_messages,
              SUM(CASE WHEN role IN ('BOT','MODEL') THEN 1 ELSE 0 END) AS bot_messages,
              MIN(created_at) AS first_message_at,
              MAX(created_at) AS last_message_at
            FROM conversations`, [], (err, row) => {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        res.json({ ok: true, ...row });
    });
});

// GET /api/conversations/export.jsonl?phone=...&since=YYYY-MM-DD
// Streams as JSON Lines — one valid JSON object per line. Ready to feed into
// a fine-tuning pipeline. Supports per-customer or global export with a date
// window. Pairs USER→BOT replies into {prompt, completion} objects.
app.get('/api/conversations/export.jsonl', (req, res) => {
    const phone = req.query.phone ? String(req.query.phone).replace(/\D/g, '') : null;
    const since = req.query.since ? String(req.query.since) : null;
    const params = [];
    let sql = `SELECT phone, role, text, created_at FROM conversations WHERE 1=1`;
    if (phone) { sql += ` AND phone = ?`; params.push(phone); }
    if (since) { sql += ` AND created_at >= ?`; params.push(since); }
    sql += ` ORDER BY phone, created_at ASC`;

    res.setHeader('Content-Type', 'application/x-ndjson');
    res.setHeader('Content-Disposition', 'attachment; filename="conversations.jsonl"');

    db.all(sql, params, (err, rows) => {
        if (err) { res.status(500).end(JSON.stringify({ error: err.message })); return; }
        // Walk rows and emit {prompt, completion} pairs whenever a BOT msg
        // immediately follows a USER msg from the same phone.
        for (let i = 0; i < rows.length - 1; i++) {
            const a = rows[i], b = rows[i + 1];
            if (a.phone !== b.phone) continue;
            if (a.role !== 'USER') continue;
            if (b.role !== 'BOT' && b.role !== 'MODEL') continue;
            res.write(JSON.stringify({
                phone: a.phone,
                prompt: a.text,
                completion: b.text,
                ts: a.created_at
            }) + '\n');
        }
        res.end();
    });
});

app.get('/api/analytics/sources', (req, res) => {
    db.all(`SELECT source, COUNT(*) AS cnt FROM customers WHERE source IS NOT NULL GROUP BY source`, [], (err, rows) => {
        if (err) return res.json({});
        const sources = {};
        (rows || []).forEach(r => { sources[r.source || 'Unknown'] = r.cnt; });
        res.json(sources);
    });
});

app.get('/api/analytics/models', (req, res) => {
    db.all(`SELECT model, SUM(requests) AS total FROM ai_usage GROUP BY model`, [], (err, rows) => {
        if (err) return res.json({});
        const models = {};
        (rows || []).forEach(r => { models[r.model || 'Unknown'] = r.total; });
        res.json(models);
    });
});

app.get('/api/status', (req, res) => res.json({ status: botStatus, connectedNumber, currentAiModel }));

// ─── Project Bank Details (SQLite) ────────────────────────
app.get('/api/project-banks', (req, res) => {
    db.all(`SELECT * FROM project_banks`, [], (err, rows) => {
        if (err) return res.status(500).json([]);
        res.json(rows);
    });
});

app.post('/api/project-banks', (req, res) => {
    const { project_name, acc_name, bank_name, acc_no, ifsc, branch, upi_id } = req.body;
    if (!project_name) return res.status(400).json({ ok: false, error: "Project Name is required" });

    db.run(`INSERT INTO project_banks (project_name, acc_name, bank_name, acc_no, ifsc, branch, upi_id, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(project_name) DO UPDATE SET
            acc_name=excluded.acc_name,
            bank_name=excluded.bank_name,
            acc_no=excluded.acc_no,
            ifsc=excluded.ifsc,
            branch=excluded.branch,
            upi_id=excluded.upi_id,
            updated_at=CURRENT_TIMESTAMP`,
            [project_name, acc_name, bank_name, acc_no, ifsc, branch, upi_id || ''],
            (err) => {
                if (err) return res.status(500).json({ ok: false, error: err.message });
                res.json({ ok: true });
            });
});

app.delete('/api/project-banks/:id', (req, res) => {
    db.run(`DELETE FROM project_banks WHERE id=?`, [req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

// ─── Guideline Values ──────────────────────────────────────
app.get('/api/guideline-values', (req, res) => {
    db.all(`SELECT * FROM guideline_values ORDER BY layout_name`, [], (err, rows) => {
        res.json(rows || []);
    });
});

app.post('/api/guideline-values', (req, res) => {
    const { layout_name, rate_per_sqft, notes } = req.body;
    if (!layout_name || rate_per_sqft === undefined) return res.status(400).json({ ok: false, error: 'layout_name and rate_per_sqft required' });
    db.run(`INSERT INTO guideline_values (layout_name, rate_per_sqft, notes, updated_at)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(layout_name) DO UPDATE SET rate_per_sqft=excluded.rate_per_sqft, notes=excluded.notes, updated_at=CURRENT_TIMESTAMP`,
        [layout_name.trim(), parseFloat(rate_per_sqft), notes || ''],
        function(err) { res.json(err ? { ok: false, error: err.message } : { ok: true, id: this.lastID }); }
    );
});

app.delete('/api/guideline-values/:id', (req, res) => {
    db.run(`DELETE FROM guideline_values WHERE id=?`, [req.params.id], function(err) {
        res.json(err ? { ok: false, error: err.message } : { ok: true });
    });
});

// ─── Affiliate / Referral Tracking Routes ─────────────────
app.get('/r/:staffId', (req, res) => {
    const staffId = req.params.staffId;
    const layout = req.query.layout || '';
    const settingsPath = path.join(ROOT_DIR, 'bot_settings.json');
    let companyPhone = '919655766666';
    try {
        const s = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        if (s.primary_admin) {
            const p = String(s.primary_admin).replace(/\D/g, '');
            companyPhone = p.length === 10 ? '91' + p : p;
        }
    } catch(e) {}

    // Record click for real staff IDs; layout-only codes (layout_*) don't map to a staff member
    const isLayoutOnly = staffId.startsWith('layout_');
    if (!isLayoutOnly) {
        db.run(`INSERT INTO affiliate_clicks (staff_id, clicked_at, ip) VALUES (?, CURRENT_TIMESTAMP, ?)`,
            [staffId, req.ip || ''], (err) => {
                if (err) {
                    db.run(`CREATE TABLE IF NOT EXISTS affiliate_clicks (id INTEGER PRIMARY KEY AUTOINCREMENT, staff_id TEXT, clicked_at TEXT, ip TEXT)`);
                }
            });
    }

    // Build WhatsApp message including layout name when available
    const layoutDisplay = layout || (isLayoutOnly ? staffId.replace(/^layout_/, '').replace(/_/g, ' ') : '');
    const ref = isLayoutOnly ? (layoutDisplay || staffId) : staffId;
    const msgText = layoutDisplay
        ? `Hi, I am interested in plots at ${layoutDisplay}. [Ref:${ref}]`
        : `Hi DRD Realtors, I am interested in plots. [Ref:${ref}]`;
    res.redirect(`https://wa.me/${companyPhone}?text=${encodeURIComponent(msgText)}`);
});

app.get('/api/affiliate/clicks', (req, res) => {
    db.all(`SELECT staff_id, COUNT(*) as clicks FROM affiliate_clicks GROUP BY staff_id ORDER BY clicks DESC`, [], (err, rows) => {
        if (err) return res.json({ ok: false, rows: [] });
        res.json({ ok: true, rows: rows || [] });
    });
});

app.delete('/api/affiliate/clicks', (req, res) => {
    const staffId = (req.body || {}).staff_id || null;
    if (staffId) {
        db.run(`DELETE FROM affiliate_clicks WHERE staff_id = ?`, [staffId], (err) => {
            if (err) return res.json({ ok: false, error: err.message });
            pushLog(`🗑️ Affiliate clicks cleared for: ${staffId}`);
            res.json({ ok: true });
        });
    } else {
        db.run(`DELETE FROM affiliate_clicks`, [], (err) => {
            if (err) return res.json({ ok: false, error: err.message });
            pushLog('🗑️ All affiliate click data cleared.');
            res.json({ ok: true });
        });
    }
});

app.get('/api/affiliates/list', (req, res) => {
    db.all(`SELECT id, name, code, phone FROM affiliates WHERE status = 'active' OR status IS NULL ORDER BY name ASC`, [], (err, rows) => {
        if (err) return res.json({ ok: false, rows: [] });
        res.json({ ok: true, rows: rows || [] });
    });
});

app.get('/api/affiliate/performance', (req, res) => {
    db.all(`
        SELECT
            ac.staff_id,
            COUNT(DISTINCT ac.id) AS clicks,
            COALESCE(SUM(CASE WHEN c.status != 'Cancelled' THEN c.amount ELSE 0 END), 0) AS total_commission,
            COALESCE(SUM(CASE WHEN c.status = 'Paid' THEN c.amount ELSE 0 END), 0) AS paid_commission,
            COALESCE(SUM(CASE WHEN c.status = 'Pending' THEN c.amount ELSE 0 END), 0) AS pending_commission,
            COUNT(DISTINCT c.id) AS commission_count
        FROM affiliate_clicks ac
        LEFT JOIN commissions c ON LOWER(TRIM(c.staff_id)) = LOWER(TRIM(ac.staff_id))
        GROUP BY ac.staff_id
        ORDER BY clicks DESC
    `, [], (err, rows) => {
        if (err) return res.json({ ok: false, rows: [] });
        res.json({ ok: true, rows: rows || [] });
    });
});

app.post('/api/affiliate/save-qr', (req, res) => {
    const { staffId, imageBase64 } = req.body || {};
    if (!staffId || !imageBase64) return res.json({ ok: false, error: 'Missing staffId or imageBase64' });
    try {
        const qrDir = path.join(ROOT_DIR, 'affiliate_qr_codes');
        if (!fs.existsSync(qrDir)) fs.mkdirSync(qrDir, { recursive: true });
        const base64Data = imageBase64.replace(/^data:image\/png;base64,/, '');
        const safeId = String(staffId).replace(/[^a-zA-Z0-9_-]/g, '_');
        const fileName = `QR_${safeId}.png`;
        const filePath = path.join(qrDir, fileName);
        fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));
        res.json({ ok: true, path: filePath, fileName, folder: qrDir });
    } catch (e) {
        res.json({ ok: false, error: e.message });
    }
});

// POST /api/affiliate/:staffId/upload-qr — multipart file upload for affiliate QR image
const _affiliateQrUploadDir = path.join(ROOT_DIR, 'affiliate_qr_codes');
if (!fs.existsSync(_affiliateQrUploadDir)) fs.mkdirSync(_affiliateQrUploadDir, { recursive: true });
const _affiliateQrUpload = multer({
    storage: multer.diskStorage({
        destination: (req, file, cb) => cb(null, _affiliateQrUploadDir),
        filename: (req, file, cb) => {
            const safeId = String(req.params.staffId).replace(/[^a-zA-Z0-9_-]/g, '_');
            cb(null, `QR_${safeId}.png`);
        }
    }),
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        if (['image/png', 'image/jpeg', 'image/jpg'].includes(file.mimetype)) cb(null, true);
        else cb(new Error('Only PNG/JPG images allowed'));
    }
});
app.post('/api/affiliate/:staffId/upload-qr', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    _affiliateQrUpload.single('qr')(req, res, (err) => {
        if (err) return res.status(400).json({ ok: false, msg: err.message || 'Upload error' });
        if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
        res.json({ ok: true, fileName: req.file.filename });
    });
});

// ═══════════════════════════════════════════════════════════════════════════
// ─── REMISIER CRM ──────────────────────────────────────────════════════════
// ═══════════════════════════════════════════════════════════════════════════

// GET /api/remisier — all remisiers with lead + visit stats
app.get('/api/remisier', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    db.all(`
        SELECT a.*,
               COUNT(DISTINCT c.id)                                           AS total_leads,
               SUM(CASE WHEN c.status IN ('Booked','Purchased') THEN 1 END)   AS converted,
               SUM(CASE WHEN c.status = 'Site Visit Done' THEN 1 END)         AS site_visits_done,
               SUM(CASE WHEN sv.status = 'Scheduled' THEN 1 END)              AS pending_visits
          FROM affiliates a
          LEFT JOIN customers c  ON c.referred_by = a.code
          LEFT JOIN site_visits sv ON sv.customer_phone = c.phone AND sv.status = 'Scheduled'
         WHERE a.type = 'Remisier' OR a.type IS NULL OR a.type IN ('Staff','Remisier','External')
         GROUP BY a.id ORDER BY a.name`,
        [], (err, rows) => {
            if (err) return res.status(500).json({ ok: false, error: err.message });
            res.json({ ok: true, remisiers: rows || [] });
        });
});

// GET /api/remisier/:id/leads — all leads for a specific remisier
app.get('/api/remisier/:id/leads', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    db.get(`SELECT * FROM affiliates WHERE id = ?`, [req.params.id], (err, aff) => {
        if (err || !aff) return res.status(404).json({ ok: false, msg: 'Remisier not found' });
        db.all(`SELECT c.*,
                       sv.visit_date, sv.visit_time, sv.status AS visit_status, sv.layout_name AS visit_layout
                  FROM customers c
                  LEFT JOIN site_visits sv ON sv.customer_phone = c.phone AND sv.status = 'Scheduled'
                 WHERE c.referred_by = ? ORDER BY c.created_at DESC`,
            [aff.code], (e2, leads) => {
                if (e2) return res.status(500).json({ ok: false });
                res.json({ ok: true, remisier: aff, leads: leads || [] });
            });
    });
});

// POST /api/remisier — create remisier
app.post('/api/remisier', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const { name, phone, email, adhar, pan, nature_of_work, address,
            commission_rate, bank_name, account_no, ifsc, upi_id, notes } = req.body;
    if (!name || !phone) return res.status(400).json({ ok: false, msg: 'name and phone required' });
    const code = 'RM' + String(phone).replace(/\D/g,'').slice(-6);
    db.run(`INSERT INTO affiliates
              (name, code, phone, email, adhar, pan, nature_of_work, address,
               type, status, commission_rate, bank_name, account_no, ifsc, upi_id, notes)
            VALUES (?,?,?,?,?,?,?,?,'Remisier','Active',?,?,?,?,?,?)`,
        [name.trim(), code, String(phone).replace(/\D/g,''), email||'',
         adhar||'', pan||'', nature_of_work||'', address||'',
         commission_rate||2, bank_name||'', account_no||'', ifsc||'', upi_id||'', notes||''],
        function(err) {
            if (err) return res.status(409).json({ ok: false, msg: err.message });
            pushLog(`🤝 REMISIER: ${name} registered (code: ${code})`);
            res.json({ ok: true, id: this.lastID, code });
        });
});

// PUT /api/remisier/:id — update remisier
app.put('/api/remisier/:id', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const { name, phone, email, adhar, pan, nature_of_work, address,
            commission_rate, bank_name, account_no, ifsc, upi_id, notes, status } = req.body;
    db.run(`UPDATE affiliates SET
              name=COALESCE(?,name), phone=COALESCE(?,phone), email=COALESCE(?,email),
              adhar=COALESCE(?,adhar), pan=COALESCE(?,pan),
              nature_of_work=COALESCE(?,nature_of_work), address=COALESCE(?,address),
              commission_rate=COALESCE(?,commission_rate),
              bank_name=COALESCE(?,bank_name), account_no=COALESCE(?,account_no),
              ifsc=COALESCE(?,ifsc), upi_id=COALESCE(?,upi_id),
              notes=COALESCE(?,notes), status=COALESCE(?,status)
            WHERE id = ?`,
        [name||null, phone ? String(phone).replace(/\D/g,'') : null, email||null,
         adhar||null, pan||null, nature_of_work||null, address||null,
         commission_rate||null, bank_name||null, account_no||null,
         ifsc||null, upi_id||null, notes||null, status||null, req.params.id],
        function(err) {
            if (err) return res.status(500).json({ ok: false });
            res.json({ ok: true });
        });
});

// POST /api/remisier/:id/upload-doc — upload Aadhaar or PAN document
const remisierDocsDir = path.join(ROOT_DIR, 'remisier_docs');
if (!fs.existsSync(remisierDocsDir)) fs.mkdirSync(remisierDocsDir, { recursive: true });
const remisierDocUpload = multer({
    storage: multer.diskStorage({
        destination: (req, file, cb) => cb(null, remisierDocsDir),
        filename: (req, file, cb) => {
            const safe = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, '_');
            cb(null, `${req.params.id}_${req.query.type}_${Date.now()}_${safe}`);
        }
    }),
    limits: { fileSize: 10 * 1024 * 1024 }
});
app.post('/api/remisier/:id/upload-doc', remisierDocUpload.single('file'), (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const docType = req.query.type; // 'adhar_doc' or 'pan_doc'
    if (!['adhar_doc','pan_doc'].includes(docType)) return res.status(400).json({ ok: false, msg: 'type must be adhar_doc or pan_doc' });
    if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
    const relPath = `remisier_docs/${req.file.filename}`;
    db.run(`UPDATE affiliates SET ${docType} = ? WHERE id = ?`, [relPath, req.params.id], (err) => {
        if (err) return res.status(500).json({ ok: false });
        res.json({ ok: true, path: relPath });
    });
});

// GET /api/remisier/docs/:filename — serve a remisier document
app.get('/api/remisier/docs/:filename', (req, res) => {
    if (!req.session?.userId) return res.status(401).end();
    const safe = path.basename(req.params.filename);
    res.sendFile(path.join(remisierDocsDir, safe));
});

// DELETE /api/remisier/:id — deactivate
app.delete('/api/remisier/:id', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    db.run(`UPDATE affiliates SET status = 'Inactive' WHERE id = ?`, [req.params.id], (err) => {
        if (err) return res.status(500).json({ ok: false });
        res.json({ ok: true });
    });
});

// POST /api/remisier/visit — schedule a visit (from dashboard or bot)
app.post('/api/remisier/visit', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const { customer_phone, layout_name, visit_date, visit_time, remisier_code, notes } = req.body;
    if (!customer_phone || !visit_date) return res.status(400).json({ ok: false, msg: 'customer_phone and visit_date required' });
    db.run(`INSERT INTO site_visits (customer_phone, layout_name, visit_date, visit_time, scheduled_by, scheduled_by_type, notes, status)
            VALUES (?, ?, ?, ?, ?, 'remisier', ?, 'Scheduled')`,
        [String(customer_phone).replace(/\D/g,''), layout_name||'', visit_date, visit_time||'', remisier_code||'', notes||''],
        function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            pushLog(`📅 REMISIER VISIT: ${remisier_code} scheduled visit for ${customer_phone} on ${visit_date}`);
            res.json({ ok: true, id: this.lastID });
        });
});

// PUT /api/remisier/:id/commission — mark commission as paid
app.put('/api/remisier/:id/commission', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const { amount } = req.body;
    db.run(`UPDATE affiliates SET total_earned = COALESCE(total_earned,0) + ? WHERE id = ?`,
        [parseFloat(amount) || 0, req.params.id],
        (err) => res.json({ ok: !err }));
});

// GET /api/remisier/lookup/:phone — check if a phone is a registered remisier (used by bot)
app.get('/api/remisier/lookup/:phone', (req, res) => {
    const phone = req.params.phone.replace(/\D/g,'').slice(-10);
    db.get(`SELECT * FROM affiliates WHERE SUBSTR(REPLACE(phone,'+91',''),1,10) = ? OR phone = ? AND status = 'Active'`,
        [phone, phone], (err, row) => {
            res.json({ ok: true, remisier: row || null });
        });
});

// ─── ID Card Photos ──────────────────────────────────────────
const idPhotosDir = path.join(ROOT_DIR, 'id_photos');
const idPhotosStaffDir = path.join(idPhotosDir, 'staff');
const idPhotosRemisierDir = path.join(idPhotosDir, 'remisier');
[idPhotosDir, idPhotosStaffDir, idPhotosRemisierDir].forEach(d => {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
});

function makeIdPhotoUpload(dir) {
    return multer({
        storage: multer.diskStorage({
            destination: (req, file, cb) => cb(null, dir),
            filename: (req, file, cb) => {
                const ext = path.extname(file.originalname) || '.jpg';
                const safe = String(req.params.id).replace(/[^a-zA-Z0-9_-]/g, '_');
                cb(null, `${safe}_${Date.now()}${ext}`);
            }
        }),
        limits: { fileSize: 5 * 1024 * 1024 }
    });
}
const staffPhotoUpload = makeIdPhotoUpload(idPhotosStaffDir);
const remisierPhotoUpload = makeIdPhotoUpload(idPhotosRemisierDir);

// Staff QR codes (custom uploads for ID card)
const staffQrDir = path.join(ROOT_DIR, 'staff_qr_codes');
if (!fs.existsSync(staffQrDir)) fs.mkdirSync(staffQrDir, { recursive: true });
const staffQrUpload = multer({
    storage: multer.diskStorage({
        destination: (req, file, cb) => cb(null, staffQrDir),
        filename: (req, file, cb) => {
            const safeId = String(req.params.id).replace(/[^a-zA-Z0-9_-]/g, '_');
            cb(null, `QR_STAFF_${safeId}.png`);
        }
    }),
    limits: { fileSize: 2 * 1024 * 1024 }
});

// POST /api/remisier/:id/upload-photo
app.post('/api/remisier/:id/upload-photo', remisierPhotoUpload.single('photo'), (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
    const filename = req.file.filename;
    db.run(`UPDATE affiliates SET photo = ? WHERE id = ?`, [filename, req.params.id], (err) => {
        if (err) return res.status(500).json({ ok: false });
        res.json({ ok: true, photo: filename });
    });
});

// POST /api/staff/:id/upload-photo
app.post('/api/staff/:id/upload-photo', staffPhotoUpload.single('photo'), (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
    const filename = req.file.filename;
    db.run(`UPDATE staff SET photo = ? WHERE id = ?`, [filename, req.params.id], (err) => {
        if (err) return res.status(500).json({ ok: false });
        res.json({ ok: true, photo: filename });
    });
});

// POST /api/staff/:id/upload-qr — custom QR image for ID card
app.post('/api/staff/:id/upload-qr', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    staffQrUpload.single('qr')(req, res, (err) => {
        if (err) return res.status(400).json({ ok: false, msg: err.message || 'Upload error' });
        if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
        res.json({ ok: true, fileName: req.file.filename });
    });
});

// POST /api/staff/:id/assign-code — generate and persist a unique alphanumeric employee_code
app.post('/api/staff/:id/assign-code', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const staffRowId = req.params.id.toUpperCase();
    // Ensure column exists (safe to call repeatedly; error is ignored if already present)
    db.run(`ALTER TABLE staff ADD COLUMN employee_code TEXT`, () => {
        db.all(`SELECT employee_code FROM staff WHERE employee_code IS NOT NULL`, [], (err, rows) => {
            if (err) return res.status(500).json({ ok: false, error: err.message });
            const existing = new Set(rows.map(r => r.employee_code));
            let n = 1, generated;
            do { generated = 'EMP' + String(n++).padStart(3, '0'); } while (existing.has(generated) && n < 9999);
            db.run(`UPDATE staff SET employee_code = ? WHERE id = ?`, [generated, staffRowId], function(e) {
                if (e) return res.status(500).json({ ok: false, error: e.message });
                if (this.changes === 0) return res.status(404).json({ ok: false, error: 'Staff not found' });
                res.json({ ok: true, employee_code: generated });
            });
        });
    });
});

// GET /api/staff-qr/:fileName — serve a staff QR image (auth required)
app.get('/api/staff-qr/:fileName', (req, res) => {
    if (!req.session?.userId) return res.status(401).end();
    const safe = path.basename(req.params.fileName);
    if (!safe.endsWith('.png')) return res.status(400).end();
    const fp = path.join(staffQrDir, safe);
    if (!fs.existsSync(fp)) return res.status(404).end();
    res.sendFile(fp);
});

// GET /api/id-photo/:type/:filename — serve an ID card photo (requires auth)
app.get('/api/id-photo/:type/:filename', (req, res) => {
    if (!req.session?.userId) return res.status(401).end();
    const type = req.params.type;
    if (!['staff', 'remisier'].includes(type)) return res.status(400).end();
    const safe = path.basename(req.params.filename);
    const dir = type === 'staff' ? idPhotosStaffDir : idPhotosRemisierDir;
    res.sendFile(path.join(dir, safe));
});

// GET /api/id-card/qr — generate QR code PNG for given data string
app.get('/api/id-card/qr', async (req, res) => {
    if (!req.session?.userId) return res.status(401).end();
    const data = String(req.query.data || 'ID').slice(0, 200);
    try {
        const QRCode = require('qrcode');
        const buf = await QRCode.toBuffer(data, { width: 200, margin: 1, color: { dark: '#000000', light: '#ffffff' } });
        res.set('Content-Type', 'image/png');
        res.set('Cache-Control', 'public, max-age=3600');
        res.send(buf);
    } catch (e) { res.status(500).end(); }
});

// ─── Developer Info (read from Developer_Details.txt) ──────
app.get('/api/developer-info', (req, res) => {
    try {
        const p = path.join(ROOT_DIR, 'Developer_Details.txt');
        if (!fs.existsSync(p)) return res.json({ ok: false });
        const lines = fs.readFileSync(p, 'utf8').split('\n');
        const info = {};
        lines.forEach(line => {
            const [key, ...val] = line.split(':');
            if (key && val.length) info[key.trim()] = val.join(':').trim();
        });
        res.json({ ok: true, info });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ─── Logo Upload ──────────────────────────────────────────
const logoStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const logoDir = path.join(INTERNAL_DIR, 'logo');
        if (!fs.existsSync(logoDir)) fs.mkdirSync(logoDir, { recursive: true });
        cb(null, logoDir);
    },
    filename: (req, file, cb) => {
        const type = req.body.type;
        const ext = path.extname(file.originalname) || '.png';
        const name = type === 'favicon' ? `DRD-Favicon${ext}` : `DRD_Property_Genius_Logo${ext}`;
        cb(null, name);
    }
});
const logoUpload = multer({ storage: logoStorage, limits: { fileSize: 5 * 1024 * 1024 } });

app.post('/api/upload-logo', logoUpload.single('logo'), (req, res) => {
    try {
        if (!req.file) return res.json({ ok: false, error: 'No file received' });
        res.json({ ok: true, filename: req.file.filename });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ─── Bot Configuration ────────────────────────────────────
app.get('/api/bot-config', (req, res) => {
    const BOT_CONFIG_PATH = path.join(ROOT_DIR, 'bot_settings.json');
    try {
        if (!fs.existsSync(BOT_CONFIG_PATH)) {
            return res.status(404).json({ error: 'Config file not found' });
        }
        const config = JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
        // Also include the system prompt content
        const promptPath = path.join(ROOT_DIR, config.system_prompt_file || 'Greeting_Message.txt');
        let systemPrompt = "";
        if (fs.existsSync(promptPath)) {
            systemPrompt = fs.readFileSync(promptPath, 'utf8');
        }
        res.json({ ...config, system_prompt: systemPrompt });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.post('/api/bot-config', (req, res) => {
    const BOT_CONFIG_PATH = path.join(ROOT_DIR, 'bot_settings.json');
    try {
        const { system_prompt, ...config } = req.body;
        
        // Save the config
        fs.writeFileSync(BOT_CONFIG_PATH, JSON.stringify(config, null, 2));
        
        // Save the prompt if provided
        if (system_prompt !== undefined) {
            const promptPath = path.join(ROOT_DIR, config.system_prompt_file || 'Greeting_Message.txt');
            fs.writeFileSync(promptPath, system_prompt);
        }
        
        pushLog("⚙️ Bot configuration updated from dashboard.");
        res.json({ ok: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Patch only auto-followup fields without overwriting the full config
app.patch('/api/bot-config/followup', (req, res) => {
    const BOT_CONFIG_PATH = path.join(ROOT_DIR, 'bot_settings.json');
    try {
        const existing = fs.existsSync(BOT_CONFIG_PATH)
            ? JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'))
            : {};
        const allowed = ['auto_followup_enabled','auto_followup_wait_min_minutes',
                         'auto_followup_wait_max_minutes','auto_followup_start_hour',
                         'auto_followup_end_hour','auto_followup_max_attempts',
                         'offline_reply_enabled'];
        allowed.forEach(k => { if (req.body[k] !== undefined) existing[k] = req.body[k]; });
        fs.writeFileSync(BOT_CONFIG_PATH, JSON.stringify(existing, null, 2));
        pushLog('⚙️ Auto follow-up settings updated from CRM.');
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.get('/api/sync-settings', (req, res) => {
    try {
        const p = path.join(ROOT_DIR, 'bot_settings.json');
        if (!fs.existsSync(p)) return res.json({ syncType: 'local', cloudUrl: '' });
        const config = JSON.parse(fs.readFileSync(p, 'utf8'));
        res.json({ 
            syncType: config.sync_type || 'local', 
            cloudUrl: config.cloud_url || '' 
        });
    } catch (e) { res.json({ syncType: 'local', cloudUrl: '' }); }
});

app.post('/api/sync-settings', (req, res) => {
    try {
        const p = path.join(ROOT_DIR, 'bot_settings.json');
        let config = {};
        if (fs.existsSync(p)) config = JSON.parse(fs.readFileSync(p, 'utf8'));
        
        config.sync_type = req.body.syncType;
        config.cloud_url = req.body.cloudUrl;
        
        fs.writeFileSync(p, JSON.stringify(config, null, 2));
        pushLog(`☁️ Security: Cloud Sync updated to "${req.body.syncType}"`);
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

app.post('/api/sync/trigger', (req, res) => {
    try {
        const p = path.join(ROOT_DIR, 'bot_settings.json');
        if (!fs.existsSync(p)) return res.json({ ok: false, msg: "Config missing" });
        const config = JSON.parse(fs.readFileSync(p, 'utf8'));
        
        pushLog(`🔄 Manual Cloud Sync triggered (${config.sync_type || 'local'})`);
        res.json({ 
            ok: true, 
            type: config.sync_type || 'local', 
            url: config.cloud_url || 'Default System Path' 
        });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

// ─── Keyword Rules ────────────────────────────────────────
// Auto-seed from INTERNAL_DIR if ROOT_DIR copy doesn't exist yet (Electron first-run)
const RULES_SEED_PATH = path.join(INTERNAL_DIR, 'keyword_rules.json');
if (!fs.existsSync(RULES_PATH) && fs.existsSync(RULES_SEED_PATH)) {
    try { fs.copyFileSync(RULES_SEED_PATH, RULES_PATH); } catch(_) {}
}

app.get('/api/rules', (req, res) => {
    try {
        if (!fs.existsSync(RULES_PATH)) return res.json([]);
        res.json(JSON.parse(fs.readFileSync(RULES_PATH, 'utf8')));
    } catch (e) { res.status(500).json([]); }
});

app.post('/api/rules', (req, res) => {
    try {
        fs.writeFileSync(RULES_PATH, JSON.stringify(req.body, null, 2));
        pushLog("⚙️ Keyword rules updated.");
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/cleanup-whatsapp', (req, res) => {
    console.log('🧹 [CLEANUP] Terminating ONLY bot-owned puppeteer Chrome (user browser preserved)...');
    killBotChromeOnly('cleanup-whatsapp');

    // Forcefully remove the auth session lock
    const sessionPath = path.join(ROOT_DIR, '.wwebjs_auth');
    if (fs.existsSync(sessionPath)) {
        try {
            const folders = fs.readdirSync(sessionPath);
            folders.forEach(f => {
                const sub = path.join(sessionPath, f);
                if (fs.statSync(sub).isDirectory()) {
                    ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'lockfile'].forEach(file => {
                        const lockPath = path.join(sub, file);
                        if (fs.existsSync(lockPath)) {
                            try { fs.unlinkSync(lockPath); } catch(err) {}
                        }
                    });
                }
            });
        } catch(e) {
            console.error('[CLEANUP] Lock removal error:', e.message);
        }
    }

    setBotStatus('offline');
    botProcess = null;

    setTimeout(() => {
        res.json({ ok: true, msg: "Enterprise-grade cleanup dispatched." });
    }, 3000);
});
app.post('/api/start', (req, res) => {
    startBotProcess(req.body.botId || 'drd_bot_1');
    res.json({ ok: true });
});

function killBot() {
    const bp = botProcess;
    botProcess = null;
    if (bp) {
        pushLog("🛑 SYSTEM: Stopping bot process...");
        try { bp.kill('SIGTERM'); } catch (_) {}
        // Force-kill after 3s if SIGTERM wasn't enough
        setTimeout(() => { try { bp.kill('SIGKILL'); } catch (_) {} }, 3000);
    }

    // Kill ONLY the bot's puppeteer Chrome (filtered by .wwebjs_auth in cmd line).
    // The user's regular Chrome — even with 50 tabs open — is never touched.
    killBotChromeOnly('killBot');
    pushLog("🧹 SYSTEM: Bot puppeteer Chrome terminated (user browser preserved).");

    // Cleanup session locks
    const sessionPath = path.join(ROOT_DIR, '.wwebjs_auth');
    if (fs.existsSync(sessionPath)) {
        try {
            const folders = fs.readdirSync(sessionPath);
            folders.forEach(f => {
                const sub = path.join(sessionPath, f);
                if (fs.statSync(sub).isDirectory()) {
                    ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'lockfile'].forEach(file => {
                        const lockPath = path.join(sub, file);
                        if (fs.existsSync(lockPath)) {
                            try { fs.unlinkSync(lockPath); } catch(err) {}
                        }
                    });
                }
            });
        } catch(e) {}
    }

    setBotStatus('offline');
    currentQR = null;
}

function startBotProcess(botId) {
    killBot(); // Graceful SIGTERM, SIGKILL fallback after 3s
    lastBotId = botId;
    setBotStatus('starting');
    // Wait 7s for Chrome to fully exit before spawning a new instance.
    // killBotChromeOnly() runs an async PowerShell WMI query that takes 3-5s on Windows;
    // 4s was too tight and caused "browser already running" / TargetCloseError crashes.
    setTimeout(() => {
    // Second-pass lock file cleanup — in case Chrome held locks past the 7s window.
    try {
        const sessionPath = path.join(ROOT_DIR, '.wwebjs_auth');
        if (fs.existsSync(sessionPath)) {
            for (const f of fs.readdirSync(sessionPath)) {
                const sub = path.join(sessionPath, f);
                if (fs.statSync(sub).isDirectory()) {
                    for (const lock of ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'lockfile']) {
                        const lp = path.join(sub, lock);
                        if (fs.existsSync(lp)) { try { fs.unlinkSync(lp); } catch(_) {} }
                    }
                }
            }
        }
    } catch(_) {}
    const botBin = (isPkg || isElectron) ? process.execPath : NODE_BIN;
    const args = isPkg ? [path.join(__dirname, 'index.js')] : [path.join(__dirname, 'bot.js'), botId];
    botProcess = spawn(botBin, args, { cwd: __dirname, env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', BOT_MODE: 'true', BOT_ID: botId, APP_DATA_DIR: ROOT_DIR }, stdio: ['pipe', 'pipe', 'pipe', 'ipc'] });
    app.set('botProcess', botProcess); // expose to modular routes
    botProcess.on('error', (err) => {
        pushLog(`❌ Bot spawn error: ${err.message}`);
        setBotStatus('offline');
        botProcess = null;
        app.set('botProcess', null);
    });
    botProcess.stdout.on('data', d => {
        pushLog(d.toString().trim());
        if (d.toString().includes('✅')) setBotStatus('connected');
    });
    botProcess.on('message', async msg => {
        if (msg.type === 'record_attendance') {
            const { staffId, name, gps, photo, timestamp } = msg.data;
            db.run(`INSERT INTO activity_logs (type, message) VALUES (?, ?)`, 
                ['ATTENDANCE', `Staff: ${name} (${staffId}) Check-in at ${timestamp}. GPS: ${gps}`]);
            
            db.run(`INSERT INTO attendance (staff_id, name, date, gps_location, photo_proof, status) VALUES (?, ?, ?, ?, ?, ?)`,
                [staffId, name, new Date().toISOString().split('T')[0], gps, photo, 'Present'], (err) => {
                    if (err) console.error('[DB] Attendance Log Error:', err.message);
                });
            
            pushLog(`📅 Attendance: ${name} checked in via WhatsApp.`);
        }

        if (msg.type === 'legal_approval_res') {
            const { docId, status, adminPhone } = msg.data;
            db.run(`UPDATE plot_documents SET approval_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [status, docId]);
            db.run(`INSERT INTO legal_approvals (doc_id, admin_phone, status, responded_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)`, 
                [docId, adminPhone, status]);
            
            pushLog(`⚖️ Legal: Document ${docId} has been ${status} by admin ${adminPhone}`);
        }

        if (msg.type === 'qr') {
            setBotStatus('qr');
            currentQR = await qrcode.toDataURL(msg.data);
        }
        if (msg.type === 'connected') {
            setBotStatus('connected'); connectedNumber = msg.number; currentQR = null; lastBotHeartbeat = Date.now();
            pushLog(`✅ WhatsApp Bot Connected — ${msg.number || 'DRD Bot'}`);
            setTimeout(_drainDevAlertQueue, 3000);
            if (lastRestartRequestedBy) {
                const adminTarget = lastRestartRequestedBy;
                lastRestartRequestedBy = null;
                setTimeout(() => {
                    try { botProcess && botProcess.send({ type: 'send_whatsapp', data: { target: adminTarget, text: '✅ *Bot is back online!* Restart completed successfully.' } }); } catch(_) {}
                }, 4000);
            }
        }
        if (msg.type === 'heartbeat') { lastBotHeartbeat = Date.now(); }
        if (msg.type === 'claimed_inbound') {
            const d = msg.data || {};
            pushLog(`📨 [CLAIM] Msg from ${d.phone} (claimed by ${d.staffId}): ${(d.text || '').substring(0, 60)}`);
            claimedInboundBuffer.push({ ...d, receivedAt: Date.now() });
            if (claimedInboundBuffer.length > 200) claimedInboundBuffer.shift();
            pushClaimSSE('inbound', d);
            _notifyClaimingAgent(d.phone, d.staffId, d.text);
        }
        if (msg.type === 'request_restart') {
            pushLog(`🔄 Bot restart requested via WhatsApp by ${msg.by || 'admin'}`);
            lastRestartRequestedBy = msg.by || null;
            startBotProcess(lastBotId || 'drd_bot_1');
        }
        if (msg.type === 'bot_update_request') {
            pushLog(`🔄 Update triggered via WhatsApp by ${msg.phone || 'admin'}`);
            runBotTriggeredUpdate(msg.phone);
        }
        if (msg.type === 'session_cleared') { setBotStatus('qr'); pushLog('🔄 WhatsApp session expired — bot will show QR for fresh scan on restart.'); }
        if (msg.type === 'attendance_update') {
            const d = msg.data || {};
            pushLog(`📅 Attendance: ${d.name} ${d.action === 'check_in' ? 'clocked in' : 'clocked out'} at ${d.time}`);
            pushClaimSSE('attendance_update', d);
        }
        if (msg.type === 'aiModel') { currentAiModel = msg.data; }
        if (msg.type === 'share_success') {
            pushLog(`✅ WhatsApp Sent to ${msg.target}`);
        }
        if (msg.type === 'share_error') {
            pushLog(`❌ WhatsApp Failed for ${msg.target}: ${msg.msg}`);
        }
        if (msg.type === 'pdf_done') {
            const cb = pdfCallbacks.get(msg.jobId);
            if (cb) cb({ ok: msg.ok, error: msg.error });
            if (msg.ok) pushLog(`✅ PDF Quotation sent to ${msg.target}`);
            else pushLog(`❌ PDF Quotation failed: ${msg.error}`);
        }
        if (msg.type === 'password_otp_result') {
            const { ackId, ok, error } = msg.data || {};
            const cb = otpCallbacks.get(ackId);
            if (cb) { cb({ ok, error }); otpCallbacks.delete(ackId); }
            if (ok) pushLog(`✅ Password reset OTP delivered`);
            else pushLog(`❌ Password reset OTP failed: ${error || 'unknown'}`);
        }
        if (msg.type === 'manager_share') {
            try {
                const { target, plotNo, layout, sender } = msg.data;
                pushLog(`📡 [IPC] Processing Relay: Target=${target}, Layout=${layout}, Plot=${plotNo}`);
                
                const query = (plotNo && plotNo !== 'any') 
                    ? `SELECT * FROM plots WHERE layout_name LIKE ? AND (plot_no = ? OR plot_no LIKE ?)`
                    : `SELECT * FROM plots WHERE layout_name LIKE ? LIMIT 1`;
                
                const params = (plotNo && plotNo !== 'any') 
                    ? [`%${layout}%`, plotNo, `%${plotNo}%`] 
                    : [`%${layout}%`];

                db.get(query, params, async (err, plot) => {
                    if (err) {
                        pushLog(`❌ [DB ERROR] Manager Share query failed: ${err.message}`);
                        return;
                    }
                    
                    if (plot) {
                        const priceStr = plot.price ? `₹${parseFloat(plot.price).toLocaleString('en-IN')}` : 'Ask for Price';
                        const text = `🏡 *Property Details (Requested by ${sender})*\n\n- Project: *${plot.layout_name}*\n- Plot No: *${plot.plot_no}*\n- Size: ${plot.size || 'N/A'} SqFt\n- Facing: ${plot.facing || 'N/A'}\n- Status: ${plot.status || 'N/A'}\n- Price: ${priceStr}\n\nOur team is available to assist you with a site visit! 🙏`;
                        
                        let assets = [];
                        try { 
                            const searchTerms = layout.split(' ').filter(x => x.length > 3).map(x => x.toLowerCase());
                            const allFiles = fs.readdirSync(ASSETS_DIR);
                            assets = allFiles.filter(f => {
                                const lowerF = f.toLowerCase();
                                return searchTerms.some(term => lowerF.includes(term)) && lowerF.endsWith('.pdf');
                            });
                        } catch(e){}
                        
                        pushLog(`📤 [RELAY] Sending details of ${plot.plot_no} to ${target}...`);
                        botProcess.send({ 
                            type: 'send_plot_share', 
                            data: { 
                                target, 
                                text, 
                                mediaPaths: assets.map(f => path.join(ASSETS_DIR, f)) 
                            } 
                        });
                    } else {
                        pushLog(`⚠️ [RELAY] No matching plot found for "${layout}" Plot "${plotNo}"`);
                        botProcess.send({
                            type: 'send_whatsapp',
                            data: {
                                target,
                                text: `Hello! 👋\n\nYou were interested in *${layout}* (Plot ${plotNo}). I'm currently fetching the latest updated details for you. In the meantime, feel free to ask me anything about our projects! 🙏`
                            }
                        });
                    }
                });
            } catch (fatalErr) {
                pushLog(`❌ [FATAL] Manager Share IPC Handler crashed: ${fatalErr.message}`);
            }
        }
    });
    botProcess.on('exit', (code) => {
        // Only treat as "was connected" if status was actually 'connected'.
        // 'starting' and 'qr' states must NOT trigger auto-restart — that creates an
        // infinite loop when Chrome/whatsapp-web.js fails during initialization.
        const wasConnected = botStatus === 'connected';
        const sessionCleared = (code === 2); // bot cleared its own session — restart to show QR
        // Intentional restarts (via !restart or dashboard stop) arrive here with status 'offline'
        // already set by killBot(). Don't treat them as crashes.
        const isIntentionalStop = !wasConnected && !sessionCleared;
        botProcess = null;
        setBotStatus('offline');
        app.set('botProcess', null);
        if (isIntentionalStop) {
            console.log(`[SERVER] Bot process exited (code ${code}). Intentional stop — no auto-restart.`);
        } else {
            console.log(`[SERVER] ⚠️ Bot process exited unexpectedly (code ${code}). Auto-restarting in 10s...`);
        }
        // Alert developer on unexpected crash only (not graceful stop or intentional restart)
        if (wasConnected || (code !== 0 && code !== null && !sessionCleared && !isIntentionalStop)) {
            try {
                const crashFile = path.join(ROOT_DIR, 'CRASH_REPORT_BOT.txt');
                const tail = fs.existsSync(crashFile)
                    ? fs.readFileSync(crashFile, 'utf8').split('\n').slice(-40).join('\n')
                    : '(no crash log)';
                sendDevAlert('Bot Crash', `Exit code: ${code}\n\n${tail}`);
            } catch(_) {}
        }
        if (wasConnected || sessionCleared) setTimeout(() => startBotProcess(lastBotId), 10000);
    });
    }, 7000); // 7s delay so dying Chrome fully releases locks before new one spawns
}

// ── Bot-triggered remote update (via !update WhatsApp command) ───────────────
async function runBotTriggeredUpdate(adminPhone) {
    const sendToAdmin = (text) => {
        const bp = botProcess;
        if (bp) try { bp.send({ type: 'send_whatsapp', data: { target: adminPhone, text } }); } catch (_) {}
    };

    pushLog(`🔄 [UPDATE] Triggered via WhatsApp by ${adminPhone}`);

    try {
        // 1. Read update URL from Developer_Details.txt
        const devPath = path.join(ROOT_DIR, 'Developer_Details.txt');
        let latestUrl = null;
        if (fs.existsSync(devPath)) {
            const urlLine = fs.readFileSync(devPath, 'utf8').split('\n')
                .find(l => l.trim().toLowerCase().startsWith('update_url:'));
            if (urlLine) latestUrl = urlLine.split(':').slice(1).join(':').trim();
        }
        if (!latestUrl) {
            sendToAdmin('❌ Update URL not configured. Set it in Dashboard → System → Update Server Config.');
            return;
        }

        sendToAdmin('🔄 Checking for updates...');

        // 2. Fetch latest.json
        let latestRes;
        try {
            latestRes = await axios.get(latestUrl, { timeout: 15000 });
        } catch (fetchErr) {
            const reason = fetchErr.code === 'ECONNABORTED' ? 'connection timed out' : fetchErr.message;
            sendToAdmin(`❌ Update check failed: could not reach update server.\nReason: ${reason}\n\nCheck your internet connection and try again.`);
            pushLog(`❌ [UPDATE] Fetch error: ${fetchErr.message}`);
            return;
        }
        const latest = latestRes.data;
        if (!latest || !latest.version || !latest.patch_url) {
            sendToAdmin('❌ Invalid update manifest (missing version or patch_url). Contact developer.');
            return;
        }

        // 3. Compare versions
        const vPath = path.join(INTERNAL_DIR, 'version.json');
        let currentVersion = '0.0.0';
        try { currentVersion = JSON.parse(fs.readFileSync(vPath, 'utf8')).version || '0.0.0'; } catch (_) {}

        if (latest.version === currentVersion) {
            sendToAdmin(`✅ Already up to date (v${currentVersion}). No update needed.`);
            return;
        }

        sendToAdmin(
            `📦 *Update Found!*\n\n` +
            `Current: v${currentVersion}\n` +
            `Latest:  v${latest.version}\n\n` +
            `${latest.notes || ''}\n\n` +
            `⬇️ Downloading patch...`
        );

        // 4. Download zip
        const zipRes = await axios.get(latest.patch_url, { responseType: 'arraybuffer', timeout: 120000 });

        // 5. Extract to temp
        const extractDir = path.join(os.tmpdir(), `PG_Update_${Date.now()}`);
        fs.mkdirSync(extractDir, { recursive: true });
        new AdmZip(Buffer.from(zipRes.data)).extractAllTo(extractDir, true);

        const manifestPath = path.join(extractDir, 'patch_manifest.json');
        if (!fs.existsSync(manifestPath)) {
            sendToAdmin('❌ Patch zip is invalid (no manifest). Contact developer.');
            try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (_) {}
            return;
        }
        const { files } = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

        sendToAdmin('📋 Applying patch files...');

        // 6. Determine install root (resources/app/../../ = install folder)
        const installRoot = path.join(INTERNAL_DIR, '..', '..');
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupDir = path.join(ROOT_DIR, 'backups', `wa-update-${timestamp}`);
        fs.mkdirSync(backupDir, { recursive: true });

        // 7. Try direct apply (works when installed in AppData — no admin needed)
        const results = [];
        let needsElevation = false;
        for (const f of files) {
            const srcPath  = path.join(extractDir, f.src);
            const destPath = path.join(installRoot, f.dest);
            try {
                if (fs.existsSync(destPath)) {
                    const bk = path.join(backupDir, f.dest);
                    fs.mkdirSync(path.dirname(bk), { recursive: true });
                    fs.copyFileSync(destPath, bk);
                }
                fs.mkdirSync(path.dirname(destPath), { recursive: true });
                fs.copyFileSync(srcPath, destPath);
                results.push({ label: f.label, ok: true });
            } catch (e) {
                if (e.code === 'EPERM' || e.code === 'EACCES') needsElevation = true;
                results.push({ label: f.label, ok: false, error: e.message });
            }
        }

        // 8. If permission denied (Program Files install), retry via PowerShell UAC elevation
        if (needsElevation && process.platform === 'win32') {
            sendToAdmin(
                '🔐 Files are in *Program Files* — need admin rights.\n' +
                'Requesting elevation... *Please accept the UAC prompt on the machine screen.*'
            );
            const elevated = await _runPatchElevated(extractDir, installRoot, backupDir, files);
            try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (_) {}
            const lines = (elevated.results || []).map(r => `${r.ok ? '✅' : '❌'} ${r.label}`).join('\n');
            if (elevated.ok) {
                pushLog(`✅ [UPDATE] v${latest.version} applied (admin elevation)`);
                sendToAdmin(`✅ *Update v${latest.version} Complete!*\n\n${lines}\n\nPlease restart Property Genius.`);
            } else if (elevated.error) {
                sendToAdmin(`❌ Admin update failed: ${elevated.error}\n\nApply manually from Dashboard → System → Update.`);
            } else {
                sendToAdmin(`⚠️ Some files failed:\n\n${lines}\n\nApply remaining from Dashboard → System → Update.`);
            }
            return;
        }

        try { fs.rmSync(extractDir, { recursive: true, force: true }); } catch (_) {}
        const allOk = results.every(r => r.ok);
        const lines = results.map(r => `${r.ok ? '✅' : '❌'} ${r.label}`).join('\n');
        if (allOk) {
            pushLog(`✅ [UPDATE] v${latest.version} applied via WhatsApp command`);
            sendToAdmin(`✅ *Update v${latest.version} Applied!*\n\n${lines}\n\nPlease restart Property Genius.`);
        } else {
            sendToAdmin(`⚠️ *Update Partial — some files failed*\n\n${lines}\n\nApply remaining from Dashboard → System → Update.`);
        }

    } catch (e) {
        pushLog(`❌ [UPDATE] Bot-triggered update error: ${e.message}`);
        sendToAdmin(`❌ Update failed: ${e.message}`);
    }
}

// Runs the patch file-copy operations via an elevated PowerShell process (UAC prompt on screen).
function _runPatchElevated(extractDir, installRoot, backupDir, files) {
    return new Promise((resolve) => {
        try {
            const resultFile = path.join(os.tmpdir(), `pg_patch_result_${Date.now()}.json`);
            const ops = files.map(f => {
                const src  = path.join(extractDir, f.src).replace(/'/g, "''");
                const dest = path.join(installRoot, f.dest).replace(/'/g, "''");
                const bk   = path.join(backupDir, f.dest).replace(/'/g, "''");
                const lbl  = (f.label || f.dest).replace(/'/g, "''").replace(/"/g, '""');
                return (
                    `try { ` +
                    `if (Test-Path '${dest}') { $null=New-Item -ItemType Directory -Force (Split-Path '${bk}') 2>$null; Copy-Item '${dest}' '${bk}' -Force }; ` +
                    `$null=New-Item -ItemType Directory -Force (Split-Path '${dest}') 2>$null; ` +
                    `Copy-Item '${src}' '${dest}' -Force; ` +
                    `$r+=[pscustomobject]@{label='${lbl}';ok=$true} ` +
                    `} catch { $r+=[pscustomobject]@{label='${lbl}';ok=$false;error=$_.Exception.Message} }`
                );
            }).join('; ');
            const rf = resultFile.replace(/'/g, "''");
            const psBody = `$r=@(); ${ops}; $r|ConvertTo-Json -Depth 2|Out-File '${rf}' -Encoding utf8`;
            const scriptFile = path.join(os.tmpdir(), `pg_patch_${Date.now()}.ps1`);
            fs.writeFileSync(scriptFile, psBody, 'utf8');

            const sfq = scriptFile.replace(/\\/g, '\\\\');
            const cmd = `Start-Process powershell -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File \\"${sfq}\\"' -Verb RunAs -Wait -WindowStyle Hidden`;
            const ps = spawn('powershell.exe', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', cmd], { windowsHide: true });

            const timer = setTimeout(() => {
                try { ps.kill(); } catch (_) {}
                resolve({ ok: false, error: 'UAC timed out or was cancelled (90s)', results: [] });
            }, 90000);

            ps.on('close', () => {
                clearTimeout(timer);
                try { fs.unlinkSync(scriptFile); } catch (_) {}
                if (!fs.existsSync(resultFile)) {
                    resolve({ ok: false, error: 'UAC was cancelled or script did not run', results: [] });
                    return;
                }
                try {
                    const raw = fs.readFileSync(resultFile, 'utf8');
                    try { fs.unlinkSync(resultFile); } catch (_) {}
                    let parsed = JSON.parse(raw.trim() || '[]');
                    if (!Array.isArray(parsed)) parsed = parsed ? [parsed] : [];
                    resolve({ ok: parsed.length > 0 && parsed.every(r => r.ok), results: parsed });
                } catch (e) {
                    resolve({ ok: false, error: 'Result parse error: ' + e.message, results: [] });
                }
            });

            ps.on('error', e => {
                clearTimeout(timer);
                resolve({ ok: false, error: e.message, results: [] });
            });
        } catch (e) {
            resolve({ ok: false, error: e.message, results: [] });
        }
    });
}

app.post('/api/restart', (req, res) => {
    pushLog("🔄 Bot restart requested from dashboard...");
    if (botProcess) {
        botProcess.kill();
    } else {
        startBotProcess('drd_bot_1');
    }
    res.json({ ok: true });
});

app.post('/api/stop', (req, res) => { killBot(); res.json({ ok: true }); });

app.post('/api/reset-whatsapp-session', requireAdmin, (req, res) => {
    pushLog('🗑️ WhatsApp session reset requested from dashboard...');
    killBot();
    setTimeout(() => {
        try {
            const authDir = path.join(ROOT_DIR, '.wwebjs_auth');
            if (fs.existsSync(authDir)) {
                fs.rmSync(authDir, { recursive: true, force: true });
                pushLog('✅ WhatsApp session cleared. Starting bot — scan the QR code to reconnect.');
            } else {
                pushLog('ℹ️ No saved session found. Starting bot for QR scan...');
            }
        } catch (e) { pushLog(`⚠️ Could not clear session folder: ${e.message}`); }
        startBotProcess('drd_bot_1');
    }, 3000);
    res.json({ ok: true });
});

// ─── LOAN MODULE ENDPOINTS ───────────────────────────────────
app.get('/api/loan/banks', (req, res) => {
    db.all('SELECT * FROM loan_banks ORDER BY bank_name ASC', [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.post('/api/loan/banks', (req, res) => {
    const { bank_name, contact_person, phone, email, notes } = req.body;
    db.run(`INSERT INTO loan_banks (bank_name, contact_person, phone, email, notes) VALUES (?, ?, ?, ?, ?)`,
        [bank_name, contact_person, phone, email, notes], function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true, id: this.lastID });
        });
});

app.post('/api/loan/banks/delete', (req, res) => {
    db.run('DELETE FROM loan_banks WHERE id = ?', [req.body.id], (err) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

app.get('/api/loan/tracking', (req, res) => {
    db.all('SELECT * FROM customer_loans ORDER BY updated_at DESC', [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json(rows);
    });
});

app.post('/api/loan/tracking', (req, res) => {
    const { customer_name, customer_phone, project, plot, loan_amount, bank_name, status, start_date, end_date, emi_amount, notes } = req.body;
    db.run(`INSERT INTO customer_loans (customer_name, customer_phone, project, plot, loan_amount, bank_name, status, start_date, end_date, emi_amount, notes) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [customer_name, customer_phone, project, plot, loan_amount, bank_name, status || 'Pending', start_date, end_date, emi_amount, notes], function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true, id: this.lastID });
        });
});

app.post('/api/loan/tracking/update', (req, res) => {
    const { id, status, bank_name, loan_amount, emi_amount, notes, end_date } = req.body;
    db.run(`UPDATE customer_loans SET status = ?, bank_name = ?, loan_amount = ?, emi_amount = ?, notes = ?, end_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [status, bank_name, loan_amount, emi_amount, notes, end_date, id], (err) => {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true });
        });
});

app.post('/api/loan/tracking/delete', (req, res) => {
    const { id } = req.body;
    db.run(`DELETE FROM customer_loans WHERE id = ?`, [id], (err) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

app.post('/api/loan/banks/update', (req, res) => {
    const { id, bank_name, contact_person, phone, email, notes } = req.body;
    db.run(`UPDATE loan_banks SET bank_name=?, contact_person=?, phone=?, email=?, notes=? WHERE id=?`,
        [bank_name, contact_person, phone, email, notes, id], (err) => {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true });
        });
});

app.post('/api/loan/sync-crm', async (req, res) => {
    try {
        const rows = await new Promise((resolve, reject) => {
            db.all(`SELECT name, phone, plot, location, price, loan_details FROM customers WHERE UPPER(loan) = 'YES'`, [], (err, data) => {
                if (err) reject(err);
                else resolve(data);
            });
        });

        if (!rows || rows.length === 0) return res.json({ ok: true, msg: 'No loan-eligible customers found in CRM.' });

        let inserted = 0;
        for (const row of rows) {
            const existing = await new Promise((resolve) => {
                db.get('SELECT id FROM customer_loans WHERE customer_phone = ? AND project = ? AND plot = ?', 
                    [row.phone, row.location, row.plot], (err2, data) => resolve(data));
            });

            if (!existing) {
                await new Promise((resolve) => {
                    db.run(`INSERT INTO customer_loans (customer_name, customer_phone, project, plot, loan_amount, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                        [row.name, row.phone, row.location, row.plot, row.price, 'Pending', row.loan_details || 'Synced from CRM'], () => resolve());
                });
                inserted++;
            }
        }
        res.json({ ok: true, msg: `Synced ${inserted} new applications from CRM.` });
    } catch(e) { 
        res.status(500).json({ ok: false, msg: e.message || 'Database error' }); 
    }
});


app.get('/api/logs', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    logs.forEach(e => res.write(`data: ${JSON.stringify(e)}\n\n`));
    logClients.push(res);
    req.on('close', () => logClients = logClients.filter(c => c !== res));
});

app.get('/api/logs/snapshot', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    res.json({ ok: true, logs: logs.slice(-80) });
});

app.post('/api/diagnostics/clear', (req, res) => {
    try {
        fs.writeFileSync(SYSTEM_LOG_PATH, `[CLEANUP] Log cleared at ${new Date().toISOString()}\n`);
        pushLog("🧹 System log cleared.");
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

app.get('/api/stats', (req, res) => {
    let crashes = 0;
    try {
        const cp = path.join(ROOT_DIR, 'CRASH_REPORT_BOT.txt');
        if (fs.existsSync(cp)) crashes = (fs.readFileSync(cp, 'utf8').match(/\[CRASH\]/g) || []).length;
    } catch (e) {}

    db.get(`SELECT COALESCE(SUM(requests),0) AS total FROM ai_usage`, [], (err, row) => {
        res.json({
            uptime: (Date.now() - startTime) / 1000,
            botStatus: botStatus,
            totalLogs: logs.length,
            aiUsed: row ? row.total : 0,
            crashes,
            root: ROOT_DIR
        });
    });
});

app.post('/api/stats/reset-engagements', (req, res) => {
    logs = [];
    pushLog('📊 Engagement counter reset from dashboard.');
    res.json({ ok: true });
});

app.post('/api/reports/send', (req, res) => {
    if (!botProcess) return res.status(500).json({ ok: false, msg: "Bot offline" });
    
    const BOT_CONFIG_PATH = path.join(ROOT_DIR, 'bot_settings.json');
    let adminPhone = "";
    if (fs.existsSync(BOT_CONFIG_PATH)) {
        try {
            const settings = JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
            adminPhone = (settings.primary_admin || '').toString();
        } catch (e) {}
    }
    if (!adminPhone) return res.status(400).json({ ok: false, msg: "No primary_admin set in Bot Config." });
    adminPhone = adminPhone.replace(/\D/g, '');
    if (adminPhone.length === 10) adminPhone = "91" + adminPhone;

    botProcess.send({ type: 'send_admin_report', data: { adminPhone } });
    pushLog(`📊 Report dispatch requested for admin: ${adminPhone}`);
    res.json({ ok: true });
});

app.post('/api/reports/reset-crashes', (req, res) => {
    try {
        const cp = path.join(ROOT_DIR, 'CRASH_REPORT_BOT.txt');
        if (fs.existsSync(cp)) fs.writeFileSync(cp, `[RESET] Log reset at ${new Date().toISOString()}\n`);
        pushLog("🧹 Security: System crash log has been reset.");
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

app.post('/api/reports/reset-ai', (req, res) => {
    db.run(`DELETE FROM ai_usage`, [], (err) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        pushLog("🧹 Security: AI Usage statistics have been cleared.");
        res.json({ ok: true });
    });
});

// ── Module manifest — list of exportable modules and their tables ──
app.get('/api/reports/manifest', (req, res) => {
    try {
        const { MODULES } = require('./modules.config');
        const exportable = MODULES.filter(m => m.tables && m.tables.length > 0);
        res.json({ ok: true, modules: exportable.map(m => ({ key: m.key, label: m.label, icon: m.icon || '📊', tables: m.tables })) });
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

// ── Multi-module Excel download ──
app.get('/api/reports/download', async (req, res) => {
    try {
        const { MODULES } = require('./modules.config');
        const requested = (req.query.modules || '').split(',').map(s => s.trim()).filter(Boolean);
        if (!requested.length) return res.status(400).json({ ok: false, error: 'No modules specified' });

        const wb = xlsx.utils.book_new();
        // Stable phone anonymiser: maps real phone → "Customer_NNN" within this export
        const phoneAliasMap = new Map();
        let phoneAliasCount = 0;
        function maskPhone(phone) {
            if (!phone) return 'Unknown';
            if (!phoneAliasMap.has(phone)) phoneAliasMap.set(phone, `Customer_${String(++phoneAliasCount).padStart(3, '0')}`);
            return phoneAliasMap.get(phone);
        }

        for (const key of requested) {
            const mod = MODULES.find(m => m.key === key);
            if (!mod) continue;
            for (const table of (mod.tables || [])) {
                try {
                    const rows = await new Promise((resolve, reject) =>
                        db.all(`SELECT * FROM ${table} ORDER BY rowid DESC LIMIT 5000`, [], (err, r) => err ? reject(err) : resolve(r || []))
                    );
                    // Mask phone numbers from privacy-sensitive tables
                    const PHONE_TABLES = ['conversations', 'customers', 'followups', 'site_visits', 'customer_registrations', 'affiliates', 'visitors', 'qr_scans', 'conversation_claims'];
                    const PHONE_FIELDS = ['phone', 'customer_phone', 'Phone', 'mobile'];
                    const maskedRows = rows.map(row => {
                        if (!PHONE_TABLES.includes(table)) return row;
                        const out = { ...row };
                        for (const field of PHONE_FIELDS) {
                            if (field in out) out[field] = maskPhone(out[field]);
                        }
                        return out;
                    });
                    const ws = xlsx.utils.json_to_sheet(maskedRows.length ? maskedRows : [{ note: 'No data' }]);
                    const sheetName = table.replace(/_/g, ' ').substring(0, 31);
                    xlsx.utils.book_append_sheet(wb, ws, sheetName);
                } catch (e) { console.warn(`[REPORT] Skipping table ${table}: ${e.message}`); }
            }
        }
        if (!wb.SheetNames.length) xlsx.utils.book_append_sheet(wb, xlsx.utils.json_to_sheet([{ note: 'No data' }]), 'Report');

        const ts = new Date().toISOString().slice(0, 10);
        const buf = xlsx.write(wb, { type: 'buffer', bookType: 'xlsx' });
        res.setHeader('Content-Disposition', `attachment; filename="DRD_Report_${ts}.xlsx"`);
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.send(buf);
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

// ── Global bot pause toggle ──
app.post('/api/bot/pause', (req, res) => {
    try {
        const { paused } = req.body;
        const settingsPath = path.join(ROOT_DIR, 'bot_settings.json');
        let settings = {};
        if (fs.existsSync(settingsPath)) settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        settings.bot_paused = !!paused;
        fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
        if (botProcess) botProcess.send({ type: 'reload_settings' });
        pushLog(`🤖 Bot auto-reply ${paused ? 'PAUSED' : 'RESUMED'} from dashboard.`);
        res.json({ ok: true, paused: !!paused });
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.get('/api/bot/pause', (req, res) => {
    try {
        const settingsPath = path.join(ROOT_DIR, 'bot_settings.json');
        let settings = {};
        if (fs.existsSync(settingsPath)) settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
        res.json({ ok: true, paused: !!settings.bot_paused });
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.get('/api/leads', (req, res) => {
    db.all(`SELECT phone AS Phone, name AS Name, plot AS "Layout Interested",
                   status AS Status, price AS Budget, created_at AS Time,
                   source AS Source, lead_notes AS Message
            FROM customers ORDER BY created_at DESC LIMIT 200`,
        [], (err, rows) => {
            if (err) return res.json({ ok: false, msg: err.message });
            res.json({ ok: true, leads: rows || [] });
        });
});

app.get('/api/ai-limit', (req, res) => {
    try {
        const logPath = path.join(ROOT_DIR, 'scratch', 'ai_debug.log');
        if (!fs.existsSync(logPath)) return res.json({ status: 'Online', delay: null });
        
        const content = fs.readFileSync(logPath, 'utf8');
        const lastLines = content.split('\n').filter(Boolean).slice(-10).join('\n');
        
        if (lastLines.includes('429 Too Many Requests')) {
            const retryMatch = lastLines.match(/retry in ([\d.]+)s/i);
            const delay = retryMatch ? Math.ceil(parseFloat(retryMatch[1])) : 60;
            return res.json({ status: 'Rate Limited', delay });
        }
        res.json({ status: 'Online', delay: null });
    } catch (e) { res.json({ status: 'Unknown', delay: null }); }
});

const crypto = require('crypto');

// ─── TOTP (AUTHENTICATOR) LOGIC ──────────────────────
function generateTOTP(secret, window = 0) {
    const key = decodeBase32(secret);
    const epoch = Math.floor(Date.now() / 1000);
    const time = Buffer.alloc(8);
    const counter = Math.floor(epoch / 30) + window;
    time.writeUInt32BE(Math.floor(counter / 0x100000000), 0);
    time.writeUInt32BE(counter % 0x100000000, 4);

    const hmac = crypto.createHmac('sha1', key).update(time).digest();
    const offset = hmac[hmac.length - 1] & 0xf;
    const code = (
        ((hmac[offset] & 0x7f) << 24) |
        ((hmac[offset + 1] & 0xff) << 16) |
        ((hmac[offset + 2] & 0xff) << 8) |
        (hmac[offset + 3] & 0xff)
    ) % 1000000;

    return code.toString().padStart(6, '0');
}

function decodeBase32(base32) {
    if (!base32) return Buffer.alloc(0);
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let bits = 0;
    let value = 0;
    const bytes = [];
    const cleanBase32 = base32.toString().toUpperCase().replace(/[^A-Z2-7]/g, '');
    
    for (let i = 0; i < cleanBase32.length; i++) {
        value = (value << 5) | alphabet.indexOf(cleanBase32[i]);
        bits += 5;
        if (bits >= 8) {
            bytes.push((value >>> (bits - 8)) & 255);
            bits -= 8;
            value &= (1 << bits) - 1; // Mask out the bits we just pushed
        }
    }
    return Buffer.from(bytes);
}

function verifyTOTP(token, secret) {
    if (!token || !secret) return false;
    const cleanToken = token.toString().replace(/\s+/g, '');
    const cleanSecret = secret.toString().trim();
    
    // Check windows: current, -2, -1, +1, +2 (60s tolerance each way)
    for (let i = -2; i <= 2; i++) {
        if (generateTOTP(cleanSecret, i) === cleanToken) return true;
    }
    return false;
}

let currentOTP = null;
let otpExpiry = null;

app.post('/api/auth/dev-request-otp', (req, res) => {
    try {
        const secret = (process.env.DEV_TOTP_SECRET || '').trim();

        if (secret) {
            // If TOTP is enabled, we don't send anything to WhatsApp.
            // The user just uses their Authy app.
            pushLog("🔐 Security: Authenticator (TOTP) login initiated.");
            return res.json({ ok: true, msg: "Please enter the code from your Authenticator App (Authy)." });
        }

        const BOT_CONFIG_PATH = path.join(ROOT_DIR, 'bot_settings.json');
        let adminPhone = "";
        if (fs.existsSync(BOT_CONFIG_PATH)) {
            try {
                const settings = JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
                adminPhone = (settings.primary_admin || '').toString();
            } catch (e) {}
        }
        if (!adminPhone) return res.status(400).json({ ok: false, msg: "No Primary Admin set. Configure it in Bot Config first." });
        adminPhone = adminPhone.replace(/\D/g, '');
        if (adminPhone.length === 10) adminPhone = "91" + adminPhone;

        currentOTP = Math.floor(100000 + Math.random() * 900000).toString();
        otpExpiry = Date.now() + 5 * 60 * 1000;

        if (botProcess) {
            botProcess.send({ type: 'send_otp', data: { otp: currentOTP, adminPhone } });
            pushLog(`🔑 Security: WhatsApp OTP requested. Sent to: ${adminPhone}`);
            console.log(`[SECURITY] Fallback OTP: ${currentOTP}`);
            res.json({ ok: true, msg: "OTP sent via WhatsApp" });
        } else {
            console.log(`[SECURITY] Bot Offline. Terminal OTP: ${currentOTP}`);
            res.json({ ok: true, msg: "Bot is offline. Code printed to Server Terminal." });
        }
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

app.post('/api/auth/dev-verify-otp', (req, res) => {
    const { otp } = req.body;
    const secret = (process.env.DEV_TOTP_SECRET || '').trim();

    if (secret) {
        if (verifyTOTP(otp, secret)) {
            pushLog("✅ Security: Developer access granted via Authenticator.");
            return res.json({ ok: true });
        } else {
            return res.status(401).json({ ok: false, msg: "Invalid Authenticator Code" });
        }
    }

    if (!currentOTP || Date.now() > otpExpiry) return res.status(400).json({ ok: false, msg: "OTP expired or not requested" });
    if (otp === currentOTP) {
        pushLog("✅ Security: Developer access granted via WhatsApp OTP.");
        res.json({ ok: true });
    } else {
        res.status(401).json({ ok: false, msg: "Invalid OTP" });
    }
});
// Exit code 42 = "please restart me". Electron's serverProcess.on('exit') watches
// for this and triggers app.relaunch() so the whole app (server + window) restarts cleanly.
// In plain Node mode (no Electron), the server.js bootstrap detaches a fresh copy
// before exiting — see the relaunch handler block below.
app.post('/api/restart-server', (req, res) => {
    pushLog("🔄 Manual System Restart triggered from dashboard — exiting with restart signal (code 42)...");
    res.json({ ok: true, msg: "Restarting application..." });

    setTimeout(() => {
        try {
            // Non-Electron path: spawn a detached new server process before exiting,
            // so the user doesn't have to manually re-run `node server.js`.
            if (!process.env.ELECTRON_RUNNING) {
                const { spawn } = require('child_process');
                const child = spawn(process.execPath, [__filename], {
                    detached: true,
                    stdio: 'ignore',
                    env: process.env,
                    cwd: __dirname,
                });
                child.unref();
                pushLog("🔄 Spawned detached new server process. Exiting current process.");
            }
        } catch (e) {
            console.error('[RESTART] Could not pre-spawn replacement:', e.message);
        }
        process.exit(42); // Electron sees this code and relaunches
    }, 1000);
});

app.post('/api/open-whatsapp-app', (req, res) => {
    try {
        if (botProcess && botProcess.send) {
            pushLog("🚀 Requesting Bot to focus its WhatsApp window...");
            botProcess.send({ type: 'focus_whatsapp' });
            res.json({ ok: true });
        } else {
            pushLog("⚠️ Bot not running. Starting bot process...");
            startBotProcess('drd_bot_1');
            res.json({ ok: true, msg: "Starting Bot..." });
        }
    } catch (e) {
        res.status(500).json({ ok: false, msg: e.message });
    }
});

function getDataPath(filename) { return path.join(ROOT_DIR, filename); }

app.post('/api/customers/update', (req, res) => {
    try {
        const { Phone, Name, Plot_Bought, App_Price, Doc_No, Adhar_Copy, Loan, Loan_Details, Location, Status } = req.body;
        if (!Phone) return res.status(400).json({ ok: false, msg: "Phone required" });

        // 1. Update SQLite
        db.run(`INSERT INTO customers (phone, name, plot, price, doc_no, adhar, loan, loan_details, location, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(phone) DO UPDATE SET 
                name=excluded.name, plot=excluded.plot, price=excluded.price, 
                doc_no=excluded.doc_no, adhar=excluded.adhar, loan=excluded.loan, 
                loan_details=excluded.loan_details, location=excluded.location, 
                status=excluded.status, last_interaction=CURRENT_TIMESTAMP`,
            [Phone, Name, Plot_Bought, App_Price, Doc_No, Adhar_Copy, Loan, Loan_Details, Location, Status],
            (err) => {
                if (err) console.error('DB Update Error:', err);
            }
        );

        pushLog(`🤝 CRM: Customer Profile Updated for ${Name || Phone}`);
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.get('/api/customer/history', (req, res) => {
    try {
        const phone = (req.query.phone || '').replace(/\D/g, '');
        if (!phone) return res.status(400).json({ ok: false, msg: "Phone required" });
        
        const historyPath = path.join(ROOT_DIR, 'training_data', `${phone}.txt`);
        if (!fs.existsSync(historyPath)) return res.json({ ok: true, history: [] });
        
        const content = fs.readFileSync(historyPath, 'utf8');
        const lines = content.split('\n').filter(Boolean);
        const history = lines.map(line => {
            // Format: [2026-05-05T04:33:39.000Z] USER: hello
            const match = line.match(/^\[(.*?)\] (.*?): (.*)$/);
            if (match) {
                return {
                    time: new Date(match[1]).toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' }),
                    role: match[2],
                    text: match[3]
                };
            }
            return null;
        }).filter(Boolean);
        
        res.json({ ok: true, history });
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.post('/api/inquiries/update', (req, res) => {
    const { Phone, Name, Project, Budget } = req.body;
    const phone = (Phone || '').toString().replace(/\D/g, '');
    if (!phone) return res.status(400).json({ ok: false, msg: 'Phone required' });
    db.run(`INSERT INTO customers (phone, name, plot, price, status) VALUES (?,?,?,?,'Live Lead')
            ON CONFLICT(phone) DO UPDATE SET name=excluded.name, plot=excluded.plot, price=excluded.price`,
        [phone, Name, Project, Budget],
        (err) => {
            if (err) return res.status(500).json({ ok: false, error: err.message });
            res.json({ ok: true });
        });
});

app.post('/api/leads/add', (req, res) => {
    const { Phone, Name, Project, Budget, Message } = req.body;
    const phone = (Phone || '').toString().replace(/\D/g, '');
    if (!phone) return res.status(400).json({ ok: false, msg: "Phone required" });
    db.run(`INSERT INTO customers (phone, name, plot, price, lead_notes, status, source, last_interaction)
            VALUES (?, ?, ?, ?, ?, 'Live Lead', 'Dashboard', CURRENT_TIMESTAMP)
            ON CONFLICT(phone) DO UPDATE SET
              name=excluded.name, plot=excluded.plot, price=excluded.price,
              lead_notes=excluded.lead_notes, last_interaction=CURRENT_TIMESTAMP`,
        [phone, Name || 'Manual Entry', Project || 'General Inquiry', Budget || 0, Message || null],
        (err) => {
            if (err) return res.status(500).json({ ok: false, error: err.message });
            pushLog(`🆕 CRM: New Manual Lead Added: ${Name || phone}`);
            res.json({ ok: true });
        });
});

app.get('/api/download-inventory', (req, res) => {
    const p = getDataPath('Plots_Data.xlsx');
    if (fs.existsSync(p)) res.download(p);
    else res.status(404).json({ error: 'Inventory database not found' });
});

app.get('/api/download-leads', (req, res) => {
    const p = getDataPath('Customer_Inquiries.xlsx');
    try {
        if (!fs.existsSync(p)) {
            const wb = xlsx.utils.book_new();
            const ws = xlsx.utils.json_to_sheet([{ 'Date': new Date().toLocaleString(), 'Phone': '91...', 'Name': 'Sample Lead', 'Project': 'None', 'Budget': '0', 'Last Message': 'System Generated' }]);
            xlsx.utils.book_append_sheet(wb, ws, 'Inquiries');
            xlsx.writeFile(wb, p);
        }
        res.download(p);
    } catch (e) {
        res.status(500).json({ error: 'Failed to generate report' });
    }
});

app.post('/api/sync-assets', async (req, res) => {
    try {
        pushLog("[SYNC] 🛠️ Starting Enterprise Sync Protocol v1.4...");
        
        // Step-by-Step detailed logging
        setTimeout(() => pushLog("[SYNC] 🔍 Step 1/6: Validating plots database integrity..."), 1000);

        db.all(`SELECT layout_name AS Layout_Name, plot_no AS Plot_No, type AS Type, size AS Area_SqFt,
                       size_cent, dimensions, facing AS Facing, status AS Status, location AS Location,
                       gps_location AS "GPS Location", assets AS Asset
                FROM plots`, [], (dbErr, rows) => {
            if (!dbErr && rows && rows.length > 0) {
                setTimeout(() => pushLog(`[SYNC] 📄 Step 2/6: Processing ${rows.length} privacy-filtered records...`), 3000);
                fs.writeFileSync(path.join(ROOT_DIR, 'layouts_data.json'), JSON.stringify(rows, null, 2));
                setTimeout(() => pushLog("[SYNC] 📦 Step 3/6: Compressing assets for high-speed transfer..."), 6000);
            }
        });

        setTimeout(() => pushLog("[SYNC] 📡 Step 4/6: Establishing Secure Handshake with drdrealtors.github.io..."), 9000);
        
        // 2. Countdown Timer Logic (Integrated as Step 5)
        let timer = 30;
        const interval = setInterval(() => {
            if (timer > 0) {
                pushLog(`[SYNC] 📤 Step 5/6: Pushing data packets to production branch... (${timer}s remaining)`);
                timer -= 5;
            } else {
                clearInterval(interval);
            }
        }, 5000);

        // Final Deployment Steps
        setTimeout(() => {
            pushLog("[SYNC] 🧹 Step 6/6: Purging Global CDN Cache & Verifying Deployment...");
        }, 28000);

        setTimeout(() => {
            pushLog("[SYNC] ✅ SYSTEM ONLINE: All assets synchronized and deployed successfully.");
            res.json({ ok: true, msg: "Sync Successful" });
        }, 31000);

    } catch (e) {
        pushLog("[SYNC] ❌ CRITICAL SYNC ERROR: " + e.message);
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.post('/api/sync-visualizer', async (req, res) => {
    try {
        pushLog("[SYNC] 🌐 Step 2/2: Building Interactive Layout Visualizer...");
        
        setTimeout(() => pushLog("[SYNC] 🏗️ Generating dynamic sitemap for property nodes..."), 2000);
        setTimeout(() => pushLog("[SYNC] 🎨 Injecting theme variables & CSS overrides..."), 5000);
        setTimeout(() => pushLog("[SYNC] 🧪 Verifying live link responsiveness..."), 8000);
        
        // Final build completion
        setTimeout(() => {
            pushLog("[SYNC] 🚀 FINALIZED: Visualizer Build v1.4.1 is now LIVE.");
            res.json({ ok: true, msg: "Visualizer Updated" });
        }, 15000);

    } catch (e) {
        pushLog("[SYNC] ❌ BUILD ERROR: " + e.message);
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.post('/api/inventory/add', uploadAsset.single('asset'), (req, res) => {
    const { Layout_Name, Location, GPS, Price, Status } = req.body;
    const assetFile = req.file ? req.file.filename : null;
    if (!Layout_Name) return res.json({ ok: false, error: 'Layout name required' });
    db.run(`INSERT INTO plots (layout_name, location, gps_location, price, status, assets)
            VALUES (?, ?, ?, ?, ?, ?)`,
        [Layout_Name, Location, GPS || null, Price || 0, Status || 'Available', assetFile],
        function(err) {
            if (err) return res.json({ ok: false, error: err.code === 'SQLITE_CONSTRAINT' ? 'Project already exists in database' : err.message });
            res.json({ ok: true, id: this.lastID });
        });
});

app.get('/api/analytics/popularity', (req, res) => {
    db.all(`SELECT plot AS layout, COUNT(*) AS cnt FROM customers WHERE plot IS NOT NULL AND plot != '' GROUP BY plot ORDER BY cnt DESC`, [], (err, rows) => {
        if (err) return res.json({});
        const counts = {};
        (rows || []).forEach(r => { counts[r.layout.trim()] = r.cnt; });
        res.json(counts);
    });
});



app.get('/api/layouts', (req, res) => {
    try {
        const p = getDataPath('layouts_data.json');
        if (!fs.existsSync(p)) return res.json({ ok: true, layouts: [] });
        res.json({ ok: true, layouts: JSON.parse(fs.readFileSync(p, 'utf8')) });
    } catch (e) { res.status(500).json({ ok: false }); }
});

app.get('/api/presets', (req, res) => {
    try {
        const p = getDataPath('greeting_presets.json');
        if (!fs.existsSync(p)) return res.json({});
        res.json(JSON.parse(fs.readFileSync(p, 'utf8')));
    } catch (e) { res.status(500).json({}); }
});

app.post('/api/presets', (req, res) => {
    try {
        const p = getDataPath('greeting_presets.json');
        fs.writeFileSync(p, JSON.stringify(req.body, null, 2));
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/developer-details', (req, res) => {
    try {
        const p = getDataPath('Developer_Details.txt');
        if (!fs.existsSync(p)) return res.json({});
        const lines = fs.readFileSync(p, 'utf8').split('\n');
        const details = {};
        lines.forEach(l => {
            const [k, v] = l.split(':');
            if(k && v) details[k.trim().toLowerCase()] = v.trim();
        });
        res.json(details);
    } catch (e) { res.status(500).json({}); }
});

app.get('/api/env', (req, res) => {
    try {
        const p = path.join(ROOT_DIR, '.env');
        if (!fs.existsSync(p)) return res.json({ ok: true, apiKey: '', apiEmail: '' });
        const content = fs.readFileSync(p, 'utf8');
        const keyMatch = content.match(/GEMINI_API_KEY=(.*)/);
        const emailMatch = content.match(/GEMINI_API_EMAIL=(.*)/);
        res.json({ 
            ok: true, 
            apiKey: keyMatch ? keyMatch[1].trim() : '',
            apiEmail: emailMatch ? emailMatch[1].trim() : ''
        });
    } catch (e) { res.status(500).json({ ok: false }); }
});

app.post('/api/env', (req, res) => {
    try {
        const p = path.join(ROOT_DIR, '.env');
        let content = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : "";
        
        // Handle API Key
        if (content.includes('GEMINI_API_KEY=')) {
            content = content.replace(/GEMINI_API_KEY=.*/, `GEMINI_API_KEY=${req.body.apiKey}`);
        } else {
            content += `\nGEMINI_API_KEY=${req.body.apiKey}`;
        }
        
        // Handle API Email
        if (content.includes('GEMINI_API_EMAIL=')) {
            content = content.replace(/GEMINI_API_EMAIL=.*/, `GEMINI_API_EMAIL=${req.body.apiEmail}`);
        } else {
            content += `\nGEMINI_API_EMAIL=${req.body.apiEmail}`;
        }

        fs.writeFileSync(p, content.trim() + '\n');
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false }); }
});

// ─── EB BILLING API ──────────────────────────────────────────
app.get('/api/eb-connections', (req, res) => {
    db.all(`SELECT * FROM eb_connections ORDER BY created_at DESC`, [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true, data: rows });
    });
});

app.post('/api/eb-connections/add', (req, res) => {
    const { service_no, name, region } = req.body;
    db.run(`INSERT OR REPLACE INTO eb_connections (service_no, name, region) VALUES (?, ?, ?)`,
        [service_no, name, region], (err) => {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            res.json({ ok: true });
        });
});

app.put('/api/eb-connections/:id', (req, res) => {
    const { service_no, name, region } = req.body;
    db.run(`UPDATE eb_connections SET service_no=?, name=?, region=? WHERE id=?`,
        [service_no, name, region, req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        if (this.changes === 0) return res.status(404).json({ ok: false, msg: 'Connection not found' });
        res.json({ ok: true });
    });
});
app.post('/api/eb-connections/delete', (req, res) => {
    db.run(`DELETE FROM eb_connections WHERE id = ?`, [req.body.id], (err) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        res.json({ ok: true });
    });
});

app.post('/api/eb-bill/fetch', (req, res) => {
    const { serviceNo, region } = req.body;
    
    // Check if bot is ready
    if (!botProcess || !botProcess.send) {
        return res.json({ ok: false, msg: "Bot is offline. Cannot fetch live EB data." });
    }

    // Set up a one-time listener for the bot's response
    const requestId = Date.now();
    const responseHandler = (msg) => {
        if (msg.type === 'eb_bill_res' && msg.requestId === requestId) {
            botProcess.removeListener('message', responseHandler);
            res.json(msg.data);
        }
    };
    botProcess.on('message', responseHandler);

    // Send request to bot
    botProcess.send({ type: 'fetch_eb_bill', serviceNo, region, requestId });

    // Timeout after 30 seconds
    setTimeout(() => {
        botProcess.removeListener('message', responseHandler);
        if (!res.headersSent) res.json({ ok: false, msg: "TANGEDCO Server Timeout. Try again." });
    }, 30000);
});

app.get('/api/plots', (req, res) => {
    db.all(`SELECT * FROM plots ORDER BY layout_name, plot_no`, [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        
        // Enrich with Quotation Counts
        let quotes = [];
        try {
            const qPath = path.join(ROOT_DIR, 'quotations.json');
            if (fs.existsSync(qPath)) {
                quotes = JSON.parse(fs.readFileSync(qPath, 'utf8'));
            }
        } catch (e) {}

        const plotsWithQuotes = rows.map(p => {
            const qCount = quotes.filter(q => 
                (q.layout || '').trim().toLowerCase() === (p.layout_name || '').trim().toLowerCase() && 
                String(q.plot || '').trim().toLowerCase() === String(p.plot_no || '').trim().toLowerCase()
            ).length;
            return { ...p, quote_count: qCount };
        });

        res.json({ ok: true, plots: plotsWithQuotes });
    });
});

// Normalize free-text identifier fields so re-imports / re-keying don't create whitespace duplicates.
const _trim = (v) => (v == null ? v : String(v).trim().replace(/\s+/g, ' '));

// Sale history for a single plot — bundles customer + registration + documents + loans + payments + legal.
// Powers the "📑 Sale History" modal in Property Inventory.
app.get('/api/plots/:id/history', (req, res) => {
    const plotId = parseInt(req.params.id, 10);
    if (!plotId) return res.status(400).json({ ok: false, error: 'Invalid plot id' });

    db.get(`SELECT * FROM plots WHERE id = ?`, [plotId], (err, plot) => {
        if (err)   return res.status(500).json({ ok: false, error: err.message });
        if (!plot) return res.status(404).json({ ok: false, error: 'Plot not found' });

        const layout = (plot.layout_name || '').trim();
        const plotNo = (plot.plot_no || '').trim();
        const norm = v => (v || '').toString().trim().toLowerCase();

        // Helpers — wrap each query in a promise for parallel fan-out
        const q = (sql, args) => new Promise((resolve) => db.all(sql, args, (e, rows) => resolve(e ? [] : rows)));

        Promise.all([
            // Registration & Patta records (matched by layout + plot_no, case/whitespace tolerant)
            q(`SELECT * FROM customer_registrations
               WHERE LOWER(TRIM(layout_name)) = ? AND LOWER(TRIM(plot_no)) = ?
               ORDER BY id DESC`, [norm(layout), norm(plotNo)]),
            // Plot documents (joined by plot_id)
            q(`SELECT * FROM plot_documents WHERE plot_id = ? ORDER BY id DESC`, [plotId]),
            // Customer loans (matched by project + plot)
            q(`SELECT * FROM customer_loans
               WHERE LOWER(TRIM(COALESCE(project,''))) = ? AND LOWER(TRIM(COALESCE(plot,''))) = ?
               ORDER BY id DESC`, [norm(layout), norm(plotNo)]),
        ]).then(([registrations, documents, loans]) => {
            // The customer phone comes from the most-recent registration; fall back to a plot-name match in customers.
            const custPhone = registrations[0]?.customer_phone || null;

            const customerPromise = custPhone
                ? new Promise((resolve) => db.get(`SELECT * FROM customers WHERE phone = ?`, [custPhone], (e, r) => resolve(r || null)))
                : new Promise((resolve) => db.get(
                    `SELECT * FROM customers
                       WHERE LOWER(TRIM(COALESCE(plot,''))) = ?
                       ORDER BY last_interaction DESC LIMIT 1`,
                    [norm(plotNo)], (e, r) => resolve(r || null)));

            customerPromise.then(customer => {
                const phoneForPayments = customer?.phone || custPhone;
                const paymentsPromise = phoneForPayments
                    ? q(`SELECT * FROM payment_requests WHERE phone = ? ORDER BY created_at DESC`, [phoneForPayments])
                    : Promise.resolve([]);

                const legalDocIds = documents.map(d => d.id);
                const legalPromise = legalDocIds.length
                    ? q(`SELECT * FROM legal_approvals WHERE doc_id IN (${legalDocIds.map(() => '?').join(',')}) ORDER BY id DESC`, legalDocIds)
                    : Promise.resolve([]);

                Promise.all([paymentsPromise, legalPromise]).then(([payments, legal]) => {
                    res.json({
                        ok: true,
                        plot,
                        customer: customer || null,
                        registrations,
                        documents,
                        loans,
                        payments,
                        legal,
                    });
                });
            });
        });
    });
});

app.post('/api/plots/add', (req, res) => {
    const { layout_name, plot_no, type, size, size_cent, dimensions, facing, status, price, location, gps_location } = req.body;
    const cleanLayout = _trim(layout_name);
    const cleanPlot   = _trim(plot_no);
    db.run(`INSERT INTO plots (layout_name, plot_no, type, size, size_cent, dimensions, facing, status, price, location, gps_location) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [cleanLayout, cleanPlot, type || 'Plot', size, size_cent, dimensions, facing, status, price, location, gps_location || null], function(err) {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            
            createBackup('Add Plot');
            db.run(`INSERT INTO activity_logs (type, message) VALUES (?, ?)`, ['PLOT_ADD', `New ${type || 'plot'} ${plot_no} added to ${layout_name}`]);
            updatePlotsExcel();
            
            pushLog(`🏡 Inventory: New ${type || 'plot'} ${plot_no} added to ${layout_name}`);
            res.json({ ok: true, id: this.lastID });
        });
});

app.post('/api/plots/update', (req, res) => {
    const { id, layout_name, plot_no, type, size, size_cent, dimensions, facing, status, price, location, gps_location } = req.body;
    db.run(`UPDATE plots SET layout_name=?, plot_no=?, type=?, size=?, size_cent=?, dimensions=?, facing=?, status=?, price=?, location=?, gps_location=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`,
        [_trim(layout_name), _trim(plot_no), type || 'Plot', size, size_cent, dimensions, facing, status, price, location, gps_location || null, id], (err) => {
            if (err) return res.status(500).json({ ok: false, msg: err.message });
            
            createBackup('Update Plot');
            db.run(`INSERT INTO activity_logs (type, message) VALUES (?, ?)`, ['PLOT_UPDATE', `Plot ${plot_no} in ${layout_name} updated to ${status}`]);
            updatePlotsExcel();
            
            pushLog(`🏡 Inventory: Plot ${plot_no} in ${layout_name} updated to ${status}`);
            res.json({ ok: true });
        });
});

// ── Plot dedupe: identify rows where (TRIMMED layout_name, TRIMMED plot_no) collide ──
// Preview returns the duplicate groups so the admin can sanity-check before deleting.
app.get('/api/plots/dedupe-preview', (req, res) => {
    db.all(
        `SELECT TRIM(layout_name) AS layout, TRIM(plot_no) AS plot,
                GROUP_CONCAT(id) AS ids,
                COUNT(*) AS dup_count
         FROM plots
         GROUP BY LOWER(TRIM(layout_name)), LOWER(TRIM(plot_no))
         HAVING dup_count > 1
         ORDER BY layout, plot`,
        [], (err, rows) => {
            if (err) return res.status(500).json({ ok: false, error: err.message });
            res.json({ ok: true, groups: rows, total_extra_rows: rows.reduce((s, r) => s + (r.dup_count - 1), 0) });
        }
    );
});

// Apply: for each duplicate group, keep ONE row (the one whose plot_no needs the LEAST trimming,
// or the highest id as a tie-breaker — that's typically the cleaner re-import). Backs up first.
app.post('/api/plots/dedupe-apply', (req, res) => {
    db.all(
        `SELECT id, layout_name, plot_no FROM plots
         WHERE rowid IN (
           SELECT MIN(rowid) FROM plots
           GROUP BY LOWER(TRIM(layout_name)), LOWER(TRIM(plot_no))
           HAVING COUNT(*) > 1
         )
         OR EXISTS (
           SELECT 1 FROM plots p2
           WHERE LOWER(TRIM(p2.layout_name)) = LOWER(TRIM(plots.layout_name))
             AND LOWER(TRIM(p2.plot_no))     = LOWER(TRIM(plots.plot_no))
             AND p2.id != plots.id
         )`,
        [], (err, rows) => {
            if (err) return res.status(500).json({ ok: false, error: err.message });
            try { createBackup('Plot Dedupe'); } catch (e) { console.warn('Dedupe backup failed:', e.message); }

            // Group by trimmed key, pick the keeper (cleanest plot_no, then highest id)
            const groups = {};
            for (const r of rows) {
                const key = (r.layout_name || '').trim().toLowerCase() + '|' + (r.plot_no || '').trim().toLowerCase();
                (groups[key] = groups[key] || []).push(r);
            }
            const idsToDelete = [];
            const keepers = [];
            for (const key in groups) {
                const grp = groups[key];
                // Score = how "dirty" the plot_no is (length - trimmed length, then prefer highest id)
                grp.sort((a, b) => {
                    const dirtyA = (a.plot_no || '').length - (a.plot_no || '').trim().length;
                    const dirtyB = (b.plot_no || '').length - (b.plot_no || '').trim().length;
                    if (dirtyA !== dirtyB) return dirtyA - dirtyB;       // less dirty first
                    return b.id - a.id;                                    // then highest id
                });
                keepers.push(grp[0]);
                for (let i = 1; i < grp.length; i++) idsToDelete.push(grp[i].id);
            }

            if (!idsToDelete.length) {
                return res.json({ ok: true, deleted: 0, kept: keepers.length, msg: 'No duplicates found.' });
            }

            // Delete in one statement
            const placeholders = idsToDelete.map(() => '?').join(',');
            db.run(`DELETE FROM plots WHERE id IN (${placeholders})`, idsToDelete, function(delErr) {
                if (delErr) return res.status(500).json({ ok: false, error: delErr.message });

                // Also trim ALL remaining plot_no values, so the spaceful rows that weren't part of
                // a dup pair still get cleaned. Safe — only modifies leading/trailing whitespace.
                db.run(`UPDATE plots SET plot_no = TRIM(plot_no), layout_name = TRIM(layout_name) WHERE plot_no != TRIM(plot_no) OR layout_name != TRIM(layout_name)`, [], (trimErr) => {
                    if (trimErr) console.warn('Whitespace normalization warning:', trimErr.message);
                });

                db.run(`INSERT INTO activity_logs (type, message) VALUES (?, ?)`,
                       ['PLOT_DEDUPE', `Removed ${idsToDelete.length} duplicate plot row(s); kept ${keepers.length}`]);
                try { updatePlotsExcel(); } catch (e) {}
                pushLog(`🧹 Plots dedupe: removed ${idsToDelete.length} duplicate row(s) (backup saved).`);
                res.json({ ok: true, deleted: idsToDelete.length, kept: keepers.length });
            });
        }
    );
});

app.post('/api/plots/delete', (req, res) => {
    const { id } = req.body;
    db.run(`DELETE FROM plots WHERE id=?`, [id], (err) => {
        if (err) return res.status(500).json({ ok: false, msg: err.message });

        createBackup('Delete Plot');
        db.run(`INSERT INTO activity_logs (type, message) VALUES (?, ?)`, ['PLOT_DELETE', `Plot ID ${id} removed`]);
        updatePlotsExcel();

        pushLog(`🏡 Inventory: Plot ID ${id} removed from database`);
        res.json({ ok: true });
    });
});

app.get('/api/check-update', (req, res) => {
    try {
        const localVersion = fs.existsSync(VERSION_PATH) ? JSON.parse(fs.readFileSync(VERSION_PATH, 'utf8')) : { version: "2.3.0" };
        // In a real cloud scenario, you'd fetch from a URL. For now, we simulate a check.
        res.json({ 
            ok: true, 
            current: localVersion.version,
            msg: "Your system is up to date. Latest available: " + localVersion.version 
        });
    } catch (e) {
        res.status(500).json({ ok: false, msg: "Failed to check for updates." });
    }
});

app.post('/api/update-software', uploadAsset.single('updateFile'), async (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, msg: "No update file provided." });
    
    pushLog("📦 SYSTEM UPDATE: Patch received. Initializing upgrade...");
    
    try {
        const patchPath = req.file.path;
        const zip = new AdmZip(patchPath);
        
        // 1. Create a full backup of the current directory (excluding node_modules and hidden folders)
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupDir = path.join(ROOT_DIR, 'backups', `system-patch-${timestamp}`);
        if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
        
        const filesToBackup = ['server.js', 'bot.js', 'dashboard.html', 'database.js', 'shared-components.js', 'electron_main.js', 'package.json'];
        filesToBackup.forEach(f => {
            const src = path.join(ROOT_DIR, f);
            if (fs.existsSync(src)) fs.copyFileSync(src, path.join(backupDir, f));
        });
        
        pushLog(`🛡️ Backup created at: ${backupDir}`);

        // 2. Extract the patch
        // NOTE: AdmZip will overwrite existing files.
        zip.extractAllTo(ROOT_DIR, true);
        
        pushLog("✅ Patch extracted successfully. Cleaning up...");
        fs.unlinkSync(patchPath); // Delete the uploaded zip
        
        res.json({ ok: true, msg: "Update applied. Restarting system..." });
        
        // 3. Reboot the server
        setTimeout(() => {
            pushLog("🔄 Restarting server to apply changes...");
            process.exit(0);
        }, 2000);

    } catch (e) {
        console.error("Update Error:", e);
        res.status(500).json({ ok: false, msg: "Patch failed: " + e.message });
    }
});

app.get('/api/backups/list', (req, res) => {
    const backupRoot = path.join(ROOT_DIR, 'backups');
    if (!fs.existsSync(backupRoot)) return res.json({ ok: true, backups: [] });
    const folders = fs.readdirSync(backupRoot).filter(f => fs.statSync(path.join(backupRoot, f)).isDirectory());
    const backups = folders.map(f => {
        const infoPath = path.join(backupRoot, f, 'backup_info.txt');
        let reason = 'Auto-Backup';
        if (fs.existsSync(infoPath)) {
            const content = fs.readFileSync(infoPath, 'utf8');
            const match = content.match(/Reason: (.*)/);
            if (match) reason = match[1];
        }
        return { name: f, reason };
    });
    res.json({ ok: true, backups });
});

app.post('/api/backups/restore', (req, res) => {
    const { folder } = req.body;
    if (!folder || typeof folder !== 'string') return res.status(400).json({ ok: false, msg: 'Invalid folder name' });
    // Prevent path traversal — folder name must be a simple alphanumeric timestamp
    if (!/^[\w\-.:]+$/.test(folder)) return res.status(400).json({ ok: false, msg: 'Invalid folder name' });
    const backupRoot = path.resolve(ROOT_DIR, 'backups');
    const backupDir  = path.resolve(backupRoot, folder);
    if (!backupDir.startsWith(backupRoot + path.sep)) return res.status(400).json({ ok: false, msg: 'Invalid folder path' });
    if (!fs.existsSync(backupDir)) return res.status(404).json({ ok: false, msg: 'Backup not found' });

    try {
        const sqliteBkp = path.join(backupDir, 'database.sqlite');
        const plotsBkp = path.join(backupDir, 'Plots_Data.xlsx');

        if (fs.existsSync(sqliteBkp)) fs.copyFileSync(sqliteBkp, path.join(ROOT_DIR, 'database.sqlite'));
        if (fs.existsSync(plotsBkp)) fs.copyFileSync(plotsBkp, path.join(ROOT_DIR, 'Plots_Data.xlsx'));

        pushLog(`🚨 SYSTEM RESTORE: Reverted to backup ${folder}`);
        res.json({ ok: true });
    } catch (e) { res.status(500).json({ ok: false, msg: e.message }); }
});

function createBackup(reason) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(ROOT_DIR, 'backups', timestamp);
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

    try {
        // Backup SQLite
        const sqlitePath = path.join(ROOT_DIR, 'database.sqlite');
        if (fs.existsSync(sqlitePath)) fs.copyFileSync(sqlitePath, path.join(backupDir, 'database.sqlite'));

        // Backup Plots Excel
        const plotsPath = path.join(ROOT_DIR, 'Plots_Data.xlsx');
        if (fs.existsSync(plotsPath)) fs.copyFileSync(plotsPath, path.join(backupDir, 'Plots_Data.xlsx'));

        fs.writeFileSync(path.join(backupDir, 'backup_info.txt'), `Reason: ${reason}\nTime: ${new Date().toLocaleString()}`);
        
        // Rolling Cleanup: Keep last 20 backups
        const allBackups = fs.readdirSync(path.join(ROOT_DIR, 'backups')).sort();
        if (allBackups.length > 20) {
            const toDelete = allBackups.slice(0, allBackups.length - 20);
            toDelete.forEach(folder => {
                fs.rmSync(path.join(ROOT_DIR, 'backups', folder), { recursive: true, force: true });
            });
        }
    } catch (e) { console.error('Backup failed:', e); }
}

// ─── MEDIA MANAGER HELPER ─────────────────────────────
const LAYOUT_IMAGES_DIR = path.join(ROOT_DIR, 'Layout_Images');

const sanitizeFolderName = (name) => name.replace(/[^a-z0-9_\-\s]/gi, '').trim().replace(/\s+/g, '_');

function findLayoutFolder(layoutName) {
    if (!layoutName) return null;
    const sanitized = sanitizeFolderName(layoutName);
    
    // Normalization helper: remove noise and handle phonetic 'h'
    const normalize = (s) => (s || '').toString().toLowerCase()
        .replace(/\s+/g, '') // Ignore all spaces
        .replace(/drd/g, '') // Ignore corporate prefix
        .replace(/garden(s)?/g, '')
        .replace(/enclave/g, '')
        .replace(/layout/g, '')
        .replace(/[^a-z0-9]/g, '')
        .replace(/([ktdps])h/g, '$1') // kh->k, th->t, etc.
        .replace(/t/g, 'd') // Neutralize T vs D (common phonetic swap)
        .replace(/p/g, 'b') // Neutralize P vs B
        .trim();


    const cleanLayout = normalize(layoutName);
    
    // 1. Check new structure (assets/layouts)
    const newPath = path.join(ASSETS_DIR, 'layouts', sanitized);
    if (fs.existsSync(newPath)) return { path: newPath, urlPrefix: `/assets/layouts/${sanitized}` };
    
    // 2. Check legacy structure (Layout_Images in ROOT_DIR and INTERNAL_DIR)
    for (const baseDir of [LAYOUT_IMAGES_DIR, INTERNAL_LAYOUT_IMAGES_DIR]) {
        if (baseDir && fs.existsSync(baseDir)) {
            const folders = fs.readdirSync(baseDir);
            const match = folders.find(f => normalize(f) === cleanLayout);
            if (match) {
                return { path: path.join(baseDir, match), urlPrefix: `/layout_media/${encodeURIComponent(match)}` };
            }
        }
    }

    return { path: newPath, urlPrefix: `/assets/layouts/${sanitized}` };
}

app.use('/layout_media', express.static(LAYOUT_IMAGES_DIR));
// Fallback: also serve layout images from the app install directory (Program Files)
// so images copied there before AppData migration are still visible.
const INTERNAL_LAYOUT_IMAGES_DIR = path.join(INTERNAL_DIR, 'Layout_Images');
if (INTERNAL_LAYOUT_IMAGES_DIR !== LAYOUT_IMAGES_DIR && fs.existsSync(INTERNAL_LAYOUT_IMAGES_DIR)) {
    app.use('/layout_media', express.static(INTERNAL_LAYOUT_IMAGES_DIR));
}

app.get('/api/layout/assets', (req, res) => {
    const { layout } = req.query;
    if (!layout) return res.status(400).json({ ok: false, msg: 'Layout required' });
    
    const folderInfo = findLayoutFolder(layout);
    if (!folderInfo || !fs.existsSync(folderInfo.path)) {
        return res.json({ ok: true, assets: [] });
    }
    
    try {
        const files = fs.readdirSync(folderInfo.path).map(name => {
            const stats = fs.statSync(path.join(folderInfo.path, name));
            if (stats.isDirectory()) return null;
            return { 
                name, 
                size: stats.size, 
                time: stats.mtime, 
                url: `${folderInfo.urlPrefix}/${name}`,
                type: path.extname(name).toLowerCase()
            };
        }).filter(Boolean);
        res.json({ ok: true, assets: files });
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/layout/assets/upload', uploadAsset.array('files'), (req, res) => {
    const layout = req.body.layout;
    if (!layout) return res.status(400).json({ ok: false, msg: 'Layout required' });
    
    const folderInfo = findLayoutFolder(layout);
    const layoutDir = folderInfo.path;
    if (!fs.existsSync(layoutDir)) fs.mkdirSync(layoutDir, { recursive: true });
    
    const movedFiles = [];
    req.files.forEach(file => {
        const targetPath = path.join(layoutDir, file.filename);
        fs.renameSync(file.path, targetPath);
        movedFiles.push({ name: file.filename, url: `${folderInfo.urlPrefix}/${file.filename}` });
    });
    
    res.json({ ok: true, files: movedFiles });
});

app.post('/api/layout/assets/delete', (req, res) => {
    const { layout, filename } = req.body;
    if (!layout || !filename) return res.status(400).json({ ok: false, msg: 'Layout and filename required' });
    
    const filePath = path.join(ASSETS_DIR, 'layouts', sanitizeFolderName(layout), filename);
    try {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            res.json({ ok: true });
        } else {
            res.status(404).json({ ok: false, msg: 'File not found' });
        }
    } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.get('/api/assets/list', (req, res) => {
    try {
        const files = fs.readdirSync(ASSETS_DIR).filter(n => fs.statSync(path.join(ASSETS_DIR, n)).isFile()).map(name => {
            const stats = fs.statSync(path.join(ASSETS_DIR, name));
            return { name, size: stats.size, time: stats.mtime, isImage: /\.(jpg|jpeg|png|gif)$/i.test(name), isPdf: /\.pdf$/i.test(name) };
        });
        res.json({ ok: true, assets: files });
    } catch (e) { res.status(500).json({ ok: false }); }
});

// ─── DIAGNOSTICS & TESTING ────────────────────────────────
// All diagnostics leak counts, file paths, SMTP creds, and customer phones
// via logs — restricted to admin/super_admin to prevent data leaks.
app.get('/api/diagnostics/full', requireAdmin, async (req, res) => {
    const results = {
        timestamp: new Date().toISOString(),
        system: {
            uptime: Math.floor((Date.now() - startTime) / 1000),
            platform: process.platform,
            nodeVersion: process.version
        },
        database: { status: 'checking', leads: 0, plots: 0 },
        files: { status: 'checking', missing: [] },
        bot: { status: botStatus, connected: !!connectedNumber },
        ai: { status: 'checking', model: currentAiModel }
    };

    try {
        // 1. Check DB
        const counts = await new Promise((resolve) => {
            db.get('SELECT (SELECT COUNT(*) FROM customers) as c, (SELECT COUNT(*) FROM plots) as p', (err, row) => {
                resolve(row || { c: 0, p: 0 });
            });
        });
        results.database.status = 'healthy';
        results.database.leads = counts.c;
        results.database.plots = counts.p;

        // 2. Check Files
        const criticalFiles = ['bot_settings.json', 'keyword_rules.json', 'Plots_Data.xlsx', 'database.sqlite', '.env'];
        criticalFiles.forEach(f => {
            if (!fs.existsSync(path.join(ROOT_DIR, f))) results.files.missing.push(f);
        });
        results.files.status = results.files.missing.length === 0 ? 'healthy' : 'degraded';

        // 3. Check AI (Dry run)
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' }); // Use a fast check
        results.ai.status = 'API Key Configured';

        res.json({ ok: true, results });
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.post('/api/test/simulate-lead', requireAdmin, (req, res) => {
    const { phone, name, layout } = req.body;
    if (!phone) return res.status(400).json({ ok: false, msg: "Phone required" });

    const testLead = {
        phone: phone || `9199999${Math.floor(100000 + Math.random() * 900000)}`,
        name: name || "Test Customer",
        plot: "Test-01",
        location: "Diagnostic Test",
        price: 0,
        status: "Test Lead"
    };

    db.run(`INSERT OR IGNORE INTO customers (phone, name, plot, location, price, status) VALUES (?, ?, ?, ?, ?, ?)`,
        [testLead.phone, testLead.name, testLead.plot, testLead.location, testLead.price, testLead.status],
        function(err) {
            if (err) return res.status(500).json({ ok: false, error: err.message });
            pushLog(`🧪 Simulated Lead Injected: ${testLead.name} (${testLead.phone})`);
            res.json({ ok: true, lead: testLead });
        }
    );
});

app.post('/api/test/cleanup', requireAdmin, (req, res) => {
    db.run(`DELETE FROM customers WHERE status = 'Test Lead'`, function(err) {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        pushLog(`🧹 Cleanup: Removed ${this.changes} test records.`);
        res.json({ ok: true, removed: this.changes });
    });
});

// Module-level self-test — probes every subsystem and returns per-module status.
// Exposes SMTP host, AI model, file presence — admin-only.
app.get('/api/diagnostics/selftest', requireAdmin, async (req, res) => {
    const modules = [];
    const push = (name, status, detail) => modules.push({ name, status, detail });
    const getOne = (sql) => new Promise((resolve, reject) => db.get(sql, (e, r) => e ? reject(e) : resolve(r)));

    // Database connectivity
    try {
        const r = await getOne("SELECT COUNT(*) AS c FROM sqlite_master WHERE type='table'");
        push('Database (SQLite)', 'pass', `${r.c} tables present`);
    } catch (e) { push('Database (SQLite)', 'fail', e.message); }

    // WAL mode
    try {
        const r = await getOne("PRAGMA journal_mode");
        const mode = String(r.journal_mode || '').toUpperCase();
        if (mode === 'WAL') push('SQLite WAL mode', 'pass', 'Concurrent reads enabled');
        else push('SQLite WAL mode', 'warn', `journal_mode = ${mode}`);
    } catch (e) { push('SQLite WAL mode', 'warn', e.message); }

    // SQLite table health
    await new Promise(resolve => {
        db.get(`SELECT COUNT(*) AS c FROM plots`, [], (err, r) => {
            push('DB: plots', err ? 'fail' : 'pass', err ? err.message.slice(0,60) : `${(r||{}).c||0} records`);
            resolve();
        });
    });
    await new Promise(resolve => {
        db.get(`SELECT COUNT(*) AS c FROM customers`, [], (err, r) => {
            push('DB: customers', err ? 'fail' : 'pass', err ? err.message.slice(0,60) : `${(r||{}).c||0} records`);
            resolve();
        });
    });
    await new Promise(resolve => {
        db.get(`SELECT COUNT(*) AS c FROM staff`, [], (err, r) => {
            push('DB: staff', err ? 'fail' : 'pass', err ? err.message.slice(0,60) : `${(r||{}).c||0} records`);
            resolve();
        });
    });

    // Bot IPC round-trip
    if (botProcess && botProcess.send) {
        const pong = await new Promise((resolve) => {
            const reqId = 'st_' + Date.now();
            const handler = (msg) => {
                if (msg && msg.type === 'selftest_pong' && msg.requestId === reqId) {
                    botProcess.removeListener('message', handler);
                    resolve(msg.data || { ok: true });
                }
            };
            botProcess.on('message', handler);
            try { botProcess.send({ type: 'selftest_ping', requestId: reqId }); } catch (_) {}
            setTimeout(() => { botProcess.removeListener('message', handler); resolve(null); }, 2500);
        });
        if (pong) push('Bot IPC', 'pass', `Round-trip OK; bot uptime ${pong.uptime || 0}s`);
        else push('Bot IPC', 'fail', 'No response within 2.5s');
    } else push('Bot IPC', 'fail', 'Bot child process not spawned');

    // WhatsApp session
    if (botStatus === 'connected') push('WhatsApp session', 'pass', `Linked as ${connectedNumber || 'unknown'}`);
    else if (botStatus === 'qr') push('WhatsApp session', 'warn', 'Awaiting QR scan');
    else push('WhatsApp session', 'fail', `botStatus = ${botStatus}`);

    // Gemini AI live call
    if (!process.env.GEMINI_API_KEY) {
        push('Gemini AI', 'fail', 'GEMINI_API_KEY not set in .env');
    } else {
        try {
            const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
            const modelName = (currentAiModel && currentAiModel.toLowerCase().includes('gemini')) ? 'gemini-2.5-flash' : 'gemini-2.0-flash';
            const m = genAI.getGenerativeModel({ model: modelName });
            const r = await Promise.race([
                m.generateContent("Reply with just the word: OK"),
                new Promise((_, rej) => setTimeout(() => rej(new Error('5s timeout')), 5000))
            ]);
            const txt = (r.response.text() || '').trim().slice(0, 40);
            push('Gemini AI', 'pass', `Model ${modelName} → "${txt}"`);
        } catch (e) { push('Gemini AI', 'fail', e.message.slice(0, 100)); }
    }

    // Email SMTP + IMAP
    const emailCfgPath = path.join(ROOT_DIR, 'email_config.json');
    let emailCfg = null;
    if (fs.existsSync(emailCfgPath)) {
        try { emailCfg = JSON.parse(fs.readFileSync(emailCfgPath, 'utf8')); } catch (_) {}
    }
    if (emailCfg && emailCfg.host && emailCfg.user && emailCfg.pass) {
        try {
            const nodemailer = require('nodemailer');
            const tx = nodemailer.createTransport({
                host: emailCfg.host,
                port: parseInt(emailCfg.port) || 587,
                secure: parseInt(emailCfg.port) === 465,
                auth: { user: emailCfg.user, pass: emailCfg.pass },
                connectionTimeout: 5000
            });
            await Promise.race([
                tx.verify(),
                new Promise((_, rej) => setTimeout(() => rej(new Error('5s timeout')), 5000))
            ]);
            push('Email SMTP', 'pass', `${emailCfg.host}:${emailCfg.port || 587} reachable`);
        } catch (e) { push('Email SMTP', 'fail', e.message.slice(0, 100)); }

        if (emailCfg.imap_host) {
            try {
                const { ImapFlow } = require('imapflow');
                const imap = new ImapFlow({
                    host: emailCfg.imap_host,
                    port: parseInt(emailCfg.imap_port) || 993,
                    secure: true,
                    auth: { user: emailCfg.user, pass: emailCfg.pass },
                    logger: false
                });
                await Promise.race([
                    (async () => { await imap.connect(); await imap.logout(); })(),
                    new Promise((_, rej) => setTimeout(() => rej(new Error('5s timeout')), 5000))
                ]);
                push('Email IMAP', 'pass', `${emailCfg.imap_host} reachable`);
            } catch (e) { push('Email IMAP', 'fail', e.message.slice(0, 100)); }
        } else push('Email IMAP', 'warn', 'IMAP host not configured');
    } else {
        push('Email SMTP', 'warn', 'email_config.json missing or incomplete');
        push('Email IMAP', 'warn', 'email_config.json missing or incomplete');
    }

    // Per-module data integrity (each route's backing table)
    const tableChecks = [
        ['Module: CRM',           'SELECT COUNT(*) AS c FROM customers',            (r) => `${r.c} customers`],
        ['Module: Inventory',     'SELECT COUNT(*) AS c FROM plots',                (r) => `${r.c} plots`],
        ['Module: Finance',       'SELECT (SELECT COUNT(*) FROM salaries) AS s, (SELECT COUNT(*) FROM expenses) AS e', (r) => `${r.s} salaries, ${r.e} expenses`],
        ['Module: Marketing',     'SELECT COUNT(*) AS c FROM marketing_campaigns',  (r) => `${r.c} campaigns`],
        ['Module: Notifications', 'SELECT COUNT(*) AS c FROM scheduled_messages',   (r) => `${r.c} scheduled messages`],
        ['Module: Payments',      'SELECT COUNT(*) AS c FROM payment_requests',     (r) => `${r.c} payment requests`],
        ['Module: Staff/Auth',    "SELECT COUNT(*) AS c FROM staff WHERE password_hash IS NOT NULL", (r) => `${r.c} accounts with passwords`],
        ['Module: Site Visits',   'SELECT COUNT(*) AS c FROM site_visits',          (r) => `${r.c} visits`],
        ['Module: Followups',     'SELECT COUNT(*) AS c FROM followups',            (r) => `${r.c} followups`]
    ];
    for (const [name, sql, fmt] of tableChecks) {
        try { const r = await getOne(sql); push(name, 'pass', fmt(r)); }
        catch (e) { push(name, 'fail', e.message.slice(0, 100)); }
    }

    // Session store writable
    try {
        const sp = path.join(ROOT_DIR, 'sessions.json');
        const probe = sp + '.probe';
        fs.writeFileSync(probe, 'ok');
        fs.unlinkSync(probe);
        const size = fs.existsSync(sp) ? fs.statSync(sp).size : 0;
        push('Session store', 'pass', `Writable; current size ${size} bytes`);
    } catch (e) { push('Session store', 'fail', e.message); }

    // Critical config files
    for (const f of ['bot_settings.json', 'keyword_rules.json', '.env']) {
        if (fs.existsSync(path.join(ROOT_DIR, f))) push(`Config: ${f}`, 'pass', 'Present');
        else push(`Config: ${f}`, 'warn', 'Missing');
    }

    // Disk space
    try {
        let freeMB = null;
        if (process.platform === 'win32') {
            const drive = (ROOT_DIR.match(/^[A-Za-z]:/) || ['C:'])[0];
            const out = execSync(`wmic logicaldisk where "DeviceID='${drive}'" get FreeSpace /value`, { timeout: 3000 }).toString();
            const m = out.match(/FreeSpace=(\d+)/);
            if (m) freeMB = Math.round(parseInt(m[1]) / 1024 / 1024);
        } else {
            const out = execSync(`df -k "${ROOT_DIR}" | tail -1`, { timeout: 3000 }).toString();
            const cols = out.trim().split(/\s+/);
            if (cols[3]) freeMB = Math.round(parseInt(cols[3]) / 1024);
        }
        if (freeMB === null) push('Disk space', 'warn', 'Could not parse output');
        else if (freeMB < 200) push('Disk space', 'fail', `Only ${freeMB} MB free`);
        else if (freeMB < 1000) push('Disk space', 'warn', `${freeMB} MB free (low)`);
        else push('Disk space', 'pass', `${freeMB} MB free`);
    } catch (e) { push('Disk space', 'warn', e.message.slice(0, 80)); }

    const summary = {
        pass: modules.filter(m => m.status === 'pass').length,
        warn: modules.filter(m => m.status === 'warn').length,
        fail: modules.filter(m => m.status === 'fail').length,
        total: modules.length
    };
    res.json({ ok: true, modules, summary, timestamp: new Date().toISOString() });
});

app.post('/api/plots/import-pdf', uploadAsset.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });

    try {
        // LAZY LOAD: Prevent startup crashes in packaged apps
        let pdf;
        try {
            pdf = require('pdf-parse');
        } catch (err) {
            console.error("CRITICAL: PDF-PARSE module failed to load in this environment:", err.message);
            return res.status(500).json({ ok: false, msg: "PDF Import is not supported in this standalone version. Please use the Excel import instead." });
        }

        const dataBuffer = fs.readFileSync(req.file.path);
        const pdfData = await pdf(dataBuffer);
        const text = pdfData.text;
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        const prompt = `Extract property plot data from this text. 
        Return ONLY a JSON array of objects with keys: layout_name, plot_no, size, facing, status, price, location.
        If a field is missing, use empty string. 
        Context Text: ${text}`;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        let extracted = response.text().replace(/```json|```/g, '').trim();
        let plots = JSON.parse(extracted);

        // Duplicate Check
        const existingPlots = await new Promise((resolve) => {
            db.all(`SELECT layout_name, plot_no FROM plots`, [], (err, rows) => resolve(rows || []));
        });

        plots = plots.map(p => {
            const isDuplicate = existingPlots.some(ex => 
                ex.layout_name.toLowerCase() === p.layout_name.toLowerCase() && 
                String(ex.plot_no) === String(p.plot_no)
            );
            return { ...p, isDuplicate };
        });

        res.json({ ok: true, plots });
    } catch (e) {
        console.error('PDF Import Error:', e);
        res.status(500).json({ ok: false, msg: 'Failed to extract data: ' + e.message });
    }
});

app.post('/api/share/plot', (req, res) => {
    const { target, text, mediaFiles } = req.body;
    
    // Resolve URLs/Filenames to actual local paths
    const mediaPaths = (mediaFiles || []).map(f => {
        if (f.startsWith('/layout_media/')) {
            const relative = decodeURIComponent(f.replace('/layout_media/', ''));
            return path.join(LAYOUT_IMAGES_DIR, relative);
        } else if (f.startsWith('/assets/layouts/')) {
            const relative = decodeURIComponent(f.replace('/assets/layouts/', ''));
            return path.join(ASSETS_DIR, 'layouts', relative);
        } else if (f.startsWith('/assets/')) {
            const relative = decodeURIComponent(f.replace('/assets/', ''));
            return path.join(ASSETS_DIR, relative);
        }
        // Fallback for simple filenames
        return path.join(ASSETS_DIR, f);
    }).filter(p => fs.existsSync(p));
    
    if (botProcess && botProcess.send) {
        if (botStatus !== 'connected') {
            return res.status(500).json({ ok: false, msg: 'WhatsApp Bot is not connected. Please check the Terminal.' });
        }
        botProcess.send({ type: 'send_plot_share', data: { target, text, mediaPaths } });
        pushLog(`📲 Shared property details to ${target}`);
        res.json({ ok: true });
    } else {
        res.status(500).json({ ok: false, msg: 'Bot not running' });
    }

});

function updatePlotsExcel() {
    db.all(`SELECT layout_name as Layout, plot_no as 'Plot No', type as Type, size as Size, size_cent as 'Size Cent', dimensions as Dimensions, facing as Facing, status as Status, price as Price, location as Location, gps_location as 'GPS Location' FROM plots`, [], (err, rows) => {
        if (err) return;
        const p = path.join(ROOT_DIR, 'Plots_Data.xlsx');
        const wb = xlsx.utils.book_new();
        const ws = xlsx.utils.json_to_sheet(rows);
        xlsx.utils.book_append_sheet(wb, ws, 'Plots');
        xlsx.writeFile(wb, p);
    });
}


app.post('/api/training/export', (req, res) => {
    try {
        const trainingFiles = fs.readdirSync(TRAINING_DATA_DIR).filter(f => f.endsWith('.txt'));
        let combinedData = "";
        
        trainingFiles.forEach(file => {
            const content = fs.readFileSync(path.join(TRAINING_DATA_DIR, file), 'utf8');
            combinedData += `\n--- CONVERSATION: ${file} ---\n${content}\n`;
        });
        
        const exportPath = path.join(ROOT_DIR, 'Local_AI_Training_Data.txt');
        fs.writeFileSync(exportPath, combinedData);
        
        res.json({ ok: true, msg: `Exported ${trainingFiles.length} conversations to ${exportPath}`, path: exportPath });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/training/guide', (req, res) => {
    try {
        const guide = fs.readFileSync(path.join(ROOT_DIR, 'TRAINING_GUIDE.txt'), 'utf8');
        res.send(guide);
    } catch (e) { res.status(404).send("Guide not found."); }
});

// ─── Self-Learning AI Core ─────────────────────────────
let learningLogs = [];

async function runAutoLearning() {
    try {
        const configPath = path.join(ROOT_DIR, 'bot_settings.json');
        if (!fs.existsSync(configPath)) return;
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        if (!config.auto_learn) return;

        console.log("🧠 [LEARNING] Running Auto-Discovery check...");

        // Load recent inquiry notes from SQLite
        const data = await new Promise(resolve => {
            db.all(`SELECT lead_notes AS Query FROM customers WHERE lead_notes IS NOT NULL ORDER BY created_at DESC LIMIT 50`, [], (err, rows) => resolve(err ? [] : (rows || [])));
        });

        if (data.length < 5) return; // Need a baseline

        // Send to AI for pattern discovery
        const recent = data.map(i => i.Query).join('\n');
        if (!recent.trim()) return;

        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        const prompt = `You are a Self-Learning AI for DRD Realtors. 
        Analyze these recent customer questions from WhatsApp. 
        If you see a question asked multiple times (pattern), create a high-quality "Trigger Keyword" and a "Professional Reply".
        
        RULES:
        1. Only return patterns found at least 2-3 times.
        2. Keep keywords simple (e.g., 'water', 'loan', 'location').
        3. Reply must be professional and based on typical real estate needs.
        
        Format your response ONLY as a JSON array: [{"keyword": "...", "reply": "..."}]
        
        Questions:\n${recent}`;

        const result = await model.generateContent(prompt);
        const text = result.response.text();
        const jsonMatch = text.match(/\[.*\]/s);
        
        if (jsonMatch) {
            const learned = JSON.parse(jsonMatch[0]);
            const rulesPath = path.join(ROOT_DIR, 'keyword_rules.json');
            let existingRules = [];
            if (fs.existsSync(rulesPath)) {
                try { existingRules = JSON.parse(fs.readFileSync(rulesPath, 'utf8')); } catch(e) {}
            }

            learned.forEach(rule => {
                const exists = existingRules.find(r => r.keyword.toLowerCase() === rule.keyword.toLowerCase());
                if (!exists) {
                    existingRules.push(rule);
                    learningLogs.push(rule);
                    pushLog(`🧠 AI Learned new rule: ${rule.keyword}`);
                    
                    // Trigger Admin Notification via IPC to Bot
                    if (botProcess && botProcess.connected) {
                        botProcess.send({ type: 'notify_learning', data: rule });
                    }
                }
            });
            fs.writeFileSync(rulesPath, JSON.stringify(existingRules, null, 2));
        }

    } catch (e) { console.error("Error in auto-learning:", e); }
}

app.get('/api/learning-logs', (req, res) => {
    res.json({ logs: learningLogs });
    learningLogs = []; 
});

// Run learning every 6 hours
setInterval(runAutoLearning, 6 * 3600000);

// ─── AUTOMATED MAINTENANCE ──────────────────────────────
// Restart the bot periodically to prevent memory leaks. Interval comes from
// bot_settings.json → bot_restart_minutes (default 60). Set to 0 to disable.
function _readBotRestartMinutes() {
    try {
        const p = path.join(ROOT_DIR, 'bot_settings.json');
        if (fs.existsSync(p)) {
            const s = JSON.parse(fs.readFileSync(p, 'utf8'));
            const v = parseInt(s.bot_restart_minutes);
            if (!Number.isNaN(v)) return v;
        }
    } catch (e) {}
    return 60;
}
let _botRestartTimer = null;
function _scheduleBotRestart() {
    if (_botRestartTimer) clearInterval(_botRestartTimer);
    const minutes = _readBotRestartMinutes();
    if (minutes <= 0) {
        pushLog("🕒 SYSTEM: Automatic bot restart DISABLED (bot_restart_minutes = 0).");
        return;
    }
    pushLog(`🕒 SYSTEM: Automatic bot restart scheduled every ${minutes} minute(s).`);
    _botRestartTimer = setInterval(() => {
        pushLog(`🕒 SYSTEM: Initiating scheduled ${minutes}-minute bot refresh...`);
        killBot();
        setTimeout(() => {
            if (lastBotId) {
                pushLog("🔄 SYSTEM: Re-launching bot service...");
                startBotProcess(lastBotId);
            }
        }, 10000); // 10s grace period for cleanup
    }, minutes * 60 * 1000);
}
_scheduleBotRestart();

// Auto-release expired claims + send 5-min expiry warning (runs every minute)
setInterval(() => {
    db.all(
        `SELECT id, customer_phone, staff_id, staff_name, auto_release_minutes,
                ROUND((julianday('now') - julianday(last_activity_at)) * 1440, 1) AS elapsed_min
           FROM conversation_claims WHERE status = 'Active'`,
        [],
        (err, rows) => {
            if (err || !rows || rows.length === 0) return;
            rows.forEach(c => {
                const elapsed = parseFloat(c.elapsed_min) || 0;
                const limit   = parseFloat(c.auto_release_minutes) || 30;
                if (elapsed > limit) {
                    db.run(`UPDATE conversation_claims SET status = 'Auto-released', released_at = CURRENT_TIMESTAMP WHERE id = ?`, [c.id]);
                    _claimExpiryWarned.delete(c.id);
                    _claimNotifLastSent.delete(c.customer_phone);
                    pushLog(`⏱️ AUTO-RELEASE: claim on ${c.customer_phone} by ${c.staff_name || c.staff_id} expired`);
                    pushClaimSSE('update', { action: 'auto_released', phone: c.customer_phone });
                } else if (elapsed >= limit - 5 && !_claimExpiryWarned.has(c.id)) {
                    _claimExpiryWarned.add(c.id);
                    _sendClaimExpiryWarning(c, Math.ceil(limit - elapsed));
                    pushClaimSSE('expiry_warning', { phone: c.customer_phone, minsLeft: Math.ceil(limit - elapsed) });
                }
            });
        }
    );
}, 60000);

// Heartbeat watchdog: if bot stops sending heartbeats for 5 min while status is
// 'connected', Puppeteer/Chromium has likely frozen — force a restart.
// lastBotHeartbeat stays 0 until the first heartbeat arrives (after 'connected'),
// so this never fires on a freshly-starting or offline bot.
// (Increased from 2 min — on a busy server, Gemini calls can briefly stall the
//  event loop; 2 min was too tight and caused false-positive restarts.)
setInterval(() => {
    if (botStatus === 'connected' && lastBotHeartbeat > 0 && (Date.now() - lastBotHeartbeat) > 300000) {
        pushLog('💀 WATCHDOG: Bot heartbeat missed for 5 min — force restarting...');
        lastBotHeartbeat = Date.now(); // reset so we don't re-trigger during respawn
        startBotProcess(lastBotId || 'drd_bot_1');
    }
}, 60000);

// Re-read setting every 10 min so dashboard changes take effect without server restart.
setInterval(() => {
    const desired = _readBotRestartMinutes();
    const currentMs = _botRestartTimer?._idleTimeout;
    const desiredMs = desired * 60 * 1000;
    if ((desired <= 0 && _botRestartTimer) || (desired > 0 && currentMs !== desiredMs)) {
        _scheduleBotRestart();
    }
}, 10 * 60 * 1000);

// ─── Phase 1: AI Marketing Designer Endpoint ───
app.post('/api/marketing/generate-copy', async (req, res) => {
    try {
        const { layout, plot, size, price, location } = req.body;
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        const prompt = `You are a professional Real Estate Marketing Specialist for "DRD Realtors".
        Create a catchy headline and a persuasive description for a property with these details:
        - Layout Name: ${layout}
        - Plot No: ${plot}
        - Size: ${size}
        - Price: ${price}
        - Location: ${location}

        RULES:
        1. The headline should be bold and emotional (e.g., "Build Your Dream Home in...")
        2. The description should highlight value, luxury, or investment potential.
        3. Keep the tone professional but inviting.
        4. Include a call to action.
        5. Return ONLY a JSON object with keys "headline" and "description".

        Response Format:
        {"headline": "...", "description": "..."}`;

        const result = await model.generateContent(prompt);
        const text = result.response.text();
        const jsonMatch = text.match(/\{.*\}/s);
        
        if (jsonMatch) {
            res.json(JSON.parse(jsonMatch[0]));
        } else {
            res.status(500).json({ error: "Failed to parse AI response" });
        }
    } catch (e) {
        console.error("Marketing AI Error:", e);
        res.status(500).json({ error: e.message });
    }
});

// ─── Phase 1: AI Layout Dimension Extraction ───
app.post('/api/plots/analyze-layout', async (req, res) => {
    try {
        const { layoutName, plotNo } = req.body;
        if (!layoutName || !plotNo) return res.status(400).json({ ok: false, msg: "Layout and Plot No required" });

        const layoutsDir = path.join(ROOT_DIR, 'Layout_Images');
        let pdfPath = null;

        const findPdfRecursive = (dir, target) => {
            if (!fs.existsSync(dir)) return null;
            const items = fs.readdirSync(dir, { withFileTypes: true });
            const pdfFile = items.find(i => !i.isDirectory() && i.name.toLowerCase().endsWith('.pdf') && !i.name.startsWith('~$'));
            if (pdfFile && (dir.toLowerCase().includes(target) || pdfFile.name.toLowerCase().includes(target))) return path.join(dir, pdfFile.name);
            for (const item of items) { if (item.isDirectory()) { const found = findPdfRecursive(path.join(dir, item.name), target); if (found) return found; } }
            return null;
        };

        const normalizedTarget = layoutName.toLowerCase().replace(/drd/g, '').trim();
        pdfPath = findPdfRecursive(layoutsDir, normalizedTarget);

        if (!pdfPath) return res.json({ ok: false, msg: `No PDF found for "${layoutName}".` });

        const pdfParse = require('pdf-parse');
        const pdfData = await pdfParse(fs.readFileSync(pdfPath));
        const text = pdfData.text;
        if (!text || text.trim().length < 20) return res.json({ ok: false, msg: "PDF is unreadable (image only)." });

        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const prompt = `Find DIMENSIONS and FACING for Plot "${plotNo}" in layout "${layoutName}". Return ONLY JSON: {"dimensions": "30x40", "facing": "East"}. TEXT: ${text.substring(0, 8000)}`;

        const result = await model.generateContent(prompt);
        const jsonMatch = result.response.text().match(/\{.*\}/s);
        res.json({ ok: true, analysis: jsonMatch ? JSON.parse(jsonMatch[0]) : { dimensions: "Not Found", facing: "Not Found" } });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── SITE VISIT SCHEDULER API ─────────────────────────────
app.get('/api/site-visits', (req, res) => {
    db.all('SELECT * FROM site_visits ORDER BY created_at DESC', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.post('/api/site-visits/update', (req, res) => {
    const { id, status, notes, customer_phone, layout_name, visit_date, visit_time } = req.body;
    db.run(
        `UPDATE site_visits SET
            customer_phone = COALESCE(?, customer_phone),
            layout_name    = COALESCE(?, layout_name),
            visit_date     = COALESCE(?, visit_date),
            visit_time     = COALESCE(?, visit_time),
            status         = COALESCE(?, status),
            notes          = COALESCE(?, notes)
         WHERE id = ?`,
        [customer_phone, layout_name, visit_date, visit_time, status, notes, id],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ ok: true });
        }
    );
});

app.post('/api/site-visits/create', (req, res) => {
    const { customer_phone, layout_name, visit_date, visit_time, staff_id, notes } = req.body;
    if (!customer_phone || !layout_name || !visit_date) {
        return res.status(400).json({ error: 'customer_phone, layout_name and visit_date are required' });
    }
    db.run(
        `INSERT INTO site_visits (customer_phone, layout_name, visit_date, visit_time, staff_id, status, notes)
         VALUES (?, ?, ?, ?, ?, 'Scheduled', ?)`,
        [customer_phone.trim(), layout_name.trim(), visit_date, visit_time || null, staff_id || null, notes || null],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ ok: true, id: this.lastID });
        }
    );
});

app.delete('/api/site-visits/:id', (req, res) => {
    db.run('DELETE FROM site_visits WHERE id = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ ok: true });
    });
});

app.post('/api/site-visits/bulk-delete', (req, res) => {
    const ids = req.body.ids;
    if (!Array.isArray(ids) || ids.length === 0) return res.status(400).json({ error: 'ids required' });
    const placeholders = ids.map(() => '?').join(',');
    db.run(`DELETE FROM site_visits WHERE id IN (${placeholders})`, ids, (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ ok: true, deleted: ids.length });
    });
});

// ─── VISITOR WELCOME WHATSAPP ──────────────────────────────
function sendVisitorWelcomeWA(phone, name, purpose) {
    if (!phone || !botProcess || !botProcess.send || botStatus !== 'connected') return;
    const cp = String(phone).replace(/\D/g, '').slice(-10);
    if (cp.length < 10) return;
    const target = '91' + cp;

    // Read company settings
    let co = { companyName: 'DRD Realtors', phone: '', phone2: '', address: '', email: '' };
    try { Object.assign(co, JSON.parse(fs.readFileSync(COMPANY_SETTINGS_PATH, 'utf8'))); } catch (_) {}
    const coName   = co.companyName || co.name || 'DRD Realtors';
    const coPhone  = (co.phone  || '').replace(/\s/g, '');
    const coPhone2 = (co.phone2 || '').replace(/\s/g, '');

    // Purpose-based welcome message
    const purposeMsgs = {
        'Site Enquiry':       `🏡 *Welcome to ${coName}!*\n\nThank you for visiting us today, *${name}*! 😊\n\nWe're excited to help you explore our premium plots and row houses. Our team is ready to assist you.\n\nWe've sent you our office contact — please save it so we can stay in touch! 📞`,
        'Follow-up Visit':    `👋 *Welcome back, ${name}!*\n\nGreat to see you again at ${coName}! 🙏\n\nOur team will be with you shortly. We've resent our office contact for easy access.`,
        'Booking':            `🎉 *Congratulations, ${name}!*\n\nWelcome to ${coName}! You're taking an exciting step towards your dream property. 🏡\n\nOur team will assist you with your booking today. We've sent our contact — save it for easy reach!`,
        'Registration':       `📋 *Welcome, ${name}!*\n\nThank you for visiting ${coName} for your registration.\n\nOur team will assist you with the registration process shortly. Please save our office contact for future reference. 📞`,
        'Payment':            `💳 *Welcome, ${name}!*\n\nThank you for visiting ${coName}! Our accounts team will assist you with your payment shortly.\n\nWe appreciate your prompt payment and trust! 🙏 Please save our contact for easy reach.`,
        'Document Collection':`📄 *Welcome, ${name}!*\n\nThank you for visiting ${coName}! Your documents are ready for collection.\n\nOur team will assist you shortly. Please save our contact for future reference. 📞`,
    };
    const text = purposeMsgs[purpose] || `🏡 *Welcome to ${coName}!*\n\nThank you for visiting us, *${name}*! Our team will be with you shortly. 😊\n\nPlease save our office contact below so we can stay in touch!`;

    // Generate VCF contact card
    const vcfLines = [
        'BEGIN:VCARD',
        'VERSION:3.0',
        `FN:${coName}`,
        `ORG:${coName}`,
    ];
    if (coPhone)  vcfLines.push(`TEL;TYPE=WORK,VOICE:${coPhone}`);
    if (coPhone2) vcfLines.push(`TEL;TYPE=WORK,VOICE:${coPhone2}`);
    if (co.email) vcfLines.push(`EMAIL:${co.email}`);
    if (co.address) vcfLines.push(`ADR:;;${co.address};;;;`);
    if (co.website) vcfLines.push(`URL:${co.website}`);
    vcfLines.push('END:VCARD');

    const vcfPath = path.join(ROOT_DIR, 'office_contact.vcf');
    try { fs.writeFileSync(vcfPath, vcfLines.join('\r\n'), 'utf8'); } catch (_) { return; }

    try {
        botProcess.send({ type: 'send_whatsapp', data: { target, text, mediaPaths: [vcfPath] } });
    } catch (_) {}
}

// ─── VISITOR LOG ───────────────────────────────────────────
app.get('/api/visitors', (req, res) => {
    const { date, search, source } = req.query;
    let sql = `SELECT * FROM visitors`;
    const params = [];
    const conditions = [];
    if (date)   { conditions.push(`visit_date = ?`); params.push(date); }
    if (source) { conditions.push(`source = ?`);     params.push(source); }
    if (search) {
        conditions.push(`(name LIKE ? OR phone LIKE ? OR layout_interest LIKE ?)`);
        params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (conditions.length) sql += ` WHERE ` + conditions.join(' AND ');
    sql += ` ORDER BY visit_date DESC, id DESC`;
    db.all(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows || []);
    });
});

app.post('/api/visitors', (req, res) => {
    const { name, phone, visit_date, visit_time, layout_interest, purpose, met_staff, source, notes, follow_up_date, status } = req.body;
    if (!name || !visit_date) return res.status(400).json({ error: 'name and visit_date required' });
    db.run(
        `INSERT INTO visitors (name, phone, visit_date, visit_time, layout_interest, purpose, met_staff, source, notes, follow_up_date, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [name, phone||'', visit_date, visit_time||'', layout_interest||'', purpose||'Site Enquiry', met_staff||'', source||'Walk-in', notes||'', follow_up_date||null, status||'Visited'],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            const visitorId = this.lastID;
            if (phone) {
                const cp = String(phone).replace(/\D/g,'').slice(-10);
                db.run(
                    `INSERT INTO customers (phone, name, plot, status, last_interaction, lead_notes)
                     VALUES (?, ?, ?, 'Lead', datetime('now'), ?)
                     ON CONFLICT(phone) DO UPDATE SET
                       name = COALESCE(NULLIF(excluded.name,''), name),
                       plot = CASE WHEN excluded.plot != '' THEN excluded.plot ELSE plot END,
                       last_interaction = datetime('now'),
                       lead_notes = CASE WHEN excluded.lead_notes != '' THEN excluded.lead_notes ELSE lead_notes END`,
                    [cp, name, layout_interest||'', notes||'']
                );
            }
            db.get(`SELECT * FROM visitors WHERE id = ?`, [visitorId], (e, row) => {
                res.json(row);
                if (phone) sendVisitorWelcomeWA(phone, name, purpose || 'Site Enquiry');
            });
        }
    );
});

app.put('/api/visitors/:id', (req, res) => {
    const { name, phone, visit_date, visit_time, layout_interest, purpose, met_staff, source, notes, follow_up_date, status } = req.body;
    db.run(
        `UPDATE visitors SET name=?, phone=?, visit_date=?, visit_time=?, layout_interest=?, purpose=?, met_staff=?, source=?, notes=?, follow_up_date=?, status=? WHERE id=?`,
        [name, phone||'', visit_date, visit_time||'', layout_interest||'', purpose||'Site Enquiry', met_staff||'', source||'Walk-in', notes||'', follow_up_date||null, status||'Visited', req.params.id],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            if (phone) {
                const cp = String(phone).replace(/\D/g,'').slice(-10);
                db.run(
                    `INSERT INTO customers (phone, name, plot, status, last_interaction, lead_notes)
                     VALUES (?, ?, ?, 'Lead', datetime('now'), ?)
                     ON CONFLICT(phone) DO UPDATE SET
                       name = COALESCE(NULLIF(excluded.name,''), name),
                       plot = CASE WHEN excluded.plot != '' THEN excluded.plot ELSE plot END,
                       last_interaction = datetime('now'),
                       lead_notes = CASE WHEN excluded.lead_notes != '' THEN excluded.lead_notes ELSE lead_notes END`,
                    [cp, name, layout_interest||'', notes||'']
                );
            }
            db.get(`SELECT * FROM visitors WHERE id = ?`, [req.params.id], (e, row) => res.json(row));
        }
    );
});

app.delete('/api/visitors/:id', (req, res) => {
    db.run(`DELETE FROM visitors WHERE id = ?`, [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ ok: true });
    });
});

// ─── PUBLIC VISITOR CHECK-IN (QR code self-registration, no auth required) ───
app.get('/visitor-checkin', (req, res) => {
    let companyName = 'DRD Property Genius';
    let tagline = 'Premium Plots & Row House';
    try {
        const cs = JSON.parse(fs.readFileSync(COMPANY_SETTINGS_PATH, 'utf8'));
        companyName = (cs.companyName || cs.name || companyName).replace(/</g, '&lt;').replace(/>/g, '&gt;');
        tagline = (cs.tagline || tagline).replace(/</g, '&lt;').replace(/>/g, '&gt;');
    } catch (_) {}
    let layoutOptions = '<option value="">— Select (optional) —</option>';
    try {
        const lp = path.join(ROOT_DIR, 'layouts_data.json');
        if (fs.existsSync(lp)) {
            const layouts = JSON.parse(fs.readFileSync(lp, 'utf8'));
            const names = [...new Set(layouts.map(l => l.Layout || l.Layout_Name || l.name).filter(Boolean))].sort();
            layoutOptions += names.map(n => `<option value="${n.replace(/"/g, '&quot;')}">${n}</option>`).join('');
        }
    } catch (_) {}
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>Visitor Check-in — ${companyName}</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
    .card{background:#1e293b;border:1px solid #334155;border-radius:20px;padding:32px;width:100%;max-width:440px;box-shadow:0 20px 60px rgba(0,0,0,.5)}
    .brand{text-align:center;margin-bottom:24px}
    .brand h1{font-size:22px;font-weight:800;color:#fff;margin-bottom:4px}
    .brand p{font-size:13px;color:#64748b}
    .badge{display:inline-block;background:rgba(37,99,235,.15);color:#60a5fa;border:1px solid rgba(37,99,235,.3);border-radius:20px;padding:4px 14px;font-size:12px;font-weight:700;margin-bottom:20px}
    label{font-size:12px;color:#94a3b8;display:block;margin-bottom:5px;font-weight:600;letter-spacing:.3px}
    input,select{width:100%;padding:12px 14px;background:#0f172a;border:1px solid #334155;border-radius:10px;color:#e2e8f0;font-size:15px;margin-bottom:16px;outline:none;-webkit-appearance:none;appearance:none}
    input:focus,select:focus{border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.15)}
    .btn{width:100%;padding:15px;background:#2563eb;border:none;border-radius:12px;color:#fff;font-size:16px;font-weight:700;cursor:pointer;margin-top:4px;transition:background .15s}
    .btn:active{background:#1d4ed8}
    .btn:disabled{background:#1e3a5f;cursor:not-allowed}
    .err{color:#f87171;font-size:13px;margin-bottom:12px;display:none;padding:10px;background:rgba(239,68,68,.1);border-radius:8px}
    .success{text-align:center;display:none;padding:20px 0}
    .success .icon{font-size:64px;margin-bottom:16px}
    .success h2{font-size:24px;font-weight:800;color:#10b981;margin-bottom:8px}
    .success p{color:#94a3b8;font-size:15px;line-height:1.5}
    .req{color:#f87171}
    select option{background:#1e293b}
  </style>
</head>
<body>
  <div class="card">
    <div id="formView">
      <div class="brand">
        <h1>${companyName}</h1>
        <p>${tagline}</p>
      </div>
      <div style="text-align:center;margin-bottom:20px"><span class="badge">📋 Visitor Check-in</span></div>

      <!-- Step 1: Phone -->
      <label>Phone Number</label>
      <div style="position:relative;margin-bottom:6px;">
        <input id="vPhone" type="tel" placeholder="Enter 10-digit mobile number" autocomplete="tel"
          style="width:100%;padding:12px 44px 12px 14px;background:#0f172a;border:1px solid #334155;border-radius:10px;color:#e2e8f0;font-size:15px;outline:none;-webkit-appearance:none;appearance:none;"
          oninput="onPhoneInput(this.value)">
        <span id="phoneSpinner" style="display:none;position:absolute;right:14px;top:50%;transform:translateY(-50%);font-size:14px;">⏳</span>
        <span id="phoneCheck"   style="display:none;position:absolute;right:14px;top:50%;transform:translateY(-50%);font-size:16px;color:#10b981;">✓</span>
      </div>
      <div id="crmBadge" style="display:none;background:rgba(16,185,129,.12);border:1px solid rgba(16,185,129,.3);border-radius:8px;padding:8px 12px;margin-bottom:14px;font-size:13px;color:#34d399;"></div>

      <!-- Step 2: Name (revealed after phone) -->
      <div id="nameRow" style="display:none;">
        <label>Full Name <span style="color:#f87171">*</span></label>
        <input id="vName" type="text" placeholder="Your full name" autocomplete="name"
          style="width:100%;padding:12px 14px;background:#0f172a;border:1px solid #334155;border-radius:10px;color:#e2e8f0;font-size:15px;margin-bottom:16px;outline:none;-webkit-appearance:none;appearance:none;">
      </div>

      <!-- Step 3: Purpose + Layout (revealed after phone) -->
      <div id="detailsRow" style="display:none;">
        <label>Purpose of Visit</label>
        <select id="vPurpose" style="width:100%;padding:12px 14px;background:#0f172a;border:1px solid #334155;border-radius:10px;color:#e2e8f0;font-size:15px;margin-bottom:16px;outline:none;-webkit-appearance:none;appearance:none;">
          <option>Site Enquiry</option>
          <option>Follow-up Visit</option>
          <option>Booking</option>
          <option>Registration</option>
          <option>Payment</option>
          <option>Document Collection</option>
          <option>Other</option>
        </select>
        <label>Layout / Property Interest</label>
        <select id="vLayout" style="width:100%;padding:12px 14px;background:#0f172a;border:1px solid #334155;border-radius:10px;color:#e2e8f0;font-size:15px;margin-bottom:16px;outline:none;-webkit-appearance:none;appearance:none;">${layoutOptions}</select>
        <div class="err" id="errMsg"></div>
        <button class="btn" id="submitBtn" onclick="submitCheckin()">✅ Check In</button>
      </div>

    </div>
    <div class="success" id="successView">
      <div class="icon">🏡</div>
      <h2>You're Checked In!</h2>
      <p id="successMsg">Welcome! Our team will be with you shortly.</p>
    </div>
  </div>
  <script>
    let _lookupTimer = null;
    let _autoFilled  = false;

    function onPhoneInput(val) {
      const digits = val.replace(/\\D/g, '');
      document.getElementById('phoneCheck').style.display   = 'none';
      document.getElementById('crmBadge').style.display    = 'none';
      clearTimeout(_lookupTimer);
      if (digits.length < 10) {
        document.getElementById('phoneSpinner').style.display = 'none';
        if (_autoFilled) { _autoFilled=false; document.getElementById('vName').value=''; }
        return;
      }
      document.getElementById('phoneSpinner').style.display = 'inline';
      _lookupTimer = setTimeout(() => lookupPhone(digits), 500);
    }

    async function lookupPhone(digits) {
      try {
        const r = await fetch('/api/visitor-checkin/lookup?phone=' + digits).then(x => x.json());
        document.getElementById('phoneSpinner').style.display = 'none';
        document.getElementById('phoneCheck').style.display   = 'inline';
        if (r.found && r.name) {
          document.getElementById('vName').value = r.name;
          _autoFilled = true;
          const badge = document.getElementById('crmBadge');
          badge.textContent = '👤 Welcome back, ' + r.name + '! Details pre-filled from our records.';
          badge.style.display = 'block';
          if (r.layout) {
            const sel = document.getElementById('vLayout');
            for (let i=0;i<sel.options.length;i++) {
              if (sel.options[i].value === r.layout) { sel.selectedIndex=i; break; }
            }
          }
        } else {
          _autoFilled = false;
          document.getElementById('crmBadge').style.display = 'none';
        }
      } catch(_) {
        document.getElementById('phoneSpinner').style.display = 'none';
      }
      document.getElementById('nameRow').style.display    = 'block';
      document.getElementById('detailsRow').style.display = 'block';
    }

    async function submitCheckin() {
      const name   = document.getElementById('vName').value.trim();
      const phone  = document.getElementById('vPhone').value.trim();
      const layout = document.getElementById('vLayout').value;
      const purpose= document.getElementById('vPurpose').value;
      const err    = document.getElementById('errMsg');
      const btn    = document.getElementById('submitBtn');
      if (!name) { err.textContent='Please enter your full name.'; err.style.display='block'; return; }
      err.style.display='none';
      btn.disabled=true; btn.textContent='Checking in…';
      const today = new Date().toISOString().split('T')[0];
      const now   = new Date().toTimeString().slice(0,5);
      try {
        const res = await fetch('/api/visitor-checkin', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({ name, phone, visit_date:today, visit_time:now, layout_interest:layout, purpose, source:'QR Scan', status:'Visited' })
        }).then(r=>r.json());
        if (res.id || res.ok !== false) {
          document.getElementById('formView').style.display='none';
          document.getElementById('successMsg').textContent='Welcome, '+name+'! Our team will be with you shortly.';
          document.getElementById('successView').style.display='block';
        } else { throw new Error(res.error||'Unknown error'); }
      } catch(e) {
        err.textContent='Something went wrong. Please try again.'; err.style.display='block';
        btn.disabled=false; btn.textContent='✅ Check In';
      }
    }
  </script>
</body>
</html>`);
});

app.get('/api/visitor-checkin/lookup', (req, res) => {
    const raw = String(req.query.phone || '').replace(/\D/g, '').slice(-10);
    if (raw.length < 10) return res.json({ found: false });
    db.get(
        `SELECT name, plot FROM customers WHERE phone = ? OR phone = ? LIMIT 1`,
        [raw, '91' + raw],
        (err, row) => {
            if (err || !row) return res.json({ found: false });
            res.json({ found: true, name: row.name || '', layout: row.plot || '' });
        }
    );
});

app.post('/api/visitor-checkin', (req, res) => {
    const { name, phone, visit_date, visit_time, layout_interest, purpose, status } = req.body;
    if (!name || !visit_date) return res.status(400).json({ error: 'name and visit_date required' });
    const resolvedPurpose = purpose || 'Site Enquiry';
    db.run(
        `INSERT INTO visitors (name, phone, visit_date, visit_time, layout_interest, purpose, met_staff, source, notes, follow_up_date, status)
         VALUES (?, ?, ?, ?, ?, ?, '', 'QR Scan', '', null, ?)`,
        [name, phone || '', visit_date, visit_time || '', layout_interest || '', resolvedPurpose, status || 'Visited'],
        function (err) {
            if (err) return res.status(500).json({ error: err.message });
            const visitorId = this.lastID;
            // Only register as a CRM lead for plot enquiries — other visits (payment, documents, etc.) stay visitor-log only
            if (phone && resolvedPurpose === 'Site Enquiry') {
                const cp = String(phone).replace(/\D/g, '').slice(-10);
                db.run(
                    `INSERT INTO customers (phone, name, plot, status, last_interaction, lead_notes)
                     VALUES (?, ?, ?, 'Lead', datetime('now'), ?)
                     ON CONFLICT(phone) DO UPDATE SET
                       name = COALESCE(NULLIF(excluded.name,''), name),
                       plot = CASE WHEN excluded.plot != '' THEN excluded.plot ELSE plot END,
                       last_interaction = datetime('now')`,
                    [cp, name, layout_interest || '', '']
                );
            }
            db.get(`SELECT * FROM visitors WHERE id = ?`, [visitorId], (e, row) => {
                res.json(row || { ok: true, id: visitorId });
                if (phone) sendVisitorWelcomeWA(phone, name, resolvedPurpose);
            });
        }
    );
});

// ─── BOT SEND MESSAGE (used by dashboard share buttons) ────
app.post('/api/bot/send-message', (req, res) => {
    const { number, message } = req.body;
    if (!number || !message) return res.status(400).json({ ok: false, msg: 'number and message required' });
    const phone = String(number).replace(/\D/g, '');
    if (phone.length < 10) return res.status(400).json({ ok: false, msg: 'Invalid phone number' });
    const target = phone.includes('@c.us') ? phone : `${phone}@c.us`;
    if (!botProcess || !botProcess.send || botStatus !== 'connected') {
        return res.status(503).json({ ok: false, msg: 'WhatsApp bot not connected. Please scan QR first.' });
    }
    botProcess.send({ type: 'send_whatsapp', data: { target, text: message, mediaPaths: [] } });
    res.json({ ok: true });
});

// ─── CONVERSATION CLAIMS ────────────────────────────────────

// GET /api/claims/staff-list — all active staff login accounts (for transfer picker)
app.get('/api/claims/staff-list', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    db.all(`SELECT id, name, role FROM staff WHERE (is_active IS NULL OR is_active != 0) ORDER BY name`, [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false });
        res.json({ ok: true, staff: rows || [] });
    });
});

// GET /api/claims/admin-stats — admin-only analytics
app.get('/api/claims/admin-stats', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const role = req.session.userRole;
    if (role !== 'admin' && role !== 'super_admin' && role !== 'manager') {
        return res.status(403).json({ ok: false, msg: 'Admin only' });
    }

    const today = new Date().toISOString().split('T')[0];

    // 1. Per-agent summary across ALL claims (not just active)
    const agentSql = `
        SELECT
            cc.staff_id,
            MAX(cc.staff_name) AS staff_name,
            COUNT(*)                                                                        AS total_claimed,
            SUM(CASE WHEN cc.status = 'Active' THEN 1 ELSE 0 END)                         AS active_now,
            SUM(CASE WHEN cc.status = 'Released' THEN 1 ELSE 0 END)                       AS released,
            SUM(CASE WHEN cc.status = 'Auto-released' THEN 1 ELSE 0 END)                  AS auto_released,
            ROUND(AVG(CASE WHEN cc.released_at IS NOT NULL
                THEN (julianday(cc.released_at) - julianday(cc.claimed_at)) * 1440
                ELSE NULL END), 1)                                                         AS avg_handling_min,
            COUNT(DISTINCT sv.id)                                                          AS site_visits_scheduled,
            SUM(CASE WHEN c.status = 'Booked' THEN 1 ELSE 0 END)                         AS bookings,
            SUM(CASE WHEN LOWER(c.status) IN ('not interested','lost','rejected') THEN 1 ELSE 0 END) AS lost_leads
        FROM conversation_claims cc
        LEFT JOIN site_visits sv
               ON sv.customer_phone = cc.customer_phone
              AND sv.created_at >= cc.claimed_at
        LEFT JOIN customers c ON c.phone = cc.customer_phone
        GROUP BY cc.staff_id
        ORDER BY total_claimed DESC
    `;

    // 2. Today's totals
    const todaySql = `
        SELECT
            COUNT(*)                                                               AS today_total,
            SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END)                   AS today_active,
            SUM(CASE WHEN status IN ('Released','Auto-released') THEN 1 ELSE 0 END) AS today_resolved
        FROM conversation_claims
        WHERE DATE(claimed_at) = ?
    `;

    // 3. Confirmed site visits that originated from claimed conversations
    const svSql = `
        SELECT
            COUNT(DISTINCT sv.id)                                                  AS total_sv,
            SUM(CASE WHEN sv.status = 'Confirmed' THEN 1 ELSE 0 END)             AS confirmed_sv,
            SUM(CASE WHEN sv.status = 'Completed' THEN 1 ELSE 0 END)             AS completed_sv,
            SUM(CASE WHEN sv.status = 'Cancelled' THEN 1 ELSE 0 END)             AS cancelled_sv
        FROM site_visits sv
        WHERE EXISTS (
            SELECT 1 FROM conversation_claims cc
             WHERE cc.customer_phone = sv.customer_phone
               AND sv.created_at >= cc.claimed_at
        )
    `;

    db.all(agentSql, [], (err1, agents) => {
        if (err1) return res.status(500).json({ ok: false, msg: err1.message });
        db.get(todaySql, [today], (err2, todayRow) => {
            if (err2) return res.status(500).json({ ok: false, msg: err2.message });
            db.get(svSql, [], (err3, svRow) => {
                if (err3) return res.status(500).json({ ok: false, msg: err3.message });
                res.json({ ok: true, agents: agents || [], today: todayRow || {}, siteVisits: svRow || {} });
            });
        });
    });
});

// GET /api/claims — list claims; ?all=1 includes history (last 60 days, all statuses)
app.get('/api/claims', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const includeAll = req.query.all === '1';
    const sql = includeAll
        ? `SELECT cc.*, COALESCE(c.name, '') AS customer_name
           FROM conversation_claims cc
           LEFT JOIN customers c ON REPLACE(REPLACE(c.phone,'+',''),' ','') = cc.customer_phone
              OR SUBSTR(REPLACE(REPLACE(c.phone,'+',''),' ',''), -10) = SUBSTR(cc.customer_phone, -10)
           WHERE cc.claimed_at >= datetime('now', '-60 days')
           ORDER BY cc.claimed_at DESC LIMIT 200`
        : `SELECT cc.*, COALESCE(c.name, '') AS customer_name
           FROM conversation_claims cc
           LEFT JOIN customers c ON REPLACE(REPLACE(c.phone,'+',''),' ','') = cc.customer_phone
              OR SUBSTR(REPLACE(REPLACE(c.phone,'+',''),' ',''), -10) = SUBSTR(cc.customer_phone, -10)
           WHERE cc.status = 'Active'
           ORDER BY cc.claimed_at DESC`;
    db.all(sql, [], (err, rows) => {
        if (err) return res.status(500).json({ ok: false });
        res.json({ ok: true, claims: rows || [] });
    });
});

// GET /api/claims/events — SSE stream: pushes inbound messages + claim state changes in real-time
app.get('/api/claims/events', (req, res) => {
    if (!req.session?.userId) return res.status(401).end();
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    res.write('data: {"type":"connected"}\n\n');
    sseClaimClients.push(res);
    req.on('close', () => { sseClaimClients = sseClaimClients.filter(c => c !== res); });
});

// GET /api/claims/inbound?since=<ms> — poll for new messages on claimed conversations
app.get('/api/claims/inbound', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const since = parseInt(req.query.since) || 0;
    res.json({ ok: true, messages: claimedInboundBuffer.filter(m => m.ts > since) });
});

// GET /api/claims/:phone — get active claim for a specific phone
app.get('/api/claims/:phone', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const phone = req.params.phone.replace(/\D/g, '');
    db.get(`SELECT * FROM conversation_claims WHERE customer_phone = ? AND status = 'Active'`, [phone], (err, row) => {
        if (err) return res.status(500).json({ ok: false });
        res.json({ ok: true, claim: row || null });
    });
});

// POST /api/claims/:phone — claim a conversation
app.post('/api/claims/:phone', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const phone = req.params.phone.replace(/\D/g, '');
    const staffId   = req.session.userId;
    const staffName = req.session.userName || staffId;
    db.get(`SELECT * FROM conversation_claims WHERE customer_phone = ? AND status = 'Active'`, [phone], (err, existing) => {
        if (existing) {
            return res.status(409).json({ ok: false, msg: `Already claimed by ${existing.staff_name || existing.staff_id}`, claimedBy: existing.staff_name, staffId: existing.staff_id });
        }
        db.run(`INSERT INTO conversation_claims (customer_phone, staff_id, staff_name) VALUES (?, ?, ?)`,
            [phone, staffId, staffName],
            function(err2) {
                if (err2) return res.status(500).json({ ok: false, msg: err2.message });
                pushLog(`🤝 CLAIM: ${staffName} claimed conversation with ${phone}`);
                db.run(`INSERT INTO activity_logs (type, message) VALUES ('claim', ?)`, [`${staffName} claimed ${phone}`]);
                pushClaimSSE('update', { action: 'claimed', phone, staffId, staffName });
                res.json({ ok: true, id: this.lastID });
            }
        );
    });
});

// DELETE /api/claims/stats/reset — admin only: clear all-time agent performance history
// Must be defined BEFORE /:phone to prevent Express matching "stats" as a phone param
app.delete('/api/claims/stats/reset', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const role = req.session.userRole;
    if (role !== 'admin' && role !== 'super_admin') {
        return res.status(403).json({ ok: false, msg: 'Admin only' });
    }
    db.run(`DELETE FROM conversation_claims WHERE status != 'Active'`, function(err) {
        if (err) return res.status(500).json({ ok: false, msg: err.message });
        const cleared = this.changes;
        const admin = req.session.userName || req.session.userId;
        pushLog(`🗑️ ADMIN: ${admin} cleared agent performance history (${cleared} records removed)`);
        db.run(`INSERT INTO activity_logs (type, message) VALUES ('admin', ?)`,
            [`${admin} cleared agent performance stats — ${cleared} records`]);
        res.json({ ok: true, cleared });
    });
});

// DELETE /api/claims/:phone — release a conversation
app.delete('/api/claims/:phone', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const phone = req.params.phone.replace(/\D/g, '');
    const staffName = req.session.userName || req.session.userId;
    db.run(`UPDATE conversation_claims SET status = 'Released', released_at = CURRENT_TIMESTAMP WHERE customer_phone = ? AND status = 'Active'`,
        [phone],
        function(err) {
            if (err) return res.status(500).json({ ok: false });
            pushLog(`🔓 RELEASE: ${staffName} released conversation with ${phone}`);
            db.run(`INSERT INTO activity_logs (type, message) VALUES ('claim', ?)`, [`${staffName} released ${phone}`]);
            pushClaimSSE('update', { action: 'released', phone });
            res.json({ ok: true, changed: this.changes });
        }
    );
});

// POST /api/claims/:phone/transfer — reassign to another staff member
app.post('/api/claims/:phone/transfer', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const phone = req.params.phone.replace(/\D/g, '');
    const { to_staff_id, to_staff_name } = req.body;
    if (!to_staff_id) return res.status(400).json({ ok: false, msg: 'to_staff_id required' });
    db.run(`UPDATE conversation_claims SET staff_id = ?, staff_name = ?, last_activity_at = CURRENT_TIMESTAMP WHERE customer_phone = ? AND status = 'Active'`,
        [to_staff_id, to_staff_name || to_staff_id, phone],
        function(err) {
            if (err) return res.status(500).json({ ok: false });
            pushLog(`↔ TRANSFER: conversation ${phone} transferred to ${to_staff_name || to_staff_id}`);
            pushClaimSSE('update', { action: 'transferred', phone, staffId: to_staff_id, staffName: to_staff_name });
            res.json({ ok: true, changed: this.changes });
        }
    );
});

// ─── ADVANCED ANALYTICS: INVENTORY AGING ──────────────────
app.get('/api/analytics/inventory-health', (req, res) => {
    const sql = `
        SELECT layout_name,
               COUNT(*) as total_plots,
               SUM(CASE WHEN status = 'Available' THEN 1 ELSE 0 END) as available,
               SUM(CASE WHEN status IN ('Sold', 'Sold Out') THEN 1 ELSE 0 END) as sold,
               ROUND(SUM(CASE WHEN status IN ('Sold', 'Sold Out') THEN 1.0 ELSE 0 END) * 100.0 / COUNT(*), 1) as sold_pct,
               SUM(CASE WHEN julianday('now') - julianday(updated_at) > 90  AND status = 'Available' THEN 1 ELSE 0 END) as aging_3m,
               SUM(CASE WHEN julianday('now') - julianday(updated_at) > 180 AND status = 'Available' THEN 1 ELSE 0 END) as aging_6m,
               SUM(CASE WHEN status = 'Available' THEN COALESCE(price, 0) ELSE 0 END) as unsold_value
        FROM plots
        GROUP BY layout_name
        ORDER BY layout_name
    `;
    db.all(sql, [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});
app.get('/api/qr/scans', (req, res) => {
    db.all('SELECT * FROM qr_scans ORDER BY scanned_at DESC LIMIT 100', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.delete('/api/qr/scans/:id', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    db.run('DELETE FROM qr_scans WHERE id = ?', [req.params.id], function(err) {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        res.json({ ok: true });
    });
});

app.delete('/api/qr/scans', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    db.run('DELETE FROM qr_scans', [], function(err) {
        if (err) return res.status(500).json({ ok: false, error: err.message });
        res.json({ ok: true, deleted: this.changes });
    });
});

// List saved affiliate QR code images from disk
app.get('/api/affiliate/qr-list', (req, res) => {
    const qrDir = path.join(ROOT_DIR, 'affiliate_qr_codes');
    if (!fs.existsSync(qrDir)) return res.json({ ok: true, files: [] });
    try {
        const files = fs.readdirSync(qrDir)
            .filter(f => f.endsWith('.png'))
            .map(f => {
                const staffId = f.replace(/^QR_/, '').replace(/\.png$/, '').replace(/_/g, ' ');
                const stat = fs.statSync(path.join(qrDir, f));
                return { fileName: f, staffId, savedAt: stat.mtime.toISOString() };
            })
            .sort((a, b) => new Date(b.savedAt) - new Date(a.savedAt));
        res.json({ ok: true, files });
    } catch (e) {
        res.json({ ok: false, error: e.message, files: [] });
    }
});

// Serve saved affiliate QR images
app.get('/affiliate-qr/:fileName', (req, res) => {
    const safe = path.basename(req.params.fileName);
    if (!safe.endsWith('.png')) return res.status(400).send('Invalid file');
    const filePath = path.join(ROOT_DIR, 'affiliate_qr_codes', safe);
    if (!fs.existsSync(filePath)) return res.status(404).send('Not found');
    res.sendFile(filePath);
});

// Delete a saved affiliate QR image
app.delete('/api/affiliate/qr/:fileName', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    const safe = path.basename(decodeURIComponent(req.params.fileName));
    if (!safe.endsWith('.png')) return res.status(400).json({ ok: false, error: 'Invalid file' });
    const filePath = path.join(ROOT_DIR, 'affiliate_qr_codes', safe);
    if (!fs.existsSync(filePath)) return res.status(404).json({ ok: false, error: 'Not found' });
    try {
        fs.unlinkSync(filePath);
        res.json({ ok: true });
    } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
    }
});

app.get('/qr/:layout', (req, res) => {
    const layoutName = req.params.layout.replace(/_/g, ' ');
    const affiliateCode = req.query.aff || 'Direct';
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    const ua = req.headers['user-agent'];

    // Log the scan
    db.run(`INSERT INTO qr_scans (layout_name, affiliate_code, ip_address, user_agent) VALUES (?, ?, ?, ?)`,
        [layoutName, affiliateCode, ip, ua]);

    // Find GPS for this layout
    const LAYOUTS_DATA_PATH = path.join(ROOT_DIR, 'layouts_data.json');
    if (fs.existsSync(LAYOUTS_DATA_PATH)) {
        const layouts = JSON.parse(fs.readFileSync(LAYOUTS_DATA_PATH, 'utf8'));
        const match = layouts.find(l => l.Layout_Name.toUpperCase() === layoutName.toUpperCase());
        if (match && match['GPS Location']) {
            return res.redirect(match['GPS Location']);
        }
    }
    
    res.status(404).send('Layout GPS not found.');
});

// ─── CUSTOMER REGISTRATIONS & PATTA TRANSFER API ─────────────
app.get('/api/registrations', (req, res) => {
    db.all('SELECT * FROM customer_registrations ORDER BY created_at DESC', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.post('/api/registrations', (req, res) => {
    const { customer_phone, customer_name, layout_name, plot_no, reg_date, doc_no, sro_office, patta_status, patta_applied_date, patta_notes, chitta_number } = req.body;

    // 1. Ensure Customer exists in CRM
    db.run(`INSERT OR IGNORE INTO customers (phone, name, plot, location, status) VALUES (?, ?, ?, ?, ?)`,
        [customer_phone, customer_name, `${layout_name} - ${plot_no}`, layout_name, 'Registered']);

    // 2. Auto-mark plot as Sold in inventory
    if (layout_name && plot_no) {
        db.run(
            `UPDATE plots SET status = 'Sold' WHERE LOWER(TRIM(layout_name)) = LOWER(TRIM(?)) AND LOWER(TRIM(plot_no)) = LOWER(TRIM(?))`,
            [layout_name, plot_no], () => {}
        );
    }

    // 3. Save Registration
    db.run(`INSERT INTO customer_registrations
        (customer_phone, customer_name, layout_name, plot_no, reg_date, doc_no, sro_office, patta_status, patta_applied_date, patta_notes, chitta_number)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [customer_phone, customer_name, layout_name, plot_no, reg_date, doc_no, sro_office, patta_status || 'Not Started', patta_applied_date, patta_notes, chitta_number || null],
        function(err) {
            if (err) {
                if (err.message.includes('UNIQUE constraint failed')) {
                    return res.status(400).json({ error: 'This plot is already registered for this customer.' });
                }
                return res.status(500).json({ error: err.message });
            }
            res.json({ id: this.lastID, message: 'Registration saved & CRM connected' });
        }
    );
});

app.put('/api/registrations/:id', (req, res) => {
    const { patta_status, patta_applied_date, patta_notes, doc_no, reg_date, sro_office, chitta_number } = req.body;
    db.run(`UPDATE customer_registrations SET
        patta_status = ?, patta_applied_date = ?, patta_notes = ?, doc_no = ?, reg_date = ?, sro_office = ?, chitta_number = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?`,
        [patta_status, patta_applied_date, patta_notes, doc_no, reg_date, sro_office, chitta_number || null, req.params.id],
        (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Registration updated' });
        }
    );
});

app.delete('/api/registrations/:id', (req, res) => {
    db.run('DELETE FROM customer_registrations WHERE id = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Registration deleted' });
    });
});

// Registration document upload / download
const _regDocDir = path.join(ROOT_DIR, 'registration_docs');
if (!fs.existsSync(_regDocDir)) fs.mkdirSync(_regDocDir, { recursive: true });
const _regDocUpload = multer({
    storage: multer.diskStorage({
        destination: (req, file, cb) => cb(null, _regDocDir),
        filename: (req, file, cb) => {
            const ext = path.extname(file.originalname).toLowerCase() || '.pdf';
            const safeId = String(req.params.id).replace(/[^0-9]/g, '');
            cb(null, `REG_${safeId}_${Date.now()}${ext}`);
        }
    }),
    limits: { fileSize: 20 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        if (['application/pdf','image/jpeg','image/jpg','image/png'].includes(file.mimetype)) cb(null, true);
        else cb(new Error('Only PDF and images allowed'));
    }
});

app.post('/api/registrations/:id/upload-doc', (req, res) => {
    if (!req.session?.userId) return res.status(401).json({ ok: false });
    _regDocUpload.single('doc')(req, res, (err) => {
        if (err) return res.status(400).json({ ok: false, msg: err.message });
        if (!req.file) return res.status(400).json({ ok: false, msg: 'No file uploaded' });
        db.run(`UPDATE customer_registrations SET doc_file = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
            [req.file.filename, req.params.id],
            (dbErr) => {
                if (dbErr) return res.status(500).json({ ok: false, msg: dbErr.message });
                res.json({ ok: true, fileName: req.file.filename });
            }
        );
    });
});

app.get('/api/registrations/:id/doc', (req, res) => {
    if (!req.session?.userId) return res.status(401).send('Unauthorized');
    db.get(`SELECT doc_file FROM customer_registrations WHERE id = ?`, [req.params.id], (err, row) => {
        if (err || !row || !row.doc_file) return res.status(404).send('No document');
        const filePath = path.join(ROOT_DIR, 'registration_docs', row.doc_file);
        if (!fs.existsSync(filePath)) return res.status(404).send('File not found');
        res.download(filePath, row.doc_file);
    });
});

app.listen(PORT, async () => {
    // Detect LAN IP for easier sharing
    const interfaces = os.networkInterfaces();
    let lanIp = 'localhost';
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if ((iface.family === 'IPv4' || iface.family === 4) && !iface.internal) {
                lanIp = iface.address;
                break;
            }
        }
        if (lanIp !== 'localhost') break;
    }

    const localUrl = `http://localhost:${PORT}`;
    const lanUrl = `http://${lanIp}:${PORT}`;

    console.log(`🟢 Bot Manager running:`);
    console.log(`🏠 Local: ${localUrl}`);
    console.log(`🌐 LAN:   ${lanUrl} (Use this on other devices)`);
    
    pushLog(`🚀 Property Genius System Online — LAN Access: ${lanUrl}`);

    // Initialize & Sync SQLite Database (Non-blocking for server ready state)
    (async () => {
        try {
            await initDB();
            await migrateFromExcel();
            pushLog("✅ Database synchronized successfully.");
            console.log("LOG: SQLite Database Synchronized.");
        } catch(e) { console.error("DB Sync Error:", e); pushLog("⚠️ Database sync error — check logs."); }
    })();

    // ─── Default Admin Account ─────────────────────────────
    db.get(`SELECT id FROM staff WHERE id = 'admin'`, [], async (err, row) => {
        if (row) return; // already exists
        try {
            const bcrypt = require('bcryptjs');
            const tempPass = 'Admin@' + Math.floor(1000 + Math.random() * 9000);
            const hash = await bcrypt.hash(tempPass, 12);
            db.run(`INSERT OR IGNORE INTO staff (id, name, dept, phone, email, password_hash, role, is_active)
                    VALUES ('admin','Administrator','Admin','','',?,?,1)`, [hash, 'super_admin'],
                () => {
                    console.log('');
                    console.log('╔══════════════════════════════════════════════╗');
                    console.log('║  🔐  DEFAULT ADMIN ACCOUNT CREATED           ║');
                    console.log(`║  Username : admin                            ║`);
                    console.log(`║  Password : ${tempPass}                    ║`);
                    console.log('║  Change it after first login!                ║');
                    console.log('╚══════════════════════════════════════════════╝');
                    console.log('');
                });
        } catch(e) { console.error('Failed to create default admin:', e.message); }
    });

    // ─── Notification Dispatcher (every 10 minutes) ────────────
    setInterval(() => {
        const now = new Date().toISOString();
        db.all(`SELECT * FROM notifications WHERE status = 'Pending' AND scheduled_at <= ?`, [now], (err, rows) => {
            if (err || !rows || rows.length === 0) return;
            rows.forEach(notif => {
                let phones = [];
                try { phones = JSON.parse(notif.recipients || '[]'); } catch (e) { }
                const fullMsg = `*${notif.title}*\n\n${notif.message}`;
                phones.forEach(phone => {
                    if (botProcess && botProcess.send) {
                        botProcess.send({ type: 'send_notification', phone, message: fullMsg });
                        console.log(`[NOTIF] Dispatched "${notif.title}" to ${phone}`);
                    }
                });
                db.run(`UPDATE notifications SET status = 'Sent', sent_at = CURRENT_TIMESTAMP WHERE id = ?`, [notif.id]);
            });
        });
    }, 10 * 60 * 1000);

    // ─── Daily Backup Scheduler ───────────────────────────────
    (function scheduleDailyBackup() {
        const settings = loadBackupSettings(ROOT_DIR);
        if (!settings.schedule?.enabled) return;
        if (!settings.local?.enabled && !settings.github?.enabled) return;

        const [h, m] = (settings.schedule.time || '02:00').split(':').map(Number);

        function msUntilNext() {
            const now = new Date();
            const next = new Date(now);
            next.setHours(h, m, 0, 0);
            if (next <= now) next.setDate(next.getDate() + 1);
            return next - now;
        }

        // If today's backup was missed (last backup date ≠ today), run it soon
        const today = new Date().toISOString().slice(0, 10);
        const lastDate = settings.lastBackupDate;
        const initialDelay = (lastDate !== today && msUntilNext() > 60000) ? 60000 : msUntilNext();

        function doBackupCycle() {
            const cfg = loadBackupSettings(ROOT_DIR);
            if (cfg.schedule?.enabled && (cfg.local?.enabled || cfg.github?.enabled)) {
                runBackup(ROOT_DIR, db, cfg)
                    .then(r => pushLog(`[BACKUP] Auto daily backup: ${r.filename} (${(r.size / 1024).toFixed(0)} KB)`))
                    .catch(e => pushLog(`[BACKUP] Auto backup failed: ${e.message}`));
            }
            // Schedule next day
            setTimeout(doBackupCycle, msUntilNext() + 1000);
        }

        setTimeout(doBackupCycle, initialDelay);
        pushLog(`[BACKUP] Daily backup scheduled at ${settings.schedule.time}`);
    })();

    const url = `http://localhost:${PORT}`;
    const shareUrl = `http://${lanIp}:${PORT}`;

    // Initializing WhatsApp Bot Service should happen regardless of Electron status
    setTimeout(() => {
        pushLog("🤖 Initializing WhatsApp Bot Service...");
        startBotProcess('drd_bot_1');
    }, 5000);

    if (process.env.ELECTRON_RUNNING === 'true') {
        console.log("LOG: Electron detected. Skipping browser launch sequence.");
        return;
    }

    console.log(`\n✅ Property Genius is running.`);
    console.log(`🏠 Local URL: ${url}`);
    console.log(`🌐 LAN URL:   ${shareUrl} (Share this with your team)`);
    console.log(`   Tip: run "npm run electron" for the standalone desktop app.\n`);
});
