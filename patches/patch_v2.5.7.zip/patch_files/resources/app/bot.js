const path = require('path');
const fs = require('fs');
const isPkg = typeof process.pkg !== 'undefined';
const isElectron = !!process.env.ELECTRON_RUNNING;

function resolveRootDir() {
    if (process.env.APP_DATA_DIR) return process.env.APP_DATA_DIR;
    if (isPkg || isElectron) {
        const appData = process.env.APPDATA || (process.platform === 'darwin' ? process.env.HOME + '/Library/Preferences' : process.env.HOME + '/.local/share');
        const drdData = path.join(appData, 'DRD-Property-Genius');
        if (!fs.existsSync(drdData)) fs.mkdirSync(drdData, { recursive: true });
        return drdData;
    }
    return __dirname;
}

const ROOT_DIR = resolveRootDir();

// ─── Startup Cleanup (Handle 'browser already running' error) ───
const SESSION_PATH = path.join(ROOT_DIR, '.wwebjs_auth', 'session-drd_bot_1');
if (fs.existsSync(SESSION_PATH)) {
    ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'lockfile'].forEach(file => {
        const lockPath = path.join(SESSION_PATH, file);
        if (fs.existsSync(lockPath)) {
            try { fs.unlinkSync(lockPath); console.log(`[CLEANUP] Removed stale lock: ${file}`); } catch(e) {}
        }
    });
}

// Load .env from AppData first (secure location), fall back to project folder
;(function() {
    const os = require('os');
    const appDataEnv = path.join(os.homedir(), 'AppData', 'Roaming', 'DRD-Property-Genius', '.env');
    const localEnv   = path.join(__dirname, '.env');
    const envPath    = fs.existsSync(appDataEnv) ? appDataEnv : localEnv;
    require('dotenv').config({ path: envPath });
})();

const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const xlsx = require('xlsx');
const { db } = require('./database');

console.log("-----------------------------------------");
console.log("   Initializing DRD Property Genius...   ");
console.log("   ROOT: " + ROOT_DIR);
console.log("-----------------------------------------");

// Global Error Handler for Standalone Stability
const BOT_START_TIME = new Date().toLocaleString('en-IN');

const logError = (type, err) => {
    const errorMsg = `\n[${type}] ${new Date().toISOString()}\nStack: ${err.stack || err}\n`;
    const crashFile = path.join(ROOT_DIR, 'CRASH_REPORT_BOT.txt');
    try {
        fs.appendFileSync(crashFile, errorMsg);
    } catch (e) {
        console.error("Failed to write to crash log:", e);
    }
    console.error(errorMsg);
    if (type === 'CRASH') process.exit(1);
};

function _isPuppeteerTeardownError(msg) {
    return msg.includes('Target closed') || msg.includes('TargetCloseError') ||
           msg.includes('Protocol error') || msg.includes('Session closed') ||
           msg.includes('detached Frame') || msg.includes('frame was detached') ||
           msg.includes('Navigating frame') || msg.includes('context was destroyed') ||
           msg.includes('Execution context') || msg.includes('net::ERR_') ||
           msg.includes('Connection closed') || msg.includes('WebSocket is not open');
}

process.on('uncaughtException', (err) => {
    const msg = (err instanceof Error ? err.message : String(err)) || '';
    if (_isPuppeteerTeardownError(msg)) {
        console.log(`[BOT] Ignoring expected Chrome error (uncaughtException): ${msg.slice(0, 120)}`);
        return;
    }
    logError('CRASH', err);
});
process.on('unhandledRejection', (reason) => {
    // TargetCloseError / "Target closed" / "Protocol error" are all Puppeteer's way of
    // saying Chrome's WebSocket disconnected. These are EXPECTED when WhatsApp disconnects
    // or the bot is restarted — the 'disconnected' event handles cleanup.
    const msg = (reason instanceof Error ? reason.message : String(reason)) || '';
    if (_isPuppeteerTeardownError(msg)) {
        console.log(`[BOT] Ignoring expected Chrome error (unhandledRejection): ${msg.slice(0, 120)}`);
        return;
    }
    logError('REJECTION', reason);
});

// Load dynamic paths from config
const BOT_PRESETS_PATH = path.join(ROOT_DIR, 'bot_config.json');

function getBasePath() {
    try {
        if (fs.existsSync(BOT_PRESETS_PATH)) {
            const cfg = JSON.parse(fs.readFileSync(BOT_PRESETS_PATH, 'utf8'));
            if (cfg.dataDir && fs.existsSync(cfg.dataDir)) return cfg.dataDir;
        }
    } catch (e) { }
    return ROOT_DIR;
}

const DATA_ROOT = getBasePath();
const MASTER_DB_PATH = path.join(DATA_ROOT, 'Master_Enterprise_DB.xlsx');
const EXCEL_PATH = path.join(DATA_ROOT, 'Plots_Data.xlsx');
const INQUIRIES_PATH = path.join(DATA_ROOT, 'Customer_Inquiries.xlsx');
const TRAINING_DATA_DIR = path.join(DATA_ROOT, 'training_data');
const CUSTOMER_DOCS_DIR = path.join(DATA_ROOT, 'customer_docs');
const IMAGES_DIR = path.join(ROOT_DIR, 'Layout_Images');
// ─── Bot Settings & Configuration ───
const BOT_CONFIG_PATH = path.join(ROOT_DIR, 'bot_settings.json');

// ── OFFLINE REPLAY STATE ──
const _OFFLINE_MARKER_PATH = path.join(ROOT_DIR, '.bot_offline_since');
let _offlineSince = null;                // ms timestamp: when the bot went offline
const _offlineRepliedPhones = new Set(); // phones already queued for offline reply this reconnect
let botSettings = {
    greeting_cooldown_ms: 1000 * 60 * 60 * 48,
    // Note: real admin numbers live in bot_settings.json (configured via Developer Hub → Bot Config).
    // These in-memory defaults are intentionally empty so we never accidentally message a stale number.
    admin_numbers: [],
    primary_admin: "",
    business_keywords: ["plot", "house", "cent", "price", "rate", "layout", "location", "details", "available", "sqft", "map", "brochure", "loan", "bank", "finance", "emi", "call", "time", "morning", "evening", "afternoon", "after", "before", " am", " pm", "visit", "site", "hi", "hello", "hai", "interested"],
    ai_mode: "online",
    system_prompt_file: "Greeting_Message.txt",
    visualizer_url: "https://drdrealtors.github.io/drd-layouts/",
    location_auto_share: true,
    // Conversation context (rolling memory) — configurable from dashboard
    read_previous_messages: true,    // always include recent chat in AI prompt
    memory_turns: 5,                 // exchanges to keep per phone (1 turn = 1 user + 1 bot msg)
    memory_ttl_minutes: 60,          // drop a session after this many minutes idle
    // Admin dispatch safety
    max_media_per_dispatch: 5,       // hard cap on images sent per "share details to" command
    // Auto follow-up nudge — when a customer goes quiet after talking to the bot,
    // send one polite AI-generated nudge a couple of hours later (only during day
    // hours, capped per customer, only if they aren't booked already).
    auto_followup_enabled: true,
    auto_followup_wait_min_minutes: 60,     // min idle minutes before nudge
    auto_followup_wait_max_minutes: 240,    // max idle minutes (after this, treat as gone cold)
    auto_followup_start_hour: 9,            // window start (24h local clock)
    auto_followup_end_hour: 21,             // window end (exclusive)
    auto_followup_max_attempts: 2           // per-customer lifetime cap
};

// Helper: re-read bot_settings.json on demand (UI saves the file directly).
// Cheap to call — settings are small JSON. Always returns current on-disk values.
function getBotSettings() {
    try {
        if (fs.existsSync(BOT_CONFIG_PATH)) {
            const onDisk = JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
            const merged = Object.assign({}, botSettings, onDisk);
            // MD number is always treated as admin — inject into admin_numbers so
            // every existing admin check picks it up automatically.
            if (merged.md_number) {
                const mdClean = String(merged.md_number).replace(/\D/g, '');
                const existing = (merged.admin_numbers || []).map(n => String(n).replace(/\D/g, ''));
                if (mdClean && !existing.includes(mdClean)) {
                    merged.admin_numbers = [...(merged.admin_numbers || []), merged.md_number];
                }
            }
            return merged;
        }
    } catch (e) { /* fall through to defaults */ }
    return botSettings;
}

// ─── AI Automation: command on/off + custom commands ─────────────
// Source of truth: bot_commands.json in ROOT_DIR (managed via dashboard).
// Cached in memory and refreshed on file change so toggles take effect
// without restarting the bot.
const BOT_COMMANDS_PATH = path.join(ROOT_DIR, 'bot_commands.json');
let _cmdCfg = { builtin: {}, custom: [] };
let _cmdCfgMtime = 0;

function _loadCmdCfg() {
    try {
        if (!fs.existsSync(BOT_COMMANDS_PATH)) return;
        const stat = fs.statSync(BOT_COMMANDS_PATH);
        if (stat.mtimeMs === _cmdCfgMtime) return;
        _cmdCfg = JSON.parse(fs.readFileSync(BOT_COMMANDS_PATH, 'utf8'));
        _cmdCfgMtime = stat.mtimeMs;
        if (!_cmdCfg.builtin) _cmdCfg.builtin = {};
        if (!Array.isArray(_cmdCfg.custom)) _cmdCfg.custom = [];
    } catch (e) { console.warn('[CMD_CFG] load failed:', e.message); }
}
_loadCmdCfg();
try { fs.watch(BOT_COMMANDS_PATH, () => _loadCmdCfg()); } catch (_) { /* file may not exist yet */ }

// Returns true if this command is enabled at the global level (legacy single flag).
function isCmdEnabled(id) {
    _loadCmdCfg();
    const entry = (_cmdCfg.builtin || {})[id];
    if (!entry) return true; // unknown id → fail-open
    if (entry.enabled === false) return false;
    // Audience-level disablement: if BOTH admin and staff are false, nobody can run it.
    if (entry.admin === false && entry.staff === false) return false;
    return true;
}

// Returns the human label for a command id (used in disabled replies).
function _cmdLabel(id) {
    const entry = (_cmdCfg.builtin || {})[id];
    return entry && entry.label ? entry.label : id;
}

// Reply with a "disabled" message and return true so caller short-circuits.
async function _replyDisabled(message, id, reason) {
    try {
        const tag = reason || 'disabled';
        await message.reply(`⛔ The *${_cmdLabel(id)}* command is ${tag} in Bot Configuration → AI Automation.`);
    } catch (_) {}
    return true;
}

// Guard helper: in a handler, write
//   if (await _guardCmd(message, 'send_quotation')) return true;
// Returns true when the command should NOT proceed (disabled or not allowed
// for this sender's audience). Audience is determined by checkIfAdmin —
// admins respect entry.admin; everyone else (staff/customer) respects entry.staff.
async function _guardCmd(message, id) {
    _loadCmdCfg();
    const entry = (_cmdCfg.builtin || {})[id];
    if (!entry) return false; // unknown id → fail-open
    if (entry.enabled === false) {
        await _replyDisabled(message, id, 'disabled');
        return true;
    }
    let isAdminSender = false;
    try { isAdminSender = await checkIfAdmin(message); } catch (_) {}
    const allowAdmin = entry.admin !== false; // default ON
    const allowStaff = entry.staff !== false; // default ON
    if (isAdminSender && !allowAdmin) {
        await _replyDisabled(message, id, 'not enabled for Admin');
        return true;
    }
    if (!isAdminSender && !allowStaff) {
        await _replyDisabled(message, id, 'not enabled for Staff');
        return true;
    }
    return false;
}

// Returns all custom commands defined in dashboard. Audience filtering
// (admin vs staff) is applied at match time, not here.
function getCustomCommands() {
    _loadCmdCfg();
    return (_cmdCfg.custom || []).filter(c => c && c.trigger && c.reply);
}

const COMPANY_SETTINGS_FILE = path.join(ROOT_DIR, 'drd_company_settings.json');
let companySettings = {};

function loadCompanySettings() {
    try {
        if (fs.existsSync(COMPANY_SETTINGS_FILE)) {
            companySettings = JSON.parse(fs.readFileSync(COMPANY_SETTINGS_FILE, 'utf8'));
        }
    } catch (e) { }
}

function formatJid(phone) {
    if (!phone) return null;
    let clean = phone.toString().replace(/\D/g, '');
    if (clean.length === 10) clean = '91' + clean;
    return clean.includes('@') ? clean : clean + '@c.us';
}


function loadBotSettings() {
    try {
        if (fs.existsSync(BOT_CONFIG_PATH)) {
            const newSettings = JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
            botSettings = { ...botSettings, ...newSettings };
            console.log("OK: Bot settings loaded from JSON.");
        }
    } catch (e) {
        console.error("Error loading bot settings:", e.message);
    }
}
async function syncToGitHub(fileName) {
    const token = process.env.GITHUB_PAT;
    const repo  = (getBotSettings().github_repo || '').trim();

    if (!token || !repo) {
        console.log('[SYNC] GITHUB_PAT or github_repo not configured — skipping sync');
        return { success: true }; // silent skip; caller shows no error
    }

    // Only sync data files — skip images, ZIPs, etc.
    const isDataFile = /\.(xlsx|json|txt|csv)$/i.test(fileName);
    if (!isDataFile && fileName !== 'Manual_Sync') return { success: true };

    const filesToSync = fileName === 'Manual_Sync'
        ? ['Plots_Data.xlsx', 'Customer_Inquiries.xlsx', 'keyword_rules.json']
        : [fileName];

    const axios = require('axios');
    const headers = { Authorization: `token ${token}`, Accept: 'application/vnd.github.v3+json' };
    const results = [];

    for (const file of filesToSync) {
        try {
            const fp = path.join(ROOT_DIR, file);
            if (!fs.existsSync(fp)) { results.push({ file, ok: false, reason: 'not found locally' }); continue; }
            const content = fs.readFileSync(fp).toString('base64');

            // Get current SHA so GitHub allows update (not just create)
            let sha;
            try {
                const r = await axios.get(`https://api.github.com/repos/${repo}/contents/${encodeURIComponent(file)}`, { headers });
                sha = r.data.sha;
            } catch (_) { /* new file — no SHA needed */ }

            const ts = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour12: false }).replace(',', '');
            await axios.put(
                `https://api.github.com/repos/${repo}/contents/${encodeURIComponent(file)}`,
                { message: `sync: ${file} @ ${ts}`, content, ...(sha ? { sha } : {}) },
                { headers }
            );
            results.push({ file, ok: true });
            console.log(`[SYNC] ✅ Pushed ${file} → ${repo}`);
        } catch (e) {
            const msg = e.response?.data?.message || e.message;
            results.push({ file, ok: false, reason: msg });
            console.error(`[SYNC] ❌ ${file}: ${msg}`);
        }
    }

    const failed = results.filter(r => !r.ok);
    if (!failed.length) return { success: true, synced: results.map(r => r.file) };
    if (failed.length === results.length) return { success: false, error: failed.map(r => `${r.file}: ${r.reason}`).join('; ') };
    return { success: true, partial: true, synced: results.filter(r => r.ok).map(r => r.file), error: failed.map(r => `${r.file}: ${r.reason}`).join('; ') };
}

loadBotSettings();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const AI_MODELS = (botSettings.ai_models || []);
// If for some reason all models were filtered or missing, provide 2026 defaults
if (AI_MODELS.length === 0) {
    AI_MODELS.push('gemini-2.5-flash', 'gemini-2.0-flash');
}
let currentModelIndex = 0;
const GREETING_COOLDOWN_MS = botSettings.greeting_cooldown_ms;
const ADMIN_NUMBERS = botSettings.admin_numbers;

// ─── Analytics Tracker ───
function logLayoutInterest(layoutName) {
    if (!layoutName) return;
    try {
        const analyticsPath = path.join(ROOT_DIR, 'analytics_data.json');
        let data = {};
        if (fs.existsSync(analyticsPath)) {
            data = JSON.parse(fs.readFileSync(analyticsPath, 'utf8'));
        }
        data[layoutName] = (data[layoutName] || 0) + 1;
        fs.writeFileSync(analyticsPath, JSON.stringify(data, null, 2));
    } catch (e) { console.error("Analytics Error:", e); }
}

function logSourceInterest(sourceName) {
    if (!sourceName) return;
    try {
        const analyticsPath = path.join(ROOT_DIR, 'analytics_sources.json');
        let data = {};
        if (fs.existsSync(analyticsPath)) {
            data = JSON.parse(fs.readFileSync(analyticsPath, 'utf8'));
        }
        data[sourceName] = (data[sourceName] || 0) + 1;
        fs.writeFileSync(analyticsPath, JSON.stringify(data, null, 2));
    } catch (e) { console.error("Source Analytics Error:", e); }
}

function notifyModel() {
    if (process.send) {
        process.send({ type: 'model_update', model: AI_MODELS[currentModelIndex] });
    }
}

function getAiModel() {
    const modelName = AI_MODELS[currentModelIndex] || "gemini-2.5-flash";
    if (process.send) process.send({ type: 'aiModel', data: modelName });
    return genAI.getGenerativeModel({ model: modelName });
}
let aiModel = getAiModel();

// Notify immediately on startup
if (process.send) {
    process.send({ type: 'aiModel', data: AI_MODELS[currentModelIndex] || "gemini-2.5-flash" });
}
const { exec } = require('child_process');
const AdmZip = require('adm-zip');

// ─── Master DB Helpers ────────────────────────────────────
// Legacy shim — reads from SQLite, no longer touches Excel
function getMasterData(sheetName) {
    // Synchronous callers still exist; return empty and let async callers use db directly
    return [];
}

// Resolve the human name of the admin/staff member who sent a WhatsApp message.
// Lookup chain (in order): SQLite `staff` table → Master_Enterprise_DB Employees sheet
// → WhatsApp contact pushname/name → never the literal string "Admin".
async function resolveStaffName(rawPhone, message) {
    const phone10 = String(rawPhone || '').replace(/\D/g, '').slice(-10);
    if (!phone10) return await _waContactName(message);

    // 1. SQLite staff (authoritative — kept in sync with dashboard)
    try {
        const row = await new Promise((resolve) => {
            db.get(
                `SELECT name FROM staff
                   WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
                   AND is_active != 0
                 ORDER BY length(phone) DESC LIMIT 1`,
                [`%${phone10}`],
                (err, r) => resolve(err ? null : r)
            );
        });
        if (row && row.name && !/^admin$/i.test(row.name.trim())) return row.name.trim();
    } catch (e) { /* fall through */ }

    // 2. Master_Enterprise_DB Employees sheet (legacy / Excel-managed)
    try {
        const employees = getMasterData('Employees');
        const hit = employees.find(s => (s.Phone || '').toString().replace(/\D/g, '').endsWith(phone10));
        if (hit && hit.Name && !/^admin$/i.test(String(hit.Name).trim())) return String(hit.Name).trim();
    } catch (e) { /* fall through */ }

    // 3. WhatsApp contact (pushname / saved contact name on bot's phone)
    const wa = await _waContactName(message);
    if (wa) return wa;

    // 4. Last resort — generic but not the literal "Admin"
    return 'our team';
}

async function _waContactName(message) {
    try {
        if (!message || typeof message.getContact !== 'function') return null;
        const contact = await message.getContact();
        const cand = (contact && (contact.name || contact.pushname || contact.shortName) || '').trim();
        if (cand && !/^admin$/i.test(cand)) return cand;
    } catch (e) {}
    return null;
}

// ─── Interaction & Greet Logic ────────────────────────────
const lastGreeted = {}; // In-memory cooldown

// ─── AI Lead Scoring & MD Reporting ───
async function analyzeAndScoreLead(phone) {
    const logPath = path.join(TRAINING_DATA_DIR, `${phone.replace(/\D/g, '')}.txt`);
    if (!fs.existsSync(logPath)) return;

    try {
        const history = fs.readFileSync(logPath, 'utf8');
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const prompt = `Analyze this real estate chat history. 
        1. Score the lead intent from 1-10 (10 is ready to buy/visit). 
        2. Summarize their main requirement (budget, location).
        Return ONLY JSON: {"score": 8, "notes": "Highly interested in Anisam Garden, asks about loan."}
        HISTORY: ${sanitizeForAI(history.slice(-4000))}`;

        const result = await model.generateContent(prompt);
        const jsonMatch = result.response.text().match(/\{.*\}/s);
        if (!jsonMatch) return;
        const analysis = JSON.parse(jsonMatch[0]);
        
        db.run(`UPDATE customers SET lead_score = ?, lead_notes = ? WHERE phone = ?`, 
            [analysis.score, analysis.notes, phone.replace(/\D/g, '')]);
        console.log(`[AI SCORE] Phone ${phone} scored ${analysis.score}`);
    } catch (e) { console.error("Lead scoring error:", e.message); }
}

async function sendDailyMDReport() {
    const primaryAdmin = botSettings.primary_admin || "919655766666";
    const today = new Date().toISOString().split('T')[0];

    db.all(`SELECT * FROM customers WHERE lead_score >= 7 AND date(last_interaction) = date('now', 'localtime') ORDER BY lead_score DESC`, [], async (err, rows) => {
        if (err || !rows.length) return;

        let report = `🚀 *DRD Daily Hot Leads Report* (${today})\n\n`;
        rows.forEach((c, i) => {
            report += `${i+1}. *${c.name || 'Unknown'}* (${c.phone})\n`;
            report += `   🔥 Score: ${c.lead_score}/10\n`;
            report += `   📝 Info: ${c.lead_notes || 'No notes'}\n\n`;
        });
        report += `Total high-intent leads today: ${rows.length}`;

        await client.sendMessage(formatJid(primaryAdmin), report);
        console.log("[REPORT] Daily MD report sent.");
    });
}

// ─── Site Visit Booking Logic ───
async function handleSiteVisitBooking(message, phone, userMsg) {
    if (message.fromMe) return false; // Never process the bot's own outgoing messages
    const keywords = ['visit', 'see', 'view', 'காண', 'பார்க்க', 'visit layout'];
    const isVisitRequest = keywords.some(k => userMsg.includes(k));

    if (isVisitRequest && !userStates[phone]?.step) {
        try {
            const layouts = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'layouts_data.json'), 'utf8'));
            const matched = layouts.find(l => userMsg.includes(l.Layout_Name.toLowerCase()));

            if (matched) {
                await message.reply(`📅 We would love to show you *${matched.Layout_Name}*!\n\nPlease reply with your preferred *Date (DD-MM)* and *Time*. \n\nOur site manager will confirm and meet you there.`);
                userStates[phone] = { ...userStates[phone], step: 'BOOKING_VISIT', layout: matched.Layout_Name };
                return true;
            }
        } catch(e) {}
    }

    if (userStates[phone] && userStates[phone].step === 'BOOKING_VISIT') {
        const dateTime = message.body;
        const layout = userStates[phone].layout;
        
        db.run(`INSERT INTO site_visits (customer_phone, layout_name, notes, status) VALUES (?, ?, ?, ?)`,
            [phone, layout, `Requested Slot: ${dateTime}`, 'Pending']);
        
        await message.reply(`✅ *Visit Requested!* \n\nLayout: ${layout}\nSlot: ${dateTime}\n\nOur manager will call you shortly to confirm.`);
        
        // Notify Admin
        const adminMsg = `🚨 *NEW SITE VISIT REQUEST*\n\nCustomer: ${phone}\nLayout: ${layout}\nSlot: ${dateTime}`;
        await client.sendMessage(formatJid(botSettings.primary_admin), adminMsg);
        
        delete userStates[phone].step;
        delete userStates[phone].layout;
        return true;
    }
    return false;
}


async function logConversation(phone, role, text, message) {
    try {
        let idToLog = phone;
        let customerName = null;
        // Try to unmask @lid if possible for cleaner logs
        if (idToLog.includes('@lid') && message) {
            try {
                const contact = await message.getContact();
                if (contact && contact.number) idToLog = contact.number;
                if (contact && (contact.pushname || contact.name)) customerName = contact.pushname || contact.name;
            } catch (e) { }
        }

        const cleanPhone = idToLog.replace(/\D/g, '');
        const logFile = path.join(TRAINING_DATA_DIR, `${cleanPhone}.txt`);
        const entry = `[${new Date().toISOString()}] ${role}: ${text}\n`;

        // 1. Legacy .txt file — still used by the dashboard chat-history viewer.
        try { fs.appendFileSync(logFile, entry); }
        catch (fileErr) { console.error('[LOG] .txt append failed:', fileErr.message); }

        // 2. Structured mirror into the conversations table. Queryable + safe for
        //    !sync backup. Fire-and-forget (don't await the DB callback to keep
        //    the hot reply path snappy).
        try {
            const msgType = (message && message.type) ? String(message.type) : 'text';
            const aiModel = role === 'MODEL' || role === 'BOT'
                ? (AI_MODELS[currentModelIndex] || null)
                : null;
            db.run(
                `INSERT INTO conversations (phone, role, text, message_type, ai_model, customer_name)
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [cleanPhone, role, text || '', msgType, aiModel, customerName],
                (dbErr) => { if (dbErr) console.error('[LOG] DB insert failed:', dbErr.message); }
            );
        } catch (dbWrap) { console.error('[LOG] DB wrap error:', dbWrap.message); }
    } catch (e) { console.error("Logging Error:", e); }
}

async function transcribeAudio(media, phone) {
    try {
        console.log(`[VOICE] Transcribing audio from ${phone}...`);
        const model = genAI.getGenerativeModel({ model: AI_MODELS[0] || 'gemini-2.5-flash' });
        const result = await model.generateContent([
            { inlineData: { mimeType: media.mimetype, data: media.data } },
            'Transcribe this audio message exactly as spoken. Return only the transcription text, nothing else.'
        ]);
        const text = result.response.text().trim();
        console.log(`[VOICE] ✅ Transcribed: "${text.substring(0, 80)}"`);
        return text;
    } catch (e) {
        logError('TRANSCRIPTION', e);
        return null;
    }
}

function checkCustomer(phone) {
    const cleanPhone = phone.replace(/\D/g, '');
    const customers = getMasterData('Customers');
    return customers.find(c => String(c.Phone).replace(/\D/g, '') === cleanPhone);
}

function logInquiryToExcel(phone, details) {
    const filePath = INQUIRIES_PATH;
    let workbook;

    const cleanPhone = (typeof phone === 'string' && phone.includes('@'))
        ? phone.split('@')[0]
        : phone;

    const newEntry = {
        'Date': new Date().toISOString().slice(0, 19).replace('T', ' '),  // UTC, parseable by timeAgo
        'Phone': cleanPhone,
        'Name': details.name || 'Unknown',
        'Project': details.layout || 'General Inquiry',
        'Budget': details.budget || 'Pending',
        'Loan Required': details.loan || 'Pending',
        'Last Message': details.lastMsg || '',
        'Highlighted': details.highlighted ? 'YES' : 'NO'
    };

    db.get(`SELECT id FROM customers WHERE phone = ?`, [cleanPhone], (err, existing) => {
        db.run(`INSERT INTO customers (phone, name, plot, status, highlighted, created_at, last_interaction)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(phone) DO UPDATE SET
                  name = CASE WHEN excluded.name NOT IN ('Unknown','Customer','') THEN excluded.name ELSE customers.name END,
                  plot = CASE WHEN excluded.plot NOT IN ('General Inquiry','Inquiry','') THEN excluded.plot ELSE customers.plot END,
                  status = CASE WHEN customers.status IN ('Purchased','Booked') THEN customers.status ELSE excluded.status END,
                  highlighted = excluded.highlighted | customers.highlighted,
                  last_interaction = CURRENT_TIMESTAMP`,
            [cleanPhone, details.name || 'Unknown', details.layout || 'General Inquiry', 'Inquiry', details.highlighted || 0, new Date().toISOString()],
            (runErr) => {
                if (runErr) { console.error('[BOT] logInquiry SQLite error:', runErr.message); return; }
                if (!existing) {
                    scheduleDripCampaigns(cleanPhone);
                    scheduleFollowUps(cleanPhone, details.name);
                }
            });
    });
}

function scheduleFollowUps(phone, name) {
    const followUps = [
        { days: 1, text: `Hi ${name || 'there'}! 👋 Do you need any more details about the property? We're happy to help. 🏡` },
        { days: 3, text: `Hi ${name || 'there'}! 📅 Would you like to schedule a site visit? Our team is available this week. Let us know your preferred time!` },
        { days: 7, text: `Hi ${name || 'there'}! 🌟 We have some exciting new layout options at DRD Realtors. Shall I send you the latest brochure?` },
    ];
    followUps.forEach(({ days, text }) => {
        const scheduledDate = new Date();
        scheduledDate.setDate(scheduledDate.getDate() + days);
        const dateStr = scheduledDate.toISOString().split('T')[0];
        // INSERT OR IGNORE prevents duplicate follow-ups if the customer messages again
        db.run(`INSERT OR IGNORE INTO scheduled_messages (customer_phone, message_text, scheduled_date, status) VALUES (?, ?, ?, 'Pending')`,
            [phone, text, dateStr],
            (err) => { if (!err) console.log(`[FOLLOW-UP] Scheduled T+${days}d for ${phone} on ${dateStr}`); });
    });
}

async function handlePaymentConfirmation(phone, message) {
    const cleanPhone = phone.replace(/\D/g, '');
    db.get(`SELECT * FROM payment_requests WHERE phone = ? AND status = 'Sent' ORDER BY created_at DESC LIMIT 1`,
        [cleanPhone],
        async (err, req) => {
            if (err || !req) return;
            const name = req.name || cleanPhone;
            const adminJid = (ADMIN_NUMBERS[0] || '').includes('@') ? ADMIN_NUMBERS[0] : (ADMIN_NUMBERS[0] + '@c.us');
            try {
                await client.sendMessage(adminJid,
                    `💰 *Payment Confirmation Received*\n\nFrom: *${name}* (${cleanPhone})\nAmount: ₹${req.amount}\nPurpose: ${req.purpose || 'N/A'}\n\n_Please verify and confirm._`);
                if (message.type === 'image') {
                    try {
                        const media = await message.downloadMedia();
                        if (media) await client.sendMessage(adminJid, media, { caption: `📎 Screenshot from ${name} (${cleanPhone})` });
                    } catch (e) { }
                }
                db.run(`UPDATE payment_requests SET status = 'Verification Pending', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [req.id]);
                console.log(`[PAYMENT] ✅ Admin notified for payment from ${cleanPhone}`);
            } catch (e) {
                console.error(`[PAYMENT] Failed to notify admin: ${e.message}`);
            }
        });
}

function logAIUsageToExcel(modelName) {
    const today = new Date().toLocaleDateString('en-GB');
    db.run(`INSERT INTO ai_usage (model, date, requests) VALUES (?, ?, 1)
            ON CONFLICT(model, date) DO UPDATE SET requests = requests + 1`,
        [modelName, today],
        (err) => { if (err) console.error('[BOT] AI usage log error:', err.message); });
}

function getPlotsData() {
    return new Promise((resolve, reject) => {
        db.all("SELECT * FROM plots", [], (err, rows) => {
            if (err) {
                console.error("SQLite plots error:", err);
                return resolve([]);
            }
            const mapped = rows.map(r => ({
                Layout_Name: r.layout_name,
                Plot_No: r.plot_no,
                Area_SqFt: r.size,
                Facing: r.facing,
                Status: r.status,
                Total_Price: r.price,
                Location: r.location
            }));
            resolve(mapped);
        });
    });
}

function findVisualForLayout(layoutName, searchDir) {
    if (!fs.existsSync(searchDir)) return null;
    const items = fs.readdirSync(searchDir, { withFileTypes: true });
    let target = items.find(i => {
        const lWords = layoutName.toLowerCase().match(/\b\w+\b/g) || [];
        const fWords = i.name.toLowerCase().match(/\b\w+\b/g) || [];
        const ignore = ['drd', 'layouts', 'layout', 'all', 'the', 'phase', 'plan', 'pdf'];
        const lSig = lWords.filter(w => !ignore.includes(w) && w.length > 2);
        const fSig = fWords.filter(w => !ignore.includes(w) && w.length > 2);
        if (lSig.length === 0 || fSig.length === 0) return false;
        return fSig.some(fw => lSig.includes(fw));
    });

    if (!target) return null;

    const ALLOWED_EXTS = ['.jpg', '.jpeg', '.png', '.webp', '.mp4', '.pdf'];
    const MAX_SIZE_MB = 16;

    let fullPath = path.join(searchDir, target.name);
    if (target.isDirectory()) {
        const files = fs.readdirSync(fullPath);
        let sendableFiles = files.filter(f => {
            const ext = path.extname(f).toLowerCase();
            if (!ALLOWED_EXTS.includes(ext)) return false;
            if (f.startsWith('~$')) return false; // Skip temporary files
            try {
                const stats = fs.statSync(path.join(fullPath, f));
                return stats.size < MAX_SIZE_MB * 1024 * 1024;
            } catch (e) { return false; }
        });
        if (sendableFiles.length > 0) return { type: 'directory', path: fullPath, files: sendableFiles };
        return null;
    } else {
        const ext = path.extname(target.name).toLowerCase();
        if (ALLOWED_EXTS.includes(ext) && !target.name.startsWith('~$')) {
            try {
                const stats = fs.statSync(fullPath);
                if (stats.size < MAX_SIZE_MB * 1024 * 1024) return { type: 'file', path: fullPath };
            } catch (e) { }
        }
        return null;
    }
}

async function sendTaglineImage(phone, client) {
    try {
        const p = path.join(IMAGES_DIR, '02 DRD Taglines');
        if (fs.existsSync(p)) {
            const files = fs.readdirSync(p);
            if (files.length > 0) {
                const rnd = files[Math.floor(Math.random() * files.length)];
                const media = MessageMedia.fromFilePath(path.join(p, rnd));
                await new Promise(r => setTimeout(r, 5000));
                await client.sendMessage(phone, media);
            }
        }
    } catch (err) {
        console.error("Error sending tagline:", err.message);
    }
}

async function sendContactVCF(phone) {
    try {
        loadCompanySettings();
        const name   = (companySettings.companyName || 'DRD Realtors').trim();
        const tel1   = (companySettings.phone  || '9655766666').replace(/\D/g, '');
        const tel2   = (companySettings.phone2 || '').replace(/\D/g, '');
        const email  = companySettings.email   || '';
        const addr   = companySettings.address || '99/1 Selvam Square, Siruvani Main Road, Coimbatore 641101';
        const web    = companySettings.website || '';
        const tag    = companySettings.tagline || '';

        const e164 = n => n.length === 10 ? `+91${n}` : `+${n}`;

        let vcf = `BEGIN:VCARD\r\nVERSION:3.0\r\n`;
        vcf += `FN:${name}\r\n`;
        vcf += `ORG:${name}\r\n`;
        vcf += `TEL;TYPE=CELL,VOICE:${e164(tel1)}\r\n`;
        if (tel2) vcf += `TEL;TYPE=CELL,VOICE:${e164(tel2)}\r\n`;
        if (email) vcf += `EMAIL;TYPE=INTERNET:${email}\r\n`;
        if (addr)  vcf += `ADR;TYPE=WORK:;;${addr};;;;\r\n`;
        if (web)   vcf += `URL:${web.startsWith('http') ? web : 'https://' + web}\r\n`;
        if (tag)   vcf += `NOTE:${tag}\r\n`;
        vcf += `END:VCARD`;

        const media = new MessageMedia(
            'text/x-vcard',
            Buffer.from(vcf).toString('base64'),
            `${name.replace(/\s+/g, '_')}.vcf`
        );
        await client.sendMessage(phone,
            `💾 *Save our contact for quick access*\n_Tap the card below to add — works on Android & iPhone_ 📱`);
        await new Promise(r => setTimeout(r, 600));
        await client.sendMessage(phone, media);
        console.log(`[VCF] Contact card sent to ${phone}`);
    } catch (e) {
        console.error('[VCF] Failed to send contact card:', e.message);
    }
}

function getSystemPrompt() {
    loadCompanySettings();
    const addr = companySettings.address || "99/1, Selvam Square, Siruvani Main Road, Coimbatore";
    const maps = companySettings.mapsUrl || "https://maps.app.goo.gl/Hqi59j65sgkRmYqz8";
    const tagline = companySettings.tagline || "";

    const base = `You are a senior property consultant named Property Genius from DRD Realtors.

    CRITICAL RULES:
    1. NEVER admit to being an AI. Respond professionally in the language the customer uses (English or Tamil/தமிழ்).
    2. Your tone should be professional yet approachable, like a real estate expert.
    3. If they ask about site visits, tell them you can schedule it and ask for their preferred date and time.
    4. If the customer expresses interest in a site visit or wants to discuss specifics over the phone, include the tag [HIGHLIGHT] in your response.
    5. If they ask for a callback, include both [HIGHLIGHT] and [REQUEST_CALL].
    6. Use the provided PLOT_DATA and PROJECT_KNOWLEDGE to provide precise details.
    7. NEVER proactively mention prices, price ranges, or rates unless the customer explicitly asks about price, rate, cost, budget, or EMI. For general enquiries, focus on availability, features, and scheduling a site visit first.
    IDENTITY:
    - Name: Property Genius
    - Company: DRD Realtors
    - Tagline: ${tagline}

    PLOT DATA: {PLOT_DATA}
    BROCHURE KNOWLEDGE: {PROJECT_KNOWLEDGE}`;
    
    try {
        let fileContent = fs.readFileSync(path.join(ROOT_DIR, 'Greeting_Message.txt'), 'utf8');
        // Inject company info into the custom instructions if placeholders exist
        fileContent = fileContent.replace('{COMPANY_ADDRESS}', addr).replace('{COMPANY_MAPS_URL}', maps);
        return base + "\n\nCUSTOM INSTRUCTIONS:\n" + fileContent;
    } catch (e) {
        return base;
    }
}


// ─── PII EGRESS FILTER ────────────────────────────────────────
// Strip customer-identifying data before any text reaches the Gemini API.
// Internal storage (SQLite, Excel, logs) retains full data — this is egress-only.
function sanitizeForAI(text) {
    if (!text || typeof text !== 'string') return text;
    return text
        .replace(/\b(?:\+91[-\s]?|91[-\s]?)?[6-9]\d{9}\b/g, '[PHONE]')
        .replace(/\b\d{10,12}@c\.us\b/g, '[PHONE]')
        .replace(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g, '[EMAIL]')
        .replace(/\b[a-zA-Z0-9._\-]+@[a-zA-Z0-9]+\b(?!\.[a-zA-Z]{2,})/g, '[UPI]')
        .replace(/\b(?:my name is|i am|i'm|this is)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gi, 'this is [NAME]');
}

// Browser detection for Windows / Linux
function findExecutable(dir, name) {
    if (!fs.existsSync(dir)) return null;
    const files = fs.readdirSync(dir, { withFileTypes: true });
    for (const f of files) {
        const full = path.join(dir, f.name);
        if (f.isDirectory()) {
            const found = findExecutable(full, name);
            if (found) return found;
        } else if (f.name.toLowerCase() === name.toLowerCase()) {
            return full;
        }
    }
    return null;
}

let executablePath = undefined;
if (process.platform === 'win32') {
    // 1. Check Portable Folders First (Recursive search)
    const portableFolders = [
        path.join(ROOT_DIR, 'chrome-win'),
        path.join(ROOT_DIR, 'portable_chrome'),
        path.join(ROOT_DIR, 'node_modules', 'puppeteer', '.local-chromium')
    ];

    for (const folder of portableFolders) {
        const found = findExecutable(folder, 'chrome.exe');
        if (found) {
            executablePath = found;
            console.log("BROWSER: Portable Chrome found at: " + found);
            break;
        }
    }

    // 2. Check System Paths if not found (Chrome first, then Edge which is always on Win10/11)
    if (!executablePath) {
        const winPaths = [
            // Google Chrome
            'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
            'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
            path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe'),
            // Microsoft Edge (pre-installed on ALL Windows 10/11 machines)
            'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
            'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
            path.join(process.env.LOCALAPPDATA || '', 'Microsoft\\Edge\\Application\\msedge.exe'),
        ];
        for (const p of winPaths) {
            if (fs.existsSync(p)) {
                executablePath = p;
                console.log("BROWSER: Browser found at: " + p);
                break;
            }
        }
    }
} else {
    // Linux logic
    const portableFolders = [
        path.join(ROOT_DIR, 'chrome-linux'),
        path.join(ROOT_DIR, 'node_modules', 'puppeteer', '.local-chromium')
    ];
    for (const folder of portableFolders) {
        const found = findExecutable(folder, 'chrome');
        if (found) {
            executablePath = found;
            console.log("BROWSER: Portable Chromium found at: " + found);
            break;
        }
    }

    if (!executablePath) {
        const linuxPaths = [
            '/usr/bin/google-chrome-stable',
            '/usr/bin/chromium-browser',
            '/usr/bin/chrome'
        ];
        for (const p of linuxPaths) {
            if (fs.existsSync(p)) {
                executablePath = p;
                console.log("BROWSER: System Chrome found at: " + p);
                break;
            }
        }
    }
}

if (!executablePath) {
    console.log("BROWSER: No system browser found in common paths. Using Puppeteer's default.");
}


const client = new Client({
    authStrategy: new LocalAuth({
        clientId: "drd_bot_1",
        dataPath: path.join(ROOT_DIR, '.wwebjs_auth')
    }),
    webVersionCache: { type: 'none' },
    puppeteer: {
        headless: false,
        executablePath: executablePath,
        args: [
            '--app=https://web.whatsapp.com',
            '--window-size=1280,720',
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--disable-gpu',
            '--disable-gpu-sandbox',
            '--disable-software-rasterizer',
            '--disable-extensions'
        ]
    }
});

// ── Connection watchdog ───────────────────────────────────────────────────────
// If no QR, authenticated, or ready signal arrives within 90s after initialize(),
// the saved session is stale (WhatsApp invalidated it silently server-side).
// Clear the session and exit so server.js respawns bot with a fresh QR.
let _initWatchdog = null;
function _clearWatchdog() { if (_initWatchdog) { clearTimeout(_initWatchdog); _initWatchdog = null; } }
function _startWatchdog() {
    _clearWatchdog();
    // 5-minute timeout — Chrome on Windows can be slow to load WhatsApp Web,
    // especially on first launch or after a reboot. 90s was too aggressive and
    // was deleting the session unnecessarily, forcing full QR re-scans.
    _initWatchdog = setTimeout(() => {
        console.log('⚠️ WATCHDOG: No response from WhatsApp in 5 min — restarting without clearing session…');
        if (process.send) process.send({ type: 'disconnected' });
        setTimeout(() => process.exit(1), 1000);
    }, 300000);
}

client.on('qr', qr => {
    _clearWatchdog(); // Got QR — not stuck
    console.log("LOGIN: Scan QR Code:");
    qrcode.generate(qr, { small: true });
    if (process.send) process.send({ type: 'qr', data: qr });
});

let _readyFired = false;
let _forceInterval = null;

client.on('authenticated', () => {
    _clearWatchdog(); // Session restored — not stuck
    console.log('🔐 WhatsApp session authenticated.');
    if (process.send) process.send({ type: 'log', data: '[BOT] Authenticated — polling for NORMAL state every 5s...' });

    if (_forceInterval) { clearInterval(_forceInterval); _forceInterval = null; }
    let _attempts = 0;
    _forceInterval = setInterval(async () => {
        if (_readyFired) { clearInterval(_forceInterval); _forceInterval = null; return; }
        _attempts++;
        try {
            const state = await client.getState().catch(() => 'UNKNOWN');
            const page = client.pupPage;
            const url = page ? (page.url().includes('web.whatsapp.com') ? 'WA' : page.url()) : 'none';
            if (process.send) process.send({ type: 'log', data: `[BOT-DIAG] ${_attempts * 5}s — state=${state} url=${url}` });

            if (state === 'NORMAL' && !_readyFired) {
                clearInterval(_forceInterval); _forceInterval = null;
                if (process.send) process.send({ type: 'log', data: '[BOT] NORMAL state confirmed — forcing ready flow' });
                _readyFired = true;
                let number = null;
                try { if (client.info && client.info.wid) number = client.info.wid.user; } catch(e) {}
                globalAdminNumber = (number || '') + "@c.us";
                if (process.send) process.send({ type: 'connected', number });
                notifyModel();
                scheduleMdReports();
                setInterval(() => { if (process.send) process.send({ type: 'heartbeat' }); }, 30000);
            }
        } catch(e) {
            if (process.send) process.send({ type: 'log', data: `[BOT-DIAG] ${_attempts * 5}s — probe error: ${e.message}` });
        }
        // After 45s without NORMAL state, reload the page and keep polling
        if (_attempts === 9 && !_readyFired) {
            try {
                const page = client.pupPage;
                if (page && !page.isClosed()) {
                    if (process.send) process.send({ type: 'log', data: '[BOT] 45s timeout — reloading WhatsApp page...' });
                    page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(()=>{});
                }
            } catch(e) {}
        }
        // After 90s without NORMAL state — restart without clearing session.
        // WhatsApp sometimes needs an extra reload to come up; clearing the session
        // forces a full QR re-scan which is disruptive. Only auth_failure/LOGOUT/UNPAIRED
        // should delete the session.
        if (_attempts >= 18 && !_readyFired) {
            clearInterval(_forceInterval); _forceInterval = null;
            if (process.send) process.send({ type: 'log', data: '[BOT] 90s timeout — restarting without clearing session...' });
            if (process.send) process.send({ type: 'disconnected' });
            setTimeout(() => process.exit(1), 1000);
        }
    }, 5000);
});

client.on('auth_failure', (msg) => {
    _clearWatchdog();
    console.log(`❌ Auth failure: ${msg} — clearing stale session and restarting…`);
    try {
        const sp = path.join(ROOT_DIR, '.wwebjs_auth', 'session-drd_bot_1');
        if (fs.existsSync(sp)) fs.rmSync(sp, { recursive: true, force: true });
    } catch (e) {}
    if (process.send) process.send({ type: 'disconnected' });
    setTimeout(() => process.exit(1), 1500);
});

let globalAdminNumber = null;

client.on('ready', async () => {
    _readyFired = true;
    if (_forceInterval) { clearInterval(_forceInterval); _forceInterval = null; }
    console.log('OK: DRD Bot is READY!');
    // Send connected status immediately — before any risky page operations
    const info = client.info;
    const number = info ? info.wid.user : null;
    globalAdminNumber = (number || '') + "@c.us";
    if (process.send) process.send({ type: 'connected', number });
    notifyModel();
    scheduleMdReports();
    setInterval(() => { if (process.send) process.send({ type: 'heartbeat' }); }, 30000);
    // Optional cosmetic: rename the WhatsApp tab title
    try {
        const page = client.pupPage;
        if (page) await page.evaluate(() => { document.title = "DRD Property Genius - Control Panel"; });
    } catch (e) { }

    // ── OFFLINE REPLAY: read offline marker written by previous process on disconnect ──
    try {
        if (fs.existsSync(_OFFLINE_MARKER_PATH)) {
            const raw = fs.readFileSync(_OFFLINE_MARKER_PATH, 'utf8').trim();
            const ts = parseInt(raw, 10);
            if (ts && !isNaN(ts) && ts > 0) {
                _offlineSince = ts;
                const gapMin = Math.round((Date.now() - ts) / 60000);
                console.log(`[OFFLINE-REPLAY] Detected offline gap of ~${gapMin} min. Will process unhandled customer messages from that window.`);
                // Auto-clear after 10 min — all buffered messages will have been delivered by then
                setTimeout(() => { _offlineSince = null; _offlineRepliedPhones.clear(); }, 10 * 60 * 1000);
            }
            try { fs.unlinkSync(_OFFLINE_MARKER_PATH); } catch (_) {}
        }
    } catch (e) { console.warn('[OFFLINE-REPLAY] Could not read offline marker:', e.message); }
});

function scheduleMdReports() {
    setInterval(async () => {
        const now = new Date();
        const time = now.getHours() + ":" + now.getMinutes();
        
        // Morning Pulse: 9:00 AM
        // Night Wrap-up: 9:00 PM
        if (time === "9:0" || time === "21:0") {
            const staff = getMasterData('Staff');
            const md = staff.find(s => s.Dept === 'Managing Director');
            if (md) {
                console.log(`[SCHEDULE] Sending ${time === "9:0" ? "Morning" : "Night"} report to MD...`);
                const report = await generateSystemReport();
                const jid = String(md.Phone).replace(/\D/g, '') + '@c.us';
                await client.sendMessage(jid, `⏰ *SCHEDULED ${time === "9:0" ? "MORNING" : "NIGHT"} REPORT*\n\n` + report);
            }
        }
    }, 60000); // Check every minute
}

client.on('disconnected', (reason) => {
    _clearWatchdog();
    console.log(`❌ Disconnected: ${reason}`);
    if (process.send) process.send({ type: 'disconnected' });
    if (reason === 'LOGOUT' || reason === 'UNPAIRED') {
        console.log('🧹 Session invalidated — clearing .wwebjs_auth for clean reconnect…');
        try {
            const sp = path.join(ROOT_DIR, '.wwebjs_auth', 'session-drd_bot_1');
            if (fs.existsSync(sp)) fs.rmSync(sp, { recursive: true, force: true });
        } catch (e) { console.error('Session cleanup error:', e.message); }
    }
    // Persist offline start time so the next process can replay missed customer messages.
    try { fs.writeFileSync(_OFFLINE_MARKER_PATH, String(Date.now())); } catch (_) {}
    // Exit cleanly so the server can restart us in 10s.
    // Without this, the process stays alive doing nothing until the server-side
    // 2-min heartbeat watchdog eventually kills it — causing unnecessary delay.
    setTimeout(() => process.exit(0), 3000);
});


const chatHistories = {};
const userStates = {};
const sessionMemory = new Map(); // { phone: { messages: [{role,text}], lastActivity: timestamp } }

function updateSessionMemory(phone, role, text) {
    if (!sessionMemory.has(phone)) {
        sessionMemory.set(phone, { messages: [], lastActivity: Date.now() });
    }
    const session = sessionMemory.get(phone);
    session.messages.push({ role, text });
    // memory_turns from settings: 1 turn = 1 user msg + 1 bot reply → cap entries at turns*2
    const turns = Math.max(1, parseInt(getBotSettings().memory_turns) || 5);
    const cap   = turns * 2;
    while (session.messages.length > cap) session.messages.shift();
    session.lastActivity = Date.now();
}

// Prune idle sessions every 5 minutes; idle threshold comes from settings.
// When auto-follow-up is enabled, give still-eligible sessions a longer leash
// so the sweeper has a chance to send the nudge before TTL wipes them.
setInterval(() => {
    const settings = getBotSettings();
    const ttlMin = Math.max(1, parseInt(settings.memory_ttl_minutes) || 60);
    const autoFuOn = settings.auto_followup_enabled !== false;
    const maxAttempts = parseInt(settings.auto_followup_max_attempts ?? 2, 10);
    const fuMax = parseInt(settings.auto_followup_wait_max_minutes ?? 240, 10);
    const normalCutoff = Date.now() - (ttlMin * 60 * 1000);
    const extendedCutoff = Date.now() - (Math.max(ttlMin, fuMax + 30) * 60 * 1000);

    for (const [phone, session] of sessionMemory) {
        const attempts = session._autoFollowupAttempts || 0;
        const cutoffForThis = (autoFuOn && attempts < maxAttempts) ? extendedCutoff : normalCutoff;
        if (session.lastActivity < cutoffForThis) {
            sessionMemory.delete(phone);
            if (chatHistories[phone]) delete chatHistories[phone];
            console.log(`[SESSION] Expired context cleared for ${phone}`);
        }
    }
}, 5 * 60 * 1000);

// ─── AUTO FOLLOW-UP SWEEPER ───────────────────────────────────
// Every 5 min: find customers whose last conversation turn was a BOT reply
// 60-240 min ago, ask Gemini for a 1-sentence nudge based on the chat, send
// it, and log to the followups table. Hard-capped to maxAttempts per customer
// and ~5 sends per sweep to avoid blasting the queue after a slow period.
async function autoFollowupSweep() {
    try {
        const settings = getBotSettings();
        if (settings.auto_followup_enabled === false) return;
        if (typeof client === 'undefined' || !client?.info?.wid) return;  // bot not ready

        const now = new Date();
        const hour = now.getHours();
        const startHour = parseInt(settings.auto_followup_start_hour ?? 9, 10);
        const endHour   = parseInt(settings.auto_followup_end_hour   ?? 21, 10);
        if (hour < startHour || hour >= endHour) return;

        const waitMinMs = parseInt(settings.auto_followup_wait_min_minutes ?? 60, 10) * 60000;
        const waitMaxMs = parseInt(settings.auto_followup_wait_max_minutes ?? 240, 10) * 60000;
        const maxAttempts = parseInt(settings.auto_followup_max_attempts ?? 2, 10);
        const MAX_PER_SWEEP = 5;
        let sentThisSweep = 0;

        const adminNums = (settings.admin_numbers || []).map(n => String(n).replace(/\D/g, '')).filter(Boolean);

        for (const [phone, session] of sessionMemory) {
            if (sentThisSweep >= MAX_PER_SWEEP) break;
            try {
                const msgs = session.messages || [];
                if (!msgs.length) continue;

                // Only nudge when the LAST message was from the bot (i.e. customer hasn't replied yet)
                const lastMsg = msgs[msgs.length - 1];
                if ((lastMsg.role || '').toUpperCase() === 'USER') continue;

                // Per-customer lifetime cap
                if ((session._autoFollowupAttempts || 0) >= maxAttempts) continue;

                // Time window
                const idleMs = Date.now() - (session.lastActivity || 0);
                if (idleMs < waitMinMs || idleMs > waitMaxMs) continue;

                // Skip admin numbers
                const clean = String(phone).replace(/\D/g, '');
                if (adminNums.some(a => a && clean.includes(a))) continue;

                const phone10 = clean.slice(-10);

                // Skip booked / purchased customers
                const cust = await new Promise(r =>
                    db.get(`SELECT status FROM customers WHERE phone = ? LIMIT 1`,
                        [phone10], (e, row) => r(row || null)));
                const lcStatus = ((cust && cust.status) || '').toLowerCase();
                if (['booked', 'purchased', 'site visit done'].includes(lcStatus)) continue;

                // Skip if a manual follow-up is already scheduled
                const pendingFu = await new Promise(r =>
                    db.get(`SELECT id FROM followups WHERE customer_phone = ? AND status = 'Pending' AND date(next_followup) >= date('now') LIMIT 1`,
                        [phone10], (e, row) => r(row || null)));
                if (pendingFu) continue;

                // Skip if staff has claimed this conversation
                const cp12auto = '91' + phone10;
                const claimedAuto = await new Promise(r =>
                    db.get(`SELECT id FROM conversation_claims WHERE (customer_phone = ? OR customer_phone = ?) AND status = 'Active'`,
                        [phone10, cp12auto], (e, row) => r(row || null)));
                if (claimedAuto) { console.log(`[AUTO-FU] Skipping ${phone10} — conversation claimed by staff`); continue; }

                // Skip if we already sent an auto-nudge today, or hit lifetime cap from DB
                const counts = await new Promise(r =>
                    db.get(`SELECT
                              SUM(CASE WHEN date(created_at) = date('now') THEN 1 ELSE 0 END) AS today_count,
                              COUNT(*) AS total_count
                            FROM followups WHERE customer_phone = ? AND staff_name = 'AI_AUTO'`,
                        [phone10], (e, row) => r(row || { today_count: 0, total_count: 0 })));
                if ((counts.today_count || 0) > 0) continue;
                if ((counts.total_count || 0) >= maxAttempts) continue;

                // Build a tiny transcript for Gemini
                const transcript = msgs.slice(-6).map(m =>
                    `${(m.role || '').toUpperCase() === 'USER' ? 'Customer' : 'Bot'}: ${sanitizeForAI(m.text)}`
                ).join('\n');
                const idleMin = Math.round(idleMs / 60000);

                const prompt = `You write polite WhatsApp follow-up nudges for DRD Realtors, a real estate company in Tamil Nadu.

Below is a chat between a customer and our bot. The customer went quiet about ${idleMin} minutes ago. Write ONE friendly, helpful sentence in English (under 30 words) that moves the conversation forward — examples: "Would tomorrow 4 PM work for a quick site visit?" / "What's a good time to call you today?" / "Want me to share our brochure for the layout you liked?".

Rules:
- Reply ONLY with the single sentence, no greeting, no signature, no quotes.
- Don't say "I noticed you went quiet" or anything passive-aggressive.
- Stay in English even if the chat was in Tamil/Tanglish.

Recent conversation:
${transcript}

Your nudge:`;

                let nudge = '';
                try {
                    const model = genAI.getGenerativeModel({ model: AI_MODELS[0] || 'gemini-2.5-flash' });
                    const res = await model.generateContent(prompt);
                    nudge = (res.response.text() || '').trim().replace(/^["'`]+|["'`]+$/g, '');
                } catch (gerr) {
                    console.warn('[AUTOFU] Gemini failed for', phone10, '-', gerr.message);
                    continue;
                }
                if (!nudge || nudge.length > 280) continue;

                // Send and log
                try {
                    await client.sendMessage(phone, nudge);
                    updateSessionMemory(phone, 'BOT', nudge);
                    session._autoFollowupAttempts = (session._autoFollowupAttempts || 0) + 1;
                    db.run(
                        `INSERT INTO followups (customer_phone, staff_name, notes, next_followup, status)
                         VALUES (?, 'AI_AUTO', ?, date('now'), 'Sent by AI')`,
                        [phone10, `[Auto-nudge after ${idleMin}m idle] ${nudge}`]);
                    sentThisSweep++;
                    console.log(`[AUTOFU] Nudge to ${phone10}: ${nudge}`);
                    await new Promise(r => setTimeout(r, 2000));  // pace sends
                } catch (sendErr) {
                    console.warn('[AUTOFU] Send failed:', sendErr.message);
                }
            } catch (perCustomerErr) {
                console.warn('[AUTOFU] Per-customer error:', perCustomerErr.message);
            }
        }

        if (sentThisSweep) console.log(`[AUTOFU] Sweep done — ${sentThisSweep} nudge(s) sent`);
    } catch (err) {
        console.error('[AUTOFU] Sweep error:', err.message);
    }
}
setInterval(autoFollowupSweep, 5 * 60 * 1000);  // every 5 min

// ─── DB-BASED 2-HOUR FOLLOW-UP SWEEPER ───────────────────────────────────
// Runs every 10 min. Reads conversations table (persists across restarts) to
// find customers whose LAST message was a BOT reply exactly 2-2.5 hours ago
// with no customer reply since. Generates a context-aware nudge via Gemini.
async function dbTwoHourFollowupSweep() {
    try {
        const settings = getBotSettings();
        if (settings.auto_followup_enabled === false) return;
        if (typeof client === 'undefined' || !client?.info?.wid) return;

        const hour = new Date().getHours();
        const startHour = parseInt(settings.auto_followup_start_hour ?? 9, 10);
        const endHour   = parseInt(settings.auto_followup_end_hour   ?? 21, 10);
        if (hour < startHour || hour >= endHour) return;

        const adminNums = (settings.admin_numbers || []).map(n => String(n).replace(/\D/g, '')).filter(Boolean);
        const MAX_PER_SWEEP = 3;

        // Find phones: last message in conversations was a BOT reply 2–2.5 hrs ago,
        // and no customer message has arrived since.
        const candidates = await new Promise(r =>
            db.all(
                `SELECT phone,
                        MAX(CASE WHEN UPPER(role)='BOT' THEN created_at END) AS last_bot_time
                 FROM conversations
                 WHERE created_at > datetime('now','-3 hours')
                 GROUP BY phone
                 HAVING last_bot_time IS NOT NULL
                   AND last_bot_time <= datetime('now','-2 hours')
                   AND last_bot_time >= datetime('now','-2.5 hours')
                   AND MAX(CASE WHEN UPPER(role)='USER' THEN created_at END) < last_bot_time`,
                [], (e, rows) => r(rows || []))
        );
        if (!candidates.length) return;

        let sentThisSweep = 0;
        for (const cand of candidates) {
            if (sentThisSweep >= MAX_PER_SWEEP) break;
            try {
                const phone10 = String(cand.phone || '').replace(/\D/g, '').slice(-10);
                if (!phone10) continue;
                if (adminNums.some(a => a && phone10.includes(a.slice(-10)))) continue;

                // Skip if session is already being handled by the in-memory sweeper
                if (sessionMemory.has(`91${phone10}@c.us`) || sessionMemory.has(`${phone10}@c.us`)) continue;

                // Skip booked/purchased
                const cust = await new Promise(r =>
                    db.get(`SELECT status FROM customers WHERE phone = ? LIMIT 1`,
                        [phone10], (e, row) => r(row || null)));
                const lcSt = ((cust && cust.status) || '').toLowerCase();
                if (['booked','purchased','site visit done','not interested','junk'].includes(lcSt)) continue;

                // Skip if already sent AI_AUTO nudge today
                const alreadySent = await new Promise(r =>
                    db.get(`SELECT id FROM followups WHERE customer_phone = ? AND staff_name = 'AI_AUTO' AND date(created_at) = date('now') LIMIT 1`,
                        [phone10], (e, row) => r(row || null)));
                if (alreadySent) continue;

                // Skip if staff claimed conversation
                const cp12 = '91' + phone10;
                const claimed = await new Promise(r =>
                    db.get(`SELECT id FROM conversation_claims WHERE (customer_phone = ? OR customer_phone = ?) AND status = 'Active'`,
                        [phone10, cp12], (e, row) => r(row || null)));
                if (claimed) continue;

                // Pull last 8 messages for context
                const msgs = await new Promise(r =>
                    db.all(`SELECT role, text FROM conversations WHERE phone LIKE ? AND text != '' ORDER BY id DESC LIMIT 8`,
                        [`%${phone10}`], (e, rows) => r(rows ? rows.reverse() : [])));
                if (!msgs.length) continue;

                const transcript = msgs.map(m =>
                    `${(m.role || '').toUpperCase() === 'USER' ? 'Customer' : 'Bot'}: ${sanitizeForAI(m.text)}`
                ).join('\n');

                const prompt = `You write polite WhatsApp follow-up nudges for DRD Realtors, a real estate company in Tamil Nadu.

The customer went quiet about 2 hours ago. Based on the conversation below, write ONE friendly, helpful sentence in English (under 30 words) that moves the conversation forward — examples: "Would tomorrow 4 PM work for a quick site visit?" / "Shall I arrange a call with our team today?" / "Want me to share the brochure for the layout you were interested in?".

Rules:
- Reply ONLY with the single sentence, no greeting, no signature, no quotes.
- Don't say "I noticed you went quiet" or "just following up" — be natural.
- Stay in English even if the chat was in Tamil/Tanglish.
- Reference something specific from the conversation if possible.

Recent conversation:
${transcript}

Your nudge:`;

                let nudge = '';
                try {
                    const model = genAI.getGenerativeModel({ model: AI_MODELS[0] || 'gemini-2.5-flash' });
                    const res = await model.generateContent(prompt);
                    nudge = (res.response.text() || '').trim().replace(/^["'`]+|["'`]+$/g, '');
                } catch (gerr) {
                    console.warn('[2HR-FU] Gemini failed for', phone10, '-', gerr.message);
                    continue;
                }
                if (!nudge || nudge.length > 280) continue;

                const phoneJid = `91${phone10}@c.us`;
                await client.sendMessage(phoneJid, nudge);
                db.run(
                    `INSERT INTO conversations (phone, role, text) VALUES (?, 'BOT', ?)`,
                    [phone10, nudge]);
                db.run(
                    `INSERT INTO followups (customer_phone, staff_name, notes, next_followup, status)
                     VALUES (?, 'AI_AUTO', ?, date('now'), 'Sent by AI')`,
                    [phone10, `[2hr DB nudge] ${nudge}`]);
                sentThisSweep++;
                console.log(`[2HR-FU] Nudge to ${phone10}: ${nudge}`);
                await new Promise(r => setTimeout(r, 2000));
            } catch (perErr) {
                console.warn('[2HR-FU] Per-customer error:', perErr.message);
            }
        }
        if (sentThisSweep) console.log(`[2HR-FU] Sweep done — ${sentThisSweep} nudge(s) sent`);
    } catch (err) {
        console.error('[2HR-FU] Sweep error:', err.message);
    }
}
setInterval(dbTwoHourFollowupSweep, 10 * 60 * 1000);  // every 10 min

// ─── DRIP FOLLOW-UP SWEEPER (1d / 3d / 7d) ───────────────────────────────
// Picks up AI_DRIP rows from the followups table whose next_followup date is
// today or earlier and that are still Pending. For each, pulls the last 6
// messages from the conversations table, asks Gemini to write a natural
// site-visit invitation referencing what the customer said, sends it, and
// marks the row as Sent. Never offers discounts. Never mentions price cuts.
async function dripFollowupSweep() {
    try {
        if (typeof client === 'undefined' || !client?.info?.wid) return;
        const settings = getBotSettings();

        // Honour the same daytime window as the nudge sweeper
        const hour = new Date().getHours();
        const startHour = parseInt(settings.auto_followup_start_hour ?? 9, 10);
        const endHour   = parseInt(settings.auto_followup_end_hour   ?? 21, 10);
        if (hour < startHour || hour >= endHour) return;

        // Pick due drip rows (max 5 per sweep to pace WhatsApp)
        const due = await new Promise(r =>
            db.all(
                `SELECT id, customer_phone, notes FROM followups
                   WHERE staff_name = 'AI_DRIP' AND status = 'Pending'
                     AND date(next_followup) <= date('now')
                   ORDER BY next_followup ASC LIMIT 5`,
                [], (e, rows) => r(rows || [])));
        if (!due.length) return;

        const adminNums = (settings.admin_numbers || []).map(n => String(n).replace(/\D/g, '')).filter(Boolean);

        for (const row of due) {
            try {
                const phone10 = String(row.customer_phone || '').replace(/\D/g, '').slice(-10);
                if (!phone10) { _markDripStatus(row.id, 'Cancelled'); continue; }

                // Skip admin numbers (safety)
                if (adminNums.some(a => a && phone10.includes(a.slice(-10)))) {
                    _markDripStatus(row.id, 'Cancelled');
                    continue;
                }

                // Skip if staff has claimed this conversation
                const cp12drip = '91' + phone10;
                const claimedDrip = await new Promise(r =>
                    db.get(`SELECT id FROM conversation_claims WHERE (customer_phone = ? OR customer_phone = ?) AND status = 'Active'`,
                        [phone10, cp12drip], (e, row) => r(row || null)));
                if (claimedDrip) { console.log(`[DRIP] Skipping ${phone10} — conversation claimed by staff`); continue; }

                // Cancel remaining stages if customer no longer needs nudging
                const cust = await new Promise(r =>
                    db.get(`SELECT name, status, plot, location FROM customers WHERE phone = ? LIMIT 1`,
                        [phone10], (e, c) => r(c || null)));
                const stat = ((cust && cust.status) || '').toLowerCase();
                if (['booked','purchased','site visit done','not interested','ignored','junk'].includes(stat)) {
                    db.run(`UPDATE followups SET status = 'Cancelled'
                              WHERE customer_phone = ? AND staff_name = 'AI_DRIP' AND status = 'Pending'`,
                        [phone10]);
                    continue;
                }

                // Pull last 6 messages for context (newest last for the prompt)
                const ctxRows = await new Promise(r =>
                    db.all(`SELECT role, text FROM conversations
                              WHERE phone = ? ORDER BY created_at DESC LIMIT 6`,
                        [phone10], (e, rows) => r((rows || []).reverse())));
                const transcript = ctxRows.map(m =>
                    `${(m.role || '').toUpperCase() === 'USER' ? 'Customer' : 'Bot'}: ${sanitizeForAI(m.text)}`
                ).join('\n') || '(No prior chat — first contact was a brief inquiry.)';

                const stage = String(row.notes || '');
                const dayLabel = stage.includes('d1') ? '1 day' : stage.includes('d3') ? '3 days' : stage.includes('d7') ? '1 week' : 'a few days';
                const plotHint = cust && cust.plot ? `Plot or layout they were interested in: ${cust.plot}` : '';
                const locHint  = cust && cust.location ? `Location they mentioned: ${cust.location}` : '';

                const prompt = `You write warm, natural WhatsApp follow-up messages for DRD Realtors, a real-estate company in Coimbatore / Pollachi, Tamil Nadu.

It has been ${dayLabel} since this customer chatted with our bot. Write ONE short, friendly message (max 2 sentences, English only) that:
- Gently nudges them to come and SEE the site in person — never just chat more on WhatsApp.
- References something specific they mentioned in the conversation (budget, layout, area, purpose, facing — whichever stood out).
- Sounds like a thoughtful sales colleague writing personally, NOT a marketing blast.

STRICT RULES:
- DO NOT mention any discount, offer, price cut, special rate, festival deal, percentage off, or limited-time anything. Never.
- DO NOT use words like "amazing", "exclusive", "huge", "lucky", "don't miss".
- DO NOT use emojis other than maybe one neutral one (📍 or 🤝) at the start.
- DO NOT add a signature, just the message.
- DO NOT say "I noticed you went quiet" or anything passive-aggressive.

${plotHint}
${locHint}

Recent conversation:
${transcript}

Your message:`;

                let nudge = '';
                try {
                    const model = genAI.getGenerativeModel({ model: AI_MODELS[0] || 'gemini-2.5-flash' });
                    const res = await model.generateContent(prompt);
                    nudge = (res.response.text() || '').trim().replace(/^["'`]+|["'`]+$/g, '');
                } catch (gerr) {
                    console.warn(`[DRIP] Gemini failed for ${phone10}/${stage}:`, gerr.message);
                    _markDripStatus(row.id, 'Failed');
                    continue;
                }

                // Safety net: if AI somehow slipped a discount keyword in, skip this round
                if (!nudge || nudge.length > 320 || /\b(discount|offer|off|deal|free|complimentary|festival|%)\b/i.test(nudge)) {
                    console.warn(`[DRIP] Rejected nudge for ${phone10}/${stage} (length/forbidden term)`);
                    _markDripStatus(row.id, 'Failed');
                    continue;
                }

                // Send
                try {
                    const jid = (phone10.length === 10 ? '91' + phone10 : phone10) + '@c.us';
                    await client.sendMessage(jid, nudge);
                    db.run(`UPDATE followups SET status = 'Sent', notes = ? WHERE id = ?`,
                        [`${stage} — ${nudge}`, row.id]);
                    // Mirror into conversations so it's part of the lead's history
                    db.run(
                        `INSERT INTO conversations (phone, role, text, message_type, ai_model, customer_name)
                         VALUES (?, 'BOT', ?, 'drip', ?, ?)`,
                        [phone10, nudge, AI_MODELS[0] || 'gemini-2.5-flash', (cust && cust.name) || null]);
                    console.log(`[DRIP] Sent ${stage} to ${phone10}: ${nudge}`);
                    await new Promise(r => setTimeout(r, 2000));
                } catch (sendErr) {
                    console.warn(`[DRIP] Send failed for ${phone10}/${stage}:`, sendErr.message);
                    _markDripStatus(row.id, 'Failed');
                }
            } catch (perRowErr) {
                console.warn('[DRIP] Per-row error:', perRowErr.message);
            }
        }
    } catch (err) {
        console.error('[DRIP] Sweep error:', err.message);
    }
}
function _markDripStatus(id, status) {
    db.run(`UPDATE followups SET status = ? WHERE id = ?`, [status, id]);
}
setInterval(dripFollowupSweep, 10 * 60 * 1000);  // every 10 min

async function checkIfAdmin(message) {
    if (message.fromMe) return true;
    
    let idToCheck = message.from || '';
    let contactNum = '';
    
    try {
        const contact = await message.getContact();
        contactNum = contact.number;
        if (idToCheck.includes('@lid') && contact.id) {
            idToCheck = contact.id._serialized || (contact.id.user + '@c.us');
        }
    } catch(e) { }
    
    const clean = (str) => (str || '').replace(/\D/g, '');
    const idClean = clean(idToCheck);
    const numClean = clean(contactNum);
    
    const loadSettings = () => {
        try {
            return JSON.parse(fs.readFileSync(BOT_CONFIG_PATH, 'utf8'));
        } catch(e) { return botSettings; }
    };
    const currentSettings = loadSettings();
    const admins = currentSettings.admin_numbers || [];

    const isMatch = admins.some(admin => {
        const adminClean = clean(admin);
        return (idClean && idClean === adminClean) || (numClean && numClean === adminClean);
    });

    if (isMatch) {
        console.log(`[AUTH] Admin confirmed: ${idToCheck} (${contactNum})`);
    }
    return isMatch;
}

// ─── STAFF BOT COMMANDS: expense/GST quick-entry ──────────
// Any registered staff member can type:
//   !exp 5000 office supplies petrol          → logs expense
//   !gst 2000 Vendor Name some invoice        → logs GST inward entry
//   !myexp                                    → shows their last 5 submissions
// Entries are saved with source='bot' so the dashboard can flag them for admin review.

async function handleStaffBotCommand(message, phone) {
    if (message.fromMe) return false;
    const body = (message.body || '').trim();

    // Match natural language: "Rs 5000 as expenses for skanda for light fitting"
    //   Group 1 = amount, Group 2 = layout/project, Group 3 = description (optional)
    const nlExpMatch = body.match(
        /^(?:rs\.?\s*|₹\s*|inr\.?\s*)(\d[\d,.]*)[\s\-]+(?:as\s+)?(?:expense|expenses?|exp)(?:\s+for\s+([\w\s]+?)(?:\s+for\s+(.+))?)?$/i
    );

    const isConfirmWord = /^(add\s+entry|yes|confirm|ok|done)$/i.test(body);
    const isCancelWord  = /^cancel$/i.test(body);

    // Pending confirmation: "Add entry" / "yes" / "confirm"
    const isPendingConfirm = isConfirmWord && userStates[phone]?.pendingExpense;
    const isPendingGstConfirm = isConfirmWord && userStates[phone]?.pendingGst;

    // Cancel pending expense
    if (isCancelWord && userStates[phone]?.pendingExpense) {
        delete userStates[phone].pendingExpense;
        return false;
    }
    if (isCancelWord && userStates[phone]?.pendingGst) {
        delete userStates[phone].pendingGst;
        await message.reply('❌ GST entry cancelled.');
        return true;
    }

    const isBillImage = message.hasMedia && message.type === 'image' &&
        /\b(?:bill|invoice|gst|receipt|tax\s*invoice|purchase\s*bill)\b/i.test(body);
    const isExplicitCmd = /^!(exp|expense|gst|myexp)/i.test(body);

    // ── Attendance: "login in" / "check in" / "logout" / "check out" ──
    const isLoginIn = /^(?:log\s*in|login\s*in|check[\s\-]?in|clock[\s\-]?in|checkin|clockin)$/i.test(body);
    const isLogout  = /^(?:log\s*out|logout|check[\s\-]?out|clock[\s\-]?out|checkout|clockout)$/i.test(body);
    if (isLoginIn || isLogout) {
        const phone10att = (phone || '').replace(/\D/g, '').slice(-10);
        let staffAtt = null;
        try {
            staffAtt = await new Promise(resolve =>
                db.get(
                    `SELECT id, name FROM staff WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ? AND is_active != 0 LIMIT 1`,
                    [`%${phone10att}`],
                    (err, row) => resolve(err ? null : row)
                )
            );
        } catch (e) {}
        if (!staffAtt) {
            console.log(`[ATT] login/logout from unrecognized number: ${phone10att}`);
            await message.reply(`⚠️ *Attendance Failed*\n\nYour number is not registered in the staff directory.\n\nAsk your manager to add your mobile number to your staff profile in the dashboard.`);
            return true;
        }

        const today = new Date().toISOString().split('T')[0];
        const timeNow = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });

        if (isLoginIn) {
            const existing = await new Promise(resolve =>
                db.get(`SELECT id, check_in FROM attendance WHERE staff_id = ? AND date = ?`, [staffAtt.id, today], (err, row) => resolve(err ? null : row))
            );
            if (existing && existing.check_in) {
                await message.reply(`⚠️ Already clocked in at *${existing.check_in}* today.`);
                return true;
            }
            if (existing) {
                await new Promise(resolve => db.run(`UPDATE attendance SET check_in=?, status='Present' WHERE id=?`, [timeNow, existing.id], resolve));
            } else {
                await new Promise(resolve => db.run(
                    `INSERT INTO attendance (staff_id, name, date, check_in, status, gps_location, photo_proof) VALUES (?, ?, ?, ?, 'Present', '', '')`,
                    [staffAtt.id, staffAtt.name, today, timeNow], resolve
                ));
            }
            await message.reply(`✅ *Clocked In*\n👤 ${staffAtt.name}\n📅 ${today}\n⏰ ${timeNow}`);
            if (process.send) process.send({ type: 'attendance_update', data: { name: staffAtt.name, action: 'check_in', time: timeNow } });
            return true;
        }

        // isLogout
        const existing = await new Promise(resolve =>
            db.get(`SELECT id, check_in, check_out FROM attendance WHERE staff_id = ? AND date = ?`, [staffAtt.id, today], (err, row) => resolve(err ? null : row))
        );
        if (!existing || !existing.check_in) {
            await message.reply(`⚠️ No clock-in found for today. Send *check in* first.`);
            return true;
        }
        if (existing.check_out) {
            await message.reply(`⚠️ Already clocked out at *${existing.check_out}* today.`);
            return true;
        }
        await new Promise(resolve => db.run(`UPDATE attendance SET check_out=?, status='Present' WHERE id=?`, [timeNow, existing.id], resolve));
        await message.reply(`✅ *Clocked Out*\n👤 ${staffAtt.name}\n📅 ${today}\n⏰ ${timeNow}`);
        if (process.send) process.send({ type: 'attendance_update', data: { name: staffAtt.name, action: 'check_out', time: timeNow } });
        return true;
    }

    // ── Visitor Log: ".visitor Name, Phone, Budget, Time, Intent, Notes" ──
    if (/^\.visitor\b/i.test(body)) {
        const rawArgs = body.replace(/^\.visitor\s*/i, '').trim();
        if (!rawArgs) {
            await message.reply(
                `📋 *Log a Site Visitor*\n\n` +
                `Format:\n*.visitor Name, Phone, Budget, Visit Time, Intent, Notes*\n\n` +
                `Example:\n_.visitor Rajesh Kumar, 9876543210, 20L, 3pm, planning in 3 months, interested in Anisam_\n\n` +
                `Only *Name* is required. All other fields are optional.`
            );
            return true;
        }
        const parts = rawArgs.split(',').map(s => s.trim());
        const visitorName  = parts[0] || '';
        const visitorPhone = parts[1] || '';
        const budget       = parts[2] || '';
        const visitTime    = parts[3] || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
        const intent       = parts[4] || '';
        const visitorNotes = parts[5] || '';
        if (!visitorName) {
            await message.reply('⚠️ Visitor name is required.\n\nUse: *.visitor Name, Phone, Budget, Time, Intent, Notes*');
            return true;
        }
        const today = new Date().toISOString().split('T')[0];
        const phone10v = (phone || '').replace(/\D/g, '').slice(-10);
        let staffV = null;
        try {
            staffV = await new Promise(resolve =>
                db.get(
                    `SELECT id, name FROM staff WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ? AND is_active != 0 LIMIT 1`,
                    [`%${phone10v}`],
                    (err, row) => resolve(err ? null : row)
                )
            );
        } catch (e) {}
        const noteParts = [];
        if (budget) noteParts.push(`Budget: ${budget}`);
        if (intent) noteParts.push(`Intent: ${intent}`);
        if (visitorNotes) noteParts.push(visitorNotes);
        const fullNotes = noteParts.join(' | ');
        try {
            await new Promise((res, rej) =>
                db.run(
                    `INSERT INTO visitors (name, phone, visit_date, visit_time, purpose, met_staff, source, notes, status)
                     VALUES (?, ?, ?, ?, 'Site Enquiry', ?, 'Walk-in', ?, 'Visited')`,
                    [visitorName, visitorPhone, today, visitTime, staffV ? staffV.name : '', fullNotes],
                    function(err) { err ? rej(err) : res(this.lastID); }
                )
            );
            let reply = `✅ *Visitor Logged*\n\n`;
            reply += `👤 Name: ${visitorName}\n`;
            if (visitorPhone) reply += `📱 Phone: ${visitorPhone}\n`;
            if (budget) reply += `💰 Budget: ${budget}\n`;
            reply += `⏰ Time: ${visitTime}\n`;
            if (intent) reply += `🎯 Intent: ${intent}\n`;
            if (visitorNotes) reply += `📝 Notes: ${visitorNotes}\n`;
            reply += `\n_Logged by ${staffV ? staffV.name : 'Staff'} · ${today}_\n_View: Dashboard → Leads & CRM → Visitor Log_`;
            await message.reply(reply);
        } catch (dbErr) {
            await message.reply('❌ Failed to save visitor record. Please try again.');
            console.error('[VISITOR_BOT]', dbErr);
        }
        return true;
    }

    if (!isExplicitCmd && !nlExpMatch && !isPendingConfirm && !isPendingGstConfirm && !isBillImage) return false;

    // Look up sender in staff table (by phone last 10 digits)
    const phone10 = (phone || '').replace(/\D/g, '').slice(-10);
    let staffMember = null;
    try {
        staffMember = await new Promise((resolve) => {
            db.get(
                `SELECT id, name, role FROM staff
                   WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
                   AND is_active != 0 LIMIT 1`,
                [`%${phone10}`],
                (err, row) => resolve(err ? null : row)
            );
        });
    } catch (e) { }

    if (!staffMember) return false; // only registered staff can use these commands

    const cmd = body.toLowerCase();
    const target = message.from;

    // ── Natural language: confirm pending expense ──
    if (isPendingConfirm) {
        const pe = userStates[phone].pendingExpense;
        delete userStates[phone].pendingExpense;
        const today = new Date().toISOString().split('T')[0];
        try {
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO expenses (category, description, amount, date, layout_name, source, bot_submitted_by, notes)
                       VALUES (?, ?, ?, ?, ?, 'bot', ?, ?)`,
                    [pe.category, pe.desc, pe.amount, today, pe.layout || null, staffMember.name, `Bot NL entry by ${staffMember.name}`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });
            await message.reply(
                `✅ *Expense Recorded*\n\n` +
                `👤 By: ${staffMember.name}\n` +
                `💰 Amount: ₹${pe.amount.toLocaleString('en-IN')}\n` +
                `📝 Description: ${pe.desc}\n` +
                `🗂️ Category: ${pe.category}\n` +
                (pe.layout ? `🏗️ Project: ${pe.layout}\n` : '') +
                `📅 Date: ${today}\n\n` +
                `_Review in Dashboard → Finance → Expenses_`
            );
            const settings = getBotSettings();
            for (const adminNum of (settings.admin_numbers || [])) {
                const adminJid = adminNum.includes('@') ? adminNum : `${adminNum}@c.us`;
                try {
                    await client.sendMessage(adminJid,
                        `🔔 *New Expense*\n\nFrom: *${staffMember.name}*\nAmount: ₹${pe.amount.toLocaleString('en-IN')}\nDesc: ${pe.desc}\nProject: ${pe.layout || '—'}\n\n_Review in Dashboard → Finance → Expenses_`
                    );
                } catch (_) { }
            }
        } catch (e) {
            await message.reply('⚠️ Could not save expense: ' + e.message);
        }
        return true;
    }

    // ── Pending GST confirmation (from bill scan) ──
    if (isPendingGstConfirm) {
        const pg = userStates[phone].pendingGst;
        delete userStates[phone].pendingGst;
        const d = new Date(pg.invoiceDate);
        const fy = (d.getMonth() + 1) >= 4 ? `${d.getFullYear()}-${String(d.getFullYear() + 1).slice(-2)}` : `${d.getFullYear() - 1}-${String(d.getFullYear()).slice(-2)}`;
        try {
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO gst_ledger
                       (direction, invoice_date, party_name, description, taxable_value, gst_rate,
                        cgst, sgst, igst, total_amount, is_interstate, is_exempt,
                        financial_year, month, year, status, source, bot_submitted_by, notes)
                       VALUES ('inward', ?, ?, ?, ?, ?, 0, 0, 0, ?, 0, 0, ?, ?, ?, 'Draft', 'bot', ?, ?)`,
                    [pg.invoiceDate, pg.vendor, pg.desc, pg.taxable, pg.gstRate, pg.total,
                     fy, d.getMonth() + 1, d.getFullYear(), staffMember.name, `Bot bill scan by ${staffMember.name} — verify GST details`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });
            await message.reply(
                `✅ *GST Entry Logged (Inward)*\n\n👤 By: ${staffMember.name}\n🏢 Vendor: ${pg.vendor}\n💰 Total: ₹${pg.total.toLocaleString('en-IN')}\n🏷️ GST Rate: ${pg.gstRate}%\n📅 Date: ${pg.invoiceDate}\n\n⚠️ _Review in Dashboard → Finance → GST Ledger_`
            );
            const settings = getBotSettings();
            for (const adminNum of (settings.admin_numbers || [])) {
                const adminJid = adminNum.includes('@') ? adminNum : `${adminNum}@c.us`;
                try { await client.sendMessage(adminJid, `🔔 *New Bot GST Entry (Bill Scan)*\n\nFrom: *${staffMember.name}*\nVendor: ${pg.vendor}\nAmount: ₹${pg.total.toLocaleString('en-IN')}\n\n_Review in Dashboard → Finance → GST Ledger_`); } catch (_) { }
            }
        } catch (e) {
            await message.reply('⚠️ Could not save GST entry: ' + e.message);
        }
        return true;
    }

    // ── Bill image scan ──
    if (isBillImage) {
        try {
            await message.reply('🔍 Scanning bill...');
            const media = await message.downloadMedia();
            if (!media) { await message.reply('⚠️ Could not download image.'); return true; }
            const model = genAI.getGenerativeModel({ model: AI_MODELS[0] || 'gemini-2.5-flash' });
            const result = await model.generateContent([
                { inlineData: { mimeType: media.mimetype, data: media.data } },
                'Extract GST invoice details from this image. Return JSON only with these keys: vendor (string), invoice_date (YYYY-MM-DD or null), taxable_value (number or null), gst_rate (number or null), total_amount (number or null), description (string). No explanation, just JSON.'
            ]);
            const txt = result.response.text();
            const jsonMatch = txt.match(/\{[\s\S]*\}/);
            if (!jsonMatch) { await message.reply('⚠️ Could not read bill details. Use *!gst* command manually.'); return true; }
            let parsed;
            try { parsed = JSON.parse(jsonMatch[0]); } catch (e) { await message.reply('⚠️ Could not parse bill. Use *!gst* command manually.'); return true; }
            const today = new Date().toISOString().split('T')[0];
            const invoiceDate = parsed.invoice_date || today;
            const vendor = parsed.vendor || 'Unknown Vendor';
            const taxable = parsed.taxable_value || parsed.total_amount || 0;
            const total = parsed.total_amount || taxable;
            const gstRate = parsed.gst_rate || 18;
            const desc = parsed.description || 'Bill scan entry';
            userStates[phone] = userStates[phone] || {};
            userStates[phone].pendingGst = { invoiceDate, vendor, taxable, total, gstRate, desc };
            await message.reply(
                `📝 *GST Entry Preview (Bill Scan)*\n\n🏢 Vendor: ${vendor}\n💰 Total: ₹${total.toLocaleString('en-IN')}\n📊 Taxable: ₹${taxable.toLocaleString('en-IN')}\n🏷️ GST Rate: ${gstRate}%\n📅 Invoice Date: ${invoiceDate}\n📝 Description: ${desc}\n\nReply *Add entry* or *yes* to confirm, or *cancel* to discard.`
            );
        } catch (e) {
            await message.reply('⚠️ Bill scan failed: ' + e.message + '. Use *!gst* command manually.');
        }
        return true;
    }

    // ── Natural language expense: "Rs 5000 as expenses for skanda for light fitting" ──
    if (nlExpMatch && !isExplicitCmd) {
        const amount = parseFloat(nlExpMatch[1].replace(/,/g, '')) || 0;
        const layout = (nlExpMatch[2] || '').trim();
        const desc   = (nlExpMatch[3] || layout || 'Expense').trim();
        const descLower = desc.toLowerCase();
        let category = 'Other';
        if (/petrol|fuel|diesel/i.test(descLower)) category = 'Travel';
        else if (/office|stationery|print/i.test(descLower)) category = 'Office Expenses';
        else if (/electricity|eb|power/i.test(descLower)) category = 'Utilities';
        else if (/salary|wage/i.test(descLower)) category = 'Salary';
        else if (/material|cement|steel|sand/i.test(descLower)) category = 'Materials';
        else if (/food|lunch|tea|snack/i.test(descLower)) category = 'Food';
        else if (/phone|mobile|internet/i.test(descLower)) category = 'Communication';
        else if (/repair|maintenance|service|fitting|fix/i.test(descLower)) category = 'Maintenance';
        else if (/rent/i.test(descLower)) category = 'Rent';

        // Save pending state and ask for confirmation
        userStates[phone] = userStates[phone] || {};
        userStates[phone].pendingExpense = { amount, layout, desc, category };
        await message.reply(
            `📝 *Expense Entry Preview*\n\n` +
            `💰 Amount: ₹${amount.toLocaleString('en-IN')}\n` +
            `📝 Description: ${desc}\n` +
            `🗂️ Category: ${category}\n` +
            (layout ? `🏗️ Project: ${layout}\n` : '') +
            `\nReply *Add entry* or *yes* to confirm, or *cancel* to discard.`
        );
        return true;
    }

    // ── !myexp — show last 5 submissions ──
    if (/^!myexp$/i.test(body.trim())) {
        if (await _guardCmd(message, 'myexp')) return true;
        try {
            const rows = await new Promise((res2) => {
                db.all(
                    `SELECT 'Expense' AS type, description AS title, amount, date AS entry_date FROM expenses
                       WHERE bot_submitted_by = ? ORDER BY created_at DESC LIMIT 3
                     UNION ALL
                     SELECT 'GST' AS type, COALESCE(description, party_name) AS title, total_amount AS amount, invoice_date AS entry_date
                       FROM gst_ledger WHERE bot_submitted_by = ? ORDER BY created_at DESC LIMIT 3`,
                    [staffMember.name, staffMember.name],
                    (err, r) => res2(err ? [] : r)
                );
            });
            if (!rows.length) {
                await message.reply('📭 No submissions found from your number yet.');
            } else {
                const lines = rows.map(r => `• ${r.type}: *${r.title}* — ₹${r.amount} (${r.entry_date || 'today'})`).join('\n');
                await message.reply(`📋 *Your recent submissions:*\n\n${lines}\n\n_View full details in the dashboard Finance section._`);
            }
        } catch (e) {
            await message.reply('⚠️ Could not fetch submissions: ' + e.message);
        }
        return true;
    }

    // ── !exp <amount> <description…> ──
    if (/^!exp(ense)?\s/i.test(body)) {
        if (await _guardCmd(message, 'expense')) return true;
        const parts = body.replace(/^!exp(ense)?\s+/i, '').trim();
        const amtMatch = parts.match(/^(\d[\d,.]*)(.*)$/);
        if (!amtMatch) {
            await message.reply('⚠️ Format: *!exp 5000 office supplies petrol*\nAmount must come first.');
            return true;
        }
        const amount = parseFloat(amtMatch[1].replace(/,/g, '')) || 0;
        const desc = amtMatch[2].trim() || 'Office Expense';

        // Guess category from description
        const descLower = desc.toLowerCase();
        let category = 'Other';
        if (/petrol|fuel|diesel/i.test(descLower)) category = 'Travel';
        else if (/office|stationery|print/i.test(descLower)) category = 'Office Expenses';
        else if (/electricity|eb|power/i.test(descLower)) category = 'Utilities';
        else if (/salary|wage/i.test(descLower)) category = 'Salary';
        else if (/material|cement|steel|sand/i.test(descLower)) category = 'Materials';
        else if (/food|lunch|tea|snack/i.test(descLower)) category = 'Food';
        else if (/phone|mobile|internet|data/i.test(descLower)) category = 'Communication';
        else if (/repair|maintenance|service/i.test(descLower)) category = 'Maintenance';
        else if (/rent/i.test(descLower)) category = 'Rent';

        const today = new Date().toISOString().split('T')[0];
        try {
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO expenses (category, description, amount, date, source, bot_submitted_by, notes)
                       VALUES (?, ?, ?, ?, 'bot', ?, ?)`,
                    [category, desc, amount, today, staffMember.name, `Bot entry by ${staffMember.name}`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });

            await message.reply(
                `✅ *Expense Recorded*\n\n` +
                `👤 Submitted by: ${staffMember.name}\n` +
                `💰 Amount: ₹${amount.toLocaleString('en-IN')}\n` +
                `📝 Description: ${desc}\n` +
                `🗂️ Category: ${category}\n` +
                `📅 Date: ${today}\n\n` +
                `_Entry saved. Admin will review from dashboard._`
            );

            // Notify admins
            const settings = getBotSettings();
            for (const adminNum of (settings.admin_numbers || [])) {
                const adminJid = adminNum.includes('@') ? adminNum : `${adminNum}@c.us`;
                try {
                    await client.sendMessage(adminJid,
                        `🔔 *New Bot Expense Entry*\n\nFrom: *${staffMember.name}*\nAmount: ₹${amount.toLocaleString('en-IN')}\nDesc: ${desc}\nCategory: ${category}\n\n_Review in Dashboard → Finance → Expenses_`
                    );
                } catch (e2) { }
            }
        } catch (e) {
            await message.reply('⚠️ Could not save expense: ' + e.message);
        }
        return true;
    }

    // ── !gst <amount> <party name> [description] ──
    if (/^!gst\s/i.test(body)) {
        if (await _guardCmd(message, 'gst')) return true;
        const parts = body.replace(/^!gst\s+/i, '').trim();
        const amtMatch = parts.match(/^(\d[\d,.]*)(.*)$/);
        if (!amtMatch) {
            await message.reply('⚠️ Format: *!gst 5000 VendorName some invoice description*\nAmount must come first.');
            return true;
        }
        const total = parseFloat(amtMatch[1].replace(/,/g, '')) || 0;
        const rest = amtMatch[2].trim();
        // First word of rest = party name, rest = description
        const [party, ...descParts] = rest.split(' ');
        const partyName = party || 'Unknown Vendor';
        const desc = descParts.join(' ') || 'Bot GST Entry';
        const today = new Date().toISOString().split('T')[0];
        const d = new Date(today);
        const fy = (d.getMonth() + 1) >= 4 ? `${d.getFullYear()}-${String(d.getFullYear() + 1).slice(-2)}` : `${d.getFullYear() - 1}-${String(d.getFullYear()).slice(-2)}`;

        try {
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO gst_ledger
                       (direction, invoice_date, party_name, description, taxable_value, gst_rate,
                        cgst, sgst, igst, total_amount, is_interstate, is_exempt,
                        financial_year, month, year, status, source, bot_submitted_by, notes)
                       VALUES ('inward', ?, ?, ?, ?, 18, 0, 0, 0, ?, 0, 0, ?, ?, ?, 'Draft', 'bot', ?, ?)`,
                    [today, partyName, desc, total, total, fy, d.getMonth() + 1, d.getFullYear(),
                     staffMember.name, `Bot entry by ${staffMember.name} — verify GST details`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });

            await message.reply(
                `✅ *GST Entry Recorded (Inward)*\n\n` +
                `👤 Submitted by: ${staffMember.name}\n` +
                `🏢 Party: ${partyName}\n` +
                `💰 Amount: ₹${total.toLocaleString('en-IN')}\n` +
                `📝 Description: ${desc}\n` +
                `📅 Date: ${today}\n\n` +
                `⚠️ _GST rate defaulted to 18%. Please update in dashboard if different._\n` +
                `_Review in Dashboard → Finance → GST Ledger_`
            );

            // Notify admins
            const settings = getBotSettings();
            for (const adminNum of (settings.admin_numbers || [])) {
                const adminJid = adminNum.includes('@') ? adminNum : `${adminNum}@c.us`;
                try {
                    await client.sendMessage(adminJid,
                        `🔔 *New Bot GST Entry*\n\nFrom: *${staffMember.name}*\nParty: ${partyName}\nAmount: ₹${total.toLocaleString('en-IN')}\nDesc: ${desc}\n\n_Review in Dashboard → Finance → GST Ledger_`
                    );
                } catch (e2) { }
            }
        } catch (e) {
            await message.reply('⚠️ Could not save GST entry: ' + e.message);
        }
        return true;
    }

    return false;
}

// ─── REMISIER BOT HANDLER ──────────────────────────────────────────────────
// If the sender is a registered remisier (affiliate), route to the remisier menu
// instead of the normal customer AI flow.
const remisierStates = new Map(); // phone → { step, data }
const pendingQuotations = new Map(); // adminPhone10 → { plotRow, customer, custPhone, custJid, senderName, pricing, sqft, cent, customNote, text, expiresAt }

function _buildQuotationText(plotRow, customer, pricing, senderName, customNote) {
    const { total, ratePerSqft, ratePerCent } = pricing;
    const sqft = parseFloat(plotRow.size) || 0;
    const cent = sqft ? (sqft / 435.6) : 0;
    const _custName = customer && customer.name && !/^(admin|unknown|new\s+lead)$/i.test(customer.name.trim()) ? customer.name.trim() : null;
    const greet = _custName ? `Hello *${_custName}*! 👋` : `Hello! 👋`;
    const fmt = n => '₹' + (n || 0).toLocaleString('en-IN');
    return `${greet}\n\n📜 *Price Quotation* — *${plotRow.layout_name}*\n` +
        `Plot No: *${plotRow.plot_no}* · Size: *${plotRow.size || '—'} sqft* (${cent.toFixed(2)} cent)\n` +
        `Facing: ${plotRow.facing || '—'} · Location: ${plotRow.location || '—'}\n\n` +
        `*Pricing Breakup*\n` +
        `▪ Plot Value: ${fmt(total)}\n` +
        (ratePerSqft ? `▪ Rate / SqFt: ${fmt(ratePerSqft)}\n` : '') +
        (ratePerCent ? `▪ Rate / Cent: ${fmt(ratePerCent)}\n` : '') +
        `▪ Extra*\n` +
        `▪ *Estimated Total*: *${fmt(total)}*\n\n` +
        (customNote ? `📌 Note: ${customNote}\n\n` : ``) +
        `Bank loan facility available with leading banks.\n` +
        `Prepared by *${senderName}* · DRD Realtors`;
}

async function handleRemisierBotMessage(message, phone) {
    if (message.fromMe) return false;
    const phone10 = String(phone).replace(/\D/g,'').slice(-10);

    // Look up remisier by phone
    const remisier = await new Promise(resolve =>
        db.get(`SELECT * FROM affiliates WHERE (REPLACE(REPLACE(phone,'+91',''),' ','') = ? OR phone = ?) AND status = 'Active'`,
            [phone10, '91' + phone10], (err, row) => resolve(row || null))
    );
    if (!remisier) return false; // not a remisier — let normal flow handle it

    const msgRaw  = (message.body || '').trim();
    const msgLow  = msgRaw.toLowerCase();
    const state   = remisierStates.get(phone10) || { step: 'menu' };

    // ── Multi-step: visit scheduling ──────────────────────────────────────
    if (state.step === 'visit_awaiting_customer') {
        const custPhone = msgRaw.replace(/\D/g,'').slice(-10);
        if (custPhone.length < 10) {
            await client.sendMessage(phone, `❌ Couldn't read that phone number. Please send the customer's 10-digit mobile number.`);
            return true;
        }
        const cust = await new Promise(r =>
            db.get(`SELECT name FROM customers WHERE phone = ? AND referred_by = ?`, [custPhone, remisier.code], (e, row) => r(row))
        );
        if (!cust) {
            await client.sendMessage(phone, `❌ Customer *${custPhone}* not found in your referral list. Make sure they inquired using your referral link.`);
            return true;
        }
        remisierStates.set(phone10, { step: 'visit_awaiting_date', data: { custPhone, custName: cust.name } });
        await client.sendMessage(phone, `✅ Found *${cust.name}*.\n\n📅 When is the site visit?\nReply with date & time, e.g.:\n• *25 June 10am*\n• *Tomorrow 3pm*\n• *02/06 11:00*`);
        return true;
    }

    if (state.step === 'visit_awaiting_date') {
        const { custPhone, custName } = state.data;
        // Try to parse date — accept free text and store as-is (staff can confirm in dashboard)
        const today = new Date();
        let visitDate = msgRaw;
        // Simple patterns
        if (/tomorrow/i.test(msgRaw)) {
            const d = new Date(today); d.setDate(d.getDate() + 1);
            visitDate = d.toISOString().slice(0,10);
        } else {
            const dMatch = msgRaw.match(/(\d{1,2})[\/\-\s](\d{1,2})(?:[\/\-\s](\d{2,4}))?/);
            if (dMatch) {
                const [, day, mon, yr] = dMatch;
                const year = yr ? (yr.length === 2 ? '20' + yr : yr) : today.getFullYear();
                visitDate = `${year}-${String(mon).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
            }
        }
        const timeMatch = msgRaw.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);
        let visitTime = '';
        if (timeMatch) {
            let h = parseInt(timeMatch[1]);
            const m = timeMatch[2] || '00';
            const ampm = (timeMatch[3] || '').toLowerCase();
            if (ampm === 'pm' && h < 12) h += 12;
            if (ampm === 'am' && h === 12) h = 0;
            visitTime = `${String(h).padStart(2,'0')}:${m}`;
        }

        await new Promise(resolve =>
            db.run(`INSERT INTO site_visits (customer_phone, visit_date, visit_time, scheduled_by, scheduled_by_type, notes, status)
                    VALUES (?, ?, ?, ?, 'remisier', ?, 'Scheduled')`,
                [custPhone, visitDate, visitTime, remisier.code, `Scheduled by remisier ${remisier.name}`],
                resolve)
        );
        remisierStates.delete(phone10);
        await client.sendMessage(phone,
            `✅ *Visit Scheduled!*\n\n👤 Customer: ${custName}\n📅 Date: ${visitDate}${visitTime ? '\n⏰ Time: ' + visitTime : ''}\n\nOur team will confirm with the customer. Thank you! 🙏`
        );
        return true;
    }

    // ── Document upload (Aadhaar / PAN) ───────────────────────────────────
    const hasMedia = message.hasMedia && (message.type === 'image' || message.type === 'document');
    const isDocType = /aadhaar|adhar|aadhar|pan\s*card|pan\s*doc|1|2/i.test(msgLow);

    if (state.step === 'doc_awaiting_type') {
        // Remisier sent a doc; we're waiting for them to say which type
        const isAdhar = /aadhaar|adhar|aadhar|1/i.test(msgLow);
        const isPan   = /pan|2/i.test(msgLow);
        if (!isAdhar && !isPan) {
            await client.sendMessage(phone, `Please reply:\n*1* — Aadhaar Card\n*2* — PAN Card`);
            return true;
        }
        const docType  = isAdhar ? 'adhar' : 'pan';
        const mediaObj = state.data?.pendingMedia;
        if (!mediaObj) {
            remisierStates.delete(phone10);
            await client.sendMessage(phone, `⚠️ Media not found. Please resend the document.`);
            return true;
        }
        try {
            const media    = await mediaObj.downloadMedia();
            const mime     = (media.mimetype || 'image/jpeg');
            const ext      = mime.split('/')[1]?.split(';')[0] || 'jpg';
            const filename = `${remisier.id}_${docType}_${Date.now()}.${ext}`;
            const docsDir  = path.join(ROOT_DIR, 'remisier_docs');
            if (!fs.existsSync(docsDir)) fs.mkdirSync(docsDir, { recursive: true });
            fs.writeFileSync(path.join(docsDir, filename), Buffer.from(media.data, 'base64'));
            const col = docType === 'adhar' ? 'adhar_doc' : 'pan_doc';
            await new Promise(resolve => db.run(`UPDATE affiliates SET ${col} = ? WHERE id = ?`, [filename, remisier.id], resolve));
            remisierStates.delete(phone10);
            await client.sendMessage(phone, `✅ ${isAdhar ? 'Aadhaar' : 'PAN'} document saved successfully! 📄`);
        } catch (err) {
            console.error('[REMISIER DOC]', err);
            remisierStates.delete(phone10);
            await client.sendMessage(phone, `❌ Failed to save document. Please try again.`);
        }
        return true;
    }

    if (hasMedia) {
        // Store media in state and ask for doc type
        remisierStates.set(phone10, { step: 'doc_awaiting_type', data: { pendingMedia: message } });
        await client.sendMessage(phone,
            `📎 Document received! Please tell me what this is:\n\n*1* — Aadhaar Card\n*2* — PAN Card`
        );
        return true;
    }

    // ── Menu commands ──────────────────────────────────────────────────────
    const isMenu    = /^(hi|hello|hai|menu|help|start|\d)$/i.test(msgLow) || msgLow.includes('menu') || msgLow.includes('help');
    const isStatus  = /status|my lead|referral|referred|lead list|my client/i.test(msgLow);
    const isVisit   = /schedule|visit|book.*visit|visit.*book|site visit/i.test(msgLow);
    const isStats   = /stat|performance|summary|earning|commission|how many/i.test(msgLow);

    if (isVisit) {
        remisierStates.set(phone10, { step: 'visit_awaiting_customer' });
        await client.sendMessage(phone,
            `📅 *Schedule a Site Visit*\n\nPlease send the customer's *10-digit mobile number* that they used to contact us.`
        );
        return true;
    }

    if (isStatus) {
        const leads = await new Promise(r =>
            db.all(`SELECT name, phone, status, created_at FROM customers WHERE referred_by = ? ORDER BY created_at DESC LIMIT 20`,
                [remisier.code], (e, rows) => r(rows || []))
        );
        if (!leads.length) {
            await client.sendMessage(phone, `📋 No referrals found yet for your code *${remisier.code}*.\n\nShare your link to start earning! 🚀`);
            return true;
        }
        const statusIcon = s => ({ 'New':'🆕', 'Interested':'✅', 'Site Visit Done':'🏗️', 'Booked':'🎉', 'Purchased':'💰', 'Not Interested':'❌' }[s] || '📌');
        const lines = leads.map((l, i) => `${i+1}. ${statusIcon(l.status)} *${l.name || l.phone}* — ${l.status}`).join('\n');
        await client.sendMessage(phone,
            `📋 *Your Referrals (${leads.length})*\n\n${lines}\n\nType *schedule visit* to book a site visit for any lead.`
        );
        return true;
    }

    if (isStats) {
        const stats = await new Promise(r =>
            db.get(`SELECT COUNT(*) AS total,
                           SUM(CASE WHEN status IN ('Booked','Purchased') THEN 1 END) AS converted,
                           SUM(CASE WHEN status = 'Site Visit Done' THEN 1 END) AS visited
                      FROM customers WHERE referred_by = ?`,
                [remisier.code], (e, row) => r(row || {}))
        );
        const rate = stats.total > 0 ? Math.round((stats.converted || 0) * 100 / stats.total) : 0;
        await client.sendMessage(phone,
            `📊 *Your Performance — ${remisier.name}*\n\n` +
            `📥 Total Referrals: *${stats.total || 0}*\n` +
            `🏗️ Site Visits Done: *${stats.visited || 0}*\n` +
            `🎉 Converted (Booked/Purchased): *${stats.converted || 0}*\n` +
            `📈 Conversion Rate: *${rate}%*\n` +
            `💰 Commission Rate: *${remisier.commission_rate || 2}%*\n\n` +
            `Keep referring to earn more! 💪`
        );
        return true;
    }

    // Default: show menu
    remisierStates.delete(phone10);
    await client.sendMessage(phone,
        `🏠 *DRD Property Genius — Remisier Portal*\n\nHello *${remisier.name}*! 👋\nYour code: *${remisier.code}*\n\n` +
        `What would you like to do?\n\n` +
        `📋 *1* — My referral status\n` +
        `📅 *2* — Schedule a site visit\n` +
        `📊 *3* — My performance & stats\n\n` +
        `Reply with the number or keyword.`
    );
    return true;
}

async function handleAdminCommand(message) {
    const bodyRaw = (message.body || '').toLowerCase().trim();
    const bodyNoSpace = bodyRaw.replace(/\s+/g, '');
    const isAdmin = await checkIfAdmin(message);

    if (!isAdmin) return false;

    // Never process the bot's own outgoing AI replies as admin commands.
    // Only allow fromMe messages that start with "!" (explicit operator commands).
    if (message.fromMe && !bodyRaw.startsWith('!')) return false;

    const target = message.fromMe ? message.to : message.from;
    const botId = client.info.wid._serialized;
    const isDirectToBot = (message.to === botId) || (message.from === botId);

    // ── Pending quotation confirmation ──
    // Purge expired entries on every admin message
    for (const [k, v] of pendingQuotations) {
        if (Date.now() > v.expiresAt) pendingQuotations.delete(k);
    }
    const _adminPhone10 = (message.fromMe ? message.to : message.from).replace(/\D/g, '').slice(-10);
    const _pendingQ = pendingQuotations.get(_adminPhone10);
    if (_pendingQ) {
        const bodyLow = (message.body || '').trim().toLowerCase();
        const bodyOrig = (message.body || '').trim();

        if (/^(confirm|yes|send|send it|ok send|ok go|go ahead)$/i.test(bodyLow)) {
            pendingQuotations.delete(_adminPhone10);
            try {
                await client.sendMessage(_pendingQ.custJid, _pendingQ.text);
                db.run(
                    `INSERT INTO customers (phone, name, plot, location, price, status, last_interaction)
                     VALUES (?, ?, ?, ?, ?, 'Quotation Generated', CURRENT_TIMESTAMP)
                     ON CONFLICT(phone) DO UPDATE SET
                       plot=excluded.plot, location=excluded.location, price=excluded.price,
                       status='Quotation Generated', last_interaction=CURRENT_TIMESTAMP`,
                    [_pendingQ.custPhone, (_pendingQ.customer && _pendingQ.customer.name) || '',
                     `${_pendingQ.plotRow.layout_name} - ${_pendingQ.plotRow.plot_no}`,
                     _pendingQ.plotRow.location || '', _pendingQ.pricing.total]
                );
                const fmt = n => '₹' + (n || 0).toLocaleString('en-IN');
                await client.sendMessage(target, `✅ Quotation sent to ${_pendingQ.custPhone} for *${_pendingQ.plotRow.plot_no}* @ ${fmt(_pendingQ.pricing.total)}.`);
            } catch (err) {
                await client.sendMessage(target, `❌ Failed to send quotation: ${err.message}`);
            }
            return true;
        }

        if (/^cancel$/i.test(bodyLow)) {
            pendingQuotations.delete(_adminPhone10);
            await client.sendMessage(target, '❌ Quotation cancelled.');
            return true;
        }

        // Price change: "price 42L" / "price 42 lakhs" / "change price to 4200000"
        const _priceMatch = bodyLow.match(/(?:price|change\s+price(?:\s+to)?|update\s+price(?:\s+to)?)\s*([\d,]+(?:\.\d+)?)\s*(?:l(?:akh(?:s)?)?)?/i);
        if (_priceMatch) {
            let newTotal = parseFloat(_priceMatch[1].replace(/,/g, ''));
            if (newTotal < 1000) newTotal = newTotal * 100000; // treat as lakhs
            _pendingQ.pricing.total = newTotal;
            _pendingQ.pricing.ratePerSqft = _pendingQ.sqft ? Math.round(newTotal / _pendingQ.sqft) : 0;
            _pendingQ.pricing.ratePerCent = _pendingQ.cent ? Math.round(newTotal / _pendingQ.cent) : 0;
            _pendingQ.pricing.regAprox = Math.round(newTotal * 0.075);
            _pendingQ.text = _buildQuotationText(_pendingQ.plotRow, _pendingQ.customer, _pendingQ.pricing, _pendingQ.senderName, _pendingQ.customNote);
            _pendingQ.expiresAt = Date.now() + 10 * 60 * 1000;
            pendingQuotations.set(_adminPhone10, _pendingQ);
            const fmt = n => '₹' + (n || 0).toLocaleString('en-IN');
            await client.sendMessage(target,
                `📝 *Updated Preview* (to ${_pendingQ.custPhone}):\n\n${_pendingQ.text}\n\n` +
                `Reply *confirm* to send · *cancel* to abort · *price X* / *note: text* for more changes.`
            );
            return true;
        }

        // Note: "note: bank loan not available"
        const _noteMatch = bodyOrig.match(/^(?:add\s+)?note:?\s+(.+)$/i);
        if (_noteMatch) {
            _pendingQ.customNote = _noteMatch[1].trim();
            _pendingQ.text = _buildQuotationText(_pendingQ.plotRow, _pendingQ.customer, _pendingQ.pricing, _pendingQ.senderName, _pendingQ.customNote);
            _pendingQ.expiresAt = Date.now() + 10 * 60 * 1000;
            pendingQuotations.set(_adminPhone10, _pendingQ);
            await client.sendMessage(target,
                `📝 *Updated Preview* (to ${_pendingQ.custPhone}):\n\n${_pendingQ.text}\n\n` +
                `Reply *confirm* to send · *cancel* to abort · *price X* / *note: text* for more changes.`
            );
            return true;
        }

        // Unrecognised input while quotation is pending
        await client.sendMessage(target,
            `⚠️ Quotation pending for *${_pendingQ.custPhone}*. Reply:\n` +
            `• *confirm* — send as shown\n` +
            `• *cancel* — abort\n` +
            `• *price 45L* — change price\n` +
            `• *note: your text* — add a custom note\n\n` +
            `_(Preview expires in ~10 min)_`
        );
        return true;
    }

    // ── Staff Attendance via WhatsApp ──
    if (bodyNoSpace === '!attendance' || (message.type === 'location' && message.hasMedia)) {
        if (await _guardCmd(message, 'attendance')) return true;
        try {
            // Find staff member by phone
            const phone = message.from.replace(/\D/g, '');
            const staffList = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'staff_members.json'), 'utf8') || '[]');
            const staffMember = staffList.find(s => s.Phone.replace(/\D/g, '').includes(phone.slice(-10)));

            if (!staffMember) {
                await message.reply("❌ Error: Phone number not recognized in Staff Database.");
                return true;
            }

            let gps = "Not Provided";
            if (message.type === 'location') {
                gps = `${message.location.latitude}, ${message.location.longitude}`;
            }

            let photoPath = "No Photo";
            if (message.hasMedia) {
                const media = await message.downloadMedia();
                if (media) {
                    const fileName = `attendance_${phone}_${Date.now()}.jpg`;
                    const dir = path.join(ROOT_DIR, 'customer_docs'); // Reuse existing media dir
                    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
                    fs.writeFileSync(path.join(dir, fileName), media.data, 'base64');
                    photoPath = `/customer_docs/${fileName}`;
                }
            }

            // Send to Server API to record attendance
            if (process.send) {
                process.send({
                    type: 'record_attendance',
                    data: {
                        staffId: staffMember.Staff_ID,
                        name: staffMember.Name,
                        gps: gps,
                        photo: photoPath,
                        timestamp: new Date().toISOString()
                    }
                });
            }

            await message.reply(`✅ *Attendance Recorded*\n👤 Name: ${staffMember.Name}\n📍 GPS: ${gps}\n📸 Photo: Verified\n⏰ Time: ${new Date().toLocaleTimeString()}`);
            return true;
        } catch (e) {
            console.error('[BOT] Attendance Error:', e);
            await message.reply("⚠️ Failed to record attendance. Please try again.");
            return true;
        }
    }

    if (bodyNoSpace.includes('!lead') || bodyNoSpace.includes('!sync') || bodyNoSpace.includes('!excel')) {
        console.log(`[ADMIN COMMAND] target=${target}, body=${bodyRaw}, isDirect=${isDirectToBot}`);
    }

    // ── Payment / Bank-details dispatch (intercepts BEFORE the layout dispatcher) ──
    // Triggers on: send|share|forward + payment-related keyword + recipient phone.
    // Examples:
    //   • share payment link to <phone>
    //   • send bank details to <phone>
    //   • forward UPI to <phone>
    //   • please share account details to <phone>
    //   • send payment request of 50000 to <phone>
    // Verb + money amount + phone is a strong signal for a payment-related request,
    // even when the body doesn't contain the literal "payment link" keyword.
    // Verbs widened to also include collect / request / raise.
    const _paymentVerb = bodyRaw.match(/^(?:please\s+|kindly\s+)?(send|share|forward|dispatch|collect|request|raise)\s+/i);

    // Strong word signals (anything money-related counts)
    const _hasPaymentKw = /(payment|advance|booking|token|deposit|registration\s*fee|emi|installment|instalment|bank\s*details|account\s*details|upi(\s*id)?|gpay|google\s*pay|qr\s*code\s*for\s*pay|payment\s*qr|account\s*number|bank|amount)/i.test(bodyRaw);

    // Money amount signals: digits with currency, lakh/crore, or just a 4+ digit number that looks like rupees
    const _hasMoneyAmount = /(?:rs\.?|₹|inr)\s*[\d,]{2,}/i.test(bodyRaw)
                         || /\b\d+(?:\.\d+)?\s*(?:lakh|lac|lakhs|cr|crore)s?\b/i.test(bodyRaw)
                         || /\b(?:of|for|amount|advance|booking|token|deposit)\s*(?:rs\.?|₹|inr)?\s*\d{4,}/i.test(bodyRaw);

    const _hasPhoneRun  = /\d[\d\s]{6,}\d/.test(bodyRaw);

    // Trigger if: verb + phone + (any payment keyword OR a money amount).
    // The money-amount check catches "send payment advance of 50000 to X" without needing exact keywords.
    if (_paymentVerb && _hasPhoneRun && (_hasPaymentKw || _hasMoneyAmount)) {
        if (await _guardCmd(message, 'payment_dispatch')) return true;
        try {
            const senderPhone = (message.fromMe ? message.to : message.from).replace(/\D/g, '');
            const senderName  = await resolveStaffName(senderPhone, message);

            // Extract target phone (last 10+ digit run)
            const digitRuns = [...bodyRaw.matchAll(/\d[\d\s]*\d/g)]
                .filter(m => m[0].replace(/\D/g, '').length >= 10);
            if (!digitRuns.length) { await client.sendMessage(target, '⚠️ No valid 10-digit phone in your message.'); return true; }
            const targetRaw = digitRuns[digitRuns.length - 1][0].replace(/\D/g, '');
            const targetNorm = targetRaw.length === 10 ? '91' + targetRaw : targetRaw;
            const targetJid  = targetNorm + '@c.us';

            // Dedup + per-target rate-limit reuse the same global guard as the layout dispatcher
            global.__recentAdminDispatches = global.__recentAdminDispatches || new Map();
            const bodyKey = `PAY|${message.from}|${bodyRaw.substring(0, 200)}`;
            const last = global.__recentAdminDispatches.get(bodyKey);
            if (last && Date.now() - last < 300_000) { console.log('[PAYMENT DISPATCH] dup suppressed'); return true; }
            global.__recentAdminDispatches.set(bodyKey, Date.now());

            // Amount extraction — handles several phrasings:
            //   "payment advance of 50000", "advance 50000", "booking amount 100000",
            //   "₹50,000", "Rs 1,00,000", "5 lakh", "1.5 lac", "2 crore", "send 50000".
            let amount = null;
            // Tier 1: word like "of/for/amount/advance/booking/token/deposit" then digits
            const m1 = bodyRaw.match(/\b(?:of|for|amount|advance|booking|token|deposit|payable|due|emi|installment|instalment)\s*(?:of\s*)?(?:rs\.?|₹|inr)?\s*([\d][\d,]{2,})/i);
            // Tier 2: explicit currency token then digits
            const m2 = bodyRaw.match(/(?:rs\.?|₹|inr)\s*([\d][\d,]{2,})/i);
            // Tier 3: "N lakh/lac/crore" — convert to rupees
            const m3 = bodyRaw.match(/\b(\d+(?:\.\d+)?)\s*(lakh|lac|lakhs|cr|crore)s?\b/i);
            // Tier 4 (last resort): a verb directly followed by a standalone money-sized number (4+ digits)
            const m4 = bodyRaw.match(/^(?:please\s+|kindly\s+)?(?:send|share|forward|dispatch|collect|request|raise)\s+([\d][\d,]{3,})\b/i);

            if (m3) {
                const mag = /lakh|lac|lakhs/i.test(m3[2]) ? 100000 : 10000000;
                amount = Math.round(parseFloat(m3[1]) * mag);
            } else if (m1) {
                amount = parseInt(m1[1].replace(/,/g, ''), 10);
            } else if (m2) {
                amount = parseInt(m2[1].replace(/,/g, ''), 10);
            } else if (m4) {
                amount = parseInt(m4[1].replace(/,/g, ''), 10);
            }
            // Sanity: very small numbers are probably not amounts (could be plot numbers)
            if (amount !== null && amount < 100) amount = null;

            // Pull bank/UPI from project_banks first, then drd_company_settings as fallback
            const bank = await new Promise((resolve) => {
                db.get(`SELECT * FROM project_banks ORDER BY id LIMIT 1`, [], (err, row) => resolve(err ? null : row));
            });
            const cs = (() => {
                try { return JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'drd_company_settings.json'), 'utf8')); } catch (e) { return {}; }
            })();

            const acc_name = (bank && bank.acc_name) || (cs.bank && cs.bank.acc_name) || cs.companyName || 'DRD Realtors';
            const bank_name = (bank && bank.bank_name) || (cs.bank && cs.bank.bank_name) || '';
            const acc_no   = (bank && bank.acc_no)   || (cs.bank && cs.bank.acc_no)   || '';
            const ifsc     = (bank && bank.ifsc)     || (cs.bank && cs.bank.ifsc)     || '';
            const branch   = (bank && bank.branch)   || (cs.bank && cs.bank.branch)   || '';
            const upi_id   = (bank && bank.upi_id)   || (cs.bank && cs.bank.upi_id)   || '';

            if (!acc_no && !upi_id) {
                await client.sendMessage(target,
                    `⚠️ No bank/UPI details configured.\n\nAdd them in *Payment Hub → Bank Details* or *Global Company Settings → bank_info*, then retry.`);
                return true;
            }

            // Resolve customer name for personalization
            const targetPhone10 = targetNorm.slice(-10);
            let customerName = await new Promise((resolve) => {
                db.get(
                    `SELECT name FROM customers
                       WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
                       ORDER BY last_interaction DESC LIMIT 1`,
                    [`%${targetPhone10}`], (e, r) => resolve(e || !r ? null : r.name || null)
                );
            });
            if (!customerName) {
                try {
                    const c = await client.getContactById(targetJid);
                    customerName = c && (c.name || c.pushname || c.shortName) || null;
                } catch (e) {}
            }
            if (customerName && /^(new\s+lead|unknown|whatsapp\s+user|undefined|null|admin)$/i.test(customerName.trim())) {
                customerName = null;
            }

            const greet = customerName ? `Hello *${customerName}*! 👋` : `Hello! 👋`;
            let msg = `${greet}\n\nAs requested by *${senderName}*, please find our payment details below.\n\n`;
            msg += `🏢 *${acc_name}*\n`;
            if (amount) msg += `💰 Amount: *₹${amount.toLocaleString('en-IN')}*\n\n`;
            else        msg += '\n';
            if (acc_no)   msg += `🏦 Bank: ${bank_name}\n`;
            if (acc_no)   msg += `📋 A/C No: \`${acc_no}\`\n`;
            if (ifsc)     msg += `🔢 IFSC: \`${ifsc}\`\n`;
            if (branch)   msg += `🏦 Branch: ${branch}\n`;
            if (upi_id) {
                const upiLink = `upi://pay?pa=${encodeURIComponent(upi_id)}&pn=${encodeURIComponent(acc_name)}${amount ? `&am=${amount}&cu=INR` : ''}`;
                msg += `\n📱 *UPI ID*: \`${upi_id}\`\n`;
                msg += `🔗 Tap to pay via UPI: ${upiLink}\n`;
            }
            msg += `\nPlease share the payment screenshot once done. Thank you! 🙏\n— Team DRD Realtors`;

            await client.sendMessage(targetJid, msg);

            // Log + record a payment_request row so the dashboard reflects it
            db.run(
                `INSERT INTO payment_requests (phone, name, amount, purpose, status) VALUES (?, ?, ?, ?, 'Sent')`,
                [targetPhone10, customerName || '', amount || 0, 'Admin Dispatch'],
                (err) => { if (err) console.warn('[PAYMENT DISPATCH] log row failed:', err.message); }
            );

            await client.sendMessage(target,
                `✅ Payment details sent to ${targetPhone10}${amount ? ` (₹${amount.toLocaleString('en-IN')})` : ''}.`);
            console.log(`[PAYMENT DISPATCH] By "${senderName}" to ${targetPhone10}${amount ? ` for ₹${amount}` : ''}`);
        } catch (err) {
            await client.sendMessage(target, `❌ Payment dispatch failed: ${err.message}`);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP A — SALES WORKFLOW ADMIN COMMANDS
    // ══════════════════════════════════════════════════════════════════════════

    // ── Shared helpers for Group A handlers ──────────────────────────────────
    const _extractPhone = (txt) => {
        const runs = [...(txt || '').matchAll(/\d[\d\s]*\d/g)].filter(m => m[0].replace(/\D/g, '').length >= 10);
        if (!runs.length) return null;
        const raw = runs[runs.length - 1][0].replace(/\D/g, '');
        return raw.length === 10 ? '91' + raw : raw;
    };
    const _extractAmount = (txt) => {
        if (!txt) return null;
        const m3 = txt.match(/\b(\d+(?:\.\d+)?)\s*(lakh|lac|lakhs|cr|crore)s?\b/i);
        if (m3) { const mag = /lakh|lac|lakhs/i.test(m3[2]) ? 100000 : 10000000; return Math.round(parseFloat(m3[1]) * mag); }
        const m1 = txt.match(/\b(?:of|for|amount|advance|booking|token|deposit|received|paid|payable)\s*(?:of\s*)?(?:rs\.?|₹|inr)?\s*([\d][\d,]{2,})/i);
        if (m1) return parseInt(m1[1].replace(/,/g, ''), 10);
        const m2 = txt.match(/(?:rs\.?|₹|inr)\s*([\d][\d,]{2,})/i);
        if (m2) return parseInt(m2[1].replace(/,/g, ''), 10);
        return null;
    };
    // Simple natural-date parser: tomorrow / today / monday / 25 may / 25/05/2026 / 5pm
    const _parseDateTime = (txt) => {
        if (!txt) return { date: null, time: null };
        const lower = txt.toLowerCase();
        let date = null, time = null;
        const now = new Date();

        // Time: "5pm", "5:30pm", "17:30"
        const t = lower.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/) || lower.match(/\b(\d{1,2}):(\d{2})\b/);
        if (t) {
            let h = parseInt(t[1], 10), m = parseInt(t[2] || '0', 10);
            const ampm = t[3];
            if (ampm === 'pm' && h < 12) h += 12;
            if (ampm === 'am' && h === 12) h = 0;
            time = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
        }

        // Date
        if (/\btoday\b/.test(lower))           date = now;
        else if (/\btomorrow\b/.test(lower))   date = new Date(now.getTime() + 86400000);
        else if (/\bday\s+after\s+tomorrow\b/.test(lower)) date = new Date(now.getTime() + 2 * 86400000);
        else {
            const days = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
            const dHit = days.findIndex(d => lower.includes(d));
            if (dHit !== -1) {
                date = new Date(now);
                const diff = (dHit - now.getDay() + 7) % 7 || 7; // next occurrence
                date.setDate(date.getDate() + diff);
            } else {
                // "25 may" / "25th may 2026" / "25/05/2026" / "2026-05-25"
                const monMap = { jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11 };
                let m = lower.match(/(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*(?:\s+(\d{4}))?/);
                if (m) date = new Date(parseInt(m[3] || now.getFullYear()), monMap[m[2]], parseInt(m[1]));
                else if ((m = lower.match(/(\d{4})-(\d{1,2})-(\d{1,2})/)))    date = new Date(parseInt(m[1]), parseInt(m[2])-1, parseInt(m[3]));
                else if ((m = lower.match(/(\d{1,2})[/-](\d{1,2})[/-](\d{4})/))) date = new Date(parseInt(m[3]), parseInt(m[2])-1, parseInt(m[1]));
            }
        }
        // Default time = 11:00 if a date was found but no time
        if (date && !time) time = '11:00';
        return { date: date ? date.toISOString().slice(0,10) : null, time };
    };
    // Relative day parser: "after 3 days", "in 5 days", "+7d"
    const _parseRelativeDays = (txt) => {
        const m = (txt || '').toLowerCase().match(/(?:after|in|next)\s+(\d+)\s*(?:day|days|d)\b|\+\s*(\d+)\s*d\b/);
        if (!m) return null;
        const n = parseInt(m[1] || m[2], 10);
        if (!n) return null;
        const d = new Date(Date.now() + n * 86400000);
        return d.toISOString().slice(0,10);
    };
    const _findCustomer = (phone10) => new Promise(resolve => {
        db.get(
            `SELECT * FROM customers
               WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
               ORDER BY last_interaction DESC LIMIT 1`,
            [`%${phone10}`], (e, r) => resolve(r || null)
        );
    });
    // Dedup-once guard (used by every Group A handler so retries don't fire twice)
    const _adminDedupOk = (label) => {
        global.__recentAdminDispatches = global.__recentAdminDispatches || new Map();
        const key = `${label}|${message.from}|${bodyRaw.substring(0, 200)}`;
        const last = global.__recentAdminDispatches.get(key);
        if (last && Date.now() - last < 300_000) { console.log(`[${label}] dedup`); return false; }
        global.__recentAdminDispatches.set(key, Date.now());
        return true;
    };
    const _greetingFor = (customer) => {
        const n = customer && customer.name && !/^(admin|unknown|new\s+lead)$/i.test(customer.name.trim())
            ? customer.name.trim() : null;
        return n ? `Hello *${n}*! 👋` : `Hello! 👋`;
    };

    // ── A2: BOOK PLOT ─────────────────────────────────────────────────────────
    //   • book plot 14 in anisam for <phone>
    //   • book anisam 14 for <phone>
    //   • book Velavan plot 3A for <phone> advance 50000
    // Negative lookahead skips "book (a) (site) visit ..." — that belongs to the A3 handler.
    if (/^(?:please\s+|kindly\s+)?book\s+(?!(?:a\s+)?(?:site\s+)?visit\b)/i.test(bodyRaw) && /\b(?:for|to)\s+\d/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'book_plot')) return true;
        if (!_adminDedupOk('BOOK')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            const amount = _extractAmount(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a 10-digit customer phone. Try: `book Anisam 14 for <phone>`'); return true; }
            const phone10 = phone.slice(-10);

            // Extract plot ref: try "plot <X>" or "<layout> <plot_no>"
            let plotNoText = '', layoutHint = '';
            const m1 = bodyRaw.match(/plot\s*(?:no\.?|number\.?)?\s*([a-z0-9\-]+)/i);
            if (m1) plotNoText = m1[1];
            // Layout hint: tokens that aren't filler/verb/phone
            const filler = new Set(['book','plot','for','to','of','the','in','please','kindly','advance','booking','token','amount','rs','rs.','₹','inr','no','number']);
            layoutHint = bodyRaw.replace(/\d/g,'').split(/\s+/).filter(w => w.length > 2 && !filler.has(w.toLowerCase())).join(' ').trim();

            // Find a matching plot in DB
            const plotRow = await new Promise(resolve => {
                db.get(
                    `SELECT * FROM plots
                       WHERE (LOWER(layout_name) LIKE ? OR ? = '')
                         AND (LOWER(TRIM(plot_no)) = ? OR ? = '')
                       ORDER BY (status = 'Available') DESC, id DESC LIMIT 1`,
                    [`%${(layoutHint||'').toLowerCase()}%`, layoutHint, plotNoText.toLowerCase(), plotNoText],
                    (e, r) => resolve(r || null)
                );
            });
            if (!plotRow) { await client.sendMessage(target, `⚠️ Couldn't find a plot matching "${layoutHint} ${plotNoText}".`); return true; }

            // Update plot → Booked
            db.run(`UPDATE plots SET status = 'Booked', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [plotRow.id]);
            // Upsert CRM customer
            const customer = await _findCustomer(phone10);
            db.run(
                `INSERT INTO customers (phone, name, plot, location, price, status, last_interaction)
                 VALUES (?, ?, ?, ?, ?, 'Booked', CURRENT_TIMESTAMP)
                 ON CONFLICT(phone) DO UPDATE SET
                   plot = excluded.plot, location = excluded.location,
                   price = COALESCE(NULLIF(excluded.price,''), price),
                   status = 'Booked', last_interaction = CURRENT_TIMESTAMP`,
                [phone10, (customer && customer.name) || '', `${plotRow.layout_name} - Plot ${plotRow.plot_no}`, plotRow.location || '', plotRow.price || 0]
            );
            // Log a payment_request for the advance if specified
            if (amount) {
                db.run(
                    `INSERT INTO payment_requests (phone, name, amount, purpose, status, layout_name, plot_no) VALUES (?, ?, ?, ?, 'Sent', ?, ?)`,
                    [phone10, (customer && customer.name) || '', amount, 'Booking Advance', plotRow.layout_name, plotRow.plot_no]
                );
            }

            // Notify customer
            const greet = _greetingFor(customer);
            const targetJid = phone + '@c.us';
            const priceTxt = plotRow.price ? `₹${parseInt(plotRow.price).toLocaleString('en-IN')}` : 'Quoted price';
            let msg = `${greet}\n\nThank you for booking with *DRD Realtors*! 🎉\n\n` +
                      `🏡 *${plotRow.layout_name}* — Plot *${plotRow.plot_no}*\n` +
                      `📐 Size: ${plotRow.size || '—'} sqft\n` +
                      `💰 Plot Value: ${priceTxt}\n`;
            if (amount) msg += `📋 Booking Advance: *₹${amount.toLocaleString('en-IN')}*\n`;
            msg += `\nYour booking has been confirmed by *${senderName}*. We'll share the next steps (sale agreement, registration date) shortly.`;
            await client.sendMessage(targetJid, msg);

            await client.sendMessage(target,
                `✅ Booked *${plotRow.plot_no}* in *${plotRow.layout_name}* for ${phone10}${amount ? ` (advance ₹${amount.toLocaleString('en-IN')})` : ''}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Booking failed: ${err.message}`);
        }
        return true;
    }

    // ── A3: SCHEDULE SITE VISIT ───────────────────────────────────────────────
    //   • schedule visit for <phone> tomorrow 4pm
    //   • schedule site visit on 25 may 5pm for <phone>
    //   • book visit for <phone> on monday 11am
    if (/^(?:please\s+|kindly\s+)?(?:schedule|book|fix|set)\s+(?:a\s+)?(?:site\s+)?visit\s+/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'schedule_visit')) return true;
        if (!_adminDedupOk('VISIT')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone. Try: `schedule visit for <phone> tomorrow 4pm`'); return true; }
            const phone10 = phone.slice(-10);

            const { date, time } = _parseDateTime(bodyRaw);
            if (!date) { await client.sendMessage(target, '⚠️ Couldn\'t parse the date. Try: `tomorrow 4pm`, `monday 11am`, `25 may 5pm`, `2026-05-25 17:00`'); return true; }

            const customer = await _findCustomer(phone10);
            // Layout hint (if present)
            let layoutHint = '';
            const lm = bodyRaw.match(/(?:at|in|for)\s+([a-z][a-z\s]+?)(?=\s+(?:on|for|tomorrow|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d|$))/i);
            if (lm) layoutHint = lm[1].trim();

            db.run(
                `INSERT INTO site_visits (customer_phone, layout_name, visit_date, visit_time, status, notes) VALUES (?, ?, ?, ?, 'Scheduled', ?)`,
                [phone10, layoutHint || (customer && customer.plot) || '', date, time, `Scheduled by ${senderName} via WhatsApp`]
            );

            const targetJid = phone + '@c.us';
            const greet = _greetingFor(customer);
            const dt = new Date(date + 'T' + (time || '11:00'));
            const dtPretty = dt.toLocaleDateString('en-IN', { weekday:'long', day:'2-digit', month:'short', year:'numeric' }) + ' at ' + dt.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', hour12:true });
            let msg = `${greet}\n\n📅 Your *Site Visit* has been scheduled!\n\n🗓️ *${dtPretty}*\n`;
            if (layoutHint || (customer && customer.plot)) msg += `📍 Location: ${layoutHint || customer.plot}\n`;
            msg += `\nScheduled by *${senderName}*. Please reply to reschedule or cancel.`;
            await client.sendMessage(targetJid, msg);

            await client.sendMessage(target, `✅ Visit scheduled for ${phone10} on ${dtPretty}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Schedule visit failed: ${err.message}`);
        }
        return true;
    }

    // ── A4: RESCHEDULE VISIT ──────────────────────────────────────────────────
    //   • reschedule visit for <phone> to tomorrow 5pm
    //   • move visit of <phone> to monday 11am
    if (/^(?:please\s+|kindly\s+)?(?:reschedule|move|postpone|shift)\s+(?:the\s+)?visit\s+/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'reschedule_visit')) return true;
        if (!_adminDedupOk('RESCHEDULE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);
            const { date, time } = _parseDateTime(bodyRaw);
            if (!date) { await client.sendMessage(target, '⚠️ Couldn\'t parse the new date/time.'); return true; }

            const existing = await new Promise(resolve =>
                db.get(`SELECT * FROM site_visits WHERE customer_phone = ? AND status != 'Cancelled' ORDER BY id DESC LIMIT 1`, [phone10], (e, r) => resolve(r || null))
            );
            if (!existing) { await client.sendMessage(target, `⚠️ No active site visit found for ${phone10}. Use \`schedule visit\` instead.`); return true; }

            db.run(`UPDATE site_visits SET visit_date = ?, visit_time = ?, status = 'Rescheduled', notes = ? WHERE id = ?`,
                [date, time, `Rescheduled by ${senderName}`, existing.id]);

            const customer = await _findCustomer(phone10);
            const targetJid = phone + '@c.us';
            const greet = _greetingFor(customer);
            const dt = new Date(date + 'T' + (time || '11:00'));
            const dtPretty = dt.toLocaleDateString('en-IN', { weekday:'long', day:'2-digit', month:'short', year:'numeric' }) + ' at ' + dt.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', hour12:true });
            await client.sendMessage(targetJid,
                `${greet}\n\n🔄 Your site visit has been *rescheduled*.\n\n🗓️ New time: *${dtPretty}*\n\nUpdated by *${senderName}*. We look forward to meeting you!`);
            await client.sendMessage(target, `✅ Visit rescheduled for ${phone10} → ${dtPretty}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Reschedule failed: ${err.message}`);
        }
        return true;
    }

    // ── A5: FOLLOW-UP SCHEDULER ───────────────────────────────────────────────
    //   • follow up with <phone> after 3 days
    //   • remind to call <phone> in 5 days
    //   • set followup for <phone> on monday: discuss bank loan
    if (/^(?:please\s+|kindly\s+)?(?:follow\s*up|followup|remind|set\s+followup)\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'followup')) return true;
        if (!_adminDedupOk('FOLLOWUP')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);

            // Date: prefer relative "after N days", else parsed date
            let next = _parseRelativeDays(bodyRaw);
            if (!next) {
                const { date } = _parseDateTime(bodyRaw);
                next = date;
            }
            if (!next) next = new Date(Date.now() + 3 * 86400000).toISOString().slice(0,10); // default T+3d

            // Note text after colon, if any
            const noteMatch = bodyRaw.match(/:\s*(.+)$/);
            const note = noteMatch ? noteMatch[1].trim() : '';

            db.run(
                `INSERT INTO followups (customer_phone, staff_name, notes, next_followup, status) VALUES (?, ?, ?, ?, 'Pending')`,
                [phone10, senderName, note, next]
            );
            const dtPretty = new Date(next).toLocaleDateString('en-IN', { weekday:'short', day:'2-digit', month:'short', year:'numeric' });
            await client.sendMessage(target, `✅ Follow-up scheduled for ${phone10} on ${dtPretty}${note ? ` — "${note}"` : ''}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Follow-up failed: ${err.message}`);
        }
        return true;
    }

    // ── A6: ASSIGN LEAD TO STAFF ──────────────────────────────────────────────
    //   • assign <phone> to ramesh
    //   • assign lead <phone> to staff prakash
    if (/^(?:please\s+|kindly\s+)?assign\s+/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'assign_lead')) return true;
        if (!_adminDedupOk('ASSIGN')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone. Try: `assign <phone> to Ramesh`'); return true; }
            const phone10 = phone.slice(-10);

            // Staff token after "to"
            const m = bodyRaw.match(/\bto\s+([a-z][a-z\s]+?)(?:\s*$|\.|,)/i);
            const staffHint = m ? m[1].trim() : '';
            if (!staffHint) { await client.sendMessage(target, '⚠️ Tell me who to assign to. Try: `assign <phone> to Ramesh`'); return true; }

            const staff = await new Promise(resolve => {
                db.get(`SELECT * FROM staff WHERE LOWER(name) LIKE ? AND is_active != 0 ORDER BY length(name) ASC LIMIT 1`,
                    [`%${staffHint.toLowerCase()}%`], (e, r) => resolve(r || null));
            });
            if (!staff) { await client.sendMessage(target, `⚠️ No active staff member matching "${staffHint}". Check Team Management.`); return true; }

            // Mark customer with lead owner via a follow-up note + status update
            db.run(
                `INSERT INTO customers (phone, name, status, last_interaction, lead_notes)
                 VALUES (?, '', 'Assigned', CURRENT_TIMESTAMP, ?)
                 ON CONFLICT(phone) DO UPDATE SET
                   status = 'Assigned',
                   lead_notes = COALESCE(lead_notes,'') || ?, last_interaction = CURRENT_TIMESTAMP`,
                [phone10, `Assigned to ${staff.name} by ${senderName}`, `\n[${new Date().toISOString().slice(0,10)}] Assigned to ${staff.name} by ${senderName}`]
            );
            db.run(`INSERT INTO followups (customer_phone, staff_name, notes, next_followup, status)
                    VALUES (?, ?, ?, date('now','+1 day'), 'Pending')`,
                [phone10, staff.name, `Lead assignment from ${senderName}`]);

            // Notify the staff member if they have a phone
            const staffPhone = String(staff.phone || '').replace(/\D/g, '');
            if (staffPhone.length >= 10) {
                const staffJid = (staffPhone.length === 10 ? '91' + staffPhone : staffPhone) + '@c.us';
                try {
                    await client.sendMessage(staffJid,
                        `📌 New lead assigned to you by *${senderName}*.\n\n📞 Customer: ${phone10}\n\nPlease reach out within 24 hours.`);
                } catch (e) { console.warn('[ASSIGN] could not notify staff:', e.message); }
            }
            await client.sendMessage(target, `✅ Lead ${phone10} assigned to *${staff.name}*.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Assign failed: ${err.message}`);
        }
        return true;
    }

    // ── A1: SEND QUOTATION ────────────────────────────────────────────────────
    //   • send quotation for plot 14 anisam to <phone>
    //   • quote anisam 14 to <phone>
    //   • send quote of velavan 3A to <phone>
    if (/^(?:please\s+|kindly\s+)?(?:send\s+|share\s+)?(?:quotation|quote)\b/i.test(bodyRaw) && (/\b(?:to|for)\s+\d/i.test(bodyRaw) || /\b(?:to|for)\b[\s\S]*\d{10}/i.test(bodyRaw))) {
        if (await _guardCmd(message, 'send_quotation')) return true;
        if (!_adminDedupOk('QUOTE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);

            let plotNoText = '', layoutHint = '';
            const m1 = bodyRaw.match(/plot\s*(?:no\.?|number\.?)?\s*([a-z0-9\-]+)/i);
            if (m1) plotNoText = m1[1];
            const filler = new Set(['send','share','please','kindly','quotation','quote','for','to','of','the','in','plot','no','number','below','above','num','mobile','phone','dear','sir','kindly','pls']);
            layoutHint = bodyRaw.replace(/\d/g,'').split(/\s+/).filter(w => w.length > 2 && !filler.has(w.toLowerCase())).join(' ').trim();

            // Match each hint token individually (OR) so "bala garen" finds "BALADHANDAYUTHABANI GARDEN"
            const hintTokens = layoutHint.split(/\s+/).filter(w => w.length >= 3);
            const plotRow = await new Promise(resolve => {
                if (hintTokens.length === 0) {
                    db.get(
                        `SELECT * FROM plots WHERE (LOWER(TRIM(plot_no)) = ? OR ? = '')
                         ORDER BY (status = 'Available') DESC, id DESC LIMIT 1`,
                        [plotNoText.toLowerCase(), plotNoText],
                        (e, r) => resolve(r || null)
                    );
                } else {
                    const likeClauses = hintTokens.map(() => `LOWER(layout_name) LIKE ?`).join(' OR ');
                    const params = [...hintTokens.map(t => `%${t.toLowerCase()}%`), plotNoText.toLowerCase(), plotNoText];
                    db.get(
                        `SELECT * FROM plots
                           WHERE (${likeClauses})
                             AND (LOWER(TRIM(plot_no)) = ? OR ? = '')
                           ORDER BY (status = 'Available') DESC, id DESC LIMIT 1`,
                        params,
                        (e, r) => resolve(r || null)
                    );
                }
            });
            if (!plotRow) {
                await client.sendMessage(target, `⚠️ Couldn't find plot *${plotNoText || '?'}* in layout matching *${layoutHint || '?'}*.\nCheck: plot number correct? Layout name clear?`);
                return true;
            }

            const customer = await _findCustomer(phone10);
            const total = parseFloat(plotRow.price) || 0;
            const sqft  = parseFloat(plotRow.size) || 0;
            const ratePerSqft = sqft ? Math.round(total / sqft) : 0;
            const cent = sqft ? (sqft / 435.6) : 0;
            const ratePerCent = cent ? Math.round(total / cent) : 0;
            const regAprox = Math.round(total * 0.075); // Tamil Nadu approx 7% reg+stamp

            const targetJid = phone + '@c.us';
            const pricing = { total, ratePerSqft, ratePerCent, regAprox };
            const text = _buildQuotationText(plotRow, customer, pricing, senderName, null);

            // Purge stale entries before storing
            for (const [k, v] of pendingQuotations) {
                if (Date.now() > v.expiresAt) pendingQuotations.delete(k);
            }
            const adminPhone10q = (message.fromMe ? message.to : message.from).replace(/\D/g, '').slice(-10);
            pendingQuotations.set(adminPhone10q, {
                plotRow, customer, custPhone: phone10, custJid: targetJid, senderName,
                pricing, sqft, cent, customNote: null, text,
                expiresAt: Date.now() + 10 * 60 * 1000
            });

            await client.sendMessage(target,
                `📋 *Quotation Preview* (will be sent to ${phone10}):\n\n${text}\n\n` +
                `Reply *confirm* to send · *cancel* to abort\n` +
                `• *price 45L* — change price\n` +
                `• *note: your text* — add a custom note\n` +
                `_(Expires in 10 min)_`
            );
        } catch (err) {
            await client.sendMessage(target, `❌ Quotation failed: ${err.message}`);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP B — OPERATIONS COMMANDS
    // ══════════════════════════════════════════════════════════════════════════

    // ── B1: MARK PLOT AS <STATUS> ─────────────────────────────────────────────
    //   • mark plot 14 anisam as sold
    //   • mark anisam 14 as booked
    //   • set status of velavan 3A to available
    if (/^(?:please\s+|kindly\s+)?(?:mark|set)\s+/i.test(bodyRaw)
        && /\b(?:as|to)\s+(available|booked|sold|blocked|hold|reserved)\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'mark_plot_status')) return true;
        if (!_adminDedupOk('MARK')) return true;
        try {
            const newStatusMatch = bodyRaw.match(/\b(?:as|to)\s+(available|booked|sold|blocked|hold|reserved)\b/i);
            const newStatus = newStatusMatch[1].charAt(0).toUpperCase() + newStatusMatch[1].slice(1).toLowerCase();

            // Strip the "as <status>" tail so plot parsing doesn't see it
            const head = bodyRaw.replace(/\s+(?:as|to)\s+(available|booked|sold|blocked|hold|reserved)\b.*$/i, '');
            let plotNoText = '', layoutHint = '';
            const m1 = head.match(/plot\s*(?:no\.?|number\.?)?\s*([a-z0-9\-]+)/i);
            if (m1) plotNoText = m1[1];
            const filler = new Set(['mark','set','plot','status','of','the','in','please','kindly','no','number']);
            layoutHint = head.replace(/\d/g,'').split(/\s+/).filter(w => w.length > 2 && !filler.has(w.toLowerCase())).join(' ').trim();

            const plotRow = await new Promise(resolve => {
                db.get(
                    `SELECT * FROM plots
                       WHERE (LOWER(layout_name) LIKE ? OR ? = '')
                         AND (LOWER(TRIM(plot_no)) = ? OR ? = '')
                       ORDER BY id DESC LIMIT 1`,
                    [`%${(layoutHint||'').toLowerCase()}%`, layoutHint, plotNoText.toLowerCase(), plotNoText],
                    (e, r) => resolve(r || null)
                );
            });
            if (!plotRow) { await client.sendMessage(target, `⚠️ No plot found matching "${layoutHint} ${plotNoText}".`); return true; }

            db.run(`UPDATE plots SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [newStatus, plotRow.id]);
            await client.sendMessage(target, `✅ *${plotRow.layout_name}* Plot *${plotRow.plot_no}* → *${newStatus}*.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Mark status failed: ${err.message}`);
        }
        return true;
    }

    // ── B2: SEND BROCHURE OF <LAYOUT> TO <PHONE> ──────────────────────────────
    // Differs from layout dispatch: sends ONLY PDF brochures, no full image set.
    if (/^(?:please\s+|kindly\s+)?(?:send|share|forward)\s+(?:the\s+)?brochure\s+/i.test(bodyRaw)
        && /\b(?:to|for)\s+\d/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'send_brochure')) return true;
        if (!_adminDedupOk('BROCHURE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a phone number.'); return true; }
            const targetJid = phone + '@c.us';
            const phone10 = phone.slice(-10);

            // Extract layout name (everything between "brochure of" and "to <phone>")
            let layoutHint = bodyRaw.replace(/^.*?brochure\s+(?:of\s+)?/i, '').replace(/\s+(?:to|for)\s+.*$/i, '').trim();

            // Find a directory matching layout; filter to .pdf only
            let visuals = findVisualForLayout(layoutHint, IMAGES_DIR)
                       || findVisualForLayout(layoutHint, path.join(IMAGES_DIR, '01 All Layouts'));
            if (!visuals) { await client.sendMessage(target, `⚠️ No layout media found for "${layoutHint}".`); return true; }

            const customer = await _findCustomer(phone10);
            const greet = _greetingFor(customer);
            await client.sendMessage(targetJid,
                `${greet}\n\nAs requested by *${senderName}*, please find the *${layoutHint}* brochure attached.\n\nFor any questions, feel free to reply.\n— Team DRD Realtors`);

            let sentCount = 0;
            if (visuals.type === 'directory') {
                const pdfs = visuals.files.filter(f => f.toLowerCase().endsWith('.pdf') && !f.startsWith('~$')).slice(0, 3);
                if (!pdfs.length) {
                    // Fall back: send the most "brochure-like" image (master/cover/main) if no PDFs
                    const fallback = visuals.files
                        .filter(f => !f.startsWith('~$') && /\.(jpe?g|png)$/i.test(f))
                        .sort((a, b) => (/master|brochure|main|cover/i.test(a) ? 0 : 1) - (/master|brochure|main|cover/i.test(b) ? 0 : 1))
                        .slice(0, 1);
                    for (const f of fallback) {
                        try { await client.sendMessage(targetJid, MessageMedia.fromFilePath(path.join(visuals.path, f))); sentCount++; } catch (e) {}
                    }
                } else {
                    for (const f of pdfs) {
                        try { await client.sendMessage(targetJid, MessageMedia.fromFilePath(path.join(visuals.path, f))); sentCount++; await new Promise(r => setTimeout(r, 1500)); } catch (e) {}
                    }
                }
            } else if (visuals.path.toLowerCase().endsWith('.pdf')) {
                try { await client.sendMessage(targetJid, MessageMedia.fromFilePath(visuals.path)); sentCount++; } catch (e) {}
            }

            await client.sendMessage(target, sentCount ? `✅ Brochure sent to ${phone10} (${sentCount} file).` : `⚠️ No brochure PDF found for "${layoutHint}". Add one in Asset Manager.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Brochure send failed: ${err.message}`);
        }
        return true;
    }

    // ── B3: SEND GPS / LOCATION OF <LAYOUT> TO <PHONE> ────────────────────────
    if (/^(?:please\s+|kindly\s+)?(?:send|share|forward)\s+(?:the\s+)?(?:gps|location|maps?|map\s+link)\s+/i.test(bodyRaw)
        && /\b(?:to|for)\s+\d/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'send_gps')) return true;
        if (!_adminDedupOk('GPS')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a phone number.'); return true; }
            const phone10 = phone.slice(-10);
            const targetJid = phone + '@c.us';

            // ── Smart layout resolver ────────────────────────────────
            // Admin doesn't need to type the full layout name. We tokenise
            // the message (minus verbs, phone, common fillers) and score
            // every known layout by how many of its distinctive words appear.
            // "send location anisam to 98765..."  → matches "DRD ANISAM GARDENS"
            // "share map velavan phase 2 to 98..." → matches "DRD VELAVAN PHASE 2"
            const allLayouts = await new Promise(resolve =>
                db.all(`SELECT DISTINCT layout_name FROM plots WHERE layout_name IS NOT NULL AND layout_name != ''`,
                    [], (e, r) => resolve(r || [])));

            const stopwords = new Set(['drd','gardens','garden','phase','project','layout','site','plot','the','of','at','in','for','to','please','kindly','send','share','forward','gps','location','map','maps','link']);
            const cleanBody = bodyRaw.toLowerCase().replace(/\b\d{7,}\b/g, ' ');

            let bestMatch = null, bestScore = 0;
            for (const { layout_name: ln } of allLayouts) {
                const tokens = ln.toLowerCase().split(/\s+/).filter(t => t.length > 2 && !stopwords.has(t));
                if (!tokens.length) continue;
                let score = 0;
                for (const tok of tokens) if (cleanBody.includes(tok)) score++;
                if (score > bestScore) { bestScore = score; bestMatch = ln; }
            }

            // Look up GPS for the matched layout (prefer rows that actually have GPS)
            let gpsLink = '';
            let layoutName = bestMatch || '';
            if (bestMatch) {
                const row = await new Promise(resolve =>
                    db.get(`SELECT gps_location FROM plots WHERE layout_name = ? AND gps_location != '' AND gps_location IS NOT NULL LIMIT 1`,
                        [bestMatch], (e, r) => resolve(r || null)));
                if (row) gpsLink = row.gps_location;
            }

            // Fall back to company-wide GPS (drd_company_settings.json)
            if (!gpsLink) {
                try {
                    const cs = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'drd_company_settings.json'), 'utf8'));
                    gpsLink = cs.mapsUrl || (cs.gps ? `https://maps.google.com/?q=${cs.gps}` : '');
                    if (!layoutName) layoutName = cs.companyName || 'Our Office';
                } catch (e) {}
            }

            // Still nothing? Show admin the layouts that DO have GPS so they can pick.
            if (!gpsLink) {
                const candidates = await new Promise(resolve =>
                    db.all(`SELECT DISTINCT layout_name FROM plots WHERE gps_location != '' AND gps_location IS NOT NULL`,
                        [], (e, r) => resolve(r || [])));
                const list = candidates.length
                    ? candidates.map(c => `• ${c.layout_name}`).join('\n')
                    : '(none configured — add GPS in Property Inventory → Edit Plot, or set Maps URL in Company Settings)';
                await client.sendMessage(target,
                    `⚠️ Couldn't find a GPS-mapped layout from your message.\n\n*Available with GPS:*\n${list}\n\nTry: \`send gps anisam to ${phone10}\``);
                return true;
            }

            const vizUrl = (getBotSettings().visualizer_url || '').trim();
            const customer = await _findCustomer(phone10);
            const greet = _greetingFor(customer);
            const msg = `${greet}\n\n📍 *${layoutName}* — site location\n\n🗺️ ${gpsLink}\n` +
                        (vizUrl ? `\n🎨 Interactive Visualizer: ${vizUrl}\n` : '') +
                        `\nShared by *${senderName}*. See you at the site!`;
            await client.sendMessage(targetJid, msg);
            await client.sendMessage(target, `✅ GPS sent to ${phone10}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ GPS send failed: ${err.message}`);
        }
        return true;
    }

    // ── B4: SEND FLOOR PLAN / MASTER PLAN ─────────────────────────────────────
    if (/^(?:please\s+|kindly\s+)?(?:send|share|forward)\s+(?:the\s+)?(?:floor\s+plan|master\s+plan|site\s+plan|layout\s+plan|plan)\s+/i.test(bodyRaw)
        && /\b(?:to|for)\s+\d/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'send_floorplan')) return true;
        if (!_adminDedupOk('PLAN')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a phone number.'); return true; }
            const targetJid = phone + '@c.us';
            const phone10 = phone.slice(-10);

            let layoutHint = bodyRaw.replace(/^.*?plan\s+(?:of\s+)?/i, '').replace(/\s+(?:to|for)\s+.*$/i, '').trim();
            const visuals = findVisualForLayout(layoutHint, IMAGES_DIR)
                         || findVisualForLayout(layoutHint, path.join(IMAGES_DIR, '01 All Layouts'));
            if (!visuals) { await client.sendMessage(target, `⚠️ No layout media for "${layoutHint}".`); return true; }

            // Pick the file most likely to be a master/floor plan
            let planFile = null;
            if (visuals.type === 'directory') {
                const ranked = visuals.files
                    .filter(f => !f.startsWith('~$') && /\.(pdf|jpe?g|png)$/i.test(f))
                    .sort((a, b) => {
                        const score = f => /master|floor|site|plan|layout/i.test(f) ? 0 : 1;
                        return score(a) - score(b);
                    });
                planFile = ranked[0] ? path.join(visuals.path, ranked[0]) : null;
            } else {
                planFile = visuals.path;
            }
            if (!planFile) { await client.sendMessage(target, `⚠️ No suitable plan file found.`); return true; }

            const customer = await _findCustomer(phone10);
            const greet = _greetingFor(customer);
            await client.sendMessage(targetJid, `${greet}\n\n🗺️ *${layoutHint}* — master plan\n\nShared by *${senderName}*. Have a look at the plot positions, road sizes, and amenities.`);
            await client.sendMessage(targetJid, MessageMedia.fromFilePath(planFile));
            await client.sendMessage(target, `✅ Plan sent to ${phone10}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Plan send failed: ${err.message}`);
        }
        return true;
    }

    // ── B5: PATTA STATUS OF <PLOT> ────────────────────────────────────────────
    //   • patta status of velavan 3A
    //   • patta status anisam 14
    if (/^(?:please\s+|kindly\s+)?patta\s+status\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'patta_status')) return true;
        if (!_adminDedupOk('PATTA')) return true;
        try {
            let plotNoText = '', layoutHint = '';
            const m1 = bodyRaw.match(/plot\s*(?:no\.?)?\s*([a-z0-9\-]+)/i);
            if (m1) plotNoText = m1[1];
            const filler = new Set(['patta','status','of','plot','the','in','please','kindly','no']);
            layoutHint = bodyRaw.replace(/\d/g,'').split(/\s+/).filter(w => w.length > 2 && !filler.has(w.toLowerCase())).join(' ').trim();

            const reg = await new Promise(resolve =>
                db.get(`SELECT * FROM customer_registrations
                          WHERE LOWER(layout_name) LIKE ? AND (LOWER(TRIM(plot_no)) = ? OR ? = '')
                          ORDER BY id DESC LIMIT 1`,
                    [`%${layoutHint.toLowerCase()}%`, plotNoText.toLowerCase(), plotNoText],
                    (e, r) => resolve(r || null)));
            if (!reg) { await client.sendMessage(target, `⚠️ No registration found for "${layoutHint} ${plotNoText}".`); return true; }

            const txt = `📋 *Patta & Registration Status*\n\n` +
                        `🏡 ${reg.layout_name} · Plot ${reg.plot_no}\n` +
                        `👤 Customer: ${reg.customer_name || '—'} (${reg.customer_phone || '—'})\n` +
                        `📅 Reg Date: ${reg.reg_date || '—'}\n` +
                        `📋 Doc No: ${reg.doc_no || '—'}\n` +
                        `🏛️ SRO: ${reg.sro_office || '—'}\n\n` +
                        `🟦 *Patta Status*: ${reg.patta_status || 'Not applied'}\n` +
                        (reg.patta_applied_date ? `📅 Applied: ${reg.patta_applied_date}\n` : '') +
                        (reg.patta_notes ? `📝 Notes: ${reg.patta_notes}\n` : '');
            await client.sendMessage(target, txt);
        } catch (err) {
            await client.sendMessage(target, `❌ Patta lookup failed: ${err.message}`);
        }
        return true;
    }

    // ── B6: OUTSTANDING BALANCE FOR <PHONE> ───────────────────────────────────
    //   • outstanding for <phone>
    //   • balance for <phone>
    // Negative lookahead skips "outstanding loans" — that belongs to C5.
    if (/^(?:please\s+|kindly\s+)?(?:outstanding|balance|dues?)\b/i.test(bodyRaw) && !/\bloans?\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'outstanding_balance')) return true;
        if (!_adminDedupOk('BALANCE')) return true;
        try {
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);
            const customer = await _findCustomer(phone10);
            if (!customer) { await client.sendMessage(target, `⚠️ ${phone10} not in CRM.`); return true; }

            const payRows = await new Promise(resolve =>
                db.all(`SELECT amount, status FROM payment_requests WHERE phone = ?`, [phone10], (e, r) => resolve(r || [])));
            const received = payRows.filter(p => /received|verified|completed/i.test(p.status || '')).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
            const pending  = payRows.filter(p => /sent|pending|verification/i.test(p.status || '')).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
            const total    = parseFloat(customer.price) || 0;
            const balance  = Math.max(0, total - received);

            const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');
            await client.sendMessage(target,
                `📑 *Payment Status* — ${customer.name || phone10}\n\n` +
                `🏡 Plot: ${customer.plot || '—'}\n` +
                `💰 Total Price: ${fmt(total)}\n` +
                `✅ Received: ${fmt(received)}\n` +
                `🟡 Pending (sent, not yet received): ${fmt(pending)}\n` +
                `🔴 *Outstanding Balance*: *${fmt(balance)}*\n\n` +
                `${payRows.length} payment record(s) on file.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Balance lookup failed: ${err.message}`);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP C — MONEY & REPORTS COMMANDS
    // ══════════════════════════════════════════════════════════════════════════

    // ── C1: SEND RECEIPT / ACKNOWLEDGE PAYMENT ────────────────────────────────
    //   • send receipt for <phone>
    //   • acknowledge 50000 from <phone>
    //   • payment received 50000 from <phone>
    if (/^(?:please\s+|kindly\s+)?(?:send\s+)?(?:receipt|acknowledge|acknowledg|payment\s+received|received\s+payment)\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'send_receipt')) return true;
        if (!_adminDedupOk('RECEIPT')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);
            const targetJid = phone + '@c.us';

            let amount = _extractAmount(bodyRaw);
            // If no explicit amount, fetch the latest pending payment_request
            let originalRequest = null;
            if (!amount) {
                originalRequest = await new Promise(resolve =>
                    db.get(`SELECT * FROM payment_requests WHERE phone = ? AND status IN ('Sent','Verification Pending') ORDER BY created_at DESC LIMIT 1`,
                        [phone10], (e, r) => resolve(r || null)));
                if (originalRequest) amount = parseFloat(originalRequest.amount) || 0;
            }
            if (!amount) { await client.sendMessage(target, `⚠️ Need an amount. Try: \`acknowledge 50000 from ${phone10}\``); return true; }

            const customer = await _findCustomer(phone10);

            // Mark the request as received (or insert a new "received" row if none exists)
            if (originalRequest) {
                db.run(`UPDATE payment_requests SET status = 'Received', updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [originalRequest.id]);
            } else {
                db.run(
                    `INSERT INTO payment_requests (phone, name, amount, purpose, status) VALUES (?, ?, ?, 'Direct Receipt', 'Received')`,
                    [phone10, (customer && customer.name) || '', amount]
                );
            }

            const greet = _greetingFor(customer);
            const fmt = n => '₹' + parseInt(n).toLocaleString('en-IN');
            const receiptNo = 'RCP-' + new Date().toISOString().slice(0,10).replace(/-/g,'') + '-' + (Math.floor(Math.random() * 9000) + 1000);

            // Receipt to customer
            await client.sendMessage(targetJid,
                `${greet}\n\n📜 *PAYMENT RECEIVED — RECEIPT*\n\n` +
                `Receipt No: \`${receiptNo}\`\n` +
                `📅 Date: ${new Date().toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })}\n` +
                `💰 Amount: *${fmt(amount)}*\n` +
                `🏡 Plot: ${(customer && customer.plot) || (originalRequest && originalRequest.layout_name) || '—'}\n\n` +
                `Thank you for your payment! We have received the amount and updated your account.\n\n` +
                `Acknowledged by *${senderName}*\n— DRD Realtors`);

            // Confirmation to admin
            await client.sendMessage(target, `✅ Receipt sent to ${phone10} for ${fmt(amount)} · No. ${receiptNo}`);
        } catch (err) {
            await client.sendMessage(target, `❌ Receipt failed: ${err.message}`);
        }
        return true;
    }

    // ── C2: PAYMENT STATUS OF <PHONE> ─────────────────────────────────────────
    //   • payment status of <phone>
    //   • payments for <phone>
    if (/^(?:please\s+|kindly\s+)?payment(?:s)?\s+(?:status|history|of|for|list)\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'payment_status')) return true;
        if (!_adminDedupOk('PAYSTATUS')) return true;
        try {
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a customer phone.'); return true; }
            const phone10 = phone.slice(-10);
            const customer = await _findCustomer(phone10);
            const rows = await new Promise(resolve =>
                db.all(`SELECT * FROM payment_requests WHERE phone = ? ORDER BY created_at DESC LIMIT 15`, [phone10], (e, r) => resolve(r || [])));
            if (!rows.length) { await client.sendMessage(target, `📭 No payment records for ${phone10}.`); return true; }

            const fmt = n => '₹' + parseInt(n || 0).toLocaleString('en-IN');
            let msg = `💳 *Payment History — ${customer ? customer.name : phone10}*\n\n`;
            for (const r of rows) {
                const ic = /received|verified|completed/i.test(r.status || '') ? '✅'
                        : /verification/i.test(r.status || '') ? '🟡'
                        : /sent|pending/i.test(r.status || '') ? '🟠' : '⚪';
                msg += `${ic} ${(r.created_at || '').slice(0, 10)} — ${fmt(r.amount)} — ${r.purpose || '—'} — *${r.status}*\n`;
            }
            await client.sendMessage(target, msg);
        } catch (err) {
            await client.sendMessage(target, `❌ Payment status failed: ${err.message}`);
        }
        return true;
    }

    // ── C3: DAILY / WEEKLY REPORT ─────────────────────────────────────────────
    //   • daily report  /  weekly report  /  today's report  /  report today
    if (/^(?:please\s+|kindly\s+)?(?:daily|weekly|today(?:'s)?|yesterday(?:'s)?)\s+report\b/i.test(bodyRaw)
        || /^(?:please\s+|kindly\s+)?report\s+(?:for\s+)?(?:today|yesterday|this\s+week|week)\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'daily_report')) return true;
        if (!_adminDedupOk('REPORT')) return true;
        try {
            const isWeekly = /weekly|week/i.test(bodyRaw);
            const isYday = /yesterday/i.test(bodyRaw);
            const days = isWeekly ? 7 : 1;
            const sinceDate = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
            const today = new Date().toISOString().slice(0, 10);
            const range = isWeekly ? `last 7 days` : (isYday ? `yesterday` : `today`);

            const q = (sql, args) => new Promise(r => db.all(sql, args, (e, rows) => r(rows || [])));
            const cnt = sql => new Promise(r => db.get(sql, (e, row) => r(row ? Object.values(row)[0] || 0 : 0)));

            const cutoff = `datetime('now', '-${days} days')`;
            const [newLeads, booked, sold, payments, visits, attendance] = await Promise.all([
                cnt(`SELECT COUNT(*) FROM customers WHERE created_at >= ${cutoff}`),
                cnt(`SELECT COUNT(*) FROM customers WHERE status = 'Booked' AND last_interaction >= ${cutoff}`),
                cnt(`SELECT COUNT(*) FROM customers WHERE status = 'Purchased' AND last_interaction >= ${cutoff}`),
                q(`SELECT amount, status FROM payment_requests WHERE created_at >= ${cutoff}`, []),
                cnt(`SELECT COUNT(*) FROM site_visits WHERE visit_date >= date('now','-${days} days')`),
                cnt(`SELECT COUNT(DISTINCT staff_id) FROM attendance WHERE date = '${today}'`),
            ]);
            const received = payments.filter(p => /received|verified|completed/i.test(p.status || '')).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
            const pending  = payments.filter(p => /sent|pending|verification/i.test(p.status || '')).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
            const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');

            const msg =
                `📊 *${isWeekly ? 'Weekly' : (isYday ? "Yesterday's" : "Today's")} Report*\n` +
                `_Period: ${range}_\n\n` +
                `📞 New Leads: *${newLeads}*\n` +
                `📝 Bookings: *${booked}*\n` +
                `🏆 Purchases: *${sold}*\n` +
                `📅 Site Visits scheduled: *${visits}*\n` +
                `👥 Staff present today: *${attendance}*\n\n` +
                `💰 *Payments*\n` +
                `   ✅ Received: ${fmt(received)}\n` +
                `   🟡 Pending: ${fmt(pending)}\n\n` +
                `_Generated at ${new Date().toLocaleString('en-IN')}_`;
            await client.sendMessage(target, msg);
        } catch (err) {
            await client.sendMessage(target, `❌ Report failed: ${err.message}`);
        }
        return true;
    }

    // ── C4: COMMISSION FOR <STAFF> ────────────────────────────────────────────
    //   • commission for Saravanan
    //   • commission for ramesh this month
    if (/^(?:please\s+|kindly\s+)?commission\s+(?:for|of)\s+/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'commission')) return true;
        if (!_adminDedupOk('COMMISSION')) return true;
        try {
            const m = bodyRaw.match(/commission\s+(?:for|of)\s+([a-z][a-z\s]+?)(?:\s+(?:this|last)\s+month|\s*$|\.|,)/i);
            const staffHint = m ? m[1].trim() : '';
            if (!staffHint) { await client.sendMessage(target, '⚠️ Specify staff. Try: `commission for Saravanan`'); return true; }
            const isLastMonth = /last\s+month/i.test(bodyRaw);

            const staff = await new Promise(resolve =>
                db.get(`SELECT * FROM staff WHERE LOWER(name) LIKE ? AND is_active != 0 LIMIT 1`,
                    [`%${staffHint.toLowerCase()}%`], (e, r) => resolve(r || null)));
            if (!staff) { await client.sendMessage(target, `⚠️ No staff matching "${staffHint}".`); return true; }

            // Best-effort: total commission/sales from customer_loans + bookings credited to this staff.
            // Schema doesn't have a direct staff link on sales — surface what we can.
            const monthSql = isLastMonth
                ? `strftime('%Y-%m', start_date) = strftime('%Y-%m', date('now','-1 month'))`
                : `strftime('%Y-%m', start_date) = strftime('%Y-%m','now')`;
            const loans = await new Promise(resolve =>
                db.all(`SELECT * FROM customer_loans WHERE ${monthSql} ORDER BY id DESC LIMIT 30`, [], (e, r) => resolve(r || [])));
            const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');

            const totalLoanValue = loans.reduce((s, l) => s + (parseFloat(l.loan_amount) || 0), 0);
            // No staff_id column on customer_loans — show as portfolio summary
            await client.sendMessage(target,
                `💼 *Commission / Portfolio*\n\n` +
                `👤 *${staff.name}* (${staff.phone || '—'})\n` +
                `📅 Period: ${isLastMonth ? 'Last month' : 'This month'}\n\n` +
                `🏦 Loans in DB this period: *${loans.length}*\n` +
                `💰 Total loan value: *${fmt(totalLoanValue)}*\n\n` +
                `_Note: Commission auto-calc requires staff↔sale linkage. Tag deals to staff via Assign Lead command for accurate tracking._`);
        } catch (err) {
            await client.sendMessage(target, `❌ Commission lookup failed: ${err.message}`);
        }
        return true;
    }

    // ── C5: OUTSTANDING LOANS ─────────────────────────────────────────────────
    //   • outstanding loans  /  pending loans  /  active loans
    if (/^(?:please\s+|kindly\s+)?(?:outstanding|pending|active|all)\s+loans?\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'outstanding_loans')) return true;
        if (!_adminDedupOk('LOANS')) return true;
        try {
            const rows = await new Promise(resolve =>
                db.all(`SELECT customer_name, customer_phone, bank_name, loan_amount, status, plot FROM customer_loans
                          WHERE status IS NULL OR LOWER(status) IN ('pending','active','disbursed','approved','in process')
                          ORDER BY id DESC LIMIT 20`, [], (e, r) => resolve(r || [])));
            if (!rows.length) { await client.sendMessage(target, `📭 No active loans on file.`); return true; }

            const fmt = n => '₹' + parseInt(n || 0).toLocaleString('en-IN');
            const total = rows.reduce((s, r) => s + (parseFloat(r.loan_amount) || 0), 0);
            let msg = `🏦 *Active / Pending Loans* (top ${rows.length})\n\n`;
            for (const r of rows) {
                msg += `• ${r.customer_name || r.customer_phone || '—'} — ${fmt(r.loan_amount)} — ${r.bank_name || '—'} — ${r.status || 'Pending'}\n`;
                if (r.plot) msg += `   _Plot: ${r.plot}_\n`;
            }
            msg += `\n💰 *Total portfolio*: ${fmt(total)}`;
            await client.sendMessage(target, msg);
        } catch (err) {
            await client.sendMessage(target, `❌ Loans lookup failed: ${err.message}`);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP D — TEAM & ADMIN COMMANDS
    // ══════════════════════════════════════════════════════════════════════════

    // ── D1: WHO IS ON LEAVE TODAY ─────────────────────────────────────────────
    if (/^(?:please\s+|kindly\s+)?(?:who(?:'s|\s+is)\s+(?:on\s+)?(?:leave|absent)|(?:leave|absent)\s+today|today(?:'s)?\s+(?:leave|absent))\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'leave_today')) return true;
        if (!_adminDedupOk('LEAVE_TODAY')) return true;
        try {
            const today = new Date().toISOString().slice(0, 10);
            const staff = await new Promise(resolve =>
                db.all(`SELECT id, name FROM staff WHERE is_active != 0`, [], (e, r) => resolve(r || [])));
            const presentRows = await new Promise(resolve =>
                db.all(`SELECT DISTINCT staff_id, name FROM attendance WHERE date = ? AND LOWER(COALESCE(status,'present')) != 'absent'`, [today], (e, r) => resolve(r || [])));
            const presentSet = new Set(presentRows.map(r => String(r.staff_id || r.name || '').toLowerCase()));
            const absent = staff.filter(s => !presentSet.has(String(s.id).toLowerCase()) && !presentSet.has(String(s.name).toLowerCase()));

            if (!absent.length) { await client.sendMessage(target, `✅ All ${staff.length} active staff have checked in today.`); return true; }
            const list = absent.map(s => `• ${s.name}`).join('\n');
            await client.sendMessage(target, `📋 *Absent / Not Checked In Today* (${absent.length} of ${staff.length})\n\n${list}\n\n_Check Attendance Hub for late check-ins._`);
        } catch (err) {
            await client.sendMessage(target, `❌ Leave check failed: ${err.message}`);
        }
        return true;
    }

    // ── D2: BROADCAST <MESSAGE> TO <SEGMENT> ──────────────────────────────────
    //   • broadcast "We have new plots in DRD Velavan" to all leads
    //   • broadcast Festival offer 5% off to all booked
    //   • announce Office closed Saturday to all staff
    // Negative lookahead skips "announce price/rate/cost change" — that belongs to D3.
    if (/^(?:please\s+|kindly\s+)?(?:broadcast|announce)\s+/i.test(bodyRaw) && !/\b(?:price|rate|cost)\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'broadcast')) return true;
        if (!_adminDedupOk('BROADCAST')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);

            // Extract message body and segment
            // Patterns: broadcast "<msg>" to <segment>  OR  broadcast <msg> to <segment>
            let msgBody = '', segment = '';
            const quoted = bodyRaw.match(/^(?:please\s+|kindly\s+)?(?:broadcast|announce)\s+"([^"]+)"\s+to\s+(.+)$/i);
            if (quoted) { msgBody = quoted[1]; segment = quoted[2]; }
            else {
                const m = bodyRaw.match(/^(?:please\s+|kindly\s+)?(?:broadcast|announce)\s+(.+?)\s+to\s+(.+)$/i);
                if (m) { msgBody = m[1]; segment = m[2]; }
            }
            if (!msgBody || !segment) { await client.sendMessage(target, '⚠️ Usage: `broadcast "Your message" to all leads`'); return true; }

            // Resolve segment to recipient list
            let recipients = [];
            const segLower = segment.toLowerCase();
            if (/all\s+staff/.test(segLower)) {
                recipients = await new Promise(r => db.all(`SELECT phone, name FROM staff WHERE is_active != 0 AND phone != ''`, [], (e, rows) => r(rows || [])));
            } else if (/all\s+(booked|customers|purchased)/.test(segLower)) {
                recipients = await new Promise(r => db.all(`SELECT phone, name FROM customers WHERE status IN ('Booked','Purchased') AND phone != ''`, [], (e, rows) => r(rows || [])));
            } else if (/all\s+(leads|inquir)/.test(segLower)) {
                recipients = await new Promise(r => db.all(`SELECT phone, name FROM customers WHERE phone != '' ORDER BY last_interaction DESC LIMIT 100`, [], (e, rows) => r(rows || [])));
            } else if (/in\s+([a-z][a-z\s]+)/i.test(segment)) {
                const layoutHint = segment.match(/in\s+([a-z][a-z\s]+)/i)[1].trim();
                recipients = await new Promise(r => db.all(`SELECT phone, name FROM customers WHERE LOWER(plot) LIKE ? AND phone != ''`, [`%${layoutHint.toLowerCase()}%`], (e, rows) => r(rows || [])));
            } else {
                await client.sendMessage(target, '⚠️ Unknown segment. Try: `all leads`, `all booked`, `all staff`, `in DRD Anisam`');
                return true;
            }

            if (!recipients.length) { await client.sendMessage(target, `⚠️ No recipients in segment "${segment}".`); return true; }
            // Safety cap
            const SAFE_MAX = 50;
            if (recipients.length > SAFE_MAX) {
                await client.sendMessage(target, `⚠️ Segment has ${recipients.length} recipients — capping at ${SAFE_MAX} for safety. Use Bulk Broadcast dashboard for larger blasts.`);
                recipients = recipients.slice(0, SAFE_MAX);
            }

            await client.sendMessage(target, `📣 Broadcasting to ${recipients.length} recipient(s)... I'll send a summary when done.`);

            let sent = 0, failed = 0;
            for (const r of recipients) {
                const phoneClean = String(r.phone).replace(/\D/g, '');
                if (phoneClean.length < 10) { failed++; continue; }
                const jid = (phoneClean.length === 10 ? '91' + phoneClean : phoneClean) + '@c.us';
                try {
                    await client.sendMessage(jid, `${r.name ? `Hello *${r.name}*! 👋\n\n` : ''}${msgBody}\n\n— DRD Realtors`);
                    sent++;
                    await new Promise(rs => setTimeout(rs, 1500)); // 1.5s between sends to avoid WA rate limits
                } catch (e) { failed++; }
            }
            await client.sendMessage(target, `📊 Broadcast complete by *${senderName}*\n✅ Sent: ${sent}\n❌ Failed: ${failed}`);
        } catch (err) {
            await client.sendMessage(target, `❌ Broadcast failed: ${err.message}`);
        }
        return true;
    }

    // ── D3: ANNOUNCE PRICE CHANGE ON <LAYOUT> ─────────────────────────────────
    //   • announce price change on velavan to 350 per sqft
    //   • update rate of anisam to 8 lakh per cent
    if (/^(?:please\s+|kindly\s+)?(?:announce|update)\s+(?:price|rate|cost)\b/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'price_change')) return true;
        if (!_adminDedupOk('PRICE_CHANGE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);

            const layoutMatch = bodyRaw.match(/(?:on|of|for)\s+([a-z][a-z\s]+?)(?:\s+to\s+|\s*$)/i);
            const rateMatch = bodyRaw.match(/(?:to|at|@)\s*(?:rs\.?|₹|inr)?\s*([\d.,]+)\s*(?:lakh|lac|cr|crore|rupees?|rs|inr)?\s*(?:per|\/)\s*(sqft|sq\.?\s*ft|cent|cents)/i);
            if (!layoutMatch || !rateMatch) {
                await client.sendMessage(target, '⚠️ Usage: `announce price change on Velavan to 350 per sqft` or `update rate of Anisam to 8 lakh per cent`');
                return true;
            }
            const layoutHint = layoutMatch[1].trim();
            let rate = parseFloat(rateMatch[1].replace(/,/g, ''));
            if (/lakh|lac/i.test(rateMatch[0])) rate *= 100000;
            else if (/cr|crore/i.test(rateMatch[0])) rate *= 10000000;
            const unit = /cent/i.test(rateMatch[2]) ? 'cent' : 'sqft';

            const plots = await new Promise(resolve =>
                db.all(`SELECT id, size, plot_no FROM plots WHERE LOWER(layout_name) LIKE ? AND status IN ('Available','Booked')`, [`%${layoutHint.toLowerCase()}%`], (e, r) => resolve(r || [])));
            if (!plots.length) { await client.sendMessage(target, `⚠️ No active plots in "${layoutHint}".`); return true; }

            // Update prices
            for (const p of plots) {
                const sqft = parseFloat(p.size) || 0;
                let newPrice = 0;
                if (unit === 'sqft') newPrice = Math.round(sqft * rate);
                else /* cent */     newPrice = Math.round((sqft / 435.6) * rate);
                if (newPrice > 0) db.run(`UPDATE plots SET price = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`, [newPrice, p.id]);
            }
            await client.sendMessage(target,
                `✅ Price updated for *${plots.length}* plot(s) in *${layoutHint}* → ₹${rate.toLocaleString('en-IN')} per ${unit}.\n\n` +
                `Changed by *${senderName}*. New prices reflect in dashboard immediately.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Price change failed: ${err.message}`);
        }
        return true;
    }

    // ── D4: MARK STAFF LEAVE ──────────────────────────────────────────────────
    //   • leave for Saravanan today
    //   • leave for Preeti on 25 may
    if (/^(?:please\s+|kindly\s+)?leave\s+(?:for|of)\s+/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'mark_leave')) return true;
        if (!_adminDedupOk('STAFF_LEAVE')) return true;
        try {
            const m = bodyRaw.match(/leave\s+(?:for|of)\s+([a-z][a-z\s]+?)(?:\s+(?:on|today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\d).*)?$/i);
            const staffHint = m ? m[1].trim() : '';
            if (!staffHint) { await client.sendMessage(target, '⚠️ Usage: `leave for Saravanan today`'); return true; }

            const staff = await new Promise(resolve =>
                db.get(`SELECT * FROM staff WHERE LOWER(name) LIKE ? AND is_active != 0 LIMIT 1`, [`%${staffHint.toLowerCase()}%`], (e, r) => resolve(r || null)));
            if (!staff) { await client.sendMessage(target, `⚠️ No staff "${staffHint}".`); return true; }

            const { date } = _parseDateTime(bodyRaw);
            const leaveDate = date || new Date().toISOString().slice(0,10);

            db.run(
                `INSERT INTO attendance (staff_id, name, date, status, gps_location, photo_proof, notes) VALUES (?, ?, ?, 'Absent', 'Leave', 'No Photo', ?)`,
                [staff.id, staff.name, leaveDate, `Leave marked by admin`]);
            await client.sendMessage(target, `✅ Marked *${staff.name}* on leave for ${leaveDate}.`);
        } catch (err) {
            await client.sendMessage(target, `❌ Leave failed: ${err.message}`);
        }
        return true;
    }

    // ── D5: ADD CRM NOTE ──────────────────────────────────────────────────────
    //   • note for <phone>: customer asked for east-facing
    //   • add note <phone> budget upto 50 lakh
    if (/^(?:please\s+|kindly\s+)?(?:add\s+)?note(?:s)?\s+(?:for|on|about)?\s*\d/i.test(bodyRaw)) {
        if (await _guardCmd(message, 'crm_note')) return true;
        if (!_adminDedupOk('NOTE')) return true;
        try {
            const senderName = await resolveStaffName((message.fromMe ? message.to : message.from).replace(/\D/g, ''), message);
            const phone = _extractPhone(bodyRaw);
            if (!phone) { await client.sendMessage(target, '⚠️ Need a phone.'); return true; }
            const phone10 = phone.slice(-10);

            const colonNote = bodyRaw.match(/:\s*(.+)$/);
            let note = colonNote ? colonNote[1].trim() : '';
            if (!note) {
                // Take anything after the phone number as the note
                const afterPhone = bodyRaw.split(phone10).slice(1).join(phone10).trim();
                if (afterPhone) note = afterPhone.replace(/^[\s.,;:]+/, '');
            }
            if (!note) { await client.sendMessage(target, '⚠️ No note text. Try: `note for <phone>: prefers east-facing plot`'); return true; }

            const stamp = `[${new Date().toISOString().slice(0,10)} · ${senderName}] ${note}`;
            db.run(
                `INSERT INTO customers (phone, lead_notes, last_interaction) VALUES (?, ?, CURRENT_TIMESTAMP)
                   ON CONFLICT(phone) DO UPDATE SET
                     lead_notes = COALESCE(lead_notes,'') || char(10) || ?,
                     last_interaction = CURRENT_TIMESTAMP`,
                [phone10, stamp, stamp]);
            await client.sendMessage(target, `📝 Note added to ${phone10}:\n_"${note}"_`);
        } catch (err) {
            await client.sendMessage(target, `❌ Note failed: ${err.message}`);
        }
        return true;
    }

    // Admin dispatch: accepts SEND / SHARE / FORWARD / DISPATCH as the verb.
    // Algorithm (robust to natural phrasings, filler words, and punctuation):
    //   1. Match verb at start of message
    //   2. Find the LAST 10+ digit run anywhere in the message → that's the phone
    //   3. Remove verb prefix + the phone + everything between " to ..." and the phone (filler)
    //   4. Iteratively strip leading filler tokens (layout, details, of, the, info, about, for, please, kindly)
    //   5. What remains is the layout name
    // Supported (and many more) — all of these now work:
    //   • send Anisam Garden to <phone>
    //   • share Anisam to <phone>
    //   • share details of Anisam to <phone>
    //   • share layout details of anisam to <phone>
    //   • share layout details of anisam to following number <phone>
    //   • share layout details of anisam to the following number..<phone>
    //   • forward Anisam Garden to <phone>
    //   • send 91<phone> details Anisam Garden  (legacy syntax A)
    // Allow optional "please/kindly" before the verb
    const dispatchVerb = bodyRaw.match(/^(?:please\s+|kindly\s+)?(send|share|forward|dispatch)\s+/i);
    const hasLongDigitRun = /\d[\d\s]{6,}\d/.test(bodyRaw);
    if (dispatchVerb && (bodyRaw.includes(' details ') || hasLongDigitRun)) {
        if (await _guardCmd(message, 'media_dispatch')) return true;
        try {
            const senderPhone = (message.fromMe ? message.to : message.from).replace(/\D/g, '');
            const senderName = await resolveStaffName(senderPhone, message);

            // Verb prefix matches "send "/"send" (with or without trailing space) so it strips cleanly.
            const verbPattern   = /^(?:please\s+|kindly\s+)?(send|share|forward|dispatch)(?=\s+|$)\s*/i;
            // Leading filler tokens to strip iteratively. Order matters — longer phrases first.
            const fillerToken   = /^(layout\s+details\s+of|please\s+share|kindly\s+share|details\s+of|layout\s+of|the\s+layout|the|layout|details|info|about|for|please|kindly|of)(?=\s+|$)\s*/i;

            // 1. Find the LAST run of digits-with-optional-spaces (10+ digits when whitespace removed)
            //    anywhere in the body. Handles "91 9894 815803", "<phone>", "..<phone>", etc.
            let phoneMatch = null;
            const digitRuns = [...bodyRaw.matchAll(/\d[\d\s]*\d/g)]
                .filter(m => m[0].replace(/\D/g, '').length >= 10);
            if (digitRuns.length) phoneMatch = digitRuns[digitRuns.length - 1];
            else {
                // Fallback: 7+ digit run if no proper 10-digit phone found
                const fb = [...bodyRaw.matchAll(/\d[\d\s]*\d/g)]
                    .filter(m => m[0].replace(/\D/g, '').length >= 7);
                if (fb.length) phoneMatch = fb[fb.length - 1];
            }

            let targetPhone, layoutName;
            if (phoneMatch) {
                const rawPhone = phoneMatch[0].replace(/\D/g, '');
                const normalizedPhone = rawPhone.length === 10 ? '91' + rawPhone : rawPhone;
                targetPhone = normalizedPhone + '@c.us';

                // Build layoutName from the body with the phone (and surrounding clutter) excised.
                let residue = bodyRaw.slice(0, phoneMatch.index);

                // If this is legacy "<verb> <phone> details <layout>" (phone BEFORE " details "),
                // layoutName actually comes from AFTER " details ", not before.
                const tail = bodyRaw.slice(phoneMatch.index + phoneMatch[0].length);
                if (/^\s*details\s+/i.test(tail) || residue.replace(verbPattern, '').replace(/\s+/g,'').length < 3) {
                    // Tail contains the layout after "details"
                    const tailParts = tail.split(/\s+details\s+/i);
                    if (tailParts.length > 1) {
                        residue = tailParts.slice(1).join(' details ');
                    } else if (/^\s*details\s+/i.test(tail)) {
                        residue = tail.replace(/^\s*details\s+/i, '');
                    } else {
                        residue = tail; // bare layout after phone
                    }
                } else {
                    // Standard "<verb> <layout> to <phone>" — cut at the LAST " to " before the phone.
                    const toIdx = residue.lastIndexOf(' to ');
                    if (toIdx !== -1) residue = residue.slice(0, toIdx);
                }

                // Strip verb prefix
                residue = residue.replace(verbPattern, '');
                // Iteratively strip leading filler tokens
                let prev;
                do { prev = residue; residue = residue.replace(fillerToken, ''); } while (residue !== prev);
                // Strip trailing punctuation/whitespace
                layoutName = residue.replace(/[\s.,;:!?"'`]+$/g, '').trim();
            } else if (bodyRaw.includes(' details ')) {
                // Pure legacy Syntax A: digits already null means no phone at all → error
                const parts = bodyRaw.split(' details ');
                const rawPhone = parts[0].replace(verbPattern, '').trim().replace(/\D/g, '');
                const normalizedPhone = rawPhone.length === 10 ? '91' + rawPhone : rawPhone;
                targetPhone = rawPhone ? normalizedPhone + '@c.us' : '';
                let residue = (parts[1] || '');
                let prev;
                do { prev = residue; residue = residue.replace(fillerToken, ''); } while (residue !== prev);
                layoutName = residue.replace(/[\s.,;:!?"'`]+$/g, '').trim();
            }

            if (!targetPhone || targetPhone === '@c.us' || !/^\d{10,}@c\.us$/.test(targetPhone)) {
                await client.sendMessage(target, `⚠️ Couldn't find a valid 10-digit phone number in your message.`);
                return true;
            }
            if (!layoutName) {
                await client.sendMessage(target,
                    `⚠️ Couldn't identify which layout to send. Try:\n` +
                    `• send [layout] to [phone]\n` +
                    `• share [layout] to [phone]\n` +
                    `• share details of [layout] to [phone]\n` +
                    `Examples: "share Anisam to <phone>", "send Velavan Garden to <phone>"`);
                return true;
            }

            // ── Idempotency guard (HARDENED) ──
            // Build a STABLE key from sender + body — message.id is an object that re-instantiates
            // on every message_create re-fire, so object identity comparisons fail and dedup misses.
            // Also keep id-based key as a secondary check.
            global.__recentAdminDispatches = global.__recentAdminDispatches || new Map();
            const idStr = (message.id && (message.id._serialized || (message.id.id ? `${message.fromMe}_${message.id.id}` : ''))) || '';
            const bodyKey = `${message.fromMe ? 'me' : 'them'}|${message.from}|${bodyRaw.substring(0, 200)}`;
            const lastByBody = global.__recentAdminDispatches.get(bodyKey);
            const lastById   = idStr ? global.__recentAdminDispatches.get(idStr) : null;
            const now = Date.now();
            // Within 5 minutes, same body OR same id = ignore. (Was 60s — too short for WA re-syncs.)
            if ((lastByBody && (now - lastByBody) < 300_000) || (lastById && (now - lastById) < 300_000)) {
                console.log(`[ADMIN DISPATCH] Duplicate command suppressed (body-dedup): "${bodyRaw.substring(0,80)}"`);
                return true;
            }
            global.__recentAdminDispatches.set(bodyKey, now);
            if (idStr) global.__recentAdminDispatches.set(idStr, now);
            // Prune entries older than 10 min
            for (const [k, t] of global.__recentAdminDispatches) {
                if (now - t > 600_000) global.__recentAdminDispatches.delete(k);
            }

            // ── GLOBAL RATE LIMIT (safety net) ──
            // No matter what bugs slip through, never send more than 10 messages to the SAME target
            // within 5 minutes from the dispatch flow. This is a hard ceiling.
            global.__dispatchSendCounter = global.__dispatchSendCounter || new Map();
            const rateKey = `RATE|${targetPhone}`;
            const counter = global.__dispatchSendCounter.get(rateKey) || { count: 0, since: now };
            if (now - counter.since > 300_000) { counter.count = 0; counter.since = now; }
            if (counter.count >= 10) {
                console.log(`[ADMIN DISPATCH] RATE-LIMITED — refused to send (already ${counter.count} msgs to ${targetPhone} in last 5min)`);
                try { await client.sendMessage(target, `⚠️ Safety stop: already sent ${counter.count} messages to ${targetPhone} in the last 5 minutes. Wait a few minutes before retrying.`); } catch(_) {}
                return true;
            }
            global.__dispatchSendCounter.set(rateKey, counter);
            const _origSend = client.sendMessage.bind(client);
            const _trackedSendForThisDispatch = async (jid, ...args) => {
                if (jid === targetJid) {
                    const c = global.__dispatchSendCounter.get(rateKey);
                    if (c) c.count++;
                    if (c && c.count > 10) {
                        console.log(`[ADMIN DISPATCH] Hit per-target ceiling mid-dispatch; aborting further sends.`);
                        throw new Error('per-target send ceiling reached');
                    }
                }
                return _origSend(jid, ...args);
            };
            // We do NOT replace client.sendMessage globally — instead, use this tracker only inside the
            // dispatch flow below by referencing it explicitly. (See sendToTarget() helper below.)
            const sendToTarget = (jid, payload) => _trackedSendForThisDispatch(jid, payload);

            const targetJid = targetPhone.includes('@c.us') ? targetPhone : `${targetPhone.replace(/\D/g, '')}@c.us`;
            const isSelfTarget = (targetJid === target);
            if (isSelfTarget) {
                await client.sendMessage(target, `⚠️ You're sending to your own number. Proceeding once — confirmations suppressed to avoid spam.`);
            } else {
                await client.sendMessage(target, `🔄 Sending *${layoutName}* details to ${targetPhone}...`);
            }

            // 1. Get Text Details
            const plots = await getPlotsData();
            const needle = layoutName.toLowerCase();
            const STOPWORDS = new Set(['drd', 'the', 'garden', 'gardens', 'enclave', 'layout', 'project']);
            const needleTokens = needle.split(/\W+/).filter(t => t.length > 1 && !STOPWORDS.has(t));

            // Score each DISTINCT layout name across all plot rows, then pick the SINGLE best layout
            // and filter to plots belonging only to it. This guarantees one dispatch = one layout.
            const layoutScores = new Map(); // layout_name → score
            for (const p of plots) {
                const layout = (p.Layout_Name || '');
                if (!layout || layoutScores.has(layout)) continue;
                const hay = layout.toLowerCase();
                const hayTokens = hay.split(/\W+/).filter(Boolean);
                let score = 0;
                // Tier A: exact substring of full needle (strongest signal)
                if (needle && hay.includes(needle)) score += 100;
                // Tier B: each needle token that appears in haystack
                for (const nt of needleTokens) {
                    if (hay.includes(nt)) {
                        score += 25;
                    } else {
                        // Tier B1: 4-char prefix overlap (catches Tamil d/t, b/p transliteration at char 4)
                        if (nt.length >= 4) {
                            const pref = nt.slice(0, 4);
                            if (hayTokens.some(ht => ht.startsWith(pref) || nt.startsWith(ht.slice(0, 4)))) score += 10;
                        }
                        // Tier B2: trigram overlap — robust against Tamil name spelling variants
                        if (nt.length >= 4) {
                            for (const ht of hayTokens) {
                                if (ht.length >= 4) {
                                    const ag = new Set(Array.from({length: nt.length - 2}, (_, i) => nt.slice(i, i + 3)));
                                    const bg = new Set(Array.from({length: ht.length - 2}, (_, i) => ht.slice(i, i + 3)));
                                    let shared = 0;
                                    for (const g of ag) if (bg.has(g)) shared++;
                                    const ratio = shared / Math.max(ag.size, bg.size);
                                    if (ratio >= 0.4) score += Math.round(ratio * 20);
                                }
                            }
                        }
                    }
                }
                if (score >= 8) layoutScores.set(layout, score);
            }

            let matching = [];
            if (layoutScores.size) {
                // Pick the highest-scoring layout; ties broken alphabetically for stability
                const ranked = [...layoutScores.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
                const [bestLayout, bestScore] = ranked[0];
                console.log(`[ADMIN DISPATCH] layout scoring: ${JSON.stringify(Object.fromEntries(ranked))} → picked "${bestLayout}" (score ${bestScore})`);
                matching = plots.filter(p => p.Layout_Name === bestLayout);
            }

            console.log(`[ADMIN DISPATCH] layoutName="${layoutName}", target=${targetPhone}, matched=${matching.length}`);

            if (matching.length === 0) {
                // Surface the actual layout names so the admin can re-type accurately.
                const known = [...new Set(plots.map(p => p.Layout_Name).filter(Boolean))];
                const list = known.length
                    ? `\n\nAvailable layouts:\n• ${known.slice(0, 15).join('\n• ')}`
                    : '\n\n(Plots table appears empty — check Database Sync.)';
                await client.sendMessage(target, `❌ Layout *${layoutName}* not found in database.${list}`);
                return true;
            }
            if (!client.info) {
                await client.sendMessage(target, `❌ Bot is starting up. Please try again in a few seconds.`);
                return true;
            }

            const layoutDisplay = matching[0].Layout_Name;

            // ── Resolve customer name: CRM first, then WhatsApp contact, then null ──
            const targetPhone10 = targetJid.replace(/\D/g, '').slice(-10);
            let customerName = null;
            let customerFromCRM = false;
            try {
                customerName = await new Promise((resolve) => {
                    db.get(
                        `SELECT name FROM customers WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ? ORDER BY last_interaction DESC LIMIT 1`,
                        [`%${targetPhone10}`],
                        (err, row) => resolve(err || !row ? null : (row.name || null))
                    );
                });
                if (customerName) customerFromCRM = true;
            } catch (e) { console.warn('[ADMIN DISPATCH] CRM lookup failed:', e.message); }

            if (!customerName) {
                try {
                    const contact = await client.getContactById(targetJid);
                    customerName = (contact && (contact.name || contact.pushname || contact.shortName)) || null;
                    if (customerName) console.log(`[ADMIN DISPATCH] WhatsApp contact name resolved: "${customerName}"`);
                } catch (e) { console.warn('[ADMIN DISPATCH] WA contact lookup failed:', e.message); }
            }

            // Strip generic placeholders that aren't real names
            if (customerName && /^(new\s+lead|unknown|whatsapp\s+user|undefined|null)$/i.test(customerName.trim())) {
                customerName = null;
            }

            // Auto-add to CRM if this is a brand-new contact, so future flows can use them.
            if (!customerFromCRM && customerName) {
                db.run(
                    `INSERT INTO customers (phone, name, plot, location, status, last_interaction)
                     VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(phone) DO UPDATE SET
                       name=COALESCE(NULLIF(name,''), excluded.name),
                       last_interaction=CURRENT_TIMESTAMP`,
                    [targetPhone10, customerName, layoutDisplay, matching[0].Location || '', 'Admin Dispatch'],
                    (err) => { if (err) console.warn('[ADMIN DISPATCH] CRM auto-insert failed:', err.message); }
                );
                console.log(`[ADMIN DISPATCH] Auto-added new customer to CRM: ${customerName} (${targetPhone10})`);
            }

            const greetingLine = customerName
                ? `Hello *${customerName}*! 👋`
                : `Hello! 👋`;

            const text =
                `${greetingLine}\n\nAs *${senderName}* asked to share details about *${layoutDisplay}*, please find the property information below.\n\n` +
                `🏡 *${layoutDisplay}*\n` +
                `📍 Location: ${matching[0].Location}\n` +
                `🏗️ Status: ${matching[0].Status}\n\n` +
                `Do you need any further details? We are here to help! 🙏\n` +
                `📞 Professional services by DRD Realtors.`;

            try { await sendToTarget(targetJid, text); }
            catch (e) { console.warn('[ADMIN DISPATCH] greeting send aborted:', e.message); return true; }

            // 2. Send Media — HARD CAP from settings + per-target ceiling enforced via sendToTarget
            const MAX_MEDIA_PER_DISPATCH = Math.max(1, parseInt(getBotSettings().max_media_per_dispatch) || 5);
            let sentCount = 0;
            const visuals = findVisualForLayout(layoutDisplay, IMAGES_DIR)
                          || findVisualForLayout(layoutDisplay, path.join(IMAGES_DIR, '01 All Layouts'));
            if (visuals) {
                if (visuals.type === 'directory') {
                    const ranked = [...visuals.files].sort((a, b) => {
                        const score = f => /master|brochure|main|cover|plan|layout/i.test(f) ? 0 : 1;
                        return score(a) - score(b);
                    }).slice(0, MAX_MEDIA_PER_DISPATCH);
                    for (const f of ranked) {
                        try {
                            const fullPath = path.join(visuals.path, f);
                            if (fs.existsSync(fullPath) && !f.startsWith('~$')) {
                                await sendToTarget(targetJid, MessageMedia.fromFilePath(fullPath));
                                sentCount++;
                                await new Promise(r => setTimeout(r, 2000));
                            }
                        } catch (e) {
                            console.error("Admin dispatch media error:", e.message);
                            if (/ceiling/.test(e.message)) break; // hard stop on safety abort
                        }
                    }
                    if (visuals.files.length > MAX_MEDIA_PER_DISPATCH) {
                        console.log(`[ADMIN DISPATCH] Capped media at ${MAX_MEDIA_PER_DISPATCH} (had ${visuals.files.length} files in ${visuals.path})`);
                    }
                } else {
                    try {
                        if (fs.existsSync(visuals.path)) {
                            await sendToTarget(targetJid, MessageMedia.fromFilePath(visuals.path));
                            sentCount++;
                        }
                    } catch (e) { console.error("Admin single media error:", e.message); }
                }
            }

            if (!isSelfTarget) {
                await client.sendMessage(target, `✅ Sent to ${targetJid.split('@')[0]} — 1 text + ${sentCount} media file(s).`);
            }
        } catch (err) {
            await client.sendMessage(target, `❌ Admin Dispatch Failed: ${err.message}`);
        }
        return true;
    }

    if (bodyRaw.startsWith('approve ') || bodyRaw.startsWith('reject ')) {
        if (await _guardCmd(message, 'approve_reject')) return true;
        const parts = bodyRaw.split(' ');
        const action = parts[0].toLowerCase();
        const docId = parts[1];
        
        if (docId) {
            const status = action === 'approve' ? 'Approved' : 'Rejected';
            console.log(`[LEGAL] Admin ${message.from} ${status} DocID=${docId}`);
            
            if (process.send) {
                process.send({
                    type: 'legal_approval_res',
                    data: { docId, status, adminPhone: message.from }
                });
            }
            
            await message.reply(`${action === 'approve' ? '✅' : '❌'} Document ${docId} has been marked as *${status}*.`);
            return true;
        }
    }

    if (bodyNoSpace === '!leads' || bodyNoSpace === '!lead' || bodyNoSpace === '!excel') {
        if (await _guardCmd(message, 'leads')) return true;
        try {
            const leadsPath = path.join(ROOT_DIR, 'Customer_Inquiries.xlsx');
            if (fs.existsSync(leadsPath)) {
                const media = MessageMedia.fromFilePath(leadsPath);
                await client.sendMessage(target, media);
                await client.sendMessage(target, "DATA: Here is the latest Leads Excel sheet.");
            } else {
                await client.sendMessage(target, "!: Leads file not found.");
            }
        } catch (err) {
            console.error("Error sending leads:", err);
            await client.sendMessage(target, "X: Failed to send Leads: " + err.message);
        }
        return true;
    }

    if (bodyNoSpace === 'status' || bodyNoSpace === '!status') {
        if (await _guardCmd(message, 'status')) return true;
        const report = await generateSystemReport();
        await message.reply(report);
        return true;
    }

    if (bodyNoSpace === 'status+' || bodyNoSpace === '!status+') {
        if (await _guardCmd(message, 'status_plus')) return true;
        const report = await generateDetailedReport();
        await message.reply(report);
        return true;
    }

    // .recent — show last N inbound customer messages (useful after coming back online)
    if (bodyNoSpace === '.recent' || bodyNoSpace === '!recent') {
        const limitMatch = (message.body || '').match(/\d+/);
        const limit = Math.min(parseInt(limitMatch ? limitMatch[0] : '10', 10), 30) || 10;
        try {
            const rows = await new Promise((resolve, reject) =>
                db.all(
                    `SELECT phone, message, created_at
                     FROM conversations
                     WHERE UPPER(role) = 'USER'
                     ORDER BY created_at DESC
                     LIMIT ?`,
                    [limit],
                    (err, r) => err ? reject(err) : resolve(r || [])
                )
            );
            if (!rows.length) {
                await message.reply(`📭 No recent customer messages found.`);
            } else {
                const ist = d => new Date(d + 'Z').toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour12: true, dateStyle: 'short', timeStyle: 'short' });
                let txt = `📬 *Last ${rows.length} Customer Messages*\n${'─'.repeat(24)}\n`;
                rows.forEach((r, i) => {
                    const ph = String(r.phone || '').replace(/\D/g, '').slice(-10);
                    const body = String(r.message || '').slice(0, 60).replace(/\n/g, ' ');
                    txt += `\n*${i + 1}.* 📞 ${ph}\n   🕐 ${ist(r.created_at)}\n   💬 ${body}${(r.message || '').length > 60 ? '…' : ''}\n`;
                });
                await message.reply(txt);
            }
        } catch (e) {
            await message.reply(`❌ Could not read conversations: ${e.message}`);
        }
        return true;
    }

    // .logins / whosin — show who is currently logged into the dashboard and when
    if (['.logins', '!logins', 'whosin', '!whosin', '.whosin'].includes(bodyNoSpace)) {
        try {
            const sessPath = path.join(ROOT_DIR, 'sessions.json');
            let sessData = {};
            try { sessData = JSON.parse(fs.readFileSync(sessPath, 'utf8')); } catch (_) {}
            const now = Date.now();
            const active = Object.values(sessData).filter(s => {
                if (!s || !s.userId) return false;
                const exp = s.cookie && s.cookie.expires ? new Date(s.cookie.expires).getTime() : 0;
                return exp > now;
            });
            const ist = d => new Date(d).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour12: true });
            if (active.length === 0) {
                await message.reply(`🔐 *Dashboard Login Status*\n\n_No active sessions — dashboard is idle._\n\n_Checked: ${ist(new Date())}_`);
            } else {
                let txt = `🔐 *Dashboard Active Logins*\n👥 *${active.length} active session${active.length > 1 ? 's' : ''}*\n${'─'.repeat(24)}\n`;
                active.forEach((s, i) => {
                    const loginAt = s.loginAt ? ist(s.loginAt) : '—';
                    const expires = s.cookie && s.cookie.expires ? ist(s.cookie.expires) : '—';
                    txt += `\n*${i + 1}. ${s.userName || s.userId}*\n`;
                    txt += `   🎫 Role: ${s.userRole || 'unknown'}\n`;
                    txt += `   🕐 Logged in: ${loginAt}\n`;
                    txt += `   ⏰ Session expires: ${expires}\n`;
                });
                txt += `\n_Checked: ${ist(new Date())}_`;
                await message.reply(txt);
            }
        } catch (e) {
            await message.reply(`❌ Could not read session data: ${e.message}`);
        }
        return true;
    }

    if (bodyNoSpace === '!help') {
        // Admin/staff command reference — triggered only by !help (with !)
        // Plain "help" (no !) is handled by keyword_rules.json and shows the customer menu
        const helpText = `🛠️ *BOT COMMANDS*
═══════════════════════
*🔑 SYSTEM*
📈 *status* — Quick system report
📊 *status+* — Detailed audit report
🔐 *.logins* (or *whosin*) — Who is logged into dashboard now
📬 *.recent* (or *.recent 20*) — Last N customer messages received
📑 *!leads* — Download latest inquiries
🔄 *!sync* — Trigger cloud sync
🔁 *!restart* (or */restart*) — Restart the bot
🤖 *!ai on* / *!ai off* — Switch Gemini AI ↔ Local templates
ℹ️ *!help* — This menu

*💼 STAFF SUBMISSIONS* (registered staff)
💸 *!exp 5000 petrol fuel* — Log expense
🧾 *!gst 2000 VendorName desc* — Log GST entry
🖼️ *Bill image scan* — Send bill/invoice image with caption _bill_, _invoice_, or _gst_ to auto-log GST
📋 *!myexp* — View your recent submissions
📍 *check in* / *check out* — Attendance clock-in/out
🧾 *.visitor Name, Phone, Budget, Time, Intent, Notes* — Log a site visitor

*⚖️ LEGAL APPROVALS* (admin only)
✅ *approve <docId>* — Approve a legal document
❌ *reject <docId>* — Reject a legal document

═══════════════════════
*✨ NATURAL LANGUAGE REQUESTS*
_Just type — no \`!\` needed. Replace <phone> with a 10-digit number._

*📤 SEND TO CUSTOMER* (most used)
📜 *Quotation* — send quotation for plot 14 Anisam to <phone>
📕 *Brochure (PDF)* — send brochure of Anisam to <phone>
🖼️ *Layout photos* — send Anisam to <phone>
🗺️ *Floor / master plan* — send floor plan of Anisam to <phone>
📍 *GPS location* — send location of Anisam to <phone>
📋 *Full details + photos* — share details of Anisam to <phone>
🏞️ *Specific plot pack* — share photos to <phone> for plot 14 Anisam
🧾 *Receipt* — send receipt for <phone>
💳 *Payment link / bank details* — send payment link to <phone>
💰 *Payment request* — send payment request of 50000 to <phone>

*🤝 Sales Workflow*
• book Anisam 14 for <phone> advance 50000
• schedule visit for <phone> tomorrow 4pm
• reschedule visit for <phone> to monday 11am
• follow up with <phone> after 3 days
• assign <phone> to Ramesh

*⚙️ Operations*
• mark plot 14 Anisam as sold
• patta status of Anisam 14
• outstanding for <phone>
• payment status of <phone>
• acknowledge 50000 from <phone>

*📊 Reports*
• daily report   /   weekly report
• commission for Saravanan
• outstanding loans

*👥 Team*
• who is on leave today
• broadcast "Festival offer 5% off" to all leads
• announce price change on Velavan to 350 per sqft
• leave for Saravanan today
• note for <phone>: prefers east-facing
═══════════════════════
_Property Genius · DRD Realtors_`;
        await message.reply(helpText);
        return true;
    }


    if (bodyNoSpace === '!sync' || bodyNoSpace === '!syc') {
        if (await _guardCmd(message, 'sync')) return true;
        const adminNums = (botSettings.admin_numbers || []).map(n => String(n).replace(/\D/g, ''));
        const primaryNum = String(botSettings.primary_admin || '').replace(/\D/g, '');
        const senderNum = target.replace(/\D/g, '').replace(/@.*/, '');
        const isAdmin = (primaryNum && senderNum.includes(primaryNum)) || adminNums.some(n => n && senderNum.includes(n));
        if (!isAdmin) {
            await client.sendMessage(target, "X: Only Admin numbers are authorized for Cloud Sync.");
            return true;
        }
        try {
            const cfg = getBotSettings();
            const repo = (cfg.github_repo || '').trim();
            if (!repo || !process.env.GITHUB_PAT) {
                await client.sendMessage(target, `⚠️ GitHub sync not configured.\nSet *github_repo* in Bot Config (Developer Hub → Bot Configuration).`);
                return true;
            }
            await client.sendMessage(target, `🔄 Syncing to *${repo}*...`);
            const result = await syncToGitHub('Manual_Sync');
            if (result.success && !result.partial) {
                const list = (result.synced || []).map(f => `• ${f}`).join('\n');
                await client.sendMessage(target, `✅ *Sync complete!*\nRepo: _${repo}_\n\n${list || 'Files pushed.'}`);
            } else if (result.partial) {
                await client.sendMessage(target, `⚠️ *Partial sync*\nSynced: ${(result.synced || []).join(', ')}\nFailed: ${result.error}`);
            } else {
                await client.sendMessage(target, `❌ Sync failed: ${result.error}`);
            }
        } catch (err) {
            await client.sendMessage(target, `❌ Sync error: ${err.message}`);
        }
        return true;
    }

    // [NEW] Flexible Relay / Share Command for Admins & Staff
    const relayPattern = /share\s+(?:photos?|details?|price|details)\s+(?:to\s+)?(\d+)\s+([\s\S]+)/im;
    const relayMatch = bodyRaw.match(relayPattern);
    if (relayMatch) {
        if (await _guardCmd(message, 'relay_share')) return true;
        const targetPhone = relayMatch[1].trim();
        const rawContext = relayMatch[2].trim();
        
        // Extract Plot No (e.g. "10A" or "plot 5")
        const plotMatch = rawContext.match(/(?:plot\s+)?(\d+[a-z]?)\b/i);
        const plotNo = plotMatch ? plotMatch[1].toUpperCase() : "";
        
        // Match against known layouts from DB
        const plotData = await getPlotsData();
        const layoutNames = [...new Set(plotData.map(d => d.Layout || d.Layout_Name).filter(Boolean))];
        let matchedLayout = "";
        
        const cleanContext = rawContext.toLowerCase();
        for (const l of layoutNames) {
            const cleanL = l.toLowerCase().replace('drd ', '').replace('gardens', 'garden').trim();
            if (cleanContext.includes(cleanL)) {
                matchedLayout = l;
                break;
            }
        }
        
        if (!matchedLayout) {
             matchedLayout = rawContext.replace(plotNo, '')
                               .replace(/plot|details|price|following|no|garden/gi, '')
                               .replace(/\s+/g, ' ')
                               .trim();
        }

        if (targetPhone) {
            const finalTarget = targetPhone.length === 10 ? '91' + targetPhone : targetPhone;
            console.log(`[RELAY COMMAND] target=${finalTarget}, plot=${plotNo}, layout=${matchedLayout}`);
            
            if (process.send) {
                process.send({ 
                    type: 'manager_share', 
                    data: { 
                        target: finalTarget, 
                        plotNo: plotNo || 'any', 
                        layout: matchedLayout || 'General', 
                        sender: 'Admin Team' 
                    } 
                });
            }

            const targetJid = finalTarget.includes('@') ? finalTarget : `${finalTarget}@c.us`;
            const intro = `Hello! 👋 I'm Property Genius from *DRD Realtors*.\n\nOur team requested me to share the details of *Plot ${plotNo || 'available plots'}* in *${matchedLayout || 'our projects'}* with you.\n\nSending over the technical details and media now!`;
            
            try {
                await client.sendMessage(targetJid, intro);
                await message.reply(`✅ Relaying details of ${plotNo} (${matchedLayout}) to ${finalTarget}. I'll handle the interaction with them!`);
            } catch (e) {
                await message.reply(`❌ Failed to send intro to ${finalTarget}: ${e.message}`);
            }
            return true;
        }
    }


    // ── Bill image scan: caption contains "bill", "invoice", "gst", "receipt" ──
    if (message.hasMedia && message.type === 'image') {
        const billCaption = (message.body || '').trim();
        if (/\b(?:bill|invoice|gst|receipt|tax\s*invoice|purchase\s*bill|vendor)\b/i.test(billCaption)) {
            try {
                await client.sendMessage(target, '🔍 Scanning bill...');
                const media = await message.downloadMedia();
                if (!media) { await client.sendMessage(target, '⚠️ Could not download image.'); return true; }
                const model = genAI.getGenerativeModel({ model: AI_MODELS[0] || 'gemini-2.5-flash' });
                const result = await model.generateContent([
                    { inlineData: { mimeType: media.mimetype, data: media.data } },
                    'Extract GST invoice details from this image. Return JSON only with these keys: vendor (string), invoice_date (YYYY-MM-DD or null), taxable_value (number or null), gst_rate (number or null), total_amount (number or null), description (string). No explanation, just JSON.'
                ]);
                const txt = result.response.text();
                const jsonMatch = txt.match(/\{[\s\S]*\}/);
                if (!jsonMatch) { await client.sendMessage(target, '⚠️ Could not read bill details. Use *!gst* command manually.'); return true; }
                let parsed;
                try { parsed = JSON.parse(jsonMatch[0]); } catch (e) {
                    await client.sendMessage(target, '⚠️ Could not parse bill. Use *!gst* command manually.'); return true;
                }
                const today = new Date().toISOString().split('T')[0];
                const invoiceDate = parsed.invoice_date || today;
                const vendor = parsed.vendor || 'Unknown Vendor';
                const taxable = parsed.taxable_value || parsed.total_amount || 0;
                const total = parsed.total_amount || taxable;
                const gstRate = parsed.gst_rate || 18;
                const desc = parsed.description || 'Bill scan entry';
                const adminPhone = message.from;
                userStates[adminPhone] = userStates[adminPhone] || {};
                userStates[adminPhone].pendingGst = { invoiceDate, vendor, taxable, total, gstRate, desc };
                await client.sendMessage(target,
                    `📝 *GST Entry Preview (Bill Scan)*\n\n` +
                    `🏢 Vendor: ${vendor}\n` +
                    `💰 Total: ₹${total.toLocaleString('en-IN')}\n` +
                    `📊 Taxable: ₹${taxable.toLocaleString('en-IN')}\n` +
                    `🏷️ GST Rate: ${gstRate}%\n` +
                    `📅 Invoice Date: ${invoiceDate}\n` +
                    `📝 Description: ${desc}\n\n` +
                    `Reply *Add entry* or *yes* to confirm, or *cancel* to discard.`
                );
                return true;
            } catch (e) {
                await client.sendMessage(target, '⚠️ Bill scan failed: ' + e.message + '. Use *!gst* command manually.');
                return true;
            }
        }
    }

    if (message.hasMedia || message.type === 'document') {
        const isPrimaryAdmin = !!botSettings.primary_admin && target.includes(botSettings.primary_admin);
        if (!isPrimaryAdmin || !isDirectToBot) return false;

        try {
            console.log(`MEDIA: Admin Media Received: ${message.type}`);


            await new Promise(r => setTimeout(r, 5000));
            const refreshedMsg = await client.getMessageById(message.id._serialized);
            const media = await refreshedMsg.downloadMedia();
            if (!media) {
                await client.sendMessage(target, "X: Failed to download media.");
                return true;
            }

            let fileName = "";
            const isExcel = media.mimetype?.includes('spreadsheet') || media.filename?.toLowerCase().endsWith('.xlsx');
            const isZip = media.filename?.toLowerCase().endsWith('.zip');
            const isImage = media.mimetype?.includes('image');

            if (isExcel) {
                fileName = 'Plots_Data.xlsx';
                fs.writeFileSync(path.join(ROOT_DIR, fileName), Buffer.from(media.data, 'base64'));
                await client.sendMessage(target, "OK: Excel Updated Locally.");
            } else if (isImage) {
                const captionLower = bodyRaw.toLowerCase().trim();
                const isDailyBroadcast = /\bdaily\b/.test(captionLower);
                const sendNow = isDailyBroadcast && /\bnow\b/.test(captionLower);

                if (isDailyBroadcast) {
                    // Save to broadcast_images/ — picked up by Daily Auto-Image Sender
                    const bcastDir = path.join(ROOT_DIR, 'broadcast_images');
                    if (!fs.existsSync(bcastDir)) fs.mkdirSync(bcastDir, { recursive: true });
                    const dailyFile = `daily_${Date.now()}.jpg`;
                    const imgPath = path.join(bcastDir, dailyFile);
                    fs.writeFileSync(imgPath, Buffer.from(media.data, 'base64'));

                    const cfg = getBotSettings();
                    const ai = cfg.auto_image || {};
                    if (sendNow) {
                        const lists = cfg.broadcast_lists || [];
                        const lst = lists.find(l => l.name === ai.list_name);
                        if (lst && lst.phones && lst.phones.length) {
                            const today = new Date().toISOString().split('T')[0];
                            const stmt = db.prepare(`INSERT INTO scheduled_messages (customer_phone, message_text, media_path, scheduled_date, status) VALUES (?, ?, ?, ?, 'Pending')`);
                            lst.phones.forEach(p => stmt.run(String(p).replace(/\D/g, ''), '📸 Daily Update from DRD Realtors', imgPath, today));
                            stmt.finalize();
                            processScheduledMessages(); // trigger immediate dispatch
                            await client.sendMessage(target, `✅ Daily image saved & broadcasting now to *${lst.phones.length}* contacts in list _${ai.list_name}_!`);
                        } else {
                            await client.sendMessage(target, `✅ Daily image saved!\n⚠️ No list configured — set one in Dashboard → Marketing → Daily Auto-Image.`);
                        }
                    } else {
                        const schedInfo = ai.enabled && ai.send_time && ai.list_name
                            ? `⏰ Auto-send: *${ai.send_time}* daily to list _${ai.list_name}_.`
                            : `⚠️ Auto-send is OFF — enable it from Dashboard → Marketing.`;
                        await client.sendMessage(target, `✅ Daily broadcast image saved!\n${schedInfo}\n\n💡 Send with caption *"daily now"* to broadcast immediately.`);
                    }
                    return true; // skip GitHub sync for broadcast images
                }

                const folder = path.join(IMAGES_DIR, '01 All Layouts');
                if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });

                let cleanCaption = bodyRaw.replace(/[^a-z0-9]/gi, '_').substring(0, 40);
                if (!cleanCaption && media.filename) {
                    cleanCaption = path.parse(media.filename).name.replace(/[^a-z0-9]/gi, '_');
                }
                const baseName = cleanCaption || "layout_img";
                fileName = `${baseName}_${Date.now()}.jpg`;

                fs.writeFileSync(path.join(folder, fileName), Buffer.from(media.data, 'base64'));
                await client.sendMessage(target, `IMAGE: Added Locally: ${fileName}`);
            } else if (isZip) {
                const zipPath = path.join(ROOT_DIR, 'temp_upload.zip');
                fs.writeFileSync(zipPath, Buffer.from(media.data, 'base64'));
                const zip = new AdmZip(zipPath);
                zip.getEntries().forEach(entry => {
                    // Use only the basename — never allow path components from ZIP entries
                    const safeName = path.basename(entry.entryName);
                    const entryName = safeName.toLowerCase();
                    if (!safeName) return; // skip entries with no filename
                    if (entryName.endsWith('.xlsx')) {
                        fs.writeFileSync(path.join(ROOT_DIR, 'Plots_Data.xlsx'), entry.getData());
                    } else if (/\.(jpg|jpeg|png)$/.test(entryName)) {
                        const imgFolder = path.join(IMAGES_DIR, '01 All Layouts');
                        if (!fs.existsSync(imgFolder)) fs.mkdirSync(imgFolder, { recursive: true });
                        fs.writeFileSync(path.join(imgFolder, safeName), entry.getData());
                    }
                });
                fs.unlinkSync(zipPath);
                fileName = "Bulk_ZIP_Update";
                await client.sendMessage(target, "ZIP: Content Processed.");
            }

            if (fileName) {
                const result = await syncToGitHub(fileName);
                if (result.success) {
                    await client.sendMessage(target, "CLOUD: Synchronized Successfully.");
                } else {
                    await client.sendMessage(target, `!: Saved Locally, but Cloud Sync failed.\nError: ${result.error}`);
                }
            }
            return true;
        } catch (err) {
            console.error("Admin upload failed:", err);
            await client.sendMessage(target, "X: Upload Failed: " + err.message);
            return true;
        }
    }

    // ── Admin expense / GST / !myexp commands ──
    const adminExpBody = (message.body || '').trim();
    const adminPhone = message.from;
    const nlAdminExpMatch = adminExpBody.match(
        /^(?:rs\.?\s*|₹\s*|inr\.?\s*)(\d[\d,.]*)[\s\-]+(?:as\s+)?(?:expense|expenses?|exp)(?:\s+for\s+([\w\s]+?)(?:\s+for\s+(.+))?)?$/i
    );
    const isAdminConfirmWord = /^(add\s+entry|yes|confirm|ok|done)$/i.test(adminExpBody);
    const isAdminCancelWord  = /^cancel$/i.test(adminExpBody);
    const isAdminPendingConfirm = isAdminConfirmWord && userStates[adminPhone]?.pendingExpense;
    const isAdminPendingCancel  = isAdminCancelWord  && userStates[adminPhone]?.pendingExpense;
    const isAdminPendingGstConfirm = isAdminConfirmWord && userStates[adminPhone]?.pendingGst;
    const isAdminPendingGstCancel  = isAdminCancelWord  && userStates[adminPhone]?.pendingGst;

    if (isAdminPendingCancel) {
        delete userStates[adminPhone].pendingExpense;
        await client.sendMessage(target, '❌ Expense entry cancelled.');
        return true;
    }

    if (isAdminPendingGstCancel) {
        delete userStates[adminPhone].pendingGst;
        await client.sendMessage(target, '❌ GST entry cancelled.');
        return true;
    }

    if (isAdminPendingConfirm) {
        const pe = userStates[adminPhone].pendingExpense;
        delete userStates[adminPhone].pendingExpense;
        const today = new Date().toISOString().split('T')[0];
        try {
            const senderName = await resolveStaffName(adminPhone.replace(/\D/g, ''), message);
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO expenses (category, description, amount, date, layout_name, source, bot_submitted_by, notes)
                       VALUES (?, ?, ?, ?, ?, 'bot', ?, ?)`,
                    [pe.category, pe.desc, pe.amount, today, pe.layout || null, senderName, `Bot NL entry by ${senderName}`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });
            await client.sendMessage(target,
                `✅ *Expense Logged*\n\n💰 ₹${pe.amount.toLocaleString('en-IN')} – ${pe.desc}\n` +
                `🗂️ Category: ${pe.category}` +
                (pe.layout ? `\n🏗️ Project: ${pe.layout}` : '') +
                `\n📅 Date: ${today}`
            );
        } catch (e) {
            await client.sendMessage(target, '⚠️ Could not save expense: ' + e.message);
        }
        return true;
    }

    if (isAdminPendingGstConfirm) {
        const pg = userStates[adminPhone].pendingGst;
        delete userStates[adminPhone].pendingGst;
        const d = new Date(pg.invoiceDate);
        const fy = (d.getMonth() + 1) >= 4 ? `${d.getFullYear()}-${String(d.getFullYear() + 1).slice(-2)}` : `${d.getFullYear() - 1}-${String(d.getFullYear()).slice(-2)}`;
        try {
            const senderName = await resolveStaffName(adminPhone.replace(/\D/g, ''), message);
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO gst_ledger
                       (direction, invoice_date, party_name, description, taxable_value, gst_rate,
                        cgst, sgst, igst, total_amount, is_interstate, is_exempt,
                        financial_year, month, year, status, source, bot_submitted_by, notes)
                       VALUES ('inward', ?, ?, ?, ?, ?, 0, 0, 0, ?, 0, 0, ?, ?, ?, 'Draft', 'bot', ?, ?)`,
                    [pg.invoiceDate, pg.vendor, pg.desc, pg.taxable, pg.gstRate, pg.total,
                     fy, d.getMonth() + 1, d.getFullYear(), senderName, `Bot bill scan by ${senderName} — verify GST details`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });
            await client.sendMessage(target,
                `✅ *GST Entry Logged (Inward)*\n\n🏢 Vendor: ${pg.vendor}\n` +
                `💰 Total: ₹${pg.total.toLocaleString('en-IN')}\n` +
                `🏷️ GST Rate: ${pg.gstRate}%\n` +
                `📅 Date: ${pg.invoiceDate}\n\n` +
                `⚠️ _Review in Dashboard → Finance → GST Ledger_`
            );
        } catch (e) {
            await client.sendMessage(target, '⚠️ Could not save GST entry: ' + e.message);
        }
        return true;
    }

    if (nlAdminExpMatch) {
        const amount = parseFloat(nlAdminExpMatch[1].replace(/,/g, '')) || 0;
        const layout = (nlAdminExpMatch[2] || '').trim();
        const desc   = (nlAdminExpMatch[3] || layout || 'Expense').trim();
        const descLower = desc.toLowerCase();
        let category = 'Other';
        if (/petrol|fuel|diesel/i.test(descLower)) category = 'Travel';
        else if (/office|stationery|print/i.test(descLower)) category = 'Office Expenses';
        else if (/electricity|eb|power/i.test(descLower)) category = 'Utilities';
        else if (/salary|wage/i.test(descLower)) category = 'Salary';
        else if (/material|cement|steel|sand/i.test(descLower)) category = 'Materials';
        else if (/food|lunch|tea|snack/i.test(descLower)) category = 'Food';
        else if (/phone|mobile|internet/i.test(descLower)) category = 'Communication';
        else if (/repair|maintenance|service|fitting|fix/i.test(descLower)) category = 'Maintenance';
        else if (/rent/i.test(descLower)) category = 'Rent';

        userStates[adminPhone] = userStates[adminPhone] || {};
        userStates[adminPhone].pendingExpense = { amount, layout, desc, category };
        await client.sendMessage(target,
            `📝 *Expense Entry Preview*\n\n` +
            `💰 Amount: ₹${amount.toLocaleString('en-IN')}\n` +
            `📝 Description: ${desc}\n` +
            `🗂️ Category: ${category}\n` +
            (layout ? `🏗️ Project: ${layout}\n` : '') +
            `\nReply *Add entry* or *yes* to confirm, or *cancel* to discard.`
        );
        return true;
    }

    // ── Admin !gst <amount> <VendorName> [description] ──
    if (/^!gst\s/i.test(adminExpBody)) {
        const parts = adminExpBody.replace(/^!gst\s+/i, '').trim();
        const amtMatch = parts.match(/^(\d[\d,.]*)(.*)$/);
        if (!amtMatch) {
            await client.sendMessage(target, '⚠️ Format: *!gst 5000 VendorName description*\nAmount must come first.');
            return true;
        }
        const total = parseFloat(amtMatch[1].replace(/,/g, '')) || 0;
        const rest = amtMatch[2].trim();
        const [party, ...descParts] = rest.split(' ');
        const partyName = party || 'Unknown Vendor';
        const desc = descParts.join(' ') || 'Bot GST Entry';
        const today = new Date().toISOString().split('T')[0];
        const d = new Date(today);
        const fy = (d.getMonth() + 1) >= 4 ? `${d.getFullYear()}-${String(d.getFullYear() + 1).slice(-2)}` : `${d.getFullYear() - 1}-${String(d.getFullYear()).slice(-2)}`;
        try {
            const senderName = await resolveStaffName(adminPhone.replace(/\D/g, ''), message);
            await new Promise((res2, rej2) => {
                db.run(
                    `INSERT INTO gst_ledger
                       (direction, invoice_date, party_name, description, taxable_value, gst_rate,
                        cgst, sgst, igst, total_amount, is_interstate, is_exempt,
                        financial_year, month, year, status, source, bot_submitted_by, notes)
                       VALUES ('inward', ?, ?, ?, ?, 18, 0, 0, 0, ?, 0, 0, ?, ?, ?, 'Draft', 'bot', ?, ?)`,
                    [today, partyName, desc, total, total, fy, d.getMonth() + 1, d.getFullYear(),
                     senderName, `Bot entry by ${senderName} — verify GST details`],
                    function(err) { err ? rej2(err) : res2(this.lastID); }
                );
            });
            await client.sendMessage(target,
                `✅ *GST Entry Recorded (Inward)*\n\n🏢 Party: ${partyName}\n💰 Amount: ₹${total.toLocaleString('en-IN')}\n📝 Description: ${desc}\n📅 Date: ${today}\n\n` +
                `⚠️ _GST rate defaulted to 18%. Review in Dashboard → Finance → GST Ledger_`
            );
        } catch (e) {
            await client.sendMessage(target, '⚠️ Could not save GST entry: ' + e.message);
        }
        return true;
    }

    // ── Admin !myexp — last 5 bot-submitted expenses + GST entries across all staff ──
    if (/^!myexp$/i.test(adminExpBody.trim())) {
        try {
            const rows = await new Promise((res2) => {
                db.all(
                    `SELECT 'Expense' AS type, description AS title, amount, date AS entry_date, bot_submitted_by AS submitter FROM expenses
                       WHERE source = 'bot' ORDER BY created_at DESC LIMIT 5
                     UNION ALL
                     SELECT 'GST' AS type, COALESCE(description, party_name) AS title, total_amount AS amount, invoice_date AS entry_date, bot_submitted_by AS submitter
                       FROM gst_ledger WHERE source = 'bot' ORDER BY created_at DESC LIMIT 5`,
                    [],
                    (err, r) => res2(err ? [] : r)
                );
            });
            if (!rows.length) { await client.sendMessage(target, '📋 No recent bot-submitted entries found.'); return true; }
            const lines = rows.map(r => `${r.type}: ₹${Number(r.amount).toLocaleString('en-IN')} – ${r.title} (${r.entry_date}) by ${r.submitter || '?'}`);
            await client.sendMessage(target, `📋 *Recent Bot Entries*\n\n${lines.join('\n')}`);
        } catch (e) {
            await client.sendMessage(target, '⚠️ Error: ' + e.message);
        }
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // GROUP E — GEMINI INTENT ROUTER (catch-all for unmatched admin commands)
    // ══════════════════════════════════════════════════════════════════════════
    // Triggers ONLY when:
    //   (1) the sender is an admin (we know — handleAdminCommand only runs for admins via the outer check)
    //   (2) the message starts with a command-ish verb, OR mentions a phone, OR mentions an amount
    //   (3) nothing above matched
    // It asks Gemini to classify the intent against the known command catalog,
    // then replies to the admin with the correct exact phrasing — does NOT auto-execute
    // (safer for v1; Gemini hallucinations / prompt injection won't cost money or fire messages).
    // A leading verb alone (e.g. "Share photos and layout") is too weak — admins who chat
    // with the bot like a customer would get hijacked into the intent router. Require a
    // *target signal* (phone, money, or "<verb> ... to <something>") alongside the verb.
    const _hasCommandVerb = /^(?:please\s+|kindly\s+)?(?:send|share|forward|dispatch|collect|request|raise|book|schedule|reschedule|move|postpone|shift|follow|remind|assign|mark|set|patta|outstanding|balance|dues?|receipt|acknowledge|payment|payments|daily|weekly|today|yesterday|report|commission|leave|broadcast|announce|update|note|notes)\b/i.test(bodyRaw);
    const _hasPhoneTarget = /\d{10,}/.test(bodyRaw);
    const _hasMoneyTarget = /(?:rs\.?|₹|inr)/i.test(bodyRaw);
    const _hasDelegation  = /\bto\s+\S/i.test(bodyRaw);
    const looksLikeAdminCommand =
        (_hasCommandVerb && (_hasPhoneTarget || _hasMoneyTarget || _hasDelegation))
        || _hasPhoneTarget
        || _hasMoneyTarget;

    if (looksLikeAdminCommand && !_adminDedupOk('E_INTENT')) return true;
    if (looksLikeAdminCommand) {
        if (!isCmdEnabled('gemini_router')) return false;
        try {
            // Hard cap so we don't burn quota on every random admin chat
            global.__intentRouterCount = global.__intentRouterCount || { count: 0, since: Date.now() };
            if (Date.now() - global.__intentRouterCount.since > 3600_000) global.__intentRouterCount = { count: 0, since: Date.now() };
            if (global.__intentRouterCount.count > 30) {
                console.log('[INTENT ROUTER] hourly cap reached');
                return false;
            }
            global.__intentRouterCount.count++;

            const catalog = `
You are the command-suggestion assistant for the DRD Property Genius WhatsApp bot.
The admin tried to issue a command and it was NOT matched by any specific handler.

Available admin commands (suggest the closest one):
SALES
- send quotation for <plot> <layout> to <phone>
- book <layout> <plot> for <phone> [advance <amount>]
- schedule visit for <phone> <date> <time>
- reschedule visit for <phone> to <new date> <time>
- follow up with <phone> after <N> days [: note]
- assign <phone> to <staff name>

OPERATIONS
- mark <plot> <layout> as <Available|Booked|Sold|Blocked>
- send brochure of <layout> to <phone>
- send GPS of <layout> to <phone>
- send floor plan of <layout> to <phone>
- patta status of <layout> <plot>
- outstanding for <phone>

MONEY
- send receipt for <phone>   /  acknowledge <amount> from <phone>
- payment status of <phone>
- daily report  /  weekly report
- commission for <staff>
- outstanding loans
- Rs <amount> as expenses for <project> for <description>
- !gst <amount> <VendorName> <description>
- !myexp  (view recent bot-submitted entries)
- [send bill image with caption "bill" or "invoice" or "gst" to auto-scan]

TEAM
- who is on leave today
- broadcast "<message>" to <all leads|all booked|all staff|in <layout>>
- announce price change on <layout> to <rate> per <sqft|cent>
- leave for <staff> [on <date>]
- note for <phone>: <text>

PAYMENT
- share payment link to <phone>
- send payment advance of <amount> to <phone>

Return JSON only: {"suggestion": "<best-guess command phrasing>", "reason": "<one-line why>"}.
If you genuinely cannot map it to anything, return {"suggestion": null, "reason": "..."}.`.trim();

            const aiModel = genAI.getGenerativeModel({ model: AI_MODELS[currentModelIndex] || 'gemini-2.5-flash-lite' });
            const result = await aiModel.generateContent(catalog + '\n\nAdmin wrote: ' + JSON.stringify(bodyRaw));
            const txt = result.response.text();
            const jsonMatch = txt.match(/\{[\s\S]*\}/);
            let suggestion = null, reason = '';
            if (jsonMatch) {
                try { const j = JSON.parse(jsonMatch[0]); suggestion = j.suggestion || null; reason = j.reason || ''; } catch (e) {}
            }

            if (suggestion) {
                await client.sendMessage(target,
                    `🤖 Not sure what you meant. Did you want:\n\n*${suggestion}*\n\n_${reason}_\n\nReply with the exact command above to execute. Type *!help* for the full command list.`);
            } else {
                await client.sendMessage(target,
                    `🤖 I couldn't map your request to a known command.${reason ? `\n\n_${reason}_` : ''}\n\nType *!help* to see all admin commands.`);
            }
            return true;
        } catch (e) {
            console.warn('[INTENT ROUTER] failed:', e.message);
            // Fall through — let the message reach the customer-AI flow (which is harmless from admin)
        }
    }

    return false;
}

async function runLocalFallback(message, phone, userMsg) {
    try {
        if (!userStates[phone]) userStates[phone] = { step: 'MENU' };
        const state = userStates[phone];
        const data = await getPlotsData();
        const availablePlots = data.filter(d => d.Status && d.Status.toLowerCase().includes('available'));
        const layouts = [...new Set(availablePlots.map(d => d.Layout || d.Layout_Name).filter(Boolean))];

        let matchedLayout = null;
        const userMsgNoSpace = userMsg.replace(/\s+/g, '').toLowerCase();
        for (const layout of layouts) {
            const layoutNoSpace = layout.replace(/\s+/g, '').toLowerCase();
            if (userMsgNoSpace.includes(layoutNoSpace)) { matchedLayout = layout; break; }
        }
        if (!matchedLayout) {
            const index = parseInt(userMsg.trim());
            if (!isNaN(index) && index >= 1 && index <= layouts.length) matchedLayout = layouts[index - 1];
        }

        if (!matchedLayout) {
            console.log(`[FALLBACK] No specific layout matched. Sending Menu.`);
            let menu = "🏡 *Welcome to DRD Realtors!* \n\nOur AI agent is currently busy, but here are our available projects to get you started. Which property would you like details for?\n\n";
            layouts.forEach((l, i) => {
                menu += `${i + 1}. ${l}\n`;
            });
            menu += "\nReply with the *Project Name* or *Number*!";
            await message.reply(menu);
            return;
        }

        const layoutPlots = availablePlots.filter(d => (d.Layout || d.Layout_Name) === matchedLayout);
        logLayoutInterest(matchedLayout); // Log popularity hit

        const perCentRates = layoutPlots.map(p => {
            const price = parseFloat(p.Price || p.Total_Price);
            const size = parseFloat(p.Size || p.Area_SqFt);
            if (!price || !size) return null;
            return (price / size) * 435.6;
        }).filter(Boolean);

        if (perCentRates.length > 0) {
            const minRate = Math.min(...perCentRates);
            const maxRate = Math.max(...perCentRates);

            // Format as Approx Range per Cent
            const lower = Math.floor(minRate / 100000);
            const upper = Math.ceil(maxRate / 100000);
            const rangeStr = lower === upper ? `${lower}L` : `${lower}L - ${upper}L`;

            let response = `🏡 *${matchedLayout}* Details:\n\n`;
            response += `📍 Prices range from **Approx. Rs.${rangeStr} per Cent**.\n`;
            response += `📞 *Note:* Final fixed price will be confirmed via Call.\n`;
            await message.reply(response);
        } else {
            await message.reply(`🏡 *${matchedLayout}*: Available soon. Please call for pricing.`);
        }

        let targetResult = findVisualForLayout(matchedLayout, IMAGES_DIR) || findVisualForLayout(matchedLayout, path.join(IMAGES_DIR, '01 All Layouts'));
        if (targetResult) {
            if (targetResult.type === 'directory') {
                for (const file of targetResult.files) {
                    try {
                        const filePath = path.join(targetResult.path, file);
                        if (fs.existsSync(filePath)) {
                            const media = MessageMedia.fromFilePath(filePath);
                            await client.sendMessage(phone, media);
                            await new Promise(r => setTimeout(r, 2000));
                        }
                    } catch(e) { console.log('Fallback media error:', e.message); }
                }
            } else {
                try {
                    if (fs.existsSync(targetResult.path)) {
                        await client.sendMessage(phone, MessageMedia.fromFilePath(targetResult.path));
                    }
                } catch(e) { console.log('Fallback single media error:', e.message); }
            }
            await client.sendMessage(phone, `(MAP) Site Plan: ${(botSettings.visualizer_url || 'https://drdrealtors.github.io/drd-layouts/')}`);
        }
        await client.sendMessage(phone, `-> Please reply with your Budget & Loan interest.`);
        userStates[phone] = userStates[phone] || {};
        userStates[phone].step = 'EXPECTING_ANSWER';
        userStates[phone].lastLayout = matchedLayout;

    } catch (err) {
        console.error("Fallback error:", err);
    }
}

client.on('message_create', async message => {
    // ── REPLAY GUARD ──
    // whatsapp-web.js re-fires message_create for buffered messages on every reconnect.
    // Skip messages older than 90s before bot start UNLESS they fell inside an offline window
    // and nobody (bot or admin) has already replied to that customer since then.
    if (message.timestamp && (message.timestamp * 1000) < (BOT_START_TIME_MS - 90000)) {
        const msgTimeMs = message.timestamp * 1000;
        const SIX_HOURS_MS = 6 * 60 * 60 * 1000;
        const canReplay = (
            !message.fromMe &&
            _offlineSince !== null &&
            msgTimeMs >= _offlineSince &&
            msgTimeMs >= (Date.now() - SIX_HOURS_MS) // ignore messages older than 6h
        );
        if (!canReplay) return; // drop as before

        const _replayPhone10 = (message.from || '').replace(/\D/g, '').slice(-10);

        // Only queue one reply per customer per reconnect — the latest message wins
        if (_offlineRepliedPhones.has(_replayPhone10)) return;

        // Check DB: did bot or admin already reply after this message arrived?
        const _alreadyHandled = await new Promise(resolve => {
            db.get(
                `SELECT id FROM conversations
                 WHERE (phone = ? OR phone LIKE ?)
                   AND UPPER(role) IN ('BOT','ADMIN')
                   AND created_at > datetime(?, 'unixepoch')
                 LIMIT 1`,
                [message.from, `%${_replayPhone10}`, message.timestamp],
                (err, row) => resolve(!!row)
            );
        });
        if (_alreadyHandled) {
            console.log(`[OFFLINE-REPLAY] ${_replayPhone10} — admin/bot already replied, skipping.`);
            return;
        }

        _offlineRepliedPhones.add(_replayPhone10);
        console.log(`[OFFLINE-REPLAY] Replaying missed message from ${_replayPhone10} (sent ${new Date(msgTimeMs).toLocaleString()})`);
        // Fall through to normal message processing below
    }

    // ── QR TRACKING LOGIC (Priority) ──
    // Supports two formats:
    //   1. Visible:  [Ref: STAFF_ID] in message body (legacy / manual)
    //   2. Hidden:   zero-width chars encoded between FEFF markers (new invisible mode)
    function zwDecodeStaffId(text) {
        const LRM  = String.fromCharCode(0x200E);  // new compact format boundary
        const FEFF = String.fromCharCode(0xFEFF);  // old format boundary
        const ZW0  = String.fromCharCode(0x200B);
        const ZW1  = String.fromCharCode(0x200C);
        const ZW2  = String.fromCharCode(0x200D);
        const ZW3  = String.fromCharCode(0x200F);
        const SEP  = ZW2;  // old format separator

        // New compact base-4 format (boundary = LRM U+200E)
        if (text.includes(LRM)) {
            const parts = text.split(LRM);
            const inner = parts.length >= 2 ? parts[1] : '';
            if (!inner || inner.length % 4 !== 0) return null;
            const map = new Map([[ZW0,0],[ZW1,1],[ZW2,2],[ZW3,3]]);
            let result = '';
            for (let i = 0; i < inner.length; i += 4) {
                let code = 0;
                for (let j = 0; j < 4; j++) {
                    const v = map.get(inner[i+j]);
                    if (v === undefined) return null;
                    code = (code << 2) | v;
                }
                result += String.fromCharCode(code);
            }
            return result || null;
        }

        // Old binary+separator format (boundary = FEFF U+FEFF)
        const inner = text.split(FEFF)[1];
        if (!inner) return null;
        const chars = inner.split(SEP).filter(Boolean);
        try {
            return chars.map(bits => String.fromCharCode(
                parseInt(bits.split('').map(c => c === ZW1 ? '1' : '0').join(''), 2)
            )).join('') || null;
        } catch(e) { return null; }
    }
    const hiddenRef = zwDecodeStaffId(message.body);
    const qrMatch = !hiddenRef && message.body.match(/\[Ref:\s*([^\]]+)\]/i);
    if (hiddenRef || qrMatch) {
        const refCode = hiddenRef || qrMatch[1].trim();
        const cleanPhone = message.from.replace(/\D/g, '');

        console.log(`[QR/REF SCAN] Customer ${cleanPhone} used Reference: ${refCode}`);

        // Always record the affiliate click immediately — before any file I/O that could throw
        db.run(`INSERT INTO affiliate_clicks (staff_id, clicked_at, ip) VALUES (?, CURRENT_TIMESTAMP, ?)`,
            [refCode, `Phone:${cleanPhone}`],
            (err) => {
                if (err) db.run(`CREATE TABLE IF NOT EXISTS affiliate_clicks (id INTEGER PRIMARY KEY AUTOINCREMENT, staff_id TEXT, clicked_at TEXT, ip TEXT)`);
            });

        try {
            // Check if it's a layout or a staff member
            // Strip 'layout_' prefix that dashboard encodes when no staff is selected
            const normalizedRef = refCode.replace(/^layout_/i, '');
            const layouts = JSON.parse(fs.readFileSync(path.join(ROOT_DIR, 'layouts_data.json'), 'utf8'));
            const matchedLayout = layouts.find(l => l.Layout_Name.replace(/[^a-z0-9]/gi, '_').toUpperCase() === normalizedRef.toUpperCase());

            const staff = getMasterData('Staff');
            const matchedStaff = staff.find(s => (s.Staff_ID || s.id || '').toUpperCase() === refCode.toUpperCase());

            const logName = matchedLayout ? matchedLayout.Layout_Name : 'Affiliate Visit';
            const logAffiliate = matchedStaff ? matchedStaff.Staff_ID : 'WhatsApp_QR';
            const logStaffName = matchedStaff ? (matchedStaff.Name || matchedStaff.Staff_ID || '') : '';
            const customerName = message._data?.notifyName || '';
            const visibleMsg = message.body.replace(/[﻿​‌‍‎‏]/g, '').trim();

            // 1. Log to QR Scans table (for Layout Scan Log)
            db.run(`INSERT INTO qr_scans (layout_name, affiliate_code, ip_address, user_agent, customer_phone, customer_name, customer_message, staff_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [logName, logAffiliate, `Phone:${cleanPhone}`, 'WhatsApp_Bot_Ref', cleanPhone, customerName, visibleMsg, logStaffName]);
            
            // 2. CONNECT TO MASTER CRM: only for real customer phones (not admin @lid or own messages)
            if (!message.fromMe && !message.from.includes('@lid')) {
                // Also look up if refCode matches a remisier affiliate code to set referred_by
                const rmCode = refCode || null;
                db.run(`INSERT INTO customers (phone, name, plot, location, status, referred_by, last_interaction)
                        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                        ON CONFLICT(phone) DO UPDATE SET
                          name = CASE WHEN customers.name IN ('New Lead (QR)','') THEN excluded.name ELSE customers.name END,
                          status = CASE WHEN customers.status IN ('Purchased','Booked') THEN customers.status ELSE 'QR Inquiry' END,
                          plot = excluded.plot,
                          referred_by = CASE WHEN customers.referred_by IS NULL THEN excluded.referred_by ELSE customers.referred_by END,
                          last_interaction = CURRENT_TIMESTAMP`,
                    [cleanPhone, customerName || 'New Lead (QR)', matchedLayout ? matchedLayout.Layout_Name : 'Property Inquiry', matchedLayout ? matchedLayout.Location : '', 'QR Inquiry', rmCode]);
            }

            console.log(`[CRM SYNC] QR Scan for ${cleanPhone} synced to Master CRM.`);

            // 3. Auto-reply logic
            if (matchedLayout && matchedLayout['GPS Location']) {
                await message.reply(`📍 *GPS Location for ${matchedLayout.Layout_Name}*:\n\n${matchedLayout['GPS Location']}\n\nOur team will contact you shortly to assist with your site visit.`);
                return; 
            } else if (matchedStaff) {
                await message.reply(`👋 Welcome! You are now connected with our senior consultant *${matchedStaff.Name}*. \n\nHow can we help you today?`);
                return;
            }
        } catch(e) { console.error('[QR] Tracking error:', e.message); }

    // QR scan detected but no specific reply was sent — strip ZWC chars so the
    // visible part of the message (or a default greeting) drives normal AI flow.
    const stripped = message.body.replace(/[​‌‍‎‏﻿]/g, '').trim();
    message.body = stripped || 'hi';
    }

    // Permanent physical logging for debug
    const logStr = `\n[${new Date().toISOString()}] fromMe:${message.fromMe} | from:${message.from} | body:${message.body.substring(0, 250)}`;
    const scratchDir = path.join(ROOT_DIR, 'scratch');
    if (!fs.existsSync(scratchDir)) fs.mkdirSync(scratchDir, { recursive: true });
    fs.appendFileSync(path.join(scratchDir, 'message_dump.log'), logStr);

    // Only log incoming to terminal, but process admin commands from both
    if (!message.fromMe) console.log(`[INCOMING] From: ${message.from}, Body: ${message.body.substring(0, 50)}...`);

    if (message.from === 'status@broadcast' || message.from.includes('@g.us')) {
        console.log(`[FILTER] Ignored (Status/Group)`);
        return;
    }

    let phone = message.from.replace(/\D/g, '');
    if (message.from.includes('@lid')) {
        try {
            const contact = await message.getContact();
            if (contact && contact.number) {
                phone = contact.number;
                console.log(`[LID UNMASK] ${message.from} -> ${phone}`);
            }
        } catch(e) {}
    }

    // ─── Voice Note Transcription ──────────────────────────────
    if (message.type === 'audio' || message.type === 'ptt') {
        try {
            const media = await message.downloadMedia();
            if (media) {
                const transcribed = await transcribeAudio(media, phone);
                if (transcribed) {
                    message.body = transcribed;
                    console.log(`[VOICE] Transcribed for ${phone}: "${transcribed.substring(0, 80)}"`);
                } else {
                    await message.reply("🎤 Sorry, I couldn't process that voice message. Please type your question.");
                    return;
                }
            } else { return; }
        } catch (e) {
            console.error(`[VOICE] Error processing audio from ${phone}: ${e.message}`);
            return;
        }
    }

    const userMsg = message.body.trim().toLowerCase();

    // ── SITE VISIT BOOKING ──
    if (await handleSiteVisitBooking(message, phone, userMsg)) {
        analyzeAndScoreLead(phone); // Background scoring
        return;
    }

    // ── STAFF / MANAGER COMMANDS ──
    const staff = getMasterData('Staff');
    const senderStaff = staff.find(s => String(s.Phone).replace(/\D/g, '') === phone);
    
    if (senderStaff) {
        // MD Status Check
        if (senderStaff.Dept === 'Managing Director' && (userMsg === 'status' || userMsg === 'report' || userMsg === 'summary')) {
            const report = await generateSystemReport();
            await message.reply(report);
            return;
        }
    }

    if (userStates[phone]?.managerLead && userStates[phone].step === 'MANAGER_INTRO') {
        // Bypass standard welcome/menu for manager leads
        userStates[phone].step = 'DONE'; 
    }

    // Auto-update bot log for clarity
    const bodyLower = message.body.trim().toLowerCase();

    // ── ADMIN: Status command — short-circuits before Gemini so it always responds ──
    const STATUS_TRIGGERS = ['status', '!status', '/status', '/ping', 'status +', '!status +', '/status +'];
    if (STATUS_TRIGGERS.includes(bodyLower)) {
        const isAdmin = await checkIfAdmin(message);
        if (isAdmin) {
            const uptimeSec = Math.floor((Date.now() - BOT_START_TIME_MS) / 1000);
            const uptimeStr = uptimeSec < 3600
                ? `${Math.floor(uptimeSec / 60)}m ${uptimeSec % 60}s`
                : `${Math.floor(uptimeSec / 3600)}h ${Math.floor((uptimeSec % 3600) / 60)}m`;
            const memMB = (process.memoryUsage().rss / 1024 / 1024).toFixed(0);
            if (bodyLower.includes('+')) {
                console.log(`[ADMIN COMMAND] Advanced Status requested by ${message.from}`);
                const report = await generateSystemReport();
                await message.reply(report);
            } else {
                console.log(`[ADMIN COMMAND] Status requested by ${message.from}`);
                await message.reply(
                    `🟢 *DRD Property Genius — Online*\n\n` +
                    `⏱️ Uptime: ${uptimeStr}\n` +
                    `💾 Memory: ${memMB} MB\n` +
                    `🤖 AI Mode: ${botSettings.ai_mode || 'online'}\n` +
                    `🧠 Model: ${AI_MODELS[currentModelIndex] || 'gemini-2.5-flash'}\n` +
                    `📅 Started: ${BOT_START_TIME}\n\n` +
                    `_Type_ status + _for full report_\n` +
                    `_Type_ !restart _to restart the bot_`
                );
            }
            return;
        }
    }

    // ── ADMIN: Bot restart command ──
    if (bodyLower === '!restart' || bodyLower === '/restart') {
        const isAdmin = await checkIfAdmin(message);
        if (isAdmin) {
            console.log(`[ADMIN COMMAND] Bot restart requested by ${message.from}`);
            await message.reply('🔄 Restarting bot in 3 seconds… BRB!');
            if (process.send) process.send({ type: 'request_restart', by: phone });
            setTimeout(() => process.exit(0), 3000);
            return;
        }
    }

    // ── ADMIN: AI mode toggle ──
    if (/^!ai\b/i.test(bodyLower)) {
        const isAdmin = await checkIfAdmin(message);
        if (isAdmin) {
            const arg = bodyLower.replace(/^!ai\s*/i, '').trim();
            const settings = getBotSettings();
            if (arg === 'off' || arg === 'local' || arg === 'offline') {
                settings.ai_mode = 'offline';
                fs.writeFileSync(BOT_CONFIG_PATH, JSON.stringify(settings, null, 2));
                await message.reply('🏠 *AI Mode → LOCAL*\nBot will now reply using keyword templates only. Send `!ai on` to restore Gemini.');
                console.log('[ADMIN COMMAND] AI mode set to offline');
                return;
            }
            if (arg === 'on' || arg === 'full' || arg === 'online') {
                settings.ai_mode = 'online';
                fs.writeFileSync(BOT_CONFIG_PATH, JSON.stringify(settings, null, 2));
                await message.reply('🤖 *AI Mode → FULL AI*\nBot is back on Gemini. Send `!ai off` to switch to local templates.');
                console.log('[ADMIN COMMAND] AI mode set to online');
                return;
            }
            // status / no arg
            const current = settings.ai_mode || 'online';
            await message.reply(`🤖 *AI Mode: ${current.toUpperCase()}*\n\n• \`!ai on\` — Full Gemini AI\n• \`!ai off\` — Local keyword templates only`);
            return;
        }
    }

    // ── Custom commands (dashboard-defined, simple keyword → reply) ──
    // INTERNAL USE ONLY. Customers cannot trigger these — only admins (in
    // bot_settings.admin_numbers) or registered staff (staff table) can.
    // Customer-facing keywords live in keyword_rules.json instead.
    // This gate prevents accidental data leakage / fake bookings via
    // crafted customer messages.
    try {
        const customCmds = getCustomCommands();
        if (customCmds.length) {
            const senderIsAdmin = await checkIfAdmin(message);
            let senderIsStaff = false;
            if (!senderIsAdmin) {
                try {
                    const phone10 = (phone || '').replace(/\D/g, '').slice(-10);
                    senderIsStaff = await new Promise(resolve => {
                        db.get(
                            `SELECT 1 FROM staff
                               WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
                                 AND is_active != 0 LIMIT 1`,
                            [`%${phone10}`],
                            (err, row) => resolve(!!row));
                    });
                } catch (_) {}
            }
            if (senderIsAdmin || senderIsStaff) {
                const msgLower = (message.body || '').toLowerCase().trim();
                // Filter by per-command audience: c.admin / c.staff (default both true for backwards compat).
                const allowed = customCmds.filter(c => {
                    const allowAdmin = c.admin !== false;
                    const allowStaff = c.staff !== false;
                    if (senderIsAdmin && allowAdmin) return true;
                    if (senderIsStaff && allowStaff) return true;
                    return false;
                });
                const hit = allowed.find(c => {
                    const trig = String(c.trigger || '').toLowerCase().trim();
                    if (!trig) return false;
                    return msgLower === trig || msgLower.includes(trig);
                });
                if (hit) {
                    console.log(`[CUSTOM CMD] matched "${hit.trigger}" from ${message.from} (admin=${senderIsAdmin}, staff=${senderIsStaff})`);
                    await message.reply(String(hit.reply));
                    return;
                }
            } else {
                // Customer message — never log full body, but note rejection for audit
                console.log(`[CUSTOM CMD] skipped (not admin/staff): ${message.from}`);
            }
        }
    } catch (e) { console.warn('[CUSTOM CMD] error:', e.message); }

    const handled = await handleAdminCommand(message);
    if (handled) return;

    // ── STAFF EXPENSE / GST QUICK-ENTRY ──
    const staffHandled = await handleStaffBotCommand(message, phone);
    if (staffHandled) return;

    // ── REMISIER BOT FLOW ──
    const remisierHandled = await handleRemisierBotMessage(message, phone);
    if (remisierHandled) return;

    // STOP THE INFINITE ALICE-IN-WONDERLAND LOOP
    // Ignore all other outgoing messages if they aren't admin commands so the bot never replies to itself.
    if (message.fromMe) return;

    // Phase 1: Logging & Tracking ───────────────────────
    // phone and userMsg are already defined above
    await logConversation(phone, 'USER', message.body, message);
    updateSessionMemory(phone, 'USER', message.body);

    // ── CLAIM CHECK: if a staff agent has claimed this conversation, skip bot auto-response ──
    // Normalize to both 12-digit (WhatsApp) and 10-digit (CRM) forms to handle format mismatch
    const phone10 = phone.replace(/\D/g,'').slice(-10);
    const activeClaim = await new Promise(resolve =>
        db.get(`SELECT staff_id, staff_name FROM conversation_claims WHERE (customer_phone = ? OR customer_phone = ?) AND status = 'Active'`, [phone, phone10], (err, row) => resolve(err ? null : row))
    );
    if (activeClaim) {
        // Send phone10 so the dashboard inbound filter (which uses CRM 10-digit phone) matches
        if (process.send) process.send({ type: 'claimed_inbound', data: { phone: phone10, text: message.body, staffId: activeClaim.staff_id, staffName: activeClaim.staff_name, ts: Date.now() } });
        db.run(`UPDATE conversation_claims SET last_activity_at = CURRENT_TIMESTAMP WHERE (customer_phone = ? OR customer_phone = ?) AND status = 'Active'`, [phone, phone10]);
        return; // staff agent is handling this — do not auto-respond
    }

    // ── Cancel any pending drip nudges (customer is engaged again) ──
    // If we've queued 1d/3d/7d drips and the customer replies, no need to
    // keep nudging them — kill the rest of the sequence.
    try {
        const phone10 = phone.replace(/\D/g, '').slice(-10);
        if (phone10.length >= 10) {
            db.run(`UPDATE followups SET status = 'Cancelled'
                      WHERE customer_phone = ?
                        AND staff_name = 'AI_DRIP'
                        AND status = 'Pending'`,
                [phone10], function(err) {
                    if (!err && this.changes > 0) {
                        console.log(`[DRIP] Cancelled ${this.changes} pending nudge(s) — ${phone10} replied`);
                    }
                });
        }
    } catch (e) { /* non-critical */ }
    // ─── Phase 1.5: Auto-Save Media Assets ───
    if (message.hasMedia) {
        try {
            const media = await message.downloadMedia();
            if (media) {
                const custDir = path.join(CUSTOMER_DOCS_DIR, phone);
                if (!fs.existsSync(custDir)) fs.mkdirSync(custDir, { recursive: true });
                
                const ext = media.mimetype.split('/')[1] || 'bin';
                const filename = `WA_ASSET_${Date.now()}.${ext}`;
                const fullPath = path.join(custDir, filename);
                
                fs.writeFileSync(fullPath, media.data, { encoding: 'base64' });
                console.log(`[ASSET AUTO-SAVE] Saved media from ${phone} to ${filename}`);

                // Update CRM: append filename to adhar field, mark last_interaction
                db.run(
                    `INSERT INTO customers (phone, adhar, last_interaction, status)
                     VALUES (?, ?, CURRENT_TIMESTAMP, 'Inquiry')
                     ON CONFLICT(phone) DO UPDATE SET
                       adhar = CASE WHEN adhar IS NULL OR adhar = '' THEN ? ELSE adhar || ', ' || ? END,
                       last_interaction = CURRENT_TIMESTAMP`,
                    [phone, filename, filename, filename],
                    (err) => { if (!err) console.log(`[CRM] Doc received from ${phone} saved to CRM`); }
                );
            }
        } catch (e) {
            console.error(`[ASSET ERROR] Failed to auto-save media from ${phone}: ${e.message}`);
        }
    }

    // ─── Payment Confirmation Detection ───────────────────────
    const paymentKeywords = ['paid', 'done', 'utr', 'screenshot', 'payment', 'transferred', 'gpay', 'phonepe', 'neft', 'paytm'];
    if (message.type === 'image' || paymentKeywords.some(kw => userMsg.includes(kw))) {
        handlePaymentConfirmation(phone, message); // non-blocking
    }

    // ─── Phase 2: Per-phone response dedup (8-second cooldown) ───
    // Prevents double-replies when WhatsApp delivers the same message twice in rapid succession.
    // Applied before admin command handling so replayed messages are dropped early.
    const now = Date.now();
    if (!message.fromMe) {
        const lastReply = lastGreeted[phone];
        if (lastReply && (now - lastReply) < 8000) {
            console.log(`[THROTTLE] ${phone} — skipped (${now - lastReply}ms since last reply)`);
            return;
        }
        lastGreeted[phone] = now;
    }
    const customer = checkCustomer(phone);


    // ─── Phase 0: Source Tracking ───
    if (userMsg.includes('[source:')) {
        const sourceMatch = message.body.match(/\[source:(\w+)\]/i);
        if (sourceMatch && sourceMatch[1]) {
            console.log(`[ANALYTICS] New Lead Origin detected: ${sourceMatch[1]}`);
            logSourceInterest(sourceMatch[1].toUpperCase());
        }
    }

    // ─── Phase 1: Custom Keyword Rules ───────────────────────
    // In ONLINE AI mode we want AI to handle ~99% of customer chats. So we
    // only honour the help/menu navigation triggers from keyword_rules.json
    // (they show a dynamic command list — AI shouldn't replicate that).
    // All other static templates are skipped so the message flows to Gemini.
    // In OFFLINE mode (or if AI repeatedly fails downstream) the runLocalFallback
    // path will still consult the full ruleset.
    try {
        const rulesPath = path.join(ROOT_DIR, 'keyword_rules.json');
        if (fs.existsSync(rulesPath)) {
            const rules = JSON.parse(fs.readFileSync(rulesPath, 'utf8'));
            const userMsgNoSpace = userMsg.replace(/\s+/g, '').toLowerCase();
            const aiOnline = (getBotSettings().ai_mode || 'online') !== 'offline';
            const NAV_TRIGGERS = new Set(['help', 'menu', 'உதவி', 'மெனு']);
            const matchedRule = rules.find(r => {
                const triggerLow = r.trigger.toLowerCase();
                const userMsgLow = userMsg.toLowerCase().trim();
                // Only trigger if message is EXACTLY the keyword, or if it's a very short message containing it
                const isExact = userMsgLow === triggerLow;
                const isShortMatch = userMsgLow.includes(triggerLow) && userMsg.length < 15;
                if (!(isExact || isShortMatch)) return false;
                // Online mode: skip static templates — let AI answer. Only honour navigation.
                if (aiOnline && !NAV_TRIGGERS.has(triggerLow)) return false;
                return true;
            });
            if (matchedRule) {
                console.log(`[KEYWORD] Rule matched: ${matchedRule.trigger}`);
                // Dynamic help menus for both English "Help" and Tamil "உதவி"
                const isTamilHelp = matchedRule.trigger === 'உதவி';
                const isEnglishHelp = matchedRule.trigger.toLowerCase() === 'help';
                if (isEnglishHelp || isTamilHelp) {
                    // Tanglish triggers (Latin script but Tamil-language responses)
                    const TANGLISH = new Set(['vilai', 'map venuma', 'loan venuma', 'ullam']);
                    const isEnglishRule = t => /^[a-zA-Z\s]+$/.test(t) && !TANGLISH.has(t.toLowerCase());
                    const menuRules = rules.filter(r => {
                        if (r.trigger.toLowerCase() === 'help' || r.trigger === 'உதவி') return false;
                        // English help: English triggers only; Tamil help: Tamil/Tanglish triggers only
                        return isTamilHelp ? !isEnglishRule(r.trigger) : isEnglishRule(r.trigger);
                    });
                    const lines = menuRules.map(r => {
                        const firstLine = r.response.split('\n')[0].replace(/[*_]/g, '').trim();
                        const desc = firstLine.length > 45 ? firstLine.slice(0, 45) + '…' : firstLine;
                        return `• *${r.trigger}* — ${desc}`;
                    }).join('\n');
                    const helpReply = isTamilHelp
                        ? `🤖 *உதவி மெனு*\n\nகீழ்வரும் வார்த்தைகளை அனுப்பலாம்:\n\n${lines}\n\nநேரடியாக கேள்விகள் கேட்கலாம்! 😊`
                        : `🤖 *Quick Help Menu*\n\nType any keyword below for instant info:\n\n${lines}\n\nOr just chat — I'm always here to help! 😊`;
                    await message.reply(helpReply);
                    return;
                }
                await message.reply(matchedRule.response);
                return;
            }
        }
    } catch (e) { console.error("Keyword rule error:", e); }

    try {
        const dataObjects = await getPlotsData();
        const availablePlotsForKeywords = dataObjects.filter(d => d.Status && d.Status.toLowerCase().includes('available'));
        const layoutNames = [...new Set(availablePlotsForKeywords.map(d => d.Layout || d.Layout_Name).filter(Boolean))];
        let dynamicWords = [];
        layoutNames.forEach(l => l.split(' ').forEach(w => { if (w.length > 3) dynamicWords.push(w.toLowerCase()) }));


        const realEstateKeywords = botSettings.business_keywords || ['plot', 'house', 'cent', 'price', 'rate', 'layout', 'location', 'details', 'available', 'sqft', 'map', 'brochure', 'loan', 'bank', 'finance', 'emi', 'call', 'time', 'morning', 'evening', 'afternoon', 'after', 'before', ' am', ' pm', 'visit', 'site', 'hi', 'hello', 'hai', 'interested', ...dynamicWords];
        const userMsgNoSpace = userMsg.replace(/\s+/g, '').toLowerCase();
        const isRealEstateInquiry = realEstateKeywords.some(keyword => {
            const kwNoSpace = keyword.replace(/\s+/g, '').toLowerCase();
            return userMsgNoSpace.includes(kwNoSpace);
        });
        // Recognized states where the bot is waiting for a specific response (avoids filtering out numbers/selections)
        const activeSteps = ['AI_EXPECTING_ANSWER', 'MENU', 'EXPECTING_ANSWER', 'AWAITING_CALL_TIME', 'DONE'];
        const isWaitingForResponse = activeSteps.includes(userStates[phone]?.step);

        const botId = client.info.wid._serialized;
        const isDirectToBot = (message.to === botId) || (message.from === botId);
        const isAdmin = await checkIfAdmin(message);

        // Refined Admin/Keyword Filter: 
        // 1. If it's an admin and talking to the bot, ALWAYS proceed.
        // 2. If it's a customer, ignore if it doesn't contain keywords AND we aren't waiting for a lead response
        const isBusinessMsg = isRealEstateInquiry || isWaitingForResponse || (isAdmin && isDirectToBot);

        console.log(`[DEBUG] isBusinessMsg: ${isBusinessMsg}, isAdmin: ${isAdmin}, isDirect: ${isDirectToBot}`);

        if (isAdmin && isDirectToBot) {
            console.log(`[ADMIN CHECK] User is ADMIN. Proceeding with interaction.`);
        } else if (!isBusinessMsg) {
            console.log(`[FILTER] Message ignored (Non-business)`);
            return;
        }

        console.log(`[PROCESS] Starting AI logic for ${phone}...`);

        const configPath = path.join(ROOT_DIR, 'bot_config.json');
        let aiMode = 'online';
        if (fs.existsSync(configPath)) {
            try {
                const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
                aiMode = cfg.aiMode || 'online';
            } catch (e) { }
        }

        if (aiMode === 'fallback') {
            console.log(`[FLOW] Admin forced Local Fallback Template.`);
            await runLocalFallback(message, phone, userMsg);
            return;
        }

        // ─── Smart Retry + Model Failover ─────────────────────────
        let aiResponse = null;
        let lastError = null;

        // [NEW] Offline/Local Mode Override
        if (botSettings && botSettings.ai_mode === 'offline') {
            console.log(`[OFFLINE] 🏠 Using local menu for ${phone}`);
            await runLocalFallback(message, phone, userMsg);
            return;
        }

        for (let attempt = 0; attempt < AI_MODELS.length; attempt++) {
            try {
                aiModel = getAiModel();
                if (process.send) process.send({ type: 'aiModel', data: AI_MODELS[currentModelIndex] });
                console.log(`[AI] Attempt ${attempt + 1}/${AI_MODELS.length} using model: ${AI_MODELS[currentModelIndex]}`);


                // Re-initialize chat history with current model if needed
                if (!chatHistories[phone] || attempt > 0) {
                    // Format DB data as a clean, readable list for the AI
                    const rawData = await getPlotsData();

                    // Fetch per-layout GPS from SQLite (most up-to-date — entered via dashboard)
                    const gpsRows = await new Promise(resolve =>
                        db.all(`SELECT DISTINCT layout_name, gps_location FROM plots WHERE gps_location IS NOT NULL AND gps_location != '' ORDER BY layout_name`, [], (e, r) => resolve(r || []))
                    );
                    const layoutGpsMap = {};
                    gpsRows.forEach(r => { if (r.layout_name) layoutGpsMap[r.layout_name.trim()] = r.gps_location; });

                    // Build per-layout price-per-cent range from available plots
                    const _lm = {};
                    rawData.forEach(r => {
                        const lyt = r.Layout_Name; if (!lyt) return;
                        const pr = parseFloat(r.Total_Price) || 0;
                        const sq = parseFloat(r.Area_SqFt) || 0;
                        const isAvail = (r.Status || '').toLowerCase().includes('available');
                        // GPS: prefer SQLite, fall back to Excel column
                        const gpsExcel = r.GPS_Location || r['GPS Location'] || r.GPS || '';
                        if (!_lm[lyt]) _lm[lyt] = { ppc: [], tot: [], avail: 0, all: 0, loc: r.Location || '', gps: layoutGpsMap[lyt.trim()] || gpsExcel };
                        else if (!_lm[lyt].gps && (layoutGpsMap[lyt.trim()] || gpsExcel)) _lm[lyt].gps = layoutGpsMap[lyt.trim()] || gpsExcel;
                        _lm[lyt].all++;
                        if (isAvail) {
                            _lm[lyt].avail++;
                            if (pr > 0 && sq > 0) { _lm[lyt].ppc.push((pr / sq) * 435.6); _lm[lyt].tot.push(pr); }
                        }
                    });
                    const layoutPriceRanges = Object.entries(_lm).map(([nm, d]) => {
                        const av = `${d.avail}/${d.all} plots`;
                        if (!d.ppc.length) return `- ${nm}: Contact for price | ${av} available${d.gps ? ' | GPS: ' + d.gps : ''}`;
                        const lo = Math.min(...d.ppc), hi = Math.max(...d.ppc);
                        const loS = (lo/100000).toFixed(2), hiS = (hi/100000).toFixed(2);
                        const pcStr = loS === hiS ? `₹${loS}L per cent` : `₹${loS}L – ₹${hiS}L per cent`;
                        return `- ${nm} (${d.loc}): ${pcStr} | ${av} available${d.gps ? ' | GPS: ' + d.gps : ''}`;
                    }).join('\n');

                    const liveData = rawData.map(r => {
                        const areaSqFt = parseFloat(r.Area_SqFt) || 0;
                        return `- Project: ${r.Layout_Name}, Plot: ${r.Plot_No || 'N/A'}, Area: ${areaSqFt} SqFt, Location: ${r.Location}, Status: ${r.Status}, Facing: ${r.Facing || 'N/A'}`;
                    }).join('\n');

                    const combinedPlotData = `LAYOUT PRICE RANGES (always use these when customer asks about price — each layout has a different rate):\n${layoutPriceRanges}\n\nINDIVIDUAL PLOT DETAILS:\n${liveData}`;
                    let initPrompt = getSystemPrompt().replaceAll('{PLOT_DATA}', combinedPlotData);

                    // [NEW] Load Project Knowledge from PDFs
                    const knowledgePath = path.join(ROOT_DIR, 'Project_Knowledge.txt');
                    let projectKnowledge = "";
                    if (fs.existsSync(knowledgePath)) {
                        projectKnowledge = fs.readFileSync(knowledgePath, 'utf8');
                    }
                    initPrompt = initPrompt.replaceAll('{PROJECT_KNOWLEDGE}', projectKnowledge);

                    // ── Lead Qualification Protocol ────────────────────────
                    initPrompt += `\n\n--- LEAD QUALIFICATION PROTOCOL ---
Before sharing detailed pricing, plot availability, brochures, or site visit arrangements, naturally gather these three things (ask one at a time):
1. Budget range (e.g., "5L-10L, 10L-20L, or above 20L?")
2. Preferred location or layout name
3. Purpose: Investment or Own Use
Once all three are collected, tag your response with: [PRE_QUALIFIED:budget=X,area=Y,purpose=Z]

PRICING RULE: When a customer asks about price, always quote the price-per-cent RANGE specific to the layout they are asking about (from LAYOUT PRICE RANGES above). Each layout has a different rate — never use a generic number. If they have not named a layout, ask which layout they are interested in before giving a price. Always say "starting from ₹X/cent" or "between ₹X–₹Y/cent" — never quote a single fixed plot price as the general rate.

ABSOLUTE PRICING RULE — NO TOTAL PRICES: Never mention total plot prices, total price ranges, "total ranges from X to Y", or any cumulative/lakhs-per-plot figure. Only ever quote the per-cent (per Cent) rate or a per-cent range. If the customer asks "what is the total price?" or "how much for the full plot?", reply: "Our team will share exact pricing on the call — can I arrange a quick call today?" This rule overrides everything else.`;

                    // ── Language Policy (English-only responses) ──────────
                    initPrompt += `\n\n--- LANGUAGE POLICY ---
You may RECEIVE messages in Tamil script (தமிழ்) or Tanglish (Tamil words in English letters, e.g. "plot venumaa?", "enna rate", "site visit pannalam"). Understand them and respond to what they mean.
But your REPLY must always be in clear, simple English. NEVER reply in Tamil or Tanglish — CRM records and follow-up sales calls are conducted in English, so consistent English replies keep the conversation thread useful for the sales team.`;

                    let historyBuilder = [
                        { role: "user", parts: [{ text: initPrompt }] },
                        { role: "model", parts: [{ text: "Understood. I will act as DRD Property Genius and analyze the chat context using the provided plot data and detailed brochure knowledge." }] }
                    ];

                    // Use in-memory session (last N turns from settings) — faster and more controlled than WhatsApp fetch.
                    // Skipped only if read_previous_messages is explicitly set to false in bot_settings.json.
                    const _readPrev = getBotSettings().read_previous_messages !== false;
                    const session = _readPrev ? sessionMemory.get(phone) : null;
                    if (session && session.messages.length > 0) {
                        for (const m of session.messages) {
                            const geminiRole = m.role === 'USER' ? 'user' : 'model';
                            const last = historyBuilder[historyBuilder.length - 1];
                            // Gemini requires strictly alternating roles — merge consecutive same-role messages
                            if (last && last.role === geminiRole) {
                                last.parts[0].text += '\n\n' + sanitizeForAI(m.text);
                            } else {
                                historyBuilder.push({ role: geminiRole, parts: [{ text: sanitizeForAI(m.text) }] });
                            }
                        }
                        console.log(`[AI] Using ${session.messages.length} in-memory context messages for ${phone}`);
                    } else if (_readPrev) {
                        // Load persistent context from DB — survives bot restarts, goes further back than WA fetch.
                        try {
                            const cleanPhone10 = phone.replace(/\D/g, '').slice(-10);

                            // 1. CRM profile for this customer
                            const crmRec = await new Promise(resolve =>
                                db.get(
                                    `SELECT name, plot, location, status, notes FROM customers
                                     WHERE REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-','') LIKE ?
                                     ORDER BY last_interaction DESC LIMIT 1`,
                                    [`%${cleanPhone10}`], (e, r) => resolve(r || null)
                                )
                            );

                            // 2. Last 12 conversation turns from DB (in chronological order)
                            const dbMsgs = await new Promise(resolve =>
                                db.all(
                                    `SELECT role, text FROM conversations
                                     WHERE phone LIKE ? AND text != '' AND LENGTH(text) > 2
                                     ORDER BY id DESC LIMIT 12`,
                                    [`%${cleanPhone10}`], (e, r) => resolve(r ? r.reverse() : [])
                                )
                            );

                            // Inject CRM profile as a system note so Gemini knows the returning customer
                            if (crmRec && (crmRec.name || crmRec.plot || crmRec.status)) {
                                const parts = [];
                                if (crmRec.name)     parts.push(`Name: ${crmRec.name}`);
                                if (crmRec.plot)     parts.push(`Previously interested in: ${crmRec.plot}`);
                                if (crmRec.status)   parts.push(`CRM status: ${crmRec.status}`);
                                if (crmRec.notes)    parts.push(`Notes: ${crmRec.notes}`);
                                const profileNote = `[RETURNING CUSTOMER PROFILE]\n${parts.join('\n')}\nAddress them by name if available. Pick up from where the last conversation left off.`;
                                historyBuilder.push({ role: 'user',  parts: [{ text: profileNote }] });
                                historyBuilder.push({ role: 'model', parts: [{ text: 'Understood. I have the customer profile and will continue from where we left off.' }] });
                            }

                            // Inject past turns — merge consecutive same-role messages (Gemini requires strict alternation)
                            for (const m of dbMsgs) {
                                const geminiRole = (m.role || '').toUpperCase() === 'USER' ? 'user' : 'model';
                                const last = historyBuilder[historyBuilder.length - 1];
                                if (last && last.role === geminiRole) {
                                    last.parts[0].text += '\n\n' + sanitizeForAI(m.text);
                                } else {
                                    historyBuilder.push({ role: geminiRole, parts: [{ text: sanitizeForAI(m.text) }] });
                                }
                            }

                            if (crmRec || dbMsgs.length > 0) {
                                console.log(`[AI] Loaded ${dbMsgs.length} DB history turns + CRM profile for ${phone}`);
                            }
                        } catch (histErr) {
                            console.log('[AI] Could not load DB context:', histErr.message);
                            // Fallback: try WhatsApp fetch
                            try {
                                const chatObj = await message.getChat();
                                const pastMsgs = await chatObj.fetchMessages({ limit: 10 });
                                for (const pMsg of pastMsgs) {
                                    if (pMsg.id.id !== message.id.id && pMsg.body) {
                                        historyBuilder.push({ role: pMsg.fromMe ? 'model' : 'user', parts: [{ text: sanitizeForAI(pMsg.body) }] });
                                    }
                                }
                            } catch (_) {}
                        }
                    }

                    chatHistories[phone] = aiModel.startChat({ history: historyBuilder });
                }

                const chat = chatHistories[phone];
                const result = await chat.sendMessage(sanitizeForAI(message.body));
                aiResponse = result.response.text();
                console.log(`[AI] ✅ Response received from ${AI_MODELS[currentModelIndex]}`);

                // Track usage in Excel CRM
                logAIUsageToExcel(AI_MODELS[currentModelIndex]);

                break; // Success — exit retry loop

            } catch (retryErr) {
                lastError = retryErr;
                const errMsg = retryErr.message || '';
                const errorLog = `[${new Date().toISOString()}] AI Error (Model: ${AI_MODELS[currentModelIndex]}): ${errMsg}\n\n`;
                try { fs.appendFileSync(path.join(ROOT_DIR, 'scratch', 'ai_debug.log'), errorLog); } catch (err) { }

                console.log(`[AI] ❌ Model ${AI_MODELS[currentModelIndex]} failed: ${errMsg.substring(0, 80)}`);

                // Move to next backup model
                currentModelIndex = (currentModelIndex + 1) % AI_MODELS.length;

                if (attempt < AI_MODELS.length - 1) {
                    console.log(`[AI] ⏳ Waiting 3s before trying backup model: ${AI_MODELS[currentModelIndex]}...`);
                    await new Promise(r => setTimeout(r, 3000));
                }
            }
        }

        // If all models failed: wait 30s and retry once before local fallback
        if (!aiResponse) {
            console.log(`[AI] ⏳ All ${AI_MODELS.length} models failed. Waiting 30s before final retry...`);
            await new Promise(r => setTimeout(r, 30000));
            currentModelIndex = 0;
            try {
                aiModel = getAiModel();
                chatHistories[phone] = null; // force fresh context on retry
                const retryRaw = await getPlotsData();
                const _rm = {};
                retryRaw.forEach(r => {
                    const lyt = r.Layout_Name; if (!lyt) return;
                    const pr = parseFloat(r.Total_Price) || 0, sq = parseFloat(r.Area_SqFt) || 0;
                    const isAvail = (r.Status || '').toLowerCase().includes('available');
                    if (!_rm[lyt]) _rm[lyt] = { ppc: [], tot: [], avail: 0, all: 0 };
                    _rm[lyt].all++;
                    if (isAvail && pr > 0 && sq > 0) { _rm[lyt].ppc.push((pr/sq)*435.6); _rm[lyt].tot.push(pr); _rm[lyt].avail++; }
                });
                const retryRanges = Object.entries(_rm).map(([nm, d]) => {
                    if (!d.ppc.length) return `- ${nm}: Contact for price`;
                    const lo = Math.min(...d.ppc), hi = Math.max(...d.ppc);
                    const loS = (lo/100000).toFixed(2), hiS = (hi/100000).toFixed(2);
                    const pcStr = loS === hiS ? `₹${loS}L per cent` : `₹${loS}L – ₹${hiS}L per cent`;
                    return `- ${nm}: ${pcStr} | ${d.avail}/${d.all} available`;
                }).join('\n');
                const retryData = retryRaw.map(r => {
                    const sq = parseFloat(r.Area_SqFt) || 0;
                    return `- Project: ${r.Layout_Name}, Plot: ${r.Plot_No || 'N/A'}, Area: ${sq} SqFt, Status: ${r.Status}`;
                }).join('\n');
                let retryPrompt = getSystemPrompt()
                    .replaceAll('{PLOT_DATA}', `LAYOUT PRICE RANGES:\n${retryRanges}\n\nINDIVIDUAL PLOTS:\n${retryData}`)
                    .replaceAll('{PROJECT_KNOWLEDGE}', '');
                chatHistories[phone] = aiModel.startChat({ history: [
                    { role: "user", parts: [{ text: retryPrompt }] },
                    { role: "model", parts: [{ text: "Understood." }] }
                ]});
                const retryResult = await chatHistories[phone].sendMessage(sanitizeForAI(message.body));
                aiResponse = retryResult.response.text();
                logAIUsageToExcel(AI_MODELS[0]);
                console.log('[AI] ✅ 30s retry succeeded.');
            } catch (retryFinalErr) {
                console.log(`[FALLBACK] ❌ Final retry failed: ${retryFinalErr.message?.substring(0, 80)}`);
            }
        }

        if (!aiResponse) {
            console.log(`[FALLBACK] ❌ All retries exhausted. Using Local Fallback Template...`);
            await runLocalFallback(message, phone, userMsg);
            return;
        }

        // Context Awareness Check: Did the AI detect this as an office/personal chat?
        if (aiResponse.includes('[IGNORE_MSG]')) {
            console.log(`[AI] 🛑 Ignoring message from ${phone} (Office/Personal Conversation Context Detected)`);
            return;
        }

        console.log(`[AI] Raw response: ${aiResponse.substring(0, 50)}...`);

        const imageMatch = aiResponse.match(/\[SEND_IMAGE:\s*(.*?)\]/i);
        let layoutName = null;
        if (imageMatch) {
            layoutName = imageMatch[1].trim();
            aiResponse = aiResponse.replace(imageMatch[0], '').trim();
        }

        // Parse [PRE_QUALIFIED:budget=X,area=Y,purpose=Z] tag
        const qualMatch = aiResponse.match(/\[PRE_QUALIFIED:([^\]]+)\]/i);
        if (qualMatch) {
            const params = {};
            qualMatch[1].split(',').forEach(p => {
                const [k, v] = p.split('=');
                if (k && v) params[k.trim()] = v.trim();
            });
            const phone10 = phone.replace(/\D/g, '').slice(-10);
            db.run(`UPDATE customers SET status = 'Pre-Qualified', loan_details = ? WHERE phone = ?`,
                [JSON.stringify(params), phone10]);
            console.log(`[QUALIFY] Lead ${phone} pre-qualified: ${qualMatch[1]}`);
            aiResponse = aiResponse.replace(qualMatch[0], '').trim();

            // ── Queue 1d/3d/7d drip rows (once per lead) ────────────────
            // Each row is a placeholder. The sweeper picks them up when
            // next_followup <= today, asks Gemini to craft a context-aware
            // site-visit nudge from the conversation, sends, and marks Sent.
            try {
                const existing = await new Promise(r =>
                    db.get(`SELECT id FROM followups WHERE customer_phone = ? AND staff_name = 'AI_DRIP' LIMIT 1`,
                        [phone10], (e, row) => r(row || null)));
                if (!existing) {
                    const stages = [
                        { tag: 'drip_d1', days: 1 },
                        { tag: 'drip_d3', days: 3 },
                        { tag: 'drip_d7', days: 7 }
                    ];
                    for (const s of stages) {
                        db.run(
                            `INSERT INTO followups (customer_phone, staff_name, notes, next_followup, status)
                             VALUES (?, 'AI_DRIP', ?, date('now','+' || ? || ' days'), 'Pending')`,
                            [phone10, s.tag, s.days]);
                    }
                    console.log(`[DRIP] Queued 1d/3d/7d sequence for ${phone10}`);
                }
            } catch (dripErr) { console.warn('[DRIP] Queue failed:', dripErr.message); }
        }

        if (aiResponse) {
            // Check for tags from AI
            let isHighlighted = false;
            if (aiResponse.includes('[HIGHLIGHT]')) {
                aiResponse = aiResponse.replace('[HIGHLIGHT]', '').trim();
                isHighlighted = true;
                console.log(`[CRM] Lead ${phone} HIGHLIGHTED (High Intent)`);
            }
            if (aiResponse.includes('[REQUEST_CALL]')) {
                aiResponse = aiResponse.replace('[REQUEST_CALL]', '').trim();
                isHighlighted = true; // Call request always highlights
                console.log(`[ALERT] Call requested by ${phone}`);
                const staff = getMasterData('Staff');
                const md = staff.find(s => s.Dept === 'Managing Director');
                if (md && process.send) {
                    process.send({ type: 'send_otp', data: { otp: `📞 CALL REQUEST from ${phone}`, adminPhone: String(md.Phone) } });
                }
            }

            await message.reply(aiResponse);
            await logConversation(phone, 'BOT', aiResponse, message);
            updateSessionMemory(phone, 'MODEL', aiResponse);

            // Trigger AI Lead Scoring asynchronously
            analyzeAndScoreLead(phone);

            // ─── Auto-send visualizer URL after customer states requirements ─
            // Trigger: AI marked this conversation as PRE_QUALIFIED (budget /
            // area / purpose collected). Sent at most once per session.
            // Skip for admin/office numbers — they already have the dashboard.
            try {
                if (qualMatch
                    && !isAdmin
                    && !userStates[phone]?.visualizerSent) {
                    const vizUrl = (getBotSettings().visualizer_url || '').trim();
                    if (vizUrl) {
                        await new Promise(r => setTimeout(r, 1200));
                        await client.sendMessage(phone,
                            `🗺️ Based on what you've shared, here's our interactive site visualizer — explore every available plot with live pricing:\n\n${vizUrl}\n\nReply *site visit* if you'd like to schedule a visit, or ask me anything else!`);
                        updateSessionMemory(phone, 'BOT', `🗺️ Visualizer: ${vizUrl}`);
                        userStates[phone] = userStates[phone] || {};
                        userStates[phone].visualizerSent = true;
                        console.log(`[VIZ] Auto-sent visualizer to ${phone} (pre-qualified)`);
                    }
                }
            } catch (vizErr) { console.error('[VIZ] Auto-send failed:', vizErr.message); }

            // Auto-share location + visualizer when customer asks about location/map
            const locationTriggers = ['location', 'where is', 'where are', 'map', 'address', 'how to reach', 'how to come', 'directions', 'direction', 'navigate', 'route', 'gps', 'எங்கே', 'எங்க'];
            const isLocationQuery = botSettings.location_auto_share !== false &&
                locationTriggers.some(kw => userMsg.includes(kw));
            if (isLocationQuery) {
                try {
                    loadCompanySettings();
                    const vizUrl = botSettings.visualizer_url || 'https://drdrealtors.github.io/drd-layouts/';
                    await new Promise(r => setTimeout(r, 800));

                    // Try to share the GPS of the specific layout the customer is asking about
                    const lastLayout = userStates[phone]?.lastLayout;
                    let layoutGpsLink = '';
                    if (lastLayout) {
                        const gpsRow = await new Promise(resolve =>
                            db.get(`SELECT gps_location FROM plots WHERE layout_name = ? AND gps_location IS NOT NULL AND gps_location != '' LIMIT 1`,
                                [lastLayout], (e, r) => resolve(r || null))
                        );
                        if (gpsRow) layoutGpsLink = gpsRow.gps_location;
                    }

                    if (layoutGpsLink) {
                        // Layout-specific GPS found — send it
                        await client.sendMessage(phone, `📍 *${lastLayout} — Site Location:*\n${layoutGpsLink}`);
                        updateSessionMemory(phone, 'BOT', `📍 ${lastLayout} GPS: ${layoutGpsLink}`);
                    } else {
                        // Fall back to company-level maps URL
                        const mapsUrl = companySettings.mapsUrl || 'https://maps.app.goo.gl/7oKNZgKzV6oop1vlh';
                        await client.sendMessage(phone, `📍 *Our Location:*\n${mapsUrl}`);
                        updateSessionMemory(phone, 'BOT', `📍 Location: ${mapsUrl}`);
                    }

                    await new Promise(r => setTimeout(r, 600));
                    await client.sendMessage(phone, `🗺️ *View All Our Layouts Online:*\n${vizUrl}`);
                    if (chatHistories[phone]) delete chatHistories[phone];
                    console.log(`[LOCATION] Auto-shared ${layoutGpsLink ? lastLayout + ' GPS' : 'company maps'} + visualizer to ${phone}`);
                } catch (locErr) {
                    console.error('[LOCATION] Failed to send location/visualizer:', locErr.message);
                }
            }

            // ── Auto-send VCF contact card at conversation closing point ──
            // Sent once per session when bot mentions a call/visit/team follow-up
            if (!isAdmin && !userStates[phone]?.contactCardSent) {
                const closingSignal = /(?:our team will|team will (?:call|contact|reach)|call you|arrange a (?:quick )?call|schedule a (?:call|visit|site visit)|site visit|get back to you|reach out to you|connect with you|thank you for your interest|good time for.*(?:call|visit))/i.test(aiResponse);
                if (closingSignal) {
                    try {
                        await new Promise(r => setTimeout(r, 1500));
                        await sendContactVCF(phone);
                        userStates[phone] = userStates[phone] || {};
                        userStates[phone].contactCardSent = true;
                    } catch (vcfErr) { console.error('[VCF] Auto-trigger error:', vcfErr.message); }
                }
            }

            // [PROACTIVE LEAD CAPTURE]
            const contact = await message.getContact();
            logInquiryToExcel(contact.number || phone, {
                name: contact.pushname || contact.name || "Customer",
                layout: userStates[phone]?.lastLayout || "Inquiry",
                budget: "Talking...",
                lastMsg: message.body,
                highlighted: isHighlighted ? 1 : 0
            });
        }

        if (userStates[phone]?.step === 'AI_EXPECTING_ANSWER') {
            await sendTaglineImage(phone, client);
            userStates[phone].step = 'DONE';
        }

        if (layoutName) {
            try {
                userStates[phone] = userStates[phone] || {};
                userStates[phone].lastLayout = layoutName;
                let targetResult = findVisualForLayout(layoutName, IMAGES_DIR) || findVisualForLayout(layoutName, path.join(IMAGES_DIR, '01 All Layouts'));
                if (targetResult) {
                    if (targetResult.type === 'directory') {
                        for (const file of targetResult.files) {
                            try {
                                if (client && client.pupPage && !client.pupPage.isClosed()) {
                                    const fullPath = path.join(targetResult.path, file);
                                    if (fs.existsSync(fullPath) && fs.lstatSync(fullPath).isFile()) {
                                        const media = MessageMedia.fromFilePath(fullPath);
                                        await client.sendMessage(phone, media);
                                        await new Promise(r => setTimeout(r, 1500));
                                    }
                                }
                            } catch (err) { console.error(`[MEDIA ERROR] Failed to send ${file}:`, err.message); }
                        }
                    } else {
                        try {
                            if (client && client.pupPage && !client.pupPage.isClosed()) {
                                if (fs.existsSync(targetResult.path) && fs.lstatSync(targetResult.path).isFile()) {
                                    const media = MessageMedia.fromFilePath(targetResult.path);
                                    await client.sendMessage(phone, media);
                                }
                            }
                        } catch (err) { console.error('[MEDIA ERROR] Failed to send single media:', err.message); }
                    }
                    userStates[phone].step = 'AI_EXPECTING_ANSWER';
                    try {
                        await client.sendMessage(phone, `(MAP) Site Plan: ${(botSettings.visualizer_url || 'https://drdrealtors.github.io/drd-layouts/')}`);
                    } catch (err) { console.error('[MEDIA ERROR] Failed to send MAP URL:', err.message); }
                }
            } catch (mediaErr) {
                console.error('[MEDIA BLOCK ERROR] Image send block failed:', mediaErr.message);
                // Isolated — does not cascade to runLocalFallback
            }
        }
    } catch (e) {
        // Unexpected critical error
        const errorLog = `[${new Date().toISOString()}] CRITICAL Error: ${e.message}\nStack: ${e.stack}\n\n`;
        try { fs.appendFileSync(path.join(ROOT_DIR, 'scratch', 'ai_debug.log'), errorLog); } catch (err) { }
        console.error(`[CRITICAL] Unexpected error: ${e.message}`);
        await runLocalFallback(message, phone, userMsg);
    }
});

async function generateSystemReport() {
    let leadsCount = 0, aiTotal = 0, crashCount = 0;
    try {
        leadsCount = await new Promise(r => db.get(`SELECT COUNT(*) AS c FROM customers`, [], (e, row) => r(row ? row.c : 0)));
        aiTotal = await new Promise(r => db.get(`SELECT COALESCE(SUM(requests),0) AS t FROM ai_usage`, [], (e, row) => r(row ? row.t : 0)));
        const crashPath = path.join(ROOT_DIR, 'CRASH_REPORT_BOT.txt');
        if (fs.existsSync(crashPath)) crashCount = (fs.readFileSync(crashPath, 'utf8').match(/\[CRASH\]/g) || []).length;
    } catch (e) { }

    return `📊 *DRD SYSTEM QUICK STATUS*
---------------------------------------
🟢 Status: ONLINE
📑 Total Leads: ${leadsCount}
🤖 AI Requests: ${aiTotal}
❌ System Crashes: ${crashCount}
---------------------------------------
_Property Genius Active_`;
}

async function generateDetailedReport() {
    const uptime = Math.floor((Date.now() - BOT_START_TIME_MS) / 3600000);
    const today = new Date().toLocaleDateString('en-GB');
    
    let totalLeadsToday = 0;
    let highIntentLeads = 0;
    let topLayout = "General Interest";
    const layoutCounts = {};

    try {
        const leads = await new Promise((resolve) => {
            db.all(`SELECT * FROM customers WHERE created_at >= date('now', 'start of day')`, [], (err, rows) => resolve(rows || []));
        });
        totalLeadsToday = leads.length;
        highIntentLeads = leads.filter(l => l.highlighted === 1).length;

        leads.forEach(l => {
            if (l.plot) layoutCounts[l.plot] = (layoutCounts[l.plot] || 0) + 1;
        });
        
        const top = Object.entries(layoutCounts).sort((a,b) => b[1] - a[1])[0];
        if (top) topLayout = top[0];

    } catch (e) { console.error("Report Generation Error:", e); }

    const status = client.info ? "🟢 ONLINE" : "🔴 OFFLINE";

    return `📊 *DRD SYSTEM AUDIT REPORT* (${today})
---------------------------------------
🤖 Bot Status: ${status}
⏱️ Uptime: ${uptime} Hours
👥 New Leads Today: ${totalLeadsToday}
🔥 High Intent Leads: ${highIntentLeads}
📍 Hot Layout: ${topLayout}
🤖 AI Failover: ${currentModelIndex > 0 ? "⚠️ ACTIVE" : "✅ STABLE"}
🧠 Memory: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB
---------------------------------------
_Audit ID: ${Date.now().toString(36).toUpperCase()}_`;
}


const BOT_START_TIME_MS = Date.now();

process.on('message', async (msg) => {
    if (msg.type === 'selftest_ping') {
        if (process.send) {
            process.send({
                type: 'selftest_pong',
                requestId: msg.requestId,
                data: { ok: true, uptime: Math.floor(process.uptime()), pid: process.pid }
            });
        }
        return;
    }

    if (msg.type === 'fetch_eb_bill') {
        const { serviceNo, region, requestId } = msg;
        console.log(`[BOT] EB Fetch Request: ServiceNo=${serviceNo}, Region=${region}`);
        
        let browser;
        try {
            const puppeteer = require('puppeteer');
            browser = await puppeteer.launch({
                headless: "new",
                executablePath: executablePath,
                args: ['--no-sandbox', '--disable-setuid-sandbox']
            });
            const page = await browser.newPage();
            
            // TANGEDCO Bill Status Page
            await page.goto('https://www.tangedco.org/en/tangedco/consumer-services/bill-status/', { waitUntil: 'networkidle2', timeout: 30000 });
            
            // Fill form
            await page.select('#region', region);
            await page.type('#consumerNo', serviceNo);
            
            // Note: TANGEDCO often has a captcha. If so, we might need a workaround or user intervention.
            // For now, let's try to submit if no captcha is present or if it's bypassable.
            // Many gov sites are hard to scrape due to captcha.
            
            await Promise.all([
                page.click('#submit'),
                page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 })
            ]);

            // Extract data
            const data = await page.evaluate(() => {
                const rows = Array.from(document.querySelectorAll('table tr'));
                const result = { ok: true };
                rows.forEach(row => {
                    const text = row.innerText;
                    if (text.includes('Total Amount')) result.amount = text.split(':').pop().trim();
                    if (text.includes('Due Date')) result.dueDate = text.split(':').pop().trim();
                    if (text.includes('Status')) result.status = text.split(':').pop().trim();
                });
                return result;
            });

            if (process.send) {
                process.send({ type: 'eb_bill_res', requestId, data });
            }
        } catch (e) {
            console.error('[BOT] EB Fetch Failed:', e.message);
            if (process.send) {
                process.send({ type: 'eb_bill_res', requestId, data: { ok: false, msg: "Failed to fetch from TANGEDCO. Captcha or site change might be blocking." } });
            }
        } finally {
            if (browser) await browser.close();
        }
        return;
    }

    if (msg.type === 'focus_whatsapp') {
        console.log(`[BOT] Focus request received. Bringing WhatsApp window to front...`);
        try {
            const page = await client.pupPage;
            if (page) {
                await page.bringToFront();
                console.log(`[BOT] Page brought to front successfully.`);
            } else {
                console.log(`[BOT] Puppeteer page not found, cannot focus.`);
            }
        } catch (err) {
            console.error(`[BOT] Failed to focus window: ${err.message}`);
        }
        return;
    }
    if (msg.type === 'request_legal_approval') {
        const { docId, adminPhone, fileName, plotInfo } = msg.data;
        const target = adminPhone.includes('@') ? adminPhone : `${adminPhone}@c.us`;
        const docPath = path.join(ROOT_DIR, 'legal_docs', fileName);
        
        console.log(`[LEGAL] Requesting approval for DocID=${docId} from ${target}`);
        
        try {
            if (fs.existsSync(docPath)) {
                const media = MessageMedia.fromFilePath(docPath);
                await client.sendMessage(target, media);
            }
            
            const text = `⚖️ *LEGAL DOCUMENT APPROVAL REQUEST*\n\n` +
                         `Plot: ${plotInfo}\n` +
                         `Document: ${fileName}\n\n` +
                         `Please reply with:\n` +
                         `✅ *Approve ${docId}*\n` +
                         `❌ *Reject ${docId}*`;
            
            await client.sendMessage(target, text);
            console.log(`[LEGAL] Approval request sent to ${target}`);
        } catch (err) {
            console.error(`[LEGAL] FAILED to send approval request: ${err.message}`);
        }
        return;
    }

    
        if (msg.type === 'send_pdf_quotation') {
            const { target, htmlPath, filename, caption, jobId } = msg.data;
            console.log(`[QUOTATION] Generating PDF from ${htmlPath} for ${target}`);

            let pdfBrowser = null;
            let page = null;
            try {
                // Use puppeteer-core with the same Chrome that WhatsApp already downloaded.
                // We MUST use a separate browser instance — sharing client.pupBrowser causes
                // file:/// security blocks and corrupts the WhatsApp session page context.
                const puppeteerCore = require('puppeteer-core');

                // Get the Chrome executable path from the running WhatsApp browser process
                const execPath = client.pupBrowser?.process()?.spawnfile
                    || client.pupBrowser?.executablePath?.()
                    || null;

                if (!execPath) throw new Error('Could not find Chrome executable from WhatsApp bot');

                pdfBrowser = await puppeteerCore.launch({
                    executablePath: execPath,
                    headless: true,
                    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage',
                           '--disable-web-security', '--allow-file-access-from-files']
                });

                page = await pdfBrowser.newPage();
                page.setDefaultTimeout(30000);

                const fileUrl = 'file:///' + htmlPath.replace(/\\/g, '/');
                await page.goto(fileUrl, { waitUntil: 'networkidle0', timeout: 30000 });

                // page.pdf() returns Uint8Array in newer Chromium — Buffer.from() handles both
                const pdfResult = await page.pdf({
                    format: 'A4',
                    printBackground: true,
                    margin: { top: '10mm', bottom: '10mm', left: '10mm', right: '10mm' }
                });
                const base64Pdf = Buffer.from(pdfResult).toString('base64');

                const media = new MessageMedia('application/pdf', base64Pdf, filename || 'Quotation.pdf');
                const msgCaption = caption || `📄 *Price Quotation*\n\nPlease find your property quotation from *DRD Realtors* attached.\n\nFor queries, contact us anytime. Thank you! 🙏`;
                await client.sendMessage(target, media, { caption: msgCaption });
                console.log(`[QUOTATION] PDF successfully sent to ${target}`);

                if (fs.existsSync(htmlPath)) fs.unlinkSync(htmlPath);
                if (jobId && process.send) process.send({ type: 'pdf_done', jobId, ok: true, target });
            } catch (err) {
                console.error(`[QUOTATION ERROR] ${err.message}`);
                if (jobId && process.send) process.send({ type: 'pdf_done', jobId, ok: false, error: err.message, target });
                if (htmlPath && fs.existsSync(htmlPath)) { try { fs.unlinkSync(htmlPath); } catch(e){} }
            } finally {
                // Close only the PDF browser — NEVER touch client.pupBrowser (WhatsApp session)
                if (page)       await page.close().catch(() => {});
                if (pdfBrowser) await pdfBrowser.close().catch(() => {});
            }
            return;
        }

        if (msg.type === 'send_otp') {
        const { otp, adminPhone } = msg.data;
        const target = adminPhone.includes('@') ? adminPhone : `${adminPhone}@c.us`;
        console.log(`[AUTH] Attempting to send OTP to ${target}...`);
        try {
            await client.sendMessage(target, `🔐 *DRD DEVELOPER AUTH*\n\nYour One-Time Password is: *${otp}*\n\nValid for 5 minutes. Do not share this code.`);
            console.log(`[AUTH] OTP successfully sent to ${target}`);
        } catch (err) {
            console.error(`[AUTH] FAILED to send OTP: ${err.message}`);
        }
        return;
    }
    if (msg.type === 'send_password_otp') {
        const { otp, phone, name, ackId } = msg.data;
        // Normalize: digits-only, prepend 91 for 10-digit Indian mobiles
        let target;
        if (phone && phone.includes('@')) {
            target = phone;
        } else {
            let digits = String(phone || '').replace(/\D/g, '');
            if (digits.length === 10) digits = '91' + digits;
            target = `${digits}@c.us`;
        }
        console.log(`[AUTH] Sending password reset OTP to ${target}...`);
        const ack = (ok, error) => {
            if (ackId && process.send) process.send({ type: 'password_otp_result', data: { ackId, ok, error } });
        };
        try {
            // Confirm the number is actually registered on WhatsApp before sending
            const isReg = await client.isRegisteredUser(target).catch(() => null);
            if (isReg === false) {
                console.error(`[AUTH] OTP delivery failed: ${target} is not a WhatsApp user`);
                return ack(false, 'Not a WhatsApp user');
            }
            await client.sendMessage(target,
                `🔑 *DRD Property Genius*\n\nHi ${name || 'there'},\n\nYour password reset OTP is: *${otp}*\n\nValid for 5 minutes. Do not share this code.\n\n_DRD Realtors_`);
            console.log(`[AUTH] Password reset OTP sent to ${target}`);
            ack(true);
        } catch (err) {
            console.error(`[AUTH] Failed to send password reset OTP: ${err.message}`);
            ack(false, err.message);
        }
        return;
    }
    if (msg.type === 'send_admin_report') {
        const { adminPhone } = msg.data;
        const target = adminPhone.includes('@') ? adminPhone : `${adminPhone}@c.us`;
        console.log(`[AUTH] Attempting to dispatch Admin Report to ${target}...`);
        try {
            const report = await generateSystemReport();
            await client.sendMessage(target, report);
            console.log(`[AUTH] Admin Report successfully sent to ${target}`);
        } catch (err) {
            console.error(`[AUTH] FAILED to dispatch Report: ${err.message}`);
        }
        return;
    }
    if (msg.type === 'send_plot_share' || msg.type === 'send_whatsapp') {
        const { target, text, mediaPaths } = msg.data;
        const jid = formatJid(target);
        
        if (!client.info) {
            console.error(`[SEND] FAILED: Bot not logged in. Cannot send to ${jid}`);
            if (process.send) process.send({ type: 'share_error', target: jid, msg: 'WhatsApp Bot not logged in / connected.' });
            return;
        }

        console.log(`[SEND] Dispatching to ${jid}. Media items: ${mediaPaths?.length || 0}`);
        try {
            // 1. Send Text
            if (text) {
                await client.sendMessage(jid, text);
                // Track admin-sent messages so the AI retains context when customer replies
                const rPhone = jid.replace('@c.us', '').replace(/\D/g, '');
                if (rPhone) {
                    updateSessionMemory(rPhone, 'BOT', text);
                    if (chatHistories[rPhone]) delete chatHistories[rPhone]; // force rebuild with updated context
                }
            }

            // 2. Send Media
            if (mediaPaths && Array.isArray(mediaPaths)) {
                for (const p of mediaPaths) {
                    if (fs.existsSync(p)) {
                        if (client.pupPage && !client.pupPage.isClosed()) {
                            const media = MessageMedia.fromFilePath(p);
                            // Ensure filename is preserved for documents
                            if (p.toLowerCase().endsWith('.pdf')) {
                                media.filename = path.basename(p);
                                media.mimetype = 'application/pdf';
                            }
                            await client.sendMessage(jid, media);
                            console.log(`[SEND] Media file sent: ${path.basename(p)}`);
                        }
                    } else {
                        console.error(`[SEND] Media file missing at path: ${p}`);
                    }
                }
            }
            console.log(`[SEND] Batch successfully sent to ${jid}`);
            if (process.send) process.send({ type: 'share_success', target: jid });
        } catch (err) {
            console.error(`[SEND] FAILED to send to ${jid}: ${err.message}`);
            if (process.send) process.send({ type: 'share_error', target: jid, msg: err.message });
        }
        return;
    }


    if (msg.type === 'get_chat_history') {
        const { phone, requestId } = msg.data;
        const jid = formatJid(phone);
        try {
            const chat = await client.getChatById(jid);
            const msgs = await chat.fetchMessages({ limit: 25 });
            const messages = msgs.map(m => ({
                body: m.body || '',
                fromMe: m.fromMe,
                timestamp: m.timestamp,
                type: m.type,
                hasMedia: m.hasMedia,
                author: m.fromMe ? 'DRD Bot' : (m.notifyName || phone)
            }));
            if (process.send) process.send({ type: 'chat_history_response', requestId, messages });
        } catch (err) {
            console.error(`[CHAT HISTORY] Failed for ${jid}: ${err.message}`);
            if (process.send) process.send({ type: 'chat_history_response', requestId, messages: [], error: err.message });
        }
        return;
    }

    if (msg.type === 'reload_settings') {
        console.log("[BOT] Reloading Company Settings...");
        loadCompanySettings();
        return;
    }


    if (msg.type === 'send_notification') {
        const { phone: notifPhone, message: notifMsg } = msg;
        const jid = notifPhone.includes('@') ? notifPhone : `${notifPhone}@c.us`;
        try {
            await client.sendMessage(jid, notifMsg);
            // Track in session so AI has context when customer replies
            const rPhone = notifPhone.replace(/\D/g, '');
            if (rPhone) {
                updateSessionMemory(rPhone, 'BOT', notifMsg);
                if (chatHistories[rPhone]) delete chatHistories[rPhone];
            }
            console.log(`[NOTIF] ✅ Sent notification to ${notifPhone}`);
            if (process.send) process.send({ type: 'notif_sent', phone: notifPhone, ok: true });
        } catch (e) {
            console.error(`[NOTIF] ❌ Failed for ${notifPhone}: ${e.message}`);
            if (process.send) process.send({ type: 'notif_sent', phone: notifPhone, ok: false, err: e.message });
        }
        return;
    }

    if (msg.type === 'broadcast') {
        const content = msg.data;
        console.log(`[BROADCAST] Starting campaign: "${content.substring(0, 30)}..."`);

        try {
            const rows = await new Promise((resolve, reject) =>
                db.all(`SELECT DISTINCT phone FROM customers WHERE phone IS NOT NULL AND phone != ''`, [], (err, r) => err ? reject(err) : resolve(r || []))
            );
            const uniqueNumbers = rows.map(r => String(r.phone).replace(/\D/g, ''));
            console.log(`[BROADCAST] Found ${uniqueNumbers.length} unique targets.`);

            for (let num of uniqueNumbers) {
                try {
                    if (num.length < 10) continue;
                    const jid = num.includes('@c.us') ? num : `${num}@c.us`;
                    await client.sendMessage(jid, content);
                    console.log(`[BROADCAST] Sent to ${num}`);
                    // Safety delay: 1.5 seconds per message to avoid ban
                    await new Promise(r => setTimeout(r, 1500));
                } catch (e) {
                    console.error(`[BROADCAST] Failed for ${num}:`, e.message);
                }
            }
            console.log(`[BROADCAST] Campaign completed.`);
        } catch (e) {
            console.error("[BROADCAST] Error in campaign thread:", e);
        }
    }
});

// ─── SCHEDULED MESSAGES PROCESSOR ────────────────────
async function scheduleDripCampaigns(phone) {
    console.log(`[DRIP] Scheduling campaigns for new lead: ${phone}`);
    db.all(`SELECT * FROM drip_campaigns WHERE is_active = 1`, [], (err, campaigns) => {
        if (err || !campaigns) return;
        
        campaigns.forEach(c => {
            const scheduledDate = new Date();
            scheduledDate.setDate(scheduledDate.getDate() + (c.days_offset || 0));
            const dateStr = scheduledDate.toISOString().split('T')[0];

            // Only schedule if not already pending for this phone+campaign to prevent duplicates
            db.get(`SELECT id FROM scheduled_messages WHERE customer_phone = ? AND campaign_id = ? AND status = 'Pending'`,
                [phone, c.id], (err2, existing) => {
                    if (existing) return;
                    db.run(
                        `INSERT INTO scheduled_messages (customer_phone, campaign_id, message_text, media_path, scheduled_date, status)
                         VALUES (?, ?, ?, ?, ?, 'Pending')`,
                        [phone, c.id, c.message_text, c.media_path, dateStr]
                    );
                    console.log(`[DRIP] Scheduled "${c.name}" for ${phone} on ${dateStr}`);
                });
        });
    });
}

async function processScheduledMessages() {
    if (!client.info) return; // Wait for login

    const today = new Date().toISOString().split('T')[0];
    console.log(`[SCHEDULER] Checking for pending messages for ${today}...`);

    db.all(`SELECT * FROM scheduled_messages WHERE status = 'Pending' AND scheduled_date <= ?`, [today], async (err, rows) => {
        if (err) {
            console.error(`[SCHEDULER] DB Error: ${err.message}`);
            return;
        }

        if (rows.length === 0) {
            console.log(`[SCHEDULER] No pending messages.`);
            return;
        }

        console.log(`[SCHEDULER] Found ${rows.length} messages to process.`);

        for (const msg of rows) {
            try {
                // Skip if an agent has claimed this conversation
                const _cp = String(msg.customer_phone).replace(/\D/g,'');
                const _cp10 = _cp.slice(-10);
                const claimedForDrip = await new Promise(resolve =>
                    db.get(`SELECT id FROM conversation_claims WHERE (customer_phone = ? OR customer_phone = ?) AND status = 'Active'`, [_cp, _cp10], (err, row) => resolve(err ? null : row))
                );
                if (claimedForDrip) {
                    console.log(`[SCHEDULER] Skipping ${msg.customer_phone} — conversation is claimed`);
                    continue;
                }

                const jid = msg.customer_phone.includes('@c.us') ? msg.customer_phone : `${msg.customer_phone}@c.us`;

                // Send Media if exists
                if (msg.media_path && fs.existsSync(msg.media_path)) {
                    const media = MessageMedia.fromFilePath(msg.media_path);
                    await client.sendMessage(jid, media);
                }

                // Send Text
                if (msg.message_text) {
                    await client.sendMessage(jid, msg.message_text);
                }

                db.run(`UPDATE scheduled_messages SET status = 'Sent', sent_at = CURRENT_TIMESTAMP WHERE id = ?`, [msg.id]);
                console.log(`[SCHEDULER] Successfully sent to ${msg.customer_phone}`);
                
                // Rate limiting delay
                await new Promise(r => setTimeout(r, 5000));
            } catch (err) {
                console.error(`[SCHEDULER] Failed for ${msg.customer_phone}: ${err.message}`);
                db.run(`UPDATE scheduled_messages SET status = 'Failed', error = ? WHERE id = ?`, [err.message, msg.id]);
            }
        }
    });
}

// Check every 30 minutes
setInterval(processScheduledMessages, 30 * 60 * 1000);

_startWatchdog();
client.initialize().catch(err => {
    const msg = err?.message || String(err);
    if (_isPuppeteerTeardownError(msg)) {
        console.log(`[BOT] Chrome closed during initialize (expected): ${msg.slice(0, 120)}`);
    } else {
        logError('CRASH', err);
    }
    process.exit(1);
});
