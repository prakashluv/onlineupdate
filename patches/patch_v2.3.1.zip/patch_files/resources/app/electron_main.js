const { app, BrowserWindow, screen, dialog, globalShortcut, ipcMain, Menu, shell } = require('electron');
const path = require('path');
const http = require('http');
const fs   = require('fs');

let mainWindow;
const SERVER_PORT = 3000;
const SERVER_URL  = `http://localhost:${SERVER_PORT}`;

// ─── Log to file (no terminal in packaged app) ─────────────────────────────
const logPath = path.join(app.getPath('userData'), 'electron.log');
function log(msg) {
    const line = `[${new Date().toISOString()}] ${msg}\n`;
    try { fs.appendFileSync(logPath, line); } catch(e) {}
    console.log(msg);
}

// ─── Version ────────────────────────────────────────────────────────────────
function getVersion() {
    try {
        const vp = path.join(__dirname, 'version.json');
        return JSON.parse(fs.readFileSync(vp, 'utf8')).version || '2.2.0';
    } catch(_) { return '2.2.0'; }
}

// ─── Persist zoom preference ────────────────────────────────────────────────
const zoomConfigPath = path.join(app.getPath('userData'), 'zoom.json');
function loadZoom() {
    try {
        if (fs.existsSync(zoomConfigPath))
            return JSON.parse(fs.readFileSync(zoomConfigPath, 'utf8')).factor || 1.0;
    } catch(e) {}
    return null;
}
function saveZoom(factor) {
    try { fs.writeFileSync(zoomConfigPath, JSON.stringify({ factor })); } catch(e) {}
}
function getAutoZoom(winWidth) {
    return Math.max(0.8, Math.min(1.1, winWidth / 1920));
}
function setZoom(factor) {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    const clamped = Math.max(0.5, Math.min(2.0, factor));
    mainWindow.webContents.setZoomFactor(clamped);
    mainWindow.webContents.send('zoom-updated', clamped);
    saveZoom(clamped);
}

// ─── IPC: zoom ───────────────────────────────────────────────────────────────
ipcMain.on('zoom-change', (_, delta) => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    setZoom(mainWindow.webContents.getZoomFactor() + delta);
});
ipcMain.on('zoom-reset', () => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    setZoom(getAutoZoom(mainWindow.getBounds().width));
});

// ─── IPC: save module config (from setup wizard) ──────────────────────────
ipcMain.handle('save-module-config', async (_, config) => {
    try {
        const cfgPath = path.join(__dirname, 'modules_config.json');
        fs.writeFileSync(cfgPath, JSON.stringify(config, null, 2));
        return { ok: true };
    } catch(e) {
        return { ok: false, error: e.message };
    }
});

ipcMain.handle('get-module-config', async () => {
    try {
        const cfgPath = path.join(__dirname, 'modules_config.json');
        if (fs.existsSync(cfgPath))
            return { ok: true, config: JSON.parse(fs.readFileSync(cfgPath, 'utf8')) };
        return { ok: true, config: null };
    } catch(e) {
        return { ok: false };
    }
});

// ─── Poll until Express server responds ─────────────────────────────────────
function waitForServer(maxAttempts = 40, interval = 1000) {
    return new Promise((resolve, reject) => {
        let attempts = 0;
        const check = () => {
            attempts++;
            const req = http.get(SERVER_URL, (res) => { res.resume(); resolve(); });
            req.on('error', () => {
                if (attempts >= maxAttempts) reject(new Error(`Server not ready after ${maxAttempts}s`));
                else setTimeout(check, interval);
            });
            req.setTimeout(800, () => {
                req.destroy();
                if (attempts >= maxAttempts) reject(new Error(`Server timeout`));
                else setTimeout(check, interval);
            });
        };
        check();
    });
}

// ─── Navigation Helper ───────────────────────────────────────────────────────
function navigateTo(viewId) {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    mainWindow.webContents.executeJavaScript(
        `if(window.switchNav) window.switchNav(null, null, '${viewId}')`
    );
}
function callDashboard(fn) {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    mainWindow.webContents.executeJavaScript(fn).catch(() => {});
}

// ─── Application Menu ────────────────────────────────────────────────────────
function createAppMenu() {
    const template = [
        {
            label: 'File',
            submenu: [
                {
                    label: 'New Entry…',
                    accelerator: 'CmdOrCtrl+N',
                    click: () => callDashboard(`document.getElementById('view-home')?.scrollIntoView()`)
                },
                { type: 'separator' },
                { label: 'Print…', accelerator: 'CmdOrCtrl+P', role: 'print' },
                { type: 'separator' },
                { role: 'quit', label: 'Exit' }
            ]
        },
        {
            label: 'Edit',
            submenu: [
                { role: 'undo' }, { role: 'redo' }, { type: 'separator' },
                { role: 'cut' }, { role: 'copy' }, { role: 'paste' },
                { role: 'delete' }, { type: 'separator' }, { role: 'selectAll' }
            ]
        },
        {
            label: 'View',
            submenu: [
                { role: 'reload' }, { role: 'forceReload' }, { role: 'toggleDevTools' },
                { type: 'separator' },
                { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' },
                { type: 'separator' },
                { role: 'togglefullscreen' }
            ]
        },
        {
            label: 'Dashboard',
            submenu: [
                { label: '🏠  Overview',           accelerator: 'Alt+Home',  click: () => navigateTo('home') },
                { label: '📊  Analytics',          accelerator: 'Alt+A',     click: () => navigateTo('analytics') },
                { label: '🔔  Notifications',                                click: () => navigateTo('notifications') },
                { type: 'separator' },
                { label: '📥  Download Reports…', accelerator: 'CmdOrCtrl+J', click: () => callDashboard('if(window.openReportsModal) window.openReportsModal()') },
                { type: 'separator' },
                { label: '⚙️  System Diagnostics',                           click: () => navigateTo('diagnostics') },
                { label: '🧪  Test Bench',                                    click: () => navigateTo('testbench') }
            ]
        },
        {
            label: 'CRM',
            submenu: [
                { label: '📑  Leads & Customers',  accelerator: 'Alt+C', click: () => navigateTo('crm') },
                { label: '👥  Team Management',                           click: () => navigateTo('staff') },
                { label: '🗓️  Site Visits',                               click: () => navigateTo('site-visits') },
                { label: '🔗  Affiliate QR Code',                         click: () => navigateTo('linkgen') },
                { label: '📧  Email Hub',                                  click: () => navigateTo('email-hub') }
            ]
        },
        {
            label: 'Inventory',
            submenu: [
                { label: '🏡  Property Inventory',                        click: () => navigateTo('inventory') },
                { label: '✅  Available Sites',                           click: () => navigateTo('available-sites') },
                { label: '🗺️  Visual Maps',                               click: () => navigateTo('visual-maps') },
                { type: 'separator' },
                { label: '📋  Quotation Engine',                          click: () => navigateTo('quotation') },
                { label: '📜  Legal & DTCP Docs',                         click: () => navigateTo('legal-hub') }
            ]
        },
        {
            label: 'Finance',
            submenu: [
                { label: '💰  Expenses',           accelerator: 'Alt+E', click: () => navigateTo('expenses') },
                { label: '🏭  Supplier Database',                         click: () => navigateTo('suppliers') },
                { label: '🏦  Cheque Register',                           click: () => navigateTo('cheques') },
                { label: '🧾  GST Ledger',          accelerator: 'Alt+G', click: () => navigateTo('gst') },
                { type: 'separator' },
                { label: '💼  Payroll & Salary',                          click: () => navigateTo('salaries') },
                { label: '📈  Commissions',                               click: () => navigateTo('commissions') },
                { label: '💳  Payment Hub',                               click: () => navigateTo('payment-hub') },
                { type: 'separator' },
                { label: '🏦  Project Banks',                             click: () => navigateTo('bank-details') },
                { label: '🔄  Loan Management',                           click: () => navigateTo('loan-hub') },
                { label: '⚡  EB Billing',                                click: () => navigateTo('eb-billing') }
            ]
        },
        {
            label: 'Marketing',
            submenu: [
                { label: '🎨  AI Designer',              click: () => navigateTo('marketing-designer') },
                { label: '📢  Broadcasts',               click: () => navigateTo('broadcast') },
                { label: '📣  Social Media Hub',         click: () => navigateTo('social') },
                { label: '🤖  Keyword Rules',            click: () => navigateTo('rules') },
                { type: 'separator' },
                { label: '📈  Ad Tracker (Meta/Google)', click: () => navigateTo('digital-marketing') },
                { label: '🔗  Affiliate QR Code',        click: () => navigateTo('linkgen') }
            ]
        },
        {
            label: 'Bot',
            submenu: [
                { label: '💬  WhatsApp Chats',     click: () => navigateTo('chats') },
                { label: '📡  QR Scan Tracker',    click: () => navigateTo('qr-scans') }
            ]
        },
        {
            label: 'Help',
            submenu: [
                { label: '❓  Help Center',         accelerator: 'F1',           click: () => navigateTo('help') },
                { label: 'ℹ️  About',               accelerator: 'CmdOrCtrl+I',  click: () => navigateTo('about') },
                { type: 'separator' },
                { label: '🔄  Check for Updates',   accelerator: 'CmdOrCtrl+U',  click: () => navigateTo('update') },
                { label: '📁  Open App Data Folder',
                    click: () => { try { shell.openPath(app.getPath('userData')); } catch(_) {} }
                },
                { label: '📋  View Log File',
                    click: () => { try { shell.openPath(logPath); } catch(_) {} }
                },
                { type: 'separator' },
                {
                    label: '🐛  Report an Issue…',
                    accelerator: 'CmdOrCtrl+Shift+R',
                    click: () => callDashboard('if(window.openErrorReport) window.openErrorReport()')
                }
            ]
        }
    ];

    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ─── Loading Screen HTML ────────────────────────────────────────────────────
const LOADING_HTML = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f172a 0%,#1e1b4b 100%);
  display:flex;flex-direction:column;align-items:center;
  justify-content:center;height:100vh;
  font-family:'Segoe UI',sans-serif;color:#fff;overflow:hidden}
.logo{font-size:3rem;margin-bottom:8px}
h1{font-size:1.8rem;font-weight:800;color:#a78bfa;margin-bottom:4px;letter-spacing:-0.02em}
.sub{color:#94a3b8;font-size:0.85rem;margin-bottom:40px}
.ring{width:48px;height:48px;border:4px solid rgba(167,139,250,.15);
  border-top-color:#a78bfa;border-radius:50%;
  animation:spin 0.9s linear infinite}
.msg{margin-top:16px;font-size:0.78rem;color:#64748b}
.tip{position:fixed;bottom:28px;font-size:0.7rem;color:#334155;
  background:rgba(255,255,255,.04);padding:6px 16px;border-radius:20px}
@keyframes spin{to{transform:rotate(360deg)}}
</style></head><body>
<div class="logo">💼</div>
<h1>Property Genius</h1>
<div class="sub">Enterprise Business Suite — Initializing…</div>
<div class="ring"></div>
<div class="msg" id="m">Starting server, please wait…</div>
<div class="tip">Tip: Ctrl+Scroll or Ctrl+= / Ctrl+- to adjust zoom · F1 for Help</div>
<script>
const msgs=['Connecting to database…','Loading modules…','Starting AI engine…','Almost ready…'];
let i=0;setInterval(()=>{const el=document.getElementById('m');if(el)el.textContent=msgs[i++%msgs.length];},2200);
</script></body></html>`;

// ─── Create the Electron window ───────────────────────────────────────────────
function createWindow() {
    const { width, height } = screen.getPrimaryDisplay().workAreaSize;

    mainWindow = new BrowserWindow({
        width, height,
        title: 'Property Genius — Enterprise Suite',
        icon: path.join(__dirname, 'logo', 'DRD-Favicon.png'),
        backgroundColor: '#0f172a',
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            preload: path.join(__dirname, 'preload.js'),
            webSecurity: false,
        }
    });

    mainWindow.maximize();
    mainWindow.loadURL(`data:text/html,${encodeURIComponent(LOADING_HTML)}`);

    waitForServer()
        .then(() => {
            log('[Electron] Server ready — loading dashboard');
            if (!mainWindow || mainWindow.isDestroyed()) return;

            // Check if first-run setup needed
            const cfgPath = path.join(__dirname, 'modules_config.json');
            let needSetup = false;
            try {
                const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
                needSetup = !cfg.configured;
            } catch(_) { needSetup = true; }

            if (needSetup) {
                mainWindow.loadURL(`${SERVER_URL}?view=module-setup`);
            } else {
                mainWindow.loadURL(SERVER_URL);
            }

            mainWindow.webContents.once('did-finish-load', () => {
                const saved = loadZoom();
                const factor = saved !== null ? saved : getAutoZoom(mainWindow.getBounds().width);
                log(`[Zoom] Initial: ${Math.round(factor * 100)}% (${saved !== null ? 'saved' : 'auto'})`);
                setZoom(factor);
            });
        })
        .catch(err => {
            log(`[Electron] ERROR: ${err.message}`);
            dialog.showErrorBox('Property Genius — Startup Failed',
                `Server could not start.\n\nError: ${err.message}\n\nLog: ${logPath}`);
            app.quit();
        });

    mainWindow.on('resize', () => {
        if (!mainWindow?.webContents.getURL().includes('localhost')) return;
        if (loadZoom() === null) setZoom(getAutoZoom(mainWindow.getBounds().width));
    });

    mainWindow.on('closed', () => { mainWindow = null; });
}

// ─── Keyboard shortcuts ───────────────────────────────────────────────────────
function registerShortcuts() {
    globalShortcut.register('CommandOrControl+=',    () => mainWindow && setZoom(mainWindow.webContents.getZoomFactor() + 0.05));
    globalShortcut.register('CommandOrControl+Plus', () => mainWindow && setZoom(mainWindow.webContents.getZoomFactor() + 0.05));
    globalShortcut.register('CommandOrControl+-',    () => mainWindow && setZoom(mainWindow.webContents.getZoomFactor() - 0.05));
    globalShortcut.register('CommandOrControl+0',    () => {
        if (!mainWindow) return;
        setZoom(getAutoZoom(mainWindow.getBounds().width));
        saveZoom(null);
    });
}

// ─── Start Express server ─────────────────────────────────────────────────────
let _currentServerProcess = null;
let _shuttingDown = false;
let _serverCrashCount = 0;

function startServer() {
    const serverPath = path.join(__dirname, 'server.js');
    log(`[Electron] Starting server: ${serverPath}`);

    const sp = require('child_process').spawn(process.execPath, [serverPath], {
        env: {
            ...process.env,
            ELECTRON_RUN_AS_NODE: '1',
            ELECTRON_RUNNING: 'true',
            APP_ROOT: __dirname,
            APP_DATA_DIR: app.isPackaged ? process.resourcesPath : __dirname
        },
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true
    });
    _currentServerProcess = sp;

    sp.stdout.on('data', (d) => log(`[Server] ${d.toString().trim()}`));
    sp.stderr.on('data', (d) => log(`[Server ERR] ${d.toString().trim()}`));

    sp.on('error', (err) => {
        log(`[Electron] FATAL: ${err.message}`);
        if (!_shuttingDown) {
            dialog.showErrorBox('Property Genius — Error', `Failed to start server.\n\n${err.message}`);
            app.quit();
        }
    });

    sp.on('exit', (code) => {
        log(`[Electron] Server exited: ${code}`);
        if (_shuttingDown) return;

        if (code === 42) {
            log('[Electron] Restart signal — relaunching.');
            _shuttingDown = true;
            app.relaunch();
            app.exit(0);
            return;
        }

        _serverCrashCount++;
        if (_serverCrashCount > 3) {
            dialog.showErrorBox('Property Genius — Server Down',
                `Server crashed repeatedly (code ${code}).\n\nLog: ${logPath}\n\nPlease restart the app.`);
            return;
        }
        log(`[Electron] Auto-respawning (${_serverCrashCount}/3) in 2s…`);
        setTimeout(() => {
            startServer();
            if (mainWindow && !mainWindow.isDestroyed()) {
                waitForServer(20).then(() => mainWindow.loadURL(SERVER_URL))
                    .catch(e => log(`Server failed to come back: ${e.message}`));
            }
        }, 2000);
    });
}

// ─── Auto crash reporter ─────────────────────────────────────────────────────
const https = require('https');
function autoReportCrash(source, err) {
    try {
        const pat = (() => {
            try {
                const envPath = path.join(__dirname, '..', '.env');
                if (!fs.existsSync(envPath)) return '';
                const line = fs.readFileSync(envPath, 'utf8').split('\n').find(l => l.startsWith('GITHUB_PAT='));
                return line ? line.split('=').slice(1).join('=').trim() : '';
            } catch (_) { return ''; }
        })();
        if (!pat) return;

        let version = '?';
        try { version = JSON.parse(fs.readFileSync(path.join(__dirname, 'version.json'), 'utf8')).version; } catch (_) {}

        const now = new Date().toISOString();
        const title = `[Auto Crash] ${source} — v${version} — ${now.split('T')[0]}`;
        const body  = `## 💥 Automatic Crash Report\n**Source:** ${source}\n**Time:** ${now}\n**Version:** v${version}\n\n\`\`\`\n${String(err?.stack || err)}\n\`\`\``;

        const bugRepo = (() => {
            try {
                const dataDir = app.isPackaged ? process.resourcesPath : __dirname;
                const s = JSON.parse(fs.readFileSync(path.join(dataDir, 'bot_settings.json'), 'utf8'));
                return (s.bug_report_repo || 'prakashluv/onlineupdate').trim();
            } catch(_) { return 'prakashluv/onlineupdate'; }
        })();
        const payload = JSON.stringify({ title, body, labels: ['bug-report', 'auto-crash'] });
        const req = https.request({
            hostname: 'api.github.com',
            path:     `/repos/${bugRepo}/issues`,
            method:   'POST',
            headers: {
                'Authorization': `token ${pat}`,
                'Content-Type':  'application/json',
                'Content-Length': Buffer.byteLength(payload),
                'User-Agent':    'PropertyGenius-ErrorReporter/1.0',
                'Accept':        'application/vnd.github.v3+json',
            },
        }, (r) => { r.resume(); });
        req.on('error', () => {});
        req.write(payload);
        req.end();
    } catch (_) {}
}

process.on('uncaughtException',  (err) => { log(`[CRASH] uncaughtException: ${err.stack || err}`); autoReportCrash('Electron Main (uncaughtException)', err); });
process.on('unhandledRejection', (err) => { log(`[CRASH] unhandledRejection: ${err}`);              autoReportCrash('Electron Main (unhandledRejection)', err); });

// ─── App lifecycle ────────────────────────────────────────────────────────────
app.whenReady().then(() => {
    log(`[Electron] App ready. v${getVersion()}`);
    createAppMenu();
    startServer();
    createWindow();
    registerShortcuts();
});

app.on('window-all-closed', () => {
    _shuttingDown = true;
    globalShortcut.unregisterAll();
    try { _currentServerProcess && _currentServerProcess.kill(); } catch(_) {}
    app.quit();
});

app.on('activate', () => { if (mainWindow === null) createWindow(); });
app.on('before-quit',  () => { _shuttingDown = true; });
app.on('will-quit',    () => { globalShortcut.unregisterAll(); });
