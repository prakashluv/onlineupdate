const path = require('path');
const fs = require('fs');

// Standardized Path Management for Cross-System Reliability
const isPkg = typeof process.pkg !== 'undefined';
const isElectron = !!process.env.ELECTRON_RUNNING;

const sqlite3 = require('sqlite3').verbose();
const xlsx = require('xlsx');

// Priority: 1. Environment Variable 2. AppData (if packaged/electron) 3. Current Directory
function resolveRootDir() {
    if (process.env.APP_DATA_DIR) return process.env.APP_DATA_DIR;
    
    if (isPkg || isElectron) {
        const appData = process.env.APPDATA || (process.platform === 'darwin' ? process.env.HOME + '/Library/Preferences' : process.env.HOME + '/.local/share');
        const drdData = path.join(appData, 'DRD-Property-Genius');
        if (!fs.existsSync(drdData)) fs.mkdirSync(drdData, { recursive: true });
        return drdData;
    }
    
    return __dirname;
}

const ROOT_DIR = resolveRootDir();
const DB_PATH = path.join(ROOT_DIR, 'database.sqlite');
console.log(`[DB] Using Database at: ${DB_PATH}`);
const db = new sqlite3.Database(DB_PATH);

// Concurrency tuning: WAL allows concurrent reads during writes; busy_timeout
// waits up to 5s on a lock instead of throwing SQLITE_BUSY immediately.
db.serialize(() => {
    db.run("PRAGMA journal_mode = WAL");
    db.run("PRAGMA busy_timeout = 5000");
    db.run("PRAGMA synchronous = NORMAL");
});


function initDB() {
    return new Promise((resolve, reject) => {
        db.serialize(() => {
            // 1. Plots Table (Inventory)
            db.run(`CREATE TABLE IF NOT EXISTS plots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                layout_name TEXT,
                plot_no TEXT,
                type TEXT DEFAULT 'Plot',
                size TEXT,
                size_cent TEXT,
                dimensions TEXT,
                facing TEXT,
                status TEXT,
                price REAL,
                location TEXT,
                assets TEXT,
                gps_location TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);
            db.run(`CREATE UNIQUE INDEX IF NOT EXISTS idx_plot_uniq ON plots (layout_name, plot_no)`);

            // 2. Customers Table (Leads)
            db.run(`CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT UNIQUE,
                name TEXT,
                plot TEXT,
                location TEXT,
                price REAL,
                received_amount REAL DEFAULT 0,
                balance_amount REAL DEFAULT 0,
                doc_no TEXT,
                adhar TEXT,
                loan TEXT,
                loan_details TEXT,
                status TEXT DEFAULT 'New',
                highlighted INTEGER DEFAULT 0,
                lead_score INTEGER DEFAULT 0,
                lead_notes TEXT,
                last_interaction DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 24. SITE VISIT SCHEDULER
            db.run(`CREATE TABLE IF NOT EXISTS site_visits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_phone TEXT,
                layout_name TEXT,
                visit_date DATE,
                visit_time TEXT,
                staff_id TEXT,
                status TEXT DEFAULT 'Scheduled',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 22. CUSTOMER DOCUMENT REGISTRATION & PATTA TRANSFER
            db.run(`CREATE TABLE IF NOT EXISTS customer_registrations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_phone TEXT,
                customer_name TEXT,
                layout_name TEXT,
                plot_no TEXT,
                reg_date DATE,
                doc_no TEXT,
                sro_office TEXT,
                patta_status TEXT DEFAULT 'Not Started',
                patta_applied_date DATE,
                patta_notes TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(customer_phone, layout_name, plot_no)
            )`);

            // 23. QR & AFFILIATE TRACKING
            db.run(`CREATE TABLE IF NOT EXISTS affiliates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                code TEXT UNIQUE,
                phone TEXT,
                type TEXT DEFAULT 'Staff',
                status TEXT DEFAULT 'Active',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            db.run(`CREATE TABLE IF NOT EXISTS qr_scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                layout_name TEXT,
                affiliate_code TEXT,
                ip_address TEXT,
                user_agent TEXT,
                customer_phone TEXT,
                customer_name TEXT,
                customer_message TEXT,
                staff_name TEXT,
                scanned_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);
            // Migrations for existing installations
            ['customer_phone','customer_name','customer_message','staff_name'].forEach(col => {
                db.run(`ALTER TABLE qr_scans ADD COLUMN ${col} TEXT`, () => {});
            });

            db.run(`CREATE TABLE IF NOT EXISTS affiliate_clicks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                staff_id TEXT,
                clicked_at TEXT,
                ip TEXT
            )`);

            // 25. GUIDELINE VALUES (per-layout government reference rate for stamp duty)
            db.run(`CREATE TABLE IF NOT EXISTS guideline_values (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                layout_name TEXT NOT NULL UNIQUE,
                rate_per_sqft REAL NOT NULL DEFAULT 0,
                notes TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // Ensure columns exist if tables were already created
            db.run(`ALTER TABLE project_banks ADD COLUMN upi_id TEXT`, (err) => {});
            db.run(`ALTER TABLE staff ADD COLUMN password_hash TEXT`, (err) => {});
            db.run(`ALTER TABLE staff ADD COLUMN role TEXT DEFAULT 'admin'`, (err) => {});
            db.run(`ALTER TABLE staff ADD COLUMN is_active INTEGER DEFAULT 1`, (err) => {});
            db.run(`ALTER TABLE staff ADD COLUMN reset_token TEXT`, (err) => {});
            db.run(`ALTER TABLE staff ADD COLUMN reset_token_expiry DATETIME`, (err) => {});
            db.run(`ALTER TABLE staff ADD COLUMN last_login DATETIME`, (err) => {});
            // Per-user JSON overrides for module access (null = inherit role defaults)
            db.run(`ALTER TABLE staff ADD COLUMN permissions TEXT`, (err) => {});
            db.run(`ALTER TABLE plots ADD COLUMN type TEXT DEFAULT 'Plot'`, (err) => {});
            db.run(`ALTER TABLE plots ADD COLUMN size_cent TEXT`, (err) => {});
            db.run(`ALTER TABLE plots ADD COLUMN dimensions TEXT`, (err) => {});
            db.run(`ALTER TABLE plots ADD COLUMN assets TEXT`, (err) => {});
            db.run(`ALTER TABLE plots ADD COLUMN gps_location TEXT`, (err) => {});
            db.run(`ALTER TABLE customers ADD COLUMN highlighted INTEGER DEFAULT 0`, (err) => {});
            db.run(`ALTER TABLE customers ADD COLUMN lead_score INTEGER DEFAULT 0`, (err) => {});
            db.run(`ALTER TABLE customers ADD COLUMN lead_notes TEXT`, (err) => {});
            db.run(`ALTER TABLE plots ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP`, (err) => {});
            db.run(`ALTER TABLE customers ADD COLUMN last_interaction DATETIME`, (err) => {});
            db.run(`ALTER TABLE customers ADD COLUMN received_amount REAL DEFAULT 0`, (err) => {});
            db.run(`ALTER TABLE customers ADD COLUMN balance_amount REAL DEFAULT 0`, (err) => {});
            // Unique index prevents duplicate follow-up entries for same phone+date
            db.run(`CREATE UNIQUE INDEX IF NOT EXISTS idx_scheduled_uniq ON scheduled_messages (customer_phone, scheduled_date, message_text)`, (err) => {});

            // 3. Staff Table
            db.run(`CREATE TABLE IF NOT EXISTS staff (
                id TEXT PRIMARY KEY,
                name TEXT,
                dept TEXT,
                phone TEXT,
                email TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 4. AI Usage Tracking
            db.run(`CREATE TABLE IF NOT EXISTS ai_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                model TEXT,
                date TEXT,
                requests INTEGER DEFAULT 1,
                UNIQUE(model, date)
            )`);

            // 5. Activity Logs
            db.run(`CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT,
                message TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 6. Project Bank Details (Existing)
            db.run(`CREATE TABLE IF NOT EXISTS project_banks (
                project_name TEXT PRIMARY KEY,
                acc_name TEXT,
                bank_name TEXT,
                acc_no TEXT,
                ifsc TEXT,
                branch TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 7. LOAN MODULE: Bank Partners
            db.run(`CREATE TABLE IF NOT EXISTS loan_banks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bank_name TEXT,
                contact_person TEXT,
                phone TEXT,
                email TEXT,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 8. LOAN MODULE: Customer Loan Tracking
            db.run(`CREATE TABLE IF NOT EXISTS customer_loans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name TEXT,
                customer_phone TEXT,
                project TEXT,
                plot TEXT,
                loan_amount REAL,
                bank_name TEXT,
                status TEXT DEFAULT 'Pending',
                start_date DATE,
                end_date DATE,
                emi_amount REAL,
                notes TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 10. HR MODULE: Salaries
            db.run(`CREATE TABLE IF NOT EXISTS salaries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                staff_id TEXT,
                month INTEGER,
                year INTEGER,
                base_pay REAL,
                deductions REAL,
                net_pay REAL,
                status TEXT DEFAULT 'Pending',
                paid_at DATETIME,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 11. ACCOUNTS MODULE: Expenses (EB Bill, etc)
            db.run(`CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date DATE,
                category TEXT,
                layout_name TEXT,
                amount REAL,
                description TEXT,
                receipt_path TEXT,
                recorded_by TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);
            db.run(`ALTER TABLE expenses ADD COLUMN layout_name TEXT`, (err) => {});

            // 11. EB Connections Table
            db.run(`CREATE TABLE IF NOT EXISTS eb_connections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service_no TEXT UNIQUE,
                name TEXT,
                region TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 12. DRIP CAMPAIGN MODULE: Templates
            db.run(`CREATE TABLE IF NOT EXISTS drip_campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                days_offset INTEGER,
                message_text TEXT,
                media_path TEXT,
                is_active INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 13. DRIP CAMPAIGN MODULE: Queue
            db.run(`CREATE TABLE IF NOT EXISTS scheduled_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_phone TEXT,
                campaign_id INTEGER,
                message_text TEXT,
                media_path TEXT,
                scheduled_date DATE,
                status TEXT DEFAULT 'Pending',
                sent_at DATETIME,
                error TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 14. LEGAL MODULE: Plot Documents
            db.run(`CREATE TABLE IF NOT EXISTS plot_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plot_id INTEGER,
                agreement_date DATE,
                sale_deed_date DATE,
                registration_number TEXT,
                pending_documents TEXT,
                document_path TEXT,
                approval_status TEXT DEFAULT 'Pending',
                notes TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 14b. Legal Approvals Tracking
            db.run(`CREATE TABLE IF NOT EXISTS legal_approvals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                doc_id INTEGER,
                admin_phone TEXT,
                status TEXT DEFAULT 'Pending',
                sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                responded_at DATETIME,
                FOREIGN KEY(doc_id) REFERENCES plot_documents(id)
            )`);

            // Migration for existing table
            db.run(`ALTER TABLE plot_documents ADD COLUMN document_path TEXT`, (err) => {});

            
            // 16. CRM MODULE: Follow-ups
            db.run(`CREATE TABLE IF NOT EXISTS followups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_phone TEXT,
                staff_name TEXT,
                notes TEXT,
                next_followup DATE,
                status TEXT DEFAULT 'Pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);
            // 15. FINANCE MODULE: Commission Tracking
            db.run(`CREATE TABLE IF NOT EXISTS commissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                staff_id TEXT,
                plot_id INTEGER,
                amount REAL,
                status TEXT DEFAULT 'Pending',
                paid_at DATETIME,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 16. DTCP / Layout Approvals
            db.run(`CREATE TABLE IF NOT EXISTS dtcp_approvals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                layout_name TEXT,
                dtcp_no TEXT,
                approval_date DATE,
                rera_no TEXT,
                rera_expiry DATE,
                patta_status TEXT,
                fmb_status TEXT,
                govt_order TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`, (err) => {
                if (err) reject(err);
            });

            // 17. DIGITAL MARKETING: Campaigns
            db.run(`CREATE TABLE IF NOT EXISTS marketing_campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                layout_name TEXT,
                campaign_name TEXT,
                platform TEXT,
                budget REAL DEFAULT 0,
                status TEXT DEFAULT 'Draft',
                start_date DATE,
                end_date DATE,
                target_audience TEXT,
                objective TEXT,
                notes TEXT,
                leads_generated INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 18. LAYOUT BROCHURES: Pamphlets per Layout
            db.run(`CREATE TABLE IF NOT EXISTS layout_brochures (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                layout_name TEXT NOT NULL,
                file_name TEXT NOT NULL,
                file_type TEXT,
                category TEXT DEFAULT 'Brochure',
                file_path TEXT,
                uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 19. PAYMENT REQUESTS
            db.run(`CREATE TABLE IF NOT EXISTS payment_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT NOT NULL,
                name TEXT,
                amount REAL NOT NULL,
                purpose TEXT,
                layout_name TEXT,
                plot_no TEXT,
                mode TEXT DEFAULT 'upi',
                status TEXT DEFAULT 'Sent',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);
            db.run(`ALTER TABLE payment_requests ADD COLUMN layout_name TEXT`, () => {});
            db.run(`ALTER TABLE payment_requests ADD COLUMN plot_no TEXT`, () => {});

            // 20. EMAIL LOGS
            db.run(`CREATE TABLE IF NOT EXISTS email_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                recipient_email TEXT,
                recipient_name TEXT,
                subject TEXT,
                body TEXT,
                status TEXT DEFAULT 'Sent',
                error TEXT,
                sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 21. NOTIFICATIONS (Staff/MD alerts sent via WhatsApp)
            db.run(`CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                category TEXT DEFAULT 'Task',
                recipient_type TEXT DEFAULT 'selected',
                recipients TEXT,
                scheduled_at DATETIME NOT NULL,
                status TEXT DEFAULT 'Pending',
                sent_at DATETIME,
                error TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 25. SUPPLIER DATABASE
            db.run(`CREATE TABLE IF NOT EXISTS suppliers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT DEFAULT 'Services',
                contact_person TEXT,
                phone TEXT,
                email TEXT,
                address TEXT,
                gstin TEXT,
                bank_name TEXT,
                acc_no TEXT,
                ifsc TEXT,
                acc_holder TEXT,
                layout_name TEXT,
                status TEXT DEFAULT 'Active',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 26. CHEQUE REGISTER
            db.run(`CREATE TABLE IF NOT EXISTS cheques (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cheque_no TEXT NOT NULL,
                date DATE NOT NULL,
                bank_account TEXT,
                payee_name TEXT NOT NULL,
                amount REAL NOT NULL,
                amount_words TEXT,
                linked_type TEXT DEFAULT 'manual',
                linked_id INTEGER,
                layout_name TEXT,
                purpose TEXT,
                status TEXT DEFAULT 'Pending',
                supplier_id INTEGER,
                created_by TEXT,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // Migrations: add supplier link to expenses
            db.run(`ALTER TABLE expenses ADD COLUMN supplier_id INTEGER`, () => {});
            db.run(`ALTER TABLE expenses ADD COLUMN supplier_name TEXT`, () => {});
            // Bot submission tracking
            db.run(`ALTER TABLE expenses ADD COLUMN source TEXT DEFAULT 'dashboard'`, () => {});
            db.run(`ALTER TABLE expenses ADD COLUMN bot_submitted_by TEXT`, () => {});
            db.run(`ALTER TABLE expenses ADD COLUMN notes TEXT`, () => {});
            db.run(`ALTER TABLE gst_ledger ADD COLUMN source TEXT DEFAULT 'dashboard'`, () => {});
            db.run(`ALTER TABLE gst_ledger ADD COLUMN bot_submitted_by TEXT`, () => {});
            // Office documents (general, not tied to a plot)
            db.run(`CREATE TABLE IF NOT EXISTS office_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category TEXT DEFAULT 'Other',
                file_name TEXT,
                file_path TEXT,
                notes TEXT,
                uploaded_by TEXT,
                uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);
            // Ad performance metrics on marketing_campaigns
            db.run(`ALTER TABLE marketing_campaigns ADD COLUMN actual_spend REAL DEFAULT 0`, () => {});
            db.run(`ALTER TABLE marketing_campaigns ADD COLUMN impressions INTEGER DEFAULT 0`, () => {});
            db.run(`ALTER TABLE marketing_campaigns ADD COLUMN clicks INTEGER DEFAULT 0`, () => {});
            db.run(`ALTER TABLE marketing_campaigns ADD COLUMN conversions INTEGER DEFAULT 0`, () => {});
            db.run(`ALTER TABLE marketing_campaigns ADD COLUMN source_tag TEXT`, () => {});
            db.run(`ALTER TABLE marketing_campaigns ADD COLUMN platform_campaign_id TEXT`, () => {});

            // 27. GST RATE MASTER
            db.run(`CREATE TABLE IF NOT EXISTS gst_rates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                description TEXT NOT NULL,
                hsn_sac TEXT,
                category TEXT DEFAULT 'Services',
                gst_rate REAL NOT NULL DEFAULT 18,
                type TEXT DEFAULT 'services',
                is_active INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // 28. GST LEDGER (Inward + Outward)
            db.run(`CREATE TABLE IF NOT EXISTS gst_ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                direction TEXT NOT NULL,
                invoice_no TEXT,
                invoice_date DATE NOT NULL,
                party_name TEXT NOT NULL,
                party_gstin TEXT,
                hsn_sac TEXT,
                description TEXT,
                taxable_value REAL NOT NULL DEFAULT 0,
                gst_rate REAL NOT NULL DEFAULT 0,
                cgst REAL DEFAULT 0,
                sgst REAL DEFAULT 0,
                igst REAL DEFAULT 0,
                total_amount REAL NOT NULL DEFAULT 0,
                is_interstate INTEGER DEFAULT 0,
                is_exempt INTEGER DEFAULT 0,
                linked_type TEXT DEFAULT 'manual',
                linked_id INTEGER,
                project_name TEXT,
                financial_year TEXT,
                month INTEGER,
                year INTEGER,
                status TEXT DEFAULT 'Draft',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // Seed default GST rates if table is empty
            db.get('SELECT COUNT(*) as cnt FROM gst_rates', [], (err, row) => {
                if (!err && row && row.cnt === 0) {
                    const defaults = [
                        ['Land / Plot Sale', '', 'Real Estate', 0, 'exempt'],
                        ['Construction Works (Residential)', '9954', 'Construction', 5, 'services'],
                        ['Construction Works (Commercial)', '9954', 'Construction', 12, 'services'],
                        ['Labour Contractor', '9986', 'Labour', 18, 'services'],
                        ['Marketing / Advertising Agency', '9983', 'Marketing', 18, 'services'],
                        ['Professional Fees (CA / Legal)', '9982', 'Professional', 18, 'services'],
                        ['IT / Software Services', '9983', 'Technology', 18, 'services'],
                        ['Materials – Cement / Steel', '2523', 'Materials', 18, 'goods'],
                        ['Materials – Sand / Gravel', '2505', 'Materials', 5, 'goods'],
                        ['Materials – Bricks', '6901', 'Materials', 5, 'goods'],
                        ['Office Rent', '9972', 'Rent', 18, 'services'],
                        ['EB / Electricity', '', 'Utilities', 0, 'exempt'],
                        ['Printing & Stationery', '4820', 'Office', 12, 'goods'],
                        ['Vehicle Hire / Transport', '9966', 'Transport', 5, 'services'],
                        ['Event / Exhibition', '9996', 'Marketing', 18, 'services'],
                    ];
                    const stmt = db.prepare(`INSERT INTO gst_rates (description, hsn_sac, category, gst_rate, type) VALUES (?, ?, ?, ?, ?)`);
                    defaults.forEach(d => stmt.run(d));
                    stmt.finalize();
                }
            });

            db.run(`SELECT 1`, (err) => {
                if (err) reject(err);
                else resolve();
            });
        });
    });
}

async function migrateFromExcel() {
    console.log('📦 Starting migration from Excel to SQLite...');

    // Migrate Plots
    const PLOTS_EXCEL = path.join(__dirname, 'Plots_Data.xlsx');
    if (fs.existsSync(PLOTS_EXCEL)) {        try {
            const workbook = xlsx.readFile(PLOTS_EXCEL);
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const data = xlsx.utils.sheet_to_json(sheet);
            
            for (const row of data) {
                const sqft = parseFloat(row.Area_SqFt || row.Size || 0);
                const cent = row.Size_Cent || row['Size Cent'] || (sqft > 0 ? (sqft / 435.6).toFixed(2) : '');
                const dims = row.Dimensions || '';
                const lName = (row.Layout_Name || row.Layout || '').trim();
                const pNo = (row.Plot_No || row['Plot No'] || '').trim();
                const gps = (row.GPS_Location || row['GPS Location'] || row.GPS || '').trim();

                if (!lName || !pNo) continue;

                // Use UPSERT-like logic (INSERT OR REPLACE or manual check)
                // SQLite 3.24+ supports ON CONFLICT, but we'll use a safer approach for compatibility
                db.run(`INSERT INTO plots (layout_name, plot_no, size, size_cent, dimensions, facing, status, price, location, gps_location) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(layout_name, plot_no) DO UPDATE SET
                        size=excluded.size, size_cent=excluded.size_cent, dimensions=excluded.dimensions,
                        facing=excluded.facing, status=excluded.status, price=excluded.price,
                        location=excluded.location, gps_location=excluded.gps_location,
                        updated_at=CURRENT_TIMESTAMP`, 
                        [
                            lName, pNo, sqft || '', cent, dims,
                            row.Facing || '', row.Status || 'Available', 
                            row.Total_Price || row.Price || 0, row.Location || '', gps
                        ]);
            }
            console.log(`✅ Migrated ${data.length} plots.`);
        } catch (e) { console.error('Plots migration failed:', e); }
    }

    // Migrate Customers & Staff from Master DB
    const MASTER_EXCEL = path.join(__dirname, 'Master_Enterprise_DB.xlsx');
    if (fs.existsSync(MASTER_EXCEL)) {
        try {
            const workbook = xlsx.readFile(MASTER_EXCEL);
            
            // Customers (Leads)
            if (workbook.SheetNames.includes('Customers')) {
                const cData = xlsx.utils.sheet_to_json(workbook.Sheets['Customers']);
                for (const row of cData) {
                    db.run(`INSERT OR IGNORE INTO customers (phone, name, plot, location, price, doc_no, adhar, loan, loan_details) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
                            [row.Phone || '', row.Name || '', row.Plot || '', row.Location || '', row.Price || 0, row.DocNo || '', row.Adhar || '', row.Loan || 'No', row.LoanDetails || '']);
                }
                console.log(`✅ Migrated ${cData.length} customers.`);
            }

            // Staff
            if (workbook.SheetNames.includes('Employees')) {
                const sData = xlsx.utils.sheet_to_json(workbook.Sheets['Employees']);
                for (const row of sData) {
                    db.run(`INSERT OR IGNORE INTO staff (id, name, dept, phone, email) 
                            VALUES (?, ?, ?, ?, ?)`, 
                            [row.Staff_ID || '', row.Name || '', row.Department || '', row.Phone || '', row.Email || '']);
                }
                console.log(`✅ Migrated ${sData.length} staff members.`);
            }
        } catch (e) { console.error('Master DB migration failed:', e); }
    }
}

module.exports = { db, initDB, migrateFromExcel };
